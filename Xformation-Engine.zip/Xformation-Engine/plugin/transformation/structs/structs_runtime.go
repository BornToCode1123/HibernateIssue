package structs

import (
	"encoding/json"
	"errors"
	"os"
	"strconv"
	"strings"

	"github.com/thedevsaddam/gojsonq/v2"
)

const (
	// rule types
	RelationalType = "relational"
	LogicalType    = "logical"
	//expression types
	VariableType    = "variable"
	LiteralType     = "literal"
	EnvironmentType = "environment"
	FunctionType    = "function"
	ExpressionType  = "expression"
	KeywordType     = "keyword"
	DeclareType     = "declare"
	LocalType       = "local"
	//config types
	TransformType = "transform"
	FilterType    = "filter"
	PayloadError  = "payloadError"
)

type StatementDetails struct {
	StatementPath string
	TransformType string
	ConfigType    string
}

type Response struct {
	Headers    map[string]interface{}
	Error      map[string]interface{}
	Body       map[string]interface{}
	TimeTaken  float64
	StatusCode string
}

type JSONQData struct {
	TransformedData      map[string]interface{}
	ExtractedData        map[string]interface{}
	DeletedData          map[string]interface{}
	LocalData            map[string]interface{}
	ErrorConfig          Errors
	Jqdata               *gojsonq.JSONQ
	ShouldReset          bool
	JsonIgnoreProperty   bool
	JsonIgnoreAliasValue interface{}
	ErrorData            *[]TransformError
	IsExceptionHandled   *bool
}

type HostProperties struct {
	OriginMethod          string                `json:"method"`
	Endpoint              string                `json:"endpoint"`
	Timeout               float64               `json:"timeout"`
	ProjectId             float64               `json:"projectId"`
	HostConnectionDetails HostConnectionDetails `json:"hostConnectionDetails"`
}

type ErrorData struct {
	Code            string `json:"code"`
	Message         string `json:"message"`
	SubCode         string `json:"subCode"`
	DetailedMessage string `json:"detailedMessage"`
}

func (jd JSONQData) ResetJsonqData() {
	if jd.ShouldReset {
		jd.Jqdata.Reset()
	}
}

type ExpressionResult struct {
	EType  string
	Vtype  string
	Evalue interface{}
}

type ConfigResult struct {
	TransformedData map[string]interface{}
	ExtractedData   map[string]interface{}
	DeletedData     map[string]interface{}
	Results         map[string]map[string]interface{}
	Errors          []TransformError
}

type StatementResult struct {
	Lhs ExpressionResult
	Rhs ExpressionResult
}

type Log struct {
	Level    string       `json:"level"`
	Messages []Expression `json:"messages"`
}

type StatementsResult struct {
	StatementResults []StatementResult
	TransFormError   TransformError
}

type KhazaamOperation struct {
	Operation string                 `json:"operation"`
	Spec      map[string]interface{} `json:"spec"`
}

type TransformResult struct {
	Result    map[string]interface{}
	Errors    []TransformError
	Mandatory bool
}

type TransformError struct {
	Code            string      `json:"code"`
	Subcode         string      `json:"subCode"`
	Message         string      `json:"message"`
	Detailedmessage interface{} `json:"detailedMessage"`
}

type StatementError struct {
	Code    string `json:"code"`
	Message string `json:"message"`
}

type JSONQueryParam struct {
	Lhs      string
	Operator string
	Rhs      interface{}
}

// type Plugin struct {
// 	Init                  map[string]interface{} `json:"init"`
// 	RequestBodyasResponse bool                   `json:"requestBodyAsResponse"`
// 	Request               map[string]interface{} `json:"request"`
// 	Response              map[string]interface{} `json:"response"`
// 	HostProperties        HostProperties         `json:"hostProperties"`
// }

type Plugin struct {
	Init                  *Config        `json:"init"`
	RequestBodyasResponse bool           `json:"requestBodyAsResponse"`
	Request               Config         `json:"request"`
	Response              Config         `json:"response"`
	HostProperties        HostProperties `json:"hostProperties"`
}

type JsonConf struct {
	Config Config `json:"config"`
}

type Config struct {
	Id                interface{} `json:"id"`
	Version           interface{} `json:"version"`
	EType             string      `json:"@type"`
	HolderConfig      interface{}
	ContentInputType  string                 `json:"contentInputType"`
	ContentOutputType string                 `json:"contentOutputType"`
	IgnoreNullFields  bool                   `json:"ignoreNullFields"`
	Errors            Errors                 `json:"errors"`
	Debug             bool                   `json:"debug"`
	JsonSchema        map[string]interface{} `json:"jsonSchema"`
	Headers           map[string]interface{} `json:"headers"`
}

type Errors struct {
	Id                   interface{} `json:"id"`
	Statements           []Statement `json:"statements"`
	JsonIgnoreProperty   interface{} `json:"jsonIgnoreProperty"`
	JsonIgnoreAliasValue interface{} `json:"jsonIgnoreAliasValue"`
}

type Transform struct {
	Id                   interface{} `json:"id"`
	Name                 string      `json:"name"`
	Statements           []Statement `json:"statements"`
	JsonIgnoreProperty   interface{} `json:"jsonIgnoreProperty"`
	JsonIgnoreAliasValue interface{} `json:"jsonIgnoreAliasValue"`
}

type Section struct {
	Id                   interface{} `json:"id"`
	Name                 string      `json:"name"`
	JsonIgnoreProperty   interface{} `json:"jsonIgnoreProperty"`
	JsonIgnoreAliasValue interface{} `json:"jsonIgnoreAliasValue"`
	Statements           []Statement `json:"statements"`
}

type Statement struct {
	Id         interface{} `json:"id"`
	EType      string      `json:"@type"`
	Name       string      `json:"name"`
	Condition  Condition   `json:"condition"`
	Assignment Assignment  `json:"assignment"`
	Log        Log         `json:"log"`
	Error      Error       `json:"error"`
	Statements []Statement
	Section    Section     `json:"section"`
	Fork       Fork        `json:"fork"`
	Mandatory  interface{} `json:"mandatory"`
	Success    Success     `json:"success"`
	Failure    Failure     `json:"failure"`
}

type Error struct {
	Id                   interface{} `json:"id"`
	Name                 string      `json:"name"`
	JsonIgnoreProperty   interface{} `json:"jsonIgnoreProperty"`
	JsonIgnoreAliasValue interface{} `json:"jsonIgnoreAliasValue"`
	Statements           []Statement `json:"statements"`
}

type Success struct {
	Id                   interface{} `json:"id"`
	Name                 string      `json:"name"`
	JsonIgnoreProperty   interface{} `json:"jsonIgnoreProperty"`
	JsonIgnoreAliasValue interface{} `json:"jsonIgnoreAliasValue"`
	Statements           []Statement `json:"statements"`
}

type Fork struct {
	Id         interface{} `json:"id"`
	Name       string      `json:"name"`
	Statements []Statement `json:"statements"`
}

type Failure struct {
	Id                   interface{} `json:"id"`
	Name                 string      `json:"name"`
	JsonIgnoreProperty   interface{} `json:"jsonIgnoreProperty"`
	JsonIgnoreAliasValue interface{} `json:"jsonIgnoreAliasValue"`
	Statements           []Statement `json:"statements"`
}

type Assignment struct {
	Lhs      Expression             `json:"lhs"`
	Rhs      Expression             `json:"rhs"`
	Operator map[string]interface{} `json:"operator"`
}

type Filter struct {
	Id        interface{} `json:"id"`
	EType     string      `json:"@type"`
	Condition Condition   `json:"condition"`
}

type Condition struct {
	EType string `json:"@type"`
	VType string `json:"type"`
	Rules []Rule `json:"rules"`
}

type RelationalRule struct {
	EType    string     `json:"@type"`
	Lhs      Expression `json:"lhs"`
	Rhs      Expression `json:"rhs"`
	Operator Operator   `json:"operator"`
}

type Rule struct {
	EType      string `json:"@type"`
	RuleHolder interface{}
}

type Expression struct {
	EType  string `json:"@type"`
	Holder interface{}
}

type Literal struct {
	EType     string      `json:"@type"`
	DataValue interface{} `json:"dataValue"`
	DataType  string      `json:"dataType"`
}
type Environment struct {
	EType     string      `json:"@type"`
	DataValue interface{} `json:"dataValue"`
	DataType  string      `json:"dataType"`
}

type Variable struct {
	EType     string      `json:"@type"`
	DataValue interface{} `json:"dataValue"`
	DataType  string      `json:"dataType"`
}

type Declare struct {
	EType     string      `json:"@type"`
	DataValue interface{} `json:"dataValue"`
	DataType  string      `json:"dataType"`
}

type Local struct {
	EType     string      `json:"@type"`
	DataValue interface{} `json:"dataValue"`
	DataType  string      `json:"dataType"`
}

type Function struct {
	EType             string                 `json:"@type"`
	FunctionName      string                 `json:"functionName"`
	FunctionArguments map[string]interface{} `json:"functionArguments"`
	Filter            Filter                 `json:"filter"`
	DataType          string                 `json:"dataType"`
}

type Keyword struct {
	EType            string      `json:"@type"`
	DataValue        interface{} `json:"dataValue"`
	DataType         string      `json:"dataType"`
	KeywordArguments interface{} `json:"keywordArguments"`
	Filter           Filter      `json:"filter"`
}

type HostConnectionDetails struct {
	Host                    string                 `json:"host"`
	DynamicUrl              string                 `json:"dynamicUrl"`
	Body                    string                 `json:"body"`
	URLPattern              string                 `json:"urlPattern"`
	RetriggerCount          float64                `json:"retriggerCount"`
	ContentInputType        string                 `json:"contentInputType"`
	ContentOutputType       string                 `json:"contentOutputType"`
	Headers                 string                 `json:"headers"`
	MethodType              string                 `json:"methodType"`
	ConnectionTimeout       float64                `json:"connectionTimeout"`
	ReadTimeout             float64                `json:"readTimeout"`
	AllowInsecureConnection bool                   `json:"allowInsecureConnection"`
	CustomHeaders           map[string]interface{} `json:"customHeaders"`
	JsonSchema              map[string]interface{} `json:"jsonSchema"`
	IsHostCall              bool
	RequestBody             string
	RequestParams           map[string]interface{}
	IsDataSetOrFormTemplate bool
	FormTemplateType        string `json:"formTemplateType"`
}

type Operator struct {
	ActualValue string `json:"actualValue"`
}

type ArithExpression struct {
	EType     string      `json:"@type"`
	Structure Arithematic `json:"structure"`
	DataType  string      `json:"dataType"`
}

type Arithematic struct {
	EType     string       `json:"@type"`
	DataType  string       `json:"dataType"`
	Variables []Expression `json:"variables"`
}

// --------------

type Endpoint struct {
	Endpoint string    `json:"endpoint"`
	Timeout  string    `json:"timeout"`
	Backend  []Backend `json:"backend"`
}

type Backend struct {
	ExtraConfig ExtraConfig `json:"extra_config"`
	UrlPattern  string      `json:"url_pattern"`
	Host        []string    `json:"host"`
	Method      string      `json:"method"`
}

type ExtraConfig struct {
	Executor Executor `json:"github.com/devopsfaith/krakend/transport/http/client/executor"`
}

type Executor struct {
	TransFormPlugin Plugin `json:"jocata_transform_plugin"`
}

//-------------

type Exp struct {
	EType  string `json:"@type"`
	holder interface{}
}

type Rul struct {
	EType      string `json:"@type"`
	RuleHolder interface{}
}

func (r *Rule) UnmarshalJSON(data []byte) error {
	var res Rul
	if err := json.Unmarshal(data, &res); err != nil {
		return err
	}

	r.EType = res.EType
	switch r.EType {

	case RelationalType:
		var relation RelationalRule
		json.Unmarshal(data, &relation)
		r.RuleHolder = relation
		if relation.EType == "" && relation.Lhs.EType == "" && relation.Rhs.EType == "" && relation.Operator.ActualValue == "" {
			return errors.New("Mandatory keys in the relational rule are missing")
		}

	case LogicalType:
		var logical Condition
		json.Unmarshal(data, &logical)
		r.RuleHolder = logical

		if logical.EType == "" && logical.VType == "" {
			return errors.New("Mandatory keys in the logical rule are missing")
		}
	default:
		return nil
	}
	return nil
}

func (e *Expression) UnmarshalJSON(data []byte) error {
	var res Exp

	if err := json.Unmarshal(data, &res); err != nil {
		return err
	}

	e.EType = res.EType

	switch e.EType {
	case VariableType:
		var variable Variable
		json.Unmarshal(data, &variable)
		e.Holder = variable
		if variable.EType == "" && variable.DataType == "" && variable.DataValue == "" {
			return errors.New("Mandatory keys in the variable expression are missing")
		}

	case LiteralType:
		var literal Literal
		json.Unmarshal(data, &literal)
		e.Holder = literal
		if literal.EType == "" && literal.DataType == "" && literal.DataValue == "" {
			return errors.New("Mandatory keys in the literal expression are missing")
		}

	case EnvironmentType:
		var environment Environment
		json.Unmarshal(data, &environment)
		e.Holder = environment
		if environment.EType == "" && environment.DataType == "" && environment.DataValue == "" {
			return errors.New("mandatory keys in the environment expression are missing")
		}

	case FunctionType:
		var function Function
		json.Unmarshal(data, &function)
		e.Holder = function
		if function.EType == "" && function.DataType == "" && function.FunctionName == "" && function.FunctionArguments == nil {
			return errors.New("Mandatory keys in the function expression are missing")
		}

	case ExpressionType:
		var arithExp ArithExpression
		json.Unmarshal(data, &arithExp)
		e.Holder = arithExp
		if arithExp.EType == "" && arithExp.DataType == "" && e.Holder == nil {
			return errors.New("Mandatory keys in the Arithematic expression are missing")
		}

	case KeywordType:
		var keyword Keyword
		json.Unmarshal(data, &keyword)
		e.Holder = keyword
		if keyword.EType == "" && keyword.DataType == "" && keyword.DataValue == nil {
			return errors.New("Mandatory keys in the keyword expression are missing")
		}

	case DeclareType:
		var declare Declare
		json.Unmarshal(data, &declare)
		e.Holder = declare
		if declare.EType == "" && declare.DataType == "" && declare.DataValue == "" {
			return errors.New("Mandatory keys in the declare expression are missing")
		}
	case LocalType:
		var local Local
		json.Unmarshal(data, &local)
		e.Holder = local
		if local.EType == "" && local.DataType == "" && local.DataValue == "" {
			return errors.New("Mandatory keys in the local expression are missing")
		}
	default:
		return nil
	}
	return nil
}

func (c *Config) UnmarshalJSON(data []byte) error {
	var res map[string]interface{}

	if err := json.Unmarshal(data, &res); err != nil {
		return err
	}

	if res["transform"] == nil {
		return nil
	}

	if res["@type"] == nil {
		return errors.New("@type is mandatory in config")
	}

	if res["jsonSchema"] != nil {
		c.JsonSchema = res["jsonSchema"].(map[string]interface{})
	}

	if res["contentInputType"] == nil {
		c.ContentInputType = "json"
	} else {
		c.ContentInputType = res["contentInputType"].(string)
	}

	if res["contentOutputType"] == nil {
		c.ContentOutputType = "json"
	} else {
		c.ContentOutputType = res["contentOutputType"].(string)
	}
	if res["ignoreNullFields"] == nil {
		c.IgnoreNullFields = false
	} else {
		c.IgnoreNullFields = res["ignoreNullFields"].(bool)
	}

	if res["debug"] == nil {
		c.Debug = false
	} else {
		c.Debug = res["debug"].(bool)
	}

	c.EType = res["@type"].(string)
	c.Id = res["id"]

	if res["errors"] != nil {
		var errors Errors
		aa, _ := json.Marshal(res["errors"])
		json.Unmarshal(aa, &errors)
		c.Errors = errors
	}

	if res["headers"] != nil {
		c.Headers = res["headers"].(map[string]interface{})
	}
	var transform Transform
	aa, _ := json.Marshal(res["transform"])
	json.Unmarshal(aa, &transform)
	c.HolderConfig = transform

	switch os.Getenv("UI_BUILDER_ENABLED") {
	case "true":
		c.HolderConfig = transform
	default:
		c.Version = res["version"]
		if res["version"] == nil || res["transform"] == nil {
			return errors.New("version or transform are required as the @type is transform ")
		}

		if transform.Id == "" && transform.Name == "" && transform.Statements == nil {
			return errors.New("mandatory keys in the transform are missing")
		}
	}
	return nil
}

func (hcd *HostConnectionDetails) UnmarshalJSON(data []byte) error {

	var raw map[string]interface{}
	if err := json.Unmarshal(data, &raw); err != nil {
		return err
	}

	hcd.Host = getString(raw, "host")
	hcd.DynamicUrl = getString(raw, "dynamicUrl")
	hcd.Body = getBodyAsString(raw, "body")
	hcd.URLPattern = getString(raw, "urlPattern")
	hcd.RetriggerCount = ParseFloat(raw["retriggerCount"])
	hcd.ContentInputType = getString(raw, "contentInputType")
	hcd.ContentOutputType = getString(raw, "contentOutputType")
	hcd.Headers = getString(raw, "headers")
	hcd.MethodType = strings.ToUpper(getString(raw, "methodType"))
	hcd.ConnectionTimeout = ParseFloat(raw["connectionTimeout"])
	hcd.ReadTimeout = ParseFloat(raw["readTimeout"])
	hcd.AllowInsecureConnection = getBool(raw, "allowInsecureConnection")
	hcd.CustomHeaders = getMap(raw, "customHeaders")
	hcd.JsonSchema = getMap(raw, "jsonSchema")
	hcd.FormTemplateType = getString(raw, "formTemplateType")

	return nil
}

func (hp *HostProperties) UnmarshalJSON(data []byte) error {

	var raw map[string]interface{}
	if err := json.Unmarshal(data, &raw); err != nil {
		return err
	}

	if raw["hostConnectionDetails"] != nil {
		var hostConnectionDetails HostConnectionDetails
		aa, _ := json.Marshal(raw["hostConnectionDetails"])
		json.Unmarshal(aa, &hostConnectionDetails)
		hp.HostConnectionDetails = hostConnectionDetails
	}

	hp.Endpoint = getString(raw, "endpoint")
	hp.OriginMethod = getString(raw, "method")
	hp.ProjectId = ParseFloat(raw["projectId"])
	if timeout := ParseFloat(raw["timeout"]); timeout == 0 {
		hp.Timeout = 3
	} else {
		hp.Timeout = timeout
	}

	return nil
}

func getString(m map[string]interface{}, key string) string {
	if val, ok := m[key].(string); ok {
		return val
	}
	return ""
}

func getBodyAsString(m map[string]interface{}, key string) string {
	if val, ok := m[key].(string); ok {
		return val
	}
	if val, ok := m[key].(map[string]interface{}); ok {
		jsonBytes, _ := json.Marshal(val)
		return string(jsonBytes)
	}
	return ""
}

func getMap(m map[string]interface{}, key string) map[string]interface{} {
	if val, ok := m[key].(map[string]interface{}); ok {
		return val
	}
	return nil
}

func ParseFloat(value interface{}) float64 {
	switch v := value.(type) {
	case string:
		v = strings.TrimSuffix(v, "s")
		if f, err := strconv.ParseFloat(v, 64); err == nil {
			return f
		}
	case float64:
		return v
	case int:
		return float64(v)
	}
	return 0
}

func getBool(m map[string]interface{}, key string) bool {
	if val, ok := m[key].(bool); ok {
		return val
	}
	return false
}

type ProcessExpression func(
	expr Expression,
	data JSONQData,
	fn ProcessInnerTransform, statementPath string) (ExpressionResult, TransformError)
type ProcessInnerTransform func(
	transConfig Transform,
	data JSONQData,
	arr *[]interface{},
	statementDetails StatementDetails) TransformError
type ProcessCondition func(
	cs Condition,
	data JSONQData,
	fn ProcessInnerTransform,
	statementPath string) (bool, TransformError)

type ProcessRules func(
	logicalType string,
	rules []Rule,
	data JSONQData,
	innerTran ProcessInnerTransform,
	statementPath string) (bool, TransformError)

type TransformStatements func(
	s Transform,
	data JSONQData,
	statementDetails StatementDetails) StatementsResult
