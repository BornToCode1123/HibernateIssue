package main

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	c "jocata_transform_plugin/constants"
	"jocata_transform_plugin/handler"
	logger "jocata_transform_plugin/log"
	par "jocata_transform_plugin/parse"
	"jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"net/http"
	"os"
	"time"
)

// ClientRegisterer is the symbol the plugin loader will try to load. It must implement the RegisterClient interface
var ClientRegisterer = registerer("jocata_transform_plugin")

type registerer string

func (registerer) RegisterLogger(v interface{}) {

	logger.WriteLoggerConfigurationFile()
	userLogPath := os.Getenv("USER_LOG_PATH")
	logger.Log.LoadJsonConfiguration(userLogPath)
	logger.Log.Debug(nil, fmt.Sprintf("[PLUGIN: %s] logger.Log loaded", ClientRegisterer))
}

func (r registerer) RegisterClients(f func(
	name string,
	handler func(context.Context, map[string]interface{}) (http.Handler, error),
)) {
	f(string(r), r.registerClients)
}

func (r registerer) registerClients(_ context.Context, extra map[string]interface{}) (http.Handler, error) {
	// check the passed configuration and initialize the plugin

	name, ok := extra["name"].(string)
	if !ok {
		return nil, errors.New("wrong config")
	}
	if name != string(r) {
		return nil, fmt.Errorf("unknown register %s", name)
	}

	executor, err := par.ParseEndpoint(nil, extra)
	if err != nil {
		return nil, fmt.Errorf("error occured while parsing the endpoint %s", err)
	}

	initMap, updatedStatements := utils.GetObjectAndMapListHardCodedData(executor.TransFormPlugin)

	if len(updatedStatements) != 0 {
		if transform, ok := executor.TransFormPlugin.Init.HolderConfig.(structs.Transform); ok {
			transform.Statements = updatedStatements
			executor.TransFormPlugin.Init.HolderConfig = transform
		}
	}

	logger.Log.Debug(nil, "The plugin is jocata_transform_plugin is injected")
	utils.PopulateErrorMap()

	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {

		hostProperties := executor.TransFormPlugin.HostProperties
		ctx, cancel := context.WithTimeout(context.Background(), time.Duration(hostProperties.Timeout)*time.Second-100*time.Millisecond)
		defer cancel()
		done := make(chan error, 1)
		var localMap = make(map[string]interface{})
		localMap[c.TRACE_ID] = req.Header.Get(c.HEADER_TRACE_ID)
		localMap[c.SPAN_ID] = "f97eada54684c527"

		go func() {
			done <- handler.PluginHandler(w, req, executor.TransFormPlugin, localMap, &initMap)
		}()

		select {
		case <-ctx.Done():
			tErrBytes := par.PopulateTransformErrorAndConvertToBytes(localMap, "1005", c.SYSTEM_ADMIN_ERROR_MESSAGE, "json")
			w.Header().Set(`Content-Type`, `application/json`)
			w.WriteHeader(http.StatusGatewayTimeout)
			timeoutMessage := fmt.Sprintf("trasformation should be processed in {%v} seconds, but it took more than the given, Hence it resulted in timeout error", hostProperties.Timeout)
			logger.Log.Info(localMap, timeoutMessage)
			io.Copy(w, bytes.NewBuffer(tErrBytes))
		case <-done:
		}

	}), nil
}

func main() {}
