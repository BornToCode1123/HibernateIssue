package constants

const (
	ENIGINE_VERSION         = "V1.3.12"
	OBJECT_SEPARATOR        = "."
	LOCAL_SEPARATOR         = "@"
	LOCAL_OBJECT_IDENTIFIER = "@local"

	// Config Types
	TRANSFORM = "transform"
	ERRORS    = "errors"

	// Config Properties :
	REQUEST                  = "request"
	RESPONSE                 = "response"
	ID                       = "id"
	REQUEST_BODY_AS_RESPONSE = "requestBodyAsResponse"

	// Statement Types
	ASSIGNMENT_STATEMENT  = "AssignmentStatement"
	CONDITIONAL_STATEMENT = "ConditionalStatement"
	SECTIONAL_STATEMENT   = "SectionalStatement"
	EEROR_STATEMENT       = "ErrorStatement"
	LOG_STATEMENT         = "LogStatement"
	FORK_STATEMENT        = "ForkStatement"

	// Expression Types
	VARIABLE    = "variable"
	LITERAL     = "literal"
	FUNCTION    = "function"
	KEYWORD     = "keyword"
	DECLARE     = "declare"
	LOCAL       = "local"
	EXPRESSION  = "expression"
	ENVIRONMENT = "environment"

	// Data types & Expression types:
	LIST         = "list"
	MAP          = "map"
	TEXT         = "text"
	NUMBER       = "number"
	BOOLEAN      = "boolean"
	DATE         = "date"
	DATE_TIME    = "datetime"
	CURRENCY     = "currency"
	NONE         = "none"
	STATEMENT_ID = "statementId"
	VALUE        = "value"

	// local properties:
	RESPONSE_HEADERS = "responseHeaders"

	// Operators :
	CONTAINS          = "contains"
	NOT_CONTAINS      = "nContains"
	EQUAL_IGNORE_CASE = "equalIgnoreCase"
	EQUALS            = "=="
	NOT_EQUALS        = "!="
	ADDITION          = "+"
	SUBSTRACTION      = "-"
	MULTIPILICATION   = "*"

	// Messages
	SYSTEM_ADMIN_ERROR_MESSAGE = "Please contact system admin."

	// Contents :
	JSON = "json"
	XML  = "xml"

	// API Rest call Request properties :
	CONTENT_INPUT_TYPE  = "contentInputType"
	CONTENT_OUTPUT_TYPE = "contentOutputType"
	GET                 = "GET"
	POST                = "POST"

	// API Restcall Response properties :
	HEADERS     = "headers"
	STATUS_CODE = "statusCode"
	ERROR       = "error"
	BODY        = "body"
	TIME_TAKEN  = "timeTaken"

	Dataset_url = `/APIGateway/dlp/get-data-by-ds-Config`

	FormTemplate_Save_Url = `/APIGateway/dlp/saveGenericRequest`
	FormTemplate_Get_Url  = `/APIGateway/dlp/getFormDataByTemplate`
	FETCH                 = `fetch`

	INIT   = `init`
	VALUES = `values`

	DAY    = `day`
	MONTH  = `month`
	YEAR   = `year`
	FORMAT = `format`

	TRUE  = "true"
	FALSE = "false"

	CODE             = "code"
	MESSAGE          = "message"
	SUB_CODE         = "subCode"
	DETAILED_MESSAGE = "detailedMessage"
	TRACE            = "trace"

	TRACE_ID         = "trace-Id"
	SPAN_ID          = "Span-Id"
	HEADER_TRACE_ID  = "X-B3-Traceid"
	SUM              = "sum"
	MIN              = "min"
	MAX              = "max"
	AVG              = "avg"
	COUNT            = "count"
	IS_EMPTY         = "isEmpty"
	FORM_URL_ENCODED = `form-urlencoded`
	FLAT_JSON        = `flatJson`
)
