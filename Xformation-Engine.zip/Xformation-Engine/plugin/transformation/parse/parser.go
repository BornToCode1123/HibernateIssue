package parse

import (
	"encoding/json"
	"errors"
	"fmt"
	c "jocata_transform_plugin/constants"
	"jocata_transform_plugin/flatten"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"net/url"

	"strconv"
	"strings"

	mxj "github.com/clbanning/mxj"
)

func ParseEndpoint(localMap, EndpointConfig map[string]interface{}) (rs.Executor, error) {

	configJson, _ := json.Marshal(EndpointConfig)
	transData := []byte(configJson)
	var EndpointConf rs.Executor
	err := json.Unmarshal(transData, &EndpointConf)
	if err != nil {
		logger.Log.Error(localMap, "Error while  parsing configuration %v", EndpointConfig)
		return rs.Executor{}, errors.New("Error while parsing configuration" + err.Error())
	}

	return EndpointConf, nil
}

func ParseConfig(localMap map[string]interface{}, transformReqConfig []byte) (rs.Config, error) {

	// configJson, _ := json.Marshal(transformReqConfig)
	// transData := []byte(configJson)
	var jsonConf rs.Config
	err := json.Unmarshal(transformReqConfig, &jsonConf)
	if err != nil {
		logger.Log.Error(localMap, "Error while  parsing configuration %v", transformReqConfig)
		return rs.Config{}, errors.New("Error while parsing configuration" + err.Error())
	}
	return jsonConf, nil
}

func ParseInput(localMap map[string]interface{}, inputType string, payloadInput []byte) (map[string]interface{}, error) {
	logger.Log.Debug(localMap, "processing  payload input type %v", inputType)
	switch inputType {
	case c.TEXT:

		var myMap = make(map[string]interface{})
		myMap["encryptedPayload"] = string(payloadInput)
		return myMap, nil

	case c.JSON:
		m, err := mxj.NewMapJson(payloadInput)
		if utils.CheckSeqData(m) {
			m = removeSeqFromMap(m)
		}

		if err != nil {
			logger.Log.Error(localMap, "Error while parsing json payload %v", string(payloadInput))
			return nil, errors.New("Error while parsing json payload " + err.Error())
		}
		return m.Old(), nil

	case c.XML:
		dat := string(payloadInput)
		subString := dat
		if strings.HasPrefix(dat, "<?xml") {
			index := strings.Index(dat, "?>")
			subString = dat[index+2:]
		}

		var finalData string
		dat = checkCDATA(subString, finalData)

		m, err := mxj.NewMapXmlSeq([]byte(dat))
		if err != nil {
			logger.Log.Error(localMap, "Error while parsing xml payload %v", string(payloadInput))
			return nil, errors.New("Error while parsing xml payload" + err.Error())
		}
		return m.Old(), nil

	case c.FLAT_JSON:
		payloadMap := make(map[string]interface{})
		err := json.Unmarshal(payloadInput, &payloadMap)
		if err != nil {
			return nil, err
		}
		unfltJson := flatten.UnFlatten(payloadMap)
		return unfltJson, nil
	case c.FORM_URL_ENCODED:
		payloadMap := make(map[string]interface{})
		values, _ := url.ParseQuery(string(payloadInput))
		for key, value := range values {
			payloadMap[key] = value[0]
		}
		return payloadMap, nil

	default:
		return nil, errors.New("unknown output type " + inputType)
	}
}

func ParseOutput(localMap map[string]interface{}, outputType string, result map[string]interface{}) ([]byte, error) {
	logger.Log.Debug(localMap, "processing  payload output type %v", outputType)
	switch outputType {
	case c.TEXT:
		str := result["text"].(string)
		return []byte(str), nil

	case c.JSON:
		if utils.CheckSeqData(result) {
			result = removeSeqFromMap(result)
		}

		jsn, err := json.Marshal(result)
		if err != nil {
			logger.Log.Error(localMap, "Error while parsing json payload %v", err.Error())
			return nil, err
		}
		return jsn, nil

	case c.XML:

		if !utils.CheckSeqData(result) {
			logger.Log.Debug(localMap, "Adding sequence type for the xml")
			result = AddSeqToMap(result)
		}

		sjjs, _ := json.Marshal(result)
		xm, _ := mxj.NewMapJson(sjjs)
		z, err := xm.XmlSeq()

		if err != nil {
			logger.Log.Error(localMap, "Error while parsing xml payload %v", err.Error())
			return nil, err
		}

		xmlHeader := `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>`
		totalXml := xmlHeader + string(z)
		z = []byte(totalXml)

		return z, nil
	case c.FLAT_JSON:

		myMap := result
		kk, err := flatten.Flatten(myMap, flatten.DefaultTokenizer)
		if err != nil {
			logger.Log.Error(localMap, "Error while parsing Flat-Json payload %v", err.Error())
			return nil, err
		}
		rspBytes, err := json.Marshal(kk.M)
		if err != nil {
			logger.Log.Error(localMap, "Error while parsing Flat-Json payload %v", err.Error())
			return nil, err
		}
		return rspBytes, nil
	case c.FORM_URL_ENCODED:
		var queryParts []string
		for key, value := range result {
			queryParts = append(queryParts, fmt.Sprintf("%s=%s", url.QueryEscape(key), url.QueryEscape(fmt.Sprintf("%v", value))))
		}
		payload := strings.Join(queryParts, "&")
		return []byte(payload), nil

	default:
		return nil, errors.New("unknown output type " + outputType)
	}
}

func PopulateTransformErrorAndConvertToBytes(localMap map[string]interface{}, code string, detailedMessage interface{}, contentOutput string) []byte {
	tErr := utils.PopulateTransFormError(code, detailedMessage)
	return ParseErrortoBytes(localMap, tErr, contentOutput)
}

func ParseErrortoBytes(localMap map[string]interface{}, tErr interface{}, contentOutput string) (errcontent []byte) {
	errMap := utils.ParseStructMap(tErr)
	if contentOutput == "xml" {
		var myMap = make(map[string]interface{})
		myMap["error"] = errMap
		errMap = myMap
	}

	switch err := errMap.(type) {
	case map[string]interface{}:
		errcontent, _ = ParseOutput(localMap, contentOutput, err)
	case []interface{}:
		errcontent, _ = ParseOutput(localMap, contentOutput, err[0].(map[string]interface{}))
	}

	return errcontent
}

// adding Seq no to each and every element on map...
func AddSeqToMap(xmlMap map[string]interface{}) map[string]interface{} {
	result := make(map[string]interface{})
	for i, j := range xmlMap {
		_, mapOk := j.(map[string]interface{})
		_, listOk := j.([]interface{})
		if mapOk {
			result[i] = AddSeqToMap(j.(map[string]interface{}))
		} else if listOk {
			result[i] = addSeqToList(j.([]interface{}))
		} else {

			if i != "#text" && i != "#seq" {
				result[i] = addSeqToElement(j)
			} else {
				result[i] = j
			}
		}
	}
	return result
}

func addSeqToList(i []interface{}) []interface{} {
	var array []interface{}
	for _, j := range i {
		_, ok := j.(map[string]interface{})
		if ok {
			obj := AddSeqToMap(j.(map[string]interface{}))
			array = append(array, obj)
		} else {
			array = append(array, j)
		}
	}
	return array
}

func addSeqToElement(j interface{}) map[string]interface{} {
	var seqMap = make(map[string]interface{})
	if numVal, floatOk := j.(float64); floatOk {
		j = strconv.FormatFloat(numVal, 'g', 5, 64)
	} else if boolVal, boolOk := j.(bool); boolOk {
		j = strconv.FormatBool(boolVal)
	}

	seqMap["#text"] = j
	seqMap["#seq"] = 0
	return seqMap
}

func checkCDATA(xmlcheck string, data string) string {
	if strings.Contains(xmlcheck, "<![CDATA") {
		data = omitCDATA(xmlcheck)
		final := checkCDATA(data, data)
		return final
	} else {
		data = xmlcheck
		return data
	}
}

func omitCDATA(xmlcheck string) string {
	start := strings.Index(xmlcheck, "<![CDATA[")
	end := strings.Index(xmlcheck, "]]>")
	var replacedVal string
	cData := xmlcheck[start+9 : end]
	cDataStart := strings.TrimSpace(cData)
	if strings.HasPrefix(cDataStart, "<?xml") {
		xmlStartTagEnd := strings.Index(xmlcheck, "?>")
		xmlRemove := xmlcheck[start : xmlStartTagEnd+2]
		replacedVal = strings.Replace(xmlcheck, xmlRemove, "", 1)
		replacedVal = strings.Replace(replacedVal, "]]>", "", 1)
	} else if strings.HasPrefix(cDataStart, "<") {
		cDataText := xmlcheck[start : start+9]
		replacedVal = strings.Replace(xmlcheck, cDataText, "", 1)
		replacedVal = strings.Replace(replacedVal, "]]>", "", 1)
	} else {
		res := xmlcheck[start : end+3]
		replacedVal = strings.ReplaceAll(xmlcheck, res, "")
	}
	return replacedVal
}

func IsthisUserException(localMap map[string]interface{}, contentOutput string, ResponseBytes []byte) bool {
	respMap, err := ParseInput(localMap, contentOutput, ResponseBytes)
	if err != nil {
		return false
	}
	if respMap["statusCode"] == "500" {
		return true
	}
	return false
}

func removeSeqFromMap(data map[string]interface{}) map[string]interface{} {
	result := make(map[string]interface{})
	for key, val := range data {
		if key != "#seq" {
			valueMap, mok := val.(map[string]interface{})
			valueList, lok := val.([]interface{})
			if mok {
				if valueMap["#text"] == nil {
					result[key] = removeSeqFromMap(valueMap)
				} else {
					result[key] = valueMap["#text"]
				}
			} else if lok {
				result[key] = removeSeqFromArray(valueList)
			} else {
				result[key] = val
			}
		}
	}
	return result
}

func removeSeqFromArray(data []interface{}) []interface{} {
	var list []interface{}
	for _, object := range data {
		valMap, ok := object.(map[string]interface{})
		if ok {
			res := removeSeqFromMap(valMap)
			list = append(list, res)
		} else {
			list = append(list, object)
		}
	}
	return list
}
