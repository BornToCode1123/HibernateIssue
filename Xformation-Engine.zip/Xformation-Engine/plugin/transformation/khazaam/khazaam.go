package khazaam

import (
	logger "jocata_transform_plugin/log"
	par "jocata_transform_plugin/parse"
	rs "jocata_transform_plugin/structs"
	tf "jocata_transform_plugin/transform"
	"jocata_transform_plugin/utils"
	"net/http"
	"strings"

	"github.com/thedevsaddam/gojsonq/v2"
)

func ConvertConfigToKhazaamSpecification(transConfig rs.Config, data []byte, headers map[string]interface{}, localMap map[string]interface{}, initMap *map[string]interface{}) (string, rs.TransformError) {

	isExceptionHandled := false
	logger.Log.Trace(localMap, "Data received for Xformation")

	addRequestHeadersToLocalData(headers, localMap)

	input, iErr := par.ParseInput(localMap, transConfig.ContentInputType, data)
	if iErr != nil {
		tErrBytes := utils.PopulateTransFormError("1009", iErr.Error())
		return "", tErrBytes
	}

	if transConfig.IgnoreNullFields {
		input = utils.IgnoreNullFields(input)
	}

	input, localMap = utils.AddPathVariablesIntoData(input, localMap)

	transform := transConfig.HolderConfig.(rs.Transform)
	jsonProperty, jsonIgnoreAliasValue, err := utils.JsonIgnorePropAssign(localMap, transform)
	if err != nil {
		tErrBytes := utils.PopulateTransFormError("10Fa09", "could not parse jsonIgnoreProperty value in transform")
		return "", tErrBytes
	}

	if initMap != nil {
		input["localData"] = *initMap
	}

	querybuilder := gojsonq.New().FromInterface(input)
	var arr []rs.TransformError
	jd := rs.JSONQData{Jqdata: querybuilder, ShouldReset: true, LocalData: localMap, JsonIgnoreProperty: jsonProperty, ErrorData: &arr, JsonIgnoreAliasValue: jsonIgnoreAliasValue, IsExceptionHandled: &isExceptionHandled}
	initMap = nil
	input = nil

	transformResult := tf.ProcessConfig(transConfig, jd)

	if len(transformResult.Errors) > 0 {
		if transformResult.Mandatory {
			// transformResult.Errors[0].Detailedmessage = c.SYSTEM_ADMIN_ERROR_MESSAGE
			return "", transformResult.Errors[0]
		}
		resAndErrs := utils.AppendResultWithError(transformResult.Errors, transformResult.Result)
		output, _ := par.ParseOutput(localMap, transConfig.ContentOutputType, resAndErrs)
		return string(output), rs.TransformError{}
	}

	output, err := par.ParseOutput(localMap, transConfig.ContentOutputType, transformResult.Result)

	if err == nil {
		logger.Log.Debug(localMap, "Transformation done succefully")
		return string(output), rs.TransformError{}
	} else {
		return "", utils.PopulateTransFormError("1001", err.Error())
	}
}

func addRequestHeadersToLocalData(headers map[string]interface{}, localDataMap map[string]interface{}) {
	if len(headers) == 0 {
		return
	}
	logger.Log.Debug(localDataMap, "Headers stored in local successfully")
	requestHeaders := make(map[string]interface{})

	for key, values := range headers {
		requestHeaders[key] = values
	}
	localDataMap["headers"] = requestHeaders
}

func TransformRequest(transConfig rs.Config, payload []byte, rh http.Header, localMap map[string]interface{}, initMap *map[string]interface{}) ([]byte, rs.TransformError) {
	logger.Log.Trace(localMap, "received the config for request transformation : %v", transConfig)
	return transform(transConfig, payload, rh, localMap, initMap)
}

func TransformResponse(transConfig rs.Config, payload []byte, rh http.Header, localMap map[string]interface{}, initMap *map[string]interface{}) ([]byte, rs.TransformError) {
	logger.Log.Trace(localMap, "received the config for response transformation : %v", transConfig)
	return transform(transConfig, payload, rh, localMap, initMap)
}

func TransformInit(transConfig rs.Config, payload []byte, rh http.Header, localMap map[string]interface{}) rs.TransformError {
	logger.Log.Trace(localMap, "received the config for init transformation : %v", transConfig)
	_, err := transform(transConfig, payload, rh, localMap, nil)
	return err
}

func transform(transConfig rs.Config, payload []byte, rh http.Header, localMap map[string]interface{}, initMap *map[string]interface{}) ([]byte, rs.TransformError) {
	var headers = make(map[string]interface{})

	for key, values := range rh {
		headers[key] = strings.Join(values, ",")
	}

	res, tErrs := ConvertConfigToKhazaamSpecification(transConfig, payload, headers, localMap, initMap)
	if tErrs.Detailedmessage == nil {
		logger.Log.Trace(localMap, "Transformed output is : %v", res)
		modified := []byte(res)
		return modified, rs.TransformError{}
	} else {
		logger.Log.Error(localMap, "Transformed Errors are : %v", tErrs)
		return []byte{}, tErrs
	}
}
