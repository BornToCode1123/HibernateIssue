package utils

import (
	"encoding/json"
	"errors"
	"fmt"
	"jocata_transform_plugin/constants"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"math/rand"

	"net/http"
	"net/url"
	"runtime"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/xeipuuv/gojsonschema"
)

var errorMap = make(map[string]rs.TransformError)

func PopulateErrorMap() {
	errorMap["1001"] = rs.TransformError{Code: "1001", Message: "Technical Error"}
	errorMap["1002"] = rs.TransformError{Code: "1002", Message: "Configuration Error"}
	errorMap["1003"] = rs.TransformError{Code: "1003", Message: "Response Validation Error"}
	errorMap["1004"] = rs.TransformError{Code: "1004", Message: "Response Validation Failed"}
	errorMap["1005"] = rs.TransformError{Code: "1005", Message: "Request Timed Out"}
	errorMap["1006"] = rs.TransformError{Code: "1006", Message: "Error from Third-Party Server"}
	errorMap["1007"] = rs.TransformError{Code: "1007", Message: "Missing Request Body"}
	errorMap["1008"] = rs.TransformError{Code: "1008", Message: "Configuration Parsing Error"}
	errorMap["1009"] = rs.TransformError{Code: "1009", Message: "Payload Parsing Error"}
	errorMap["1010"] = rs.TransformError{Code: "1010", Message: "Payload Property Error"}
	errorMap["1011"] = rs.TransformError{Code: "1011", Message: "Transformation Errors"}
	errorMap["1111"] = rs.TransformError{Code: "1111", Message: "Error Statement"}
	errorMap["1112"] = rs.TransformError{Code: "1112", Message: "Error While Fetching Configuration from the Database"}
	errorMap["1113"] = rs.TransformError{Code: "1113", Message: "JSON Schema Validation Error"}
	errorMap["1114"] = rs.TransformError{Code: "1114", Message: "JSON Schema Parsing Error"}
}

func GetErrorObject(errCode string) rs.TransformError {
	return errorMap[errCode]
}

func MakeResultMap() map[string]map[string]interface{} {
	var res = make(map[string]map[string]interface{})
	res["transformed"] = make(map[string]interface{})
	res["errors"] = make(map[string]interface{})
	return res
}

func PushToMap(result map[string]interface{}, objKey string, value interface{}, dataType string) {
	dotPos := strings.Index(objKey, constants.OBJECT_SEPARATOR)
	if dotPos < 0 {
		val, ok := result[objKey]
		if ok && dataType != "any" {

			switch existingVal := val.(type) {
			case []interface{}:
				if value != nil {
					switch va := value.(type) {
					case []interface{}:
						lv := append(existingVal, va...)
						result[objKey] = lv
					case map[string]interface{}:
						lv := append(existingVal, va)
						result[objKey] = lv
					}
				} else {
					list := []interface{}{}
					result[objKey] = list
				}

			case map[string]interface{}:
				if value != nil {
					MergeMaps(result[objKey].(map[string]interface{}), value.(map[string]interface{}))
				} else {
					result[objKey] = make(map[string]interface{})
				}

			default:
				result[objKey] = value
			}
		} else {
			result[objKey] = value
		}
	} else {
		key := objKey[:dotPos]
		v := objKey[dotPos+1:]
		var res map[string]interface{}
		val, ok := result[key]
		if ok {
			res = val.(map[string]interface{})
		} else {
			res = make(map[string]interface{})
			result[key] = res
		}
		PushToMap(res, v, value, dataType)
	}
}

func GetFromMap(result map[string]interface{}, objKey string, data rs.JSONQData) (interface{}, error) {
	dotPos := strings.Index(objKey, constants.OBJECT_SEPARATOR)

	res := data.Jqdata.Find("localData." + objKey)
	err := data.Jqdata.Error()
	if err == nil {
		data.Jqdata.Reset()
		return res, nil
	}
	data.Jqdata.Reset()

	if dotPos < 0 {
		_, ok := result[objKey]
		if !ok {
			errMessage := fmt.Sprintf("the variable : %v, is not declared earlier", objKey)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, errors.New(errMessage)
		}

		res := result[objKey]
		if res != nil {
			switch res := res.(type) {
			case int:
				return float64(res), nil
			case int16:
				return float64(res), nil
			case int32:
				return float64(res), nil
			case int64:
				return float64(res), nil
			}
		}
		return res, nil
	} else {
		var v string
		key := objKey[:dotPos]
		v = objKey[dotPos+1:]
		res := make(map[string]interface{})
		val, ok := result[key]
		if !ok {
			errMessage := fmt.Sprintf("the variable : %v, is not declared earlier", key)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, errors.New(errMessage)
		}

		switch val := val.(type) {
		case map[string]interface{}:
			res = val
		case []interface{}:
			if strings.HasPrefix(v, "[") {
				dot := strings.Index(v, constants.OBJECT_SEPARATOR)
				if dot == -1 {
					dot = len(v)
				}
				indx := v[1 : dot-1]
				index, _ := strconv.Atoi(indx)
				if len(val) > index {
					arr := val[index]
					if rs, ok := arr.(map[string]interface{}); ok {
						res = rs
					} else {
						return arr, nil
					}
					if strings.Contains(v, ".") {
						v = v[dot+1:]
					} else {
						return res, nil
					}

				} else {
					errMessage := fmt.Sprintf("the given index : %v, is greater than list size %v", index, len(val))
					logger.Log.Error(data.LocalData, errMessage)
					return nil, errors.New(errMessage)
				}
			}
		case []string:
			if strings.HasPrefix(v, "[") {
				dot := strings.Index(v, constants.OBJECT_SEPARATOR)
				if dot == -1 {
					dot = len(v)
				}
				indx := v[1 : dot-1]
				index, _ := strconv.Atoi(indx)
				if len(val) > index {
					arr := val[index]
					return arr, nil
				} else {
					errMessage := fmt.Sprintf("the given index : %v, is greater than list size %v", index, len(val))
					logger.Log.Error(data.LocalData, errMessage)
					return nil, errors.New(errMessage)
				}
			}

		}

		return GetFromMap(res, v, data)
	}
}

func FindValue(variable string, data rs.JSONQData) (interface{}, error) {
	var res interface{}
	var err error

	if strings.Contains(variable, constants.LOCAL_SEPARATOR) {
		variableName := ModifyName(variable)
		res, err = GetFromMap(data.LocalData, variableName, data)
		if !data.JsonIgnoreProperty && err != nil {
			logger.Log.Error(data.LocalData, err.Error())
			return nil, err
		} else if data.JsonIgnoreProperty && err != nil {
			return data.JsonIgnoreAliasValue, nil
		}

	} else {
		res = data.Jqdata.Find(variable)
		er := data.Jqdata.Error()
		if !data.JsonIgnoreProperty && er != nil {
			erMsg := er.Error()
			logger.Log.Error(data.LocalData, er.Error())
			if len(erMsg) > 27 {
				erMsg = erMsg[27:]
			}
			errMessage := fmt.Sprintf("the key :" + erMsg + ", is not found in the payload specified path " + variable)
			return nil, errors.New(errMessage)
		} else if data.JsonIgnoreProperty && er != nil {
			return data.JsonIgnoreAliasValue, nil
		}
	}
	return res, nil
}

func MergeMaps(map1, map2 map[string]interface{}) map[string]interface{} {
	for k, v := range map2 {
		mpV, mOk := v.(map[string]interface{})
		listV, lOk := v.([]interface{})
		if mOk && map1[k] != nil {
			MergeMaps(map1[k].(map[string]interface{}), mpV)
		} else if lOk && map1[k] != nil {
			map1[k] = mergeArrays(map1[k].([]interface{}), listV)
		} else {
			map1[k] = v
		}
	}
	return map1
}

func mergeArrays(result, values []interface{}) []interface{} {
	result = append(result, values...)
	return result
}

func PopulateErrorData(id interface{}, name string, tErr rs.TransformError, localMap map[string]interface{}) {

	statementId := GetStringId(id)
	PushToMap(localMap, "statementId", statementId, "text")

	var errData = make(map[string]interface{})
	errorObject := name + `_error`

	errData["code"] = tErr.Code
	errData["message"] = tErr.Message
	errData["detailedMessage"] = tErr.Detailedmessage
	errData["subCode"] = tErr.Subcode

	PushToMap(localMap, errorObject, errData, "error")
	PushToMap(localMap, "currentError", errData, "error")
}

func generateUUid(length int, charset string) string {
	var seededRand *rand.Rand = rand.New(rand.NewSource(time.Now().UnixNano()))
	b := make([]byte, length)
	for i := range b {
		b[i] = charset[seededRand.Intn(len(charset))]
	}
	return string(b)
}

func GetUUID(data rs.JSONQData, UUIDType string, UUIDSize float64) (string, error) {
	const charsetNumeric = "0123456789"
	const charsetAlpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	const charsetHomogenious = "abcde456789fghijklmnopqrstuvwxyz0123"

	switch UUIDType {

	case "numeric":
		return generateUUid(int(UUIDSize), charsetNumeric), nil

	case "alpha":
		return generateUUid(int(UUIDSize), charsetAlpha), nil

	case "alphaNumeric":
		return generateUUid(int(UUIDSize), charsetHomogenious), nil
	case "unique":
		u, err := uuid.NewRandom()
		return u.String(), err

	default:
		errMessage := fmt.Sprintf("No Such Type UUID %v", UUIDType)
		logger.Log.Error(data.LocalData, errMessage)
		return "", errors.New(errMessage)
	}
}

func JsonIgnorePropAssign(localMap map[string]interface{}, transform rs.Transform) (jsonProperty bool, jsonIgnoreAliasValue interface{}, err error) {
	if transform.JsonIgnoreProperty == nil {
		transform.JsonIgnoreProperty = "false"
	}

	switch v := transform.JsonIgnoreProperty.(type) {
	case string:
		jsonProperty, err = strconv.ParseBool(v)
	case bool:
		jsonProperty = v
	default:
		err = errors.New("could not parse jsonIgnoreProperty value in transform")
		logger.Log.Error(localMap, err.Error())
	}

	switch aliasval := transform.JsonIgnoreAliasValue.(type) {
	case string:
		jsonIgnoreAliasValue = strings.Trim(aliasval, " ")
	default:
		jsonIgnoreAliasValue = aliasval
	}

	return jsonProperty, jsonIgnoreAliasValue, err
}

func ReplaceJsonIgnorePropertyWith(data rs.JSONQData, transform rs.Transform) (bool, error) {
	if transform.JsonIgnoreAliasValue == nil {
		transform.JsonIgnoreAliasValue = nil
	}
	var jsonProperty bool
	var err error
	switch v := transform.JsonIgnoreProperty.(type) {
	case string:
		jsonProperty, err = strconv.ParseBool(v)
	case bool:
		jsonProperty = v
	default:
		err = errors.New("could not parse jsonIgnoreProperty value in transform")
		logger.Log.Error(data.LocalData, err.Error())
	}
	return jsonProperty, err
}

func PopulateTransFormError(code string, detailedMessage interface{}) rs.TransformError {
	tErr := GetErrorObject(code)
	tErr.Detailedmessage = detailedMessage
	return tErr
}

func ContentOutput(config map[string]interface{}) string {
	if config["config"] != nil {
		conf := config["config"].(map[string]interface{})
		if conf["contentOutputType"] != nil {
			contentOutputType := conf["contentOutputType"].(string)
			return contentOutputType
		}
	} else {
		if config["contentOutputType"] != nil {
			contentOutputType := config["contentOutputType"].(string)
			return contentOutputType
		}
	}
	return "json"
}

func ParseStructMap(tErr interface{}) interface{} {
	var myMap interface{}
	data, _ := json.Marshal(tErr)
	json.Unmarshal(data, &myMap)
	return myMap
}

func AppendResultWithError(tErr []rs.TransformError, result map[string]interface{}) map[string]interface{} {
	errRes := ParseStructMap(tErr)
	if result != nil {
		result["errors"] = errRes
		return result
	}
	var res = make(map[string]interface{})
	res["errors"] = errRes
	return res
}

func ignoreNullFields(newMap, payloadMap map[string]interface{}) map[string]interface{} {
	for k, v := range payloadMap {
		_, mOk := v.(map[string]interface{})
		_, lOk := v.([]interface{})
		if mOk {
			mpV := v.(map[string]interface{})
			newMap[k] = IgnoreNullFields(mpV)
		} else if lOk {
			var newList []interface{}
			listV := v.([]interface{})
			for _, obj := range listV {
				_, ok := obj.(map[string]interface{})
				if ok {
					updatedObj := IgnoreNullFields(obj.(map[string]interface{}))
					newList = append(newList, updatedObj)
				} else {
					newList = append(newList, obj)
				}
			}
			if newList != nil {
				newMap[k] = newList
			} else {
				slice := []interface{}{}
				newMap[k] = slice
			}

		} else if v != nil {
			newMap[k] = v
		}
	}
	return newMap
}

func IgnoreNullFields(payloadMap map[string]interface{}) map[string]interface{} {
	var newMap = make(map[string]interface{})
	return ignoreNullFields(newMap, payloadMap)
}

func CheckSeqData(data map[string]interface{}) bool {
	var count float64
	if data["#seq"] == nil {
		for _, val := range data {
			count++
			valueMap, mok := val.(map[string]interface{})
			valueList, lok := val.([]interface{})
			if mok {
				if CheckSeqData(valueMap) {
					return true
				}
			}
			if lok {
				for _, obj := range valueList {
					valueMap, mok := obj.(map[string]interface{})
					if mok {
						if CheckSeqData(valueMap) {
							return true
						}
					}
				}
			}
			if count == 200 {
				break
			}
		}
		return false
	}
	return true
}

func GetStringId(id interface{}) string {
	textId, ok := id.(string)
	if ok {
		return textId
	}
	floatId, ok := id.(float64)
	if ok {
		var y = int(floatId)
		kk := fmt.Sprintf("%v", y)
		return kk
	} else {
		kk := fmt.Sprintf("%v", id)
		return kk
	}
}

func PrintStackTrace(localMap map[string]interface{}) {
	stack := make([]byte, 4096)
	length := runtime.Stack(stack, false)
	logger.Log.Error(localMap, "---------stack_trace----------")
	logger.Log.Error(localMap, string(stack[:length]))
}

func replaceHostProperties(payloadData string) (finalPayload string) {
	// Unmarshal JSON into the Payload struct
	var endpointConfig rs.Endpoint
	err := json.Unmarshal([]byte(payloadData), &endpointConfig)
	if err != nil {
		fmt.Println("Error unmarshalling payload:", err)
		return ""
	}

	// Extract the backend and update host properties
	if len(endpointConfig.Backend) > 0 {
		backend := &endpointConfig.Backend[0]
		hostProperties := rs.HostProperties{
			Endpoint: endpointConfig.Endpoint,
			Timeout:  rs.ParseFloat(endpointConfig.Timeout),
		}
		backend.ExtraConfig.Executor.TransFormPlugin.HostProperties = hostProperties
	}

	// Marshal the updated payload back to JSON
	updatedPayload, err := json.Marshal(endpointConfig)
	if err != nil {
		fmt.Println("Error marshalling updated payload:", err)
		return ""
	}

	return string(updatedPayload)
}

func GetHostProperties(pluginConfig map[string]interface{}) rs.HostProperties {
	var hostProperties rs.HostProperties

	if pluginConfig["hostProperties"] != nil {
		propertyBytes, _ := json.Marshal(pluginConfig["hostProperties"])
		json.Unmarshal(propertyBytes, &hostProperties)
	}

	return hostProperties
}

func GetConnectionDetails(arguments map[string]interface{}) rs.HostConnectionDetails {
	var hostConnectionDetails rs.HostConnectionDetails
	bytes, _ := json.Marshal(arguments)
	json.Unmarshal(bytes, &hostConnectionDetails)
	return hostConnectionDetails
}

func ProcessParams(url url.Values) map[string]interface{} {
	var getMap = make(map[string]interface{})
	for k, v := range url {
		getMap[k] = v[0]
	}
	return getMap
}

func GetPathVariables(template, target string) (map[string]interface{}, error) {
	pathVariables := make(map[string]interface{})
	templateParts := strings.Split(template, "/")
	targetParts := strings.Split(target, "/")

	if len(templateParts) != len(targetParts) {
		return nil, fmt.Errorf("mismatch between template and target URL segments")
	}

	for i, part := range templateParts {
		if strings.HasPrefix(part, "{") && strings.HasSuffix(part, "}") {
			pathVariables[strings.Trim(templateParts[i], "{}")] = targetParts[i]
		}
	}

	return pathVariables, nil
}

func GetHttpStatusCode(localMap map[string]interface{}) (statusCode int) {
	statusCode = http.StatusOK
	if localMap["responseHeaders"] != nil {
		responseHeaders := localMap["responseHeaders"].(map[string]interface{})
		if responseHeaders["httpStatusCode"] != nil {
			switch responseHeaders["httpStatusCode"].(type) {
			case string:
				httpStatusCode := responseHeaders["httpStatusCode"].(string)
				statusCode, _ = strconv.Atoi(httpStatusCode)
			case float64:
				httpStatusCode := responseHeaders["httpStatusCode"].(float64)
				statusCode = int(httpStatusCode)
			}
		}
	}
	logger.Log.Trace(localMap, "http status code : %v", statusCode)
	return statusCode
}

func AddPathVariablesIntoData(input, localMap map[string]interface{}) (map[string]interface{}, map[string]interface{}) {
	if localMap["pathVariables"] != nil {
		for key, val := range localMap["pathVariables"].(map[string]interface{}) {
			input[key] = val
		}
		localMap = make(map[string]interface{})
	}
	return input, localMap
}

func ModifyName(name string) string {
	dotPos := strings.Index(name, constants.LOCAL_SEPARATOR)
	name = name[:dotPos]
	return name
}

func CombineMap(map1, map2 map[string]interface{}) map[string]interface{} {
	if len(map1) == 0 {
		return map2
	}
	if len(map2) == 0 {
		return map1
	}

	result := make(map[string]interface{})
	for key, value := range map1 {
		result[key] = value
	}
	for key, value := range map2 {
		result[key] = value
	}
	return result
}

func EvaluateJsonSchema(schema map[string]interface{}, payload []byte, localMap map[string]interface{}) (bool, rs.TransformError) {

	jsonSchemaBytes, _ := json.Marshal(schema)
	jsonSchemaString := string(jsonSchemaBytes)
	payloadString := string(payload)

	isValid, validationErrors, err := ValidateJSON(localMap, jsonSchemaString, payloadString)

	if err != nil {
		errMessage := fmt.Sprintf("Error during JSON validation: %v", err.Error())
		logger.Log.Debug(localMap, errMessage)
		tErr := PopulateTransFormError("1114", err.Error())
		return false, tErr
	}

	if !isValid {
		logger.Log.Debug(localMap, "Validation failed. Errors:", validationErrors)
		tErr := PopulateTransFormError("1113", validationErrors)
		return false, tErr
	}

	logger.Log.Debug(localMap, "Validation successful. Proceeding with further transformation.")
	return true, rs.TransformError{}
}

func ValidateJSON(localMap map[string]interface{}, jsonSchema, payload string) (bool, []interface{}, error) {
	logger.Log.Debug(localMap, "Validating JSON...")

	schemaLoader := gojsonschema.NewStringLoader(jsonSchema)
	payloadLoader := gojsonschema.NewStringLoader(payload)

	result, err := gojsonschema.Validate(schemaLoader, payloadLoader)
	if err != nil {
		logger.Log.Debug(localMap, "Error validating JSON:", err)
		return false, nil, err
	}

	if result.Valid() {
		logger.Log.Debug(localMap, "The JSON data is valid.")
		return true, nil, nil
	}

	var errors []interface{}
	for _, desc := range result.Errors() {

		var schemaError map[string]interface{}
		switch desc.Type() {
		case "required":
			schemaError = map[string]interface{}{
				"type":     desc.Type(),
				"path":     desc.Field(),
				"property": desc.Field(),
				"value":    nil,
			}
			details := desc.Details()
			if property, ok := details["property"]; ok {
				schemaError["property"] = property
				schemaError["path"] = fmt.Sprintf("%v.%v", desc.Field(), property)
			}

		case "invalid_type":
			schemaError = map[string]interface{}{
				"type":     desc.Type(),
				"path":     desc.Field(),
				"property": getProperty(desc.Field()),
				"value":    desc.Value(),
			}
		case "pattern":
			schemaError = map[string]interface{}{
				"type":     "valueFormat",
				"path":     desc.Field(),
				"property": getProperty(desc.Field()),
				"value":    desc.Value(),
			}
		}
		if schemaError != nil {
			errors = append(errors, schemaError)
		}
	}
	logger.Log.Debug(localMap, "The JSON data is invalid. See errors:", errors)
	return false, errors, nil
}

func getProperty(path string) string {
	keys := strings.Split(path, ".")
	return keys[len(keys)-1]
}

func GetObjectAndMapListHardCodedData(TransFormPlugin rs.Plugin) (map[string]interface{}, []rs.Statement) {
	var statements []rs.Statement
	if init := TransFormPlugin.Init; init != nil && init.HolderConfig != nil {
		statements = init.HolderConfig.(rs.Transform).Statements
	}
	var result = make(map[string]interface{})
	updatedStatements := getJsonDataFromSection(statements, result)
	return result, updatedStatements
}

func getJsonDataFromSection(statements []rs.Statement, result map[string]interface{}) []rs.Statement {

	var updatedStatements []rs.Statement

	for _, statement := range statements {
		switch statement.EType {
		case "AssignmentStatement":
			if rhsExp := statement.Assignment.Rhs; rhsExp.EType == "keyword" {
				if rhs := rhsExp.Holder.(rs.Keyword); rhs.DataValue == "map" || rhs.DataValue == "list" {
					if keywordArgs := rhs.KeywordArguments; keywordArgs != nil {
						if args := keywordArgs.(map[string]interface{}); args["format"] == "jsonObjectMap" || args["format"] == "jsonObjectList" {
							init := args["init"].(map[string]interface{})
							var Object interface{}
							json.Unmarshal([]byte(init["value"].(string)), &Object)
							result[statement.Assignment.Lhs.Holder.(rs.Declare).DataValue.(string)] = Object
							continue
						}
					}
				}
			}
		case "SectionalStatement":
			updatdStmts := getJsonDataFromSection(statement.Section.Statements, result)
			statement.Section.Statements = updatdStmts
		}
		updatedStatements = append(updatedStatements, statement)
	}
	return updatedStatements
}
