package flatten

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// Tokenizer is an interface for key manipulators
type Tokenizer interface {
	Separator() string
	Token([]string) string
	Keys(string) []string
}

// StringTokenizer is a Tokenizer using the string as separator
type StringTokenizer string

// Token returns a token joining all the keys with s as separator
func (s StringTokenizer) Token(ks []string) string { return strings.Join(ks, string(s)) }

// Keys returns the keys contained in the received token
func (s StringTokenizer) Keys(ks string) []string { return strings.Split(ks, string(s)) }

// Separator returns the separator
func (s StringTokenizer) Separator() string { return string(s) }

// DefaultTokenizer is a tokenizer using a dot or fullstop
var DefaultTokenizer = StringTokenizer(".")

// Flatten takes a hierarchy and flatten it using the tokenizer supplied
func Flatten(m map[string]interface{}, tokenizer Tokenizer) (*Map, error) {
	result, err := newMap(tokenizer)
	if err != nil {
		return nil, err
	}
	flatten(m, []string{}, func(ks []string, v interface{}) {
		result.M[tokenizer.Token(ks)] = v
	})
	return result, nil
}

type updateFunc func([]string, interface{})

func flatten(i interface{}, ks []string, update updateFunc) {
	switch v := i.(type) {
	case map[string]interface{}:
		flattenMap(v, ks, update)
	case []interface{}:
		flattenSlice(v, ks, update)
	default:
		update(ks, v)
	}
}

func flattenMap(m map[string]interface{}, ks []string, update updateFunc) {
	for k, v := range m {
		flatten(v, append(ks, k), update)
	}
}

func flattenSlice(vs []interface{}, ks []string, update updateFunc) {
	key := ks[len(ks)-1]
	for i, v := range vs {
		ks[len(ks)-1] = key
		kk := fmt.Sprintf("%s[%d]", ks[len(ks)-1], i)
		ks[len(ks)-1] = kk
		flatten(v, ks, update)
		// flatten(v, append(ks, fmt.Sprintf("[%d]", i)), update)
	}
}

var defaultCollectionPattern = regexp.MustCompile(`\.\*\.`)

func newMap(t Tokenizer) (*Map, error) {
	sep := t.Separator()
	var hasWildcard *regexp.Regexp
	var err error
	if sep == "." {
		hasWildcard = defaultCollectionPattern
	} else {
		hasWildcard, err = regexp.Compile(sep + `\*` + sep)
	}
	if err != nil {
		return nil, err
	}
	return &Map{
		M:  make(map[string]interface{}),
		t:  t,
		re: hasWildcard,
	}, nil
}

// Map is a flatten map
type Map struct {
	M  map[string]interface{}
	t  Tokenizer
	re *regexp.Regexp
}

// Move makes changes in the flatten hierarchy moving contents from origin to newKey
func (m *Map) Move(original, newKey string) {
	if v, ok := m.M[original]; ok {
		m.M[newKey] = v
		delete(m.M, original)
		return
	}

	if m.re.MatchString(original) {
		m.moveSliceAttribute(original, newKey)
		return
	}

	sep := m.t.Separator()

	for k := range m.M {
		if !strings.HasPrefix(k, original) {
			continue
		}

		if k[len(original):len(original)+1] != sep {
			continue
		}

		m.M[newKey+sep+k[len(original)+1:]] = m.M[k]
		delete(m.M, k)
	}
}

// Del deletes a key out of the map with the given prefix
func (m *Map) Del(prefix string) {
	if _, ok := m.M[prefix]; ok {
		delete(m.M, prefix)
		return
	}

	if m.re.MatchString(prefix) {
		m.delSliceAttribute(prefix)
		return
	}

	sep := m.t.Separator()

	for k := range m.M {
		if !strings.HasPrefix(k, prefix) {
			continue
		}

		if k[len(prefix):len(prefix)+1] != sep {
			continue
		}

		delete(m.M, k)
	}
}

func (m *Map) delSliceAttribute(prefix string) {
	i := strings.Index(prefix, "*")
	sep := m.t.Separator()
	prefixRemainder := prefix[i+1:]
	recursive := strings.Contains(prefixRemainder, "*")

	for k := range m.M {
		if len(k) < i+2 {
			continue
		}

		if !strings.HasPrefix(k, prefix[:i]) {
			continue
		}

		if recursive {
			// TODO: avoid recursive calls by managing nested collections in a single key evaluation
			newPref := k[:i+1+strings.Index(k[i+1:], sep)] + prefixRemainder
			m.Del(newPref)
			continue
		}

		keyRemainder := k[i+1+strings.Index(k[i+1:], sep):]
		if keyRemainder == prefixRemainder {
			delete(m.M, k)
			continue
		}

		if !strings.HasPrefix(keyRemainder, prefixRemainder+sep) {
			continue
		}

		delete(m.M, k)
	}
}

func (m *Map) moveSliceAttribute(original, newKey string) {
	i := strings.Index(original, "*")
	sep := m.t.Separator()
	originalRemainder := original[i+1:]
	recursive := strings.Contains(originalRemainder, "*")

	newKeyOffset := strings.Index(newKey, "*")
	newKeyRemainder := newKey[newKeyOffset+1:]
	newKeyPrefix := newKey[:newKeyOffset]

	for k := range m.M {
		if len(k) <= i+2 {
			continue
		}

		if !strings.HasPrefix(k, original[:i]) {
			continue
		}

		remainder := k[i:]
		idLen := strings.Index(remainder, sep)
		cleanRemainder := k[i+idLen:]
		keyPrefix := newKeyPrefix + k[i:i+idLen]

		if recursive {
			// TODO: avoid recursive calls by managing nested collections in a single key evaluation
			m.Move(k[:i+idLen]+originalRemainder, keyPrefix+newKeyRemainder)
			continue
		}

		if cleanRemainder == originalRemainder[1:] {
			m.M[keyPrefix+newKeyRemainder] = m.M[k]
			delete(m.M, k)
			continue
		}

		rPrefix := originalRemainder[1:] + sep

		if cleanRemainder != sep+originalRemainder[1:] && !strings.HasPrefix(cleanRemainder, sep+rPrefix) {
			continue
		}

		m.M[keyPrefix+newKeyRemainder+cleanRemainder[len(rPrefix):]] = m.M[k]
		delete(m.M, k)
	}
}

func UnFlatten(dat map[string]interface{}) map[string]interface{} {

	data := make(map[string]interface{})
	// Loop through the flattened JSON strings
	for k, f := range dat {
		temp := make(map[string]interface{})
		temp[k] = f
		unflattenJson(data, temp)
	}

	return data
}

func unflattenJson(data map[string]interface{}, temp interface{}) error {

	var key string
	var value interface{}
	for k, v := range temp.(map[string]interface{}) {
		key = k
		value = v
	}

	keys := strings.Split(key, ".")
	keys = keys[0:]
	unflattenMap(data, keys, value)
	return nil
}

func unflattenMap(m map[string]interface{}, keys []string, value interface{}) {
	if len(keys) == 0 {
		return
	}
	k := keys[0]
	if strings.Contains(k, "[") && strings.Contains(k, "]") {
		unflattenArray(k, m, keys, value)
	} else {
		n, ok := m[k].(map[string]interface{})
		if !ok {
			n = make(map[string]interface{})
		}
		if len(keys) == 1 {
			key := getKey(k)
			m[key] = value
		} else {
			m[k] = n
			unflattenMap(n, keys[1:], value)
		}
	}
}

func unflattenArray(k string, m map[string]interface{}, keys []string, value interface{}) {
	ind := strings.LastIndex(k, "[")
	index, err := strconv.Atoi(k[ind+1 : len(k)-1])
	if err != nil {
		fmt.Println(err)
	}

	s, ok := m[getKey(keys[0])].([]interface{})
	if !ok {
		s = make([]interface{}, 0)
	}

	if len(s) <= index {
		for len(s) <= index {
			if len(keys) == 1 {
				s = append(s, "")
			} else {
				s = append(s, make(map[string]interface{}))
			}
		}
	}

	key := getKey(keys[0])

	m[key] = s

	if len(keys) == 1 {
		s[index] = value
	} else {
		unflattenMap(s[index].(map[string]interface{}), keys[1:], value)
	}
}

func getKey(key string) string {
	if !(strings.Contains(key, "[") && strings.Contains(key, "]")) {
		return key
	}

	ind := strings.LastIndex(key, "[")
	return key[0:ind]
}
