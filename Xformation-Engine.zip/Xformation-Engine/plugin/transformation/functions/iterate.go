package functions

import (
	"encoding/json"
	"fmt"
	c "jocata_transform_plugin/constants"
	filt "jocata_transform_plugin/functions/filters"

	"jocata_transform_plugin/utils"

	"strings"

	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"

	"github.com/thedevsaddam/gojsonq/v2"
)

func IterateArray(arrName string, funcArgs map[string]interface{}, data rs.JSONQData, fn rs.ProcessInnerTransform, pe rs.ProcessExpression, filter rs.Filter, con rs.ProcessCondition, processRules rs.ProcessRules, statementPath string) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function iterate")
	data.ResetJsonqData()
	var aggData rs.JSONQData

	if strings.Contains(arrName, c.LOCAL_OBJECT_IDENTIFIER) {
		dotPos := strings.Index(arrName, c.LOCAL_SEPARATOR)
		arrName = arrName[:dotPos]

		dat, err := json.Marshal(data.LocalData)

		if err != nil {
			logger.Log.Error(data.LocalData, "Error while retrieving the data from local %v ", err.Error())
			tErr := utils.PopulateTransFormError("1001", err.Error())
			return rs.ExpressionResult{}, tErr
		}
		arrData := gojsonq.New().JSONString(string(dat))
		aggData = rs.JSONQData{
			TransformedData:    map[string]interface{}{},
			ExtractedData:      map[string]interface{}{},
			DeletedData:        map[string]interface{}{},
			LocalData:          data.LocalData,
			ErrorConfig:        data.ErrorConfig,
			Jqdata:             arrData,
			ShouldReset:        true,
			IsExceptionHandled: data.IsExceptionHandled,
			ErrorData:          data.ErrorData,
		}

	} else {
		aggData = data
	}

	if funcArgs["transform"] == nil {
		if filter.Id != nil {
			tErr := filt.BuildWhereclause(filter, aggData, pe, fn, statementPath)
			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = fmt.Sprintf("error %v while filtering the data", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return nil, tErr
			}
		}
		return iterateArraywithFields(arrName, funcArgs, aggData)
	} else {
		return iterateArraywithTransform(arrName, funcArgs, aggData, fn, con, processRules, statementPath, filter)
	}
}

func iterateArraywithFields(arrName string, funcArgs map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "iterating with fields")
	var fields []interface{}

	switch funcArgs["fields"].(type) {
	case map[string]interface{}:
		fields = makeMapFieldstoListOfFields(funcArgs)
	case []interface{}:
		fields = funcArgs["fields"].([]interface{})
	}

	var sfields []string

	for _, field := range fields {
		f := field.(string)
		sfields = append(sfields, f)
	}

	if len(sfields) == 0 {
		slice := []string{}
		return slice, rs.TransformError{}
	}

	res := data.Jqdata.From(arrName).Select(sfields...).Get()
	err := data.Jqdata.Error()

	if !data.JsonIgnoreProperty && err != nil {
		errMessage := fmt.Sprintf("error while iterating the fields %v, on %v array ", err.Error(), arrName)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	} else if data.JsonIgnoreProperty && err != nil {
		return data.JsonIgnoreAliasValue, rs.TransformError{}
	}
	return res, rs.TransformError{}
}

func iterateArraywithTransform(arrName string, funcArgs map[string]interface{}, data rs.JSONQData, fn rs.ProcessInnerTransform, con rs.ProcessCondition, processRules rs.ProcessRules, statementPath string, filterConfig rs.Filter) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "iterating with transform")
	transConfig := funcArgs["transform"].(map[string]interface{})

	breakStatement := funcArgs["break"]
	var condition rs.Condition
	if breakStatement != nil {
		breakStatement := funcArgs["break"].(map[string]interface{})
		xyz, _ := json.Marshal(breakStatement)
		transDat := []byte(xyz)
		json.Unmarshal(transDat, &condition)
	}

	abc, _ := json.Marshal(transConfig)
	transData := []byte(abc)
	var transform rs.Transform
	json.Unmarshal(transData, &transform)

	jsonProperty, jsonIgnoreAliasValue, parseErr := utils.JsonIgnorePropAssign(data.LocalData, transform)
	if parseErr != nil {
		detailedmessage := "could not parse jsonIgnoreProperty value in transform"
		logger.Log.Error(data.LocalData, detailedmessage)
		tErr := utils.PopulateTransFormError("1009", detailedmessage)
		return "", tErr
	}

	iteratedData := data
	iteratedData.JsonIgnoreProperty = jsonProperty
	dat := iteratedData.Jqdata.From(arrName).Get()
	err := iteratedData.Jqdata.Error()
	if !iteratedData.JsonIgnoreProperty && err != nil {
		erMsg := err.Error()
		erMsg = erMsg[27:] // taking specific part from the error message to making user understandable message.
		errMessage := "the arrayName : " + erMsg + ", is not found in the specified payload path " + arrName
		logger.Log.Error(data.LocalData, errMessage)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		return nil, tErr
	} else if iteratedData.JsonIgnoreProperty && err != nil {
		slice := []interface{}{}
		return slice, rs.TransformError{}
	}
	var arrayData []interface{}

	if dat != nil {
		var ok bool
		arrayData, ok = dat.([]interface{})
		if !ok {
			errMessage := fmt.Sprintf("the provided '%v', is not a array", arrName)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
	}

	if len(arrayData) == 0 {
		errMessage := fmt.Sprintf("The provided '%v' is an empty array; therefore, iteration will not be performed on it.", arrName)
		logger.Log.Info(data.LocalData, errMessage)
	}

	var arr = []interface{}{}
	var index = 0
	var res bool
	var tErr rs.TransformError
	config := filterConfig
	condtionsConfig := config.Condition
	logicalType := condtionsConfig.VType
	filterConditions := condtionsConfig.Rules

	for _, arrObject := range arrayData {
		responseBytes, _ := json.Marshal(arrObject)
		arrData := gojsonq.New().JSONString(string(responseBytes))
		subData := rs.JSONQData{Jqdata: arrData, ShouldReset: true, LocalData: data.LocalData, TransformedData: data.TransformedData, ErrorConfig: data.ErrorConfig, JsonIgnoreProperty: iteratedData.JsonIgnoreProperty, ErrorData: data.ErrorData, JsonIgnoreAliasValue: jsonIgnoreAliasValue, IsExceptionHandled: data.IsExceptionHandled}

		var statementDetails = rs.StatementDetails{
			TransformType: c.TRANSFORM,
			StatementPath: statementPath + ` [ iteration ] ` + transform.Name,
		}

		if len(filterConditions) != 0 {
			res, tErr = processRules(logicalType, filterConditions, subData, fn, statementPath)
			if tErr.Detailedmessage != nil {
				return nil, tErr
			}
		} else {
			res = true
		}

		if res {
			if breakStatement != nil {
				logger.Log.Trace(data.LocalData, "Executing break statement for transformation")
				flag, tErr := con(condition, subData, fn, statementPath)
				if tErr.Detailedmessage != nil {
					logger.Log.Error(data.LocalData, "Error while executing break condition in transformation")
					tErr.Detailedmessage = fmt.Sprintf("Error while executing break condition in transformation %v", tErr.Detailedmessage)
					return nil, tErr
				}
				if flag {
					logger.Log.Trace(data.LocalData, "transformation got terminated because of break condition is successfull")
					break
				}
			}

			utils.PushToMap(data.LocalData, "currentIndex", index, "number")
			tErr = fn(transform, subData, &arr, statementDetails)
			if tErr.Detailedmessage != nil {
				// tErr.Detailedmessage = "No of Errors in iterate Function are , they are ", +tErr.Detailedmessage
				tErr.Detailedmessage = fmt.Sprintf("error while iterating transformation %v, on %v array ", tErr.Detailedmessage, arrName)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return arr, tErr
			}
			index += 1
		}
	}

	delete(data.LocalData, "currentIndex")
	return arr, rs.TransformError{}
}

func makeMapFieldstoListOfFields(mm map[string]interface{}) []interface{} {
	var list []interface{}
	fields := mm["fields"].(map[string]interface{})
	for key, value := range fields {
		field := fmt.Sprint(value.(string) + " as " + key)
		list = append(list, field)
	}
	return list
}
