package functions

func permutations(prefix string, str string, results *[]string) {
	n := len(str)
	if n == 0 {
		*results = append(*results, prefix)
		return
	}
	for i := 0; i < n; i++ {
		permutations(prefix+string(str[i]), str[:i]+str[i+1:], results)
	}
}

func Shuffle(input string) []interface{} {
	var uniquePrimitives []interface{}
	var results []string

	permutations("", input, &results)

	uniqueResults := make(map[string]bool)
	for _, result := range results {
		uniqueResults[result] = true
	}
	for perm := range uniqueResults {
		uniquePrimitives = append(uniquePrimitives, perm)
	}
	return uniquePrimitives
}

func GenerateCombinations(strings []string, prefix string, combinations *[]string) {
	if len(strings) == 0 {
		*combinations = append(*combinations, prefix)
		return
	}

	for i, str := range strings {
		remaining := make([]string, len(strings)-1)
		copy(remaining[:i], strings[:i])
		copy(remaining[i:], strings[i+1:])

		GenerateCombinations(remaining, prefix+str, combinations)
	}
}
