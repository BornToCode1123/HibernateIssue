package functions

import (
	"fmt"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"strconv"
	"strings"
)

func Paginate(args map[string]interface{}, data rs.JSONQData) ([]interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function paginate")
	var page, size int
	var err error

	pgNo, err := utils.FindValue("pageNo", data)

	if err != nil {
		if strings.Contains(err.Error(), "is not found in the payload specified path") {
			pgNo = "0"
			// "The page number was not received from the payload; therefore, the default page number has been assigned."
		} else {
			errMsg := fmt.Sprintf("techincal error occured : %v", err)
			tErr := utils.PopulateTransFormError("1001", errMsg)
			logger.Log.Error(data.LocalData, errMsg)
			return nil, tErr
		}
	}

	data.ResetJsonqData()
	count, err := utils.FindValue("size", data)
	data.ResetJsonqData()

	if err != nil {
		if strings.Contains(err.Error(), "is not found in the payload specified path") {
			count = "30"
			// "The count was not received from the payload; therefore, the default count size has been applied."
		} else {
			errMsg := fmt.Sprintf("techincal error occured : %v", err)
			tErr := utils.PopulateTransFormError("1001", errMsg)
			logger.Log.Error(data.LocalData, errMsg)
			return nil, tErr
		}
	}

	if pgNo != nil || count != nil {

		switch value := pgNo.(type) {
		case string:
			page, err = strconv.Atoi(value)

			if err != nil {
				errMsg := fmt.Sprintf("error occured while converting pageNo %v to string", pgNo)
				tErr := utils.PopulateTransFormError("1001", errMsg)
				logger.Log.Error(data.LocalData, errMsg)
				return nil, tErr
			}

		case int:
			page = value

		case float64:
			page = int(value)
		}

		switch value := count.(type) {
		case string:
			size, err = strconv.Atoi(value)

			if err != nil {
				errMsg := fmt.Sprintf("error occured while converting pageNo %v to string", pgNo)
				tErr := utils.PopulateTransFormError("1001", errMsg)
				logger.Log.Error(data.LocalData, errMsg)
				return nil, tErr
			}

		case int:
			size = value

		case float64:
			size = int(value)
		}

	} else {
		errMsg := fmt.Sprintf("page number or size is null : pageNo : %v, size : %v ", pgNo, size)
		tErr := utils.PopulateTransFormError("1010", errMsg)
		logger.Log.Error(data.LocalData, errMsg)
		return nil, tErr
	}

	if page < 0 || size < 0 {
		errMsg := fmt.Sprintf("pageNo %v and size %v is invalid. Both values should be greater than 0", pgNo, size)
		tErr := utils.PopulateTransFormError("1001", errMsg)
		logger.Log.Error(data.LocalData, errMsg)
		return nil, tErr
	}

	skip := (page) * size
	paginateArray := args["arrayName"]
	if paginateArray != nil && paginateArray != "" {
		arrList, err := utils.FindValue(paginateArray.(string), data)

		if err != nil {
			logger.Log.Error(data.LocalData, err.Error())
			tErr := utils.PopulateTransFormError("1010", err.Error())
			return nil, tErr
		}

		list := arrList.([]interface{})
		if skip > len(list) {
			skip = len(list)
		}
		end := skip + size
		if end > len(list) {
			end = len(list)
		}
		return list[skip:end], rs.TransformError{}
	} else {
		errMessage := "ArrayPath is not specified in the pagination function"
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
}
