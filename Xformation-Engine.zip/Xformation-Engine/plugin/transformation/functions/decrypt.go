package functions

import (
	"crypto/cipher"
	"crypto/des"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"strings"
)

func Decrypt(funcArgs map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function decrypt")
	var decData interface{}
	var tErr rs.TransformError
	variable := funcArgs["value"].(string)

	dataVal, err := utils.FindValue(variable, data)
	if !data.JsonIgnoreProperty && err != nil {
		errMessage := fmt.Sprintf("in function 'decrypt' %v", err.Error())
		logger.Log.Error(data.LocalData, errMessage)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		return rs.ExpressionResult{}, tErr
	} else if data.JsonIgnoreProperty && err != nil {
		return rs.ExpressionResult{}, rs.TransformError{}
	}

	dataInput := dataVal.(string)
	decType := funcArgs["decType"]

	if decType == nil {
		errMessage := fmt.Sprintf("Decryption type cannot be empty")
		logger.Log.Error(data.LocalData, errMessage)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		return nil, tErr
	}

	switch decType {
	case "AES":
		decData, tErr = modeDecryption(data, dataInput, funcArgs, decType.(string))
	case "DES":
		decData, tErr = modeDecryption(data, dataInput, funcArgs, decType.(string))
	case "3DES":
		decData, tErr = modeDecryption(data, dataInput, funcArgs, decType.(string))
	default:
		errMessage := fmt.Sprintf("The decryption type  %v specified in the json is invalid", decType)
		logger.Log.Error(data.LocalData, errMessage)
		tErr = utils.PopulateTransFormError("1002", errMessage)
	}
	return decData, tErr
}

func modeDecryption(data rs.JSONQData, dat string, funcArgs map[string]interface{}, decType string) (interface{}, rs.TransformError) {
	var iv string
	var errorMsg string
	var trr rs.TransformError
	secretKey := funcArgs["decKey"]
	decMode := funcArgs["decMode"]
	decodeType := funcArgs["decodeType"]

	if decMode == nil {
		decMode = "CBC"
	}
	if decMode == "GCM" && decType != "AES" {
		errMessage := fmt.Sprintf("GCM mode is applicable only for decryption type AES")
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}

	// setting default Secret key & IV if they are not provided
	secretKey, iv, trr = defaultSecretAndIV(data, decType, decMode, secretKey, funcArgs, iv)
	if trr.Detailedmessage != nil {
		trr.Detailedmessage = fmt.Sprintf("error in getting secretkey & IV while decryption %v", trr.Detailedmessage)
		return nil, trr
	}
	if decType == "AES" && decMode != "GCM" && len(iv) != 16 {
		errorMsg = fmt.Sprintf("IV length specified is incorrect, please pass the IV of size 16")
	} else if decType == "AES" && decMode == "GCM" && len(iv) != 12 {
		errorMsg = fmt.Sprintf("IV length specified is incorrect, please pass the IV of size 12")
	} else if (decType == "DES" || decType == "3DES") && len(iv) != 8 {
		errorMsg = fmt.Sprintf("IV length specified is incorrect, please pass the IV of size 8")
	}
	if errorMsg != "" {
		tErr := utils.PopulateTransFormError("1010", errorMsg)
		return nil, tErr
	}
	bs := []byte(iv)

	block, tErr := blockCipherCreation(data, decType, secretKey.(string))

	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in creation of Cipher %v", tErr.Detailedmessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	switch decMode {
	case "ECB":
		return ECBDec(data, dat, block, decodeType)

	case "CBC":
		return CBCDec(data, bs, dat, block, decodeType)

	case "CFB":
		return CFBDec(data, bs, dat, block, decodeType)

	case "OFB":
		return OFBDec(data, bs, dat, block, decodeType)

	case "CTR":
		return CTRDec(data, bs, dat, block, decodeType)

	case "GCM":
		if secretKey == nil {
			secretKey = AESGCMSecretKey
		}
		return GCMDec(data, block, dat, bs, decodeType)

	default:
		errMsg := fmt.Sprintf("The decryption mode  %v specified in the json is invalid", decMode)
		tErr = utils.PopulateTransFormError("1002", errMsg)
		logger.Log.Error(data.LocalData, errMsg)
		return nil, tErr
	}

}

func ECBDec(data rs.JSONQData, plainText interface{}, block cipher.Block, decodeType interface{}) (interface{}, rs.TransformError) {
	decodedText, tErr := Decode(data, plainText.(string), decodeType)
	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in decode: %v", tErr.Detailedmessage)
		return nil, tErr
	}
	blockMode := NewECBDecrypter(block)
	origData := make([]byte, len(decodedText))
	blockMode.CryptBlocks(origData, decodedText)
	origData = PKCS5UnPadding(origData)
	return string(origData), rs.TransformError{}
}

func CBCDec(data rs.JSONQData, iv []byte, dat string, block cipher.Block, decodeType interface{}) (interface{}, rs.TransformError) {
	cipherText, tErr := Decode(data, dat, decodeType)
	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in decode: %v", tErr.Detailedmessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	cfb := cipher.NewCBCDecrypter(block, iv)
	decrypted := make([]byte, len(cipherText))
	cfb.CryptBlocks(decrypted, cipherText)
	return string(PKCS5Trimming(decrypted)), rs.TransformError{}
}

func CFBDec(data rs.JSONQData, iv []byte, dat string, block cipher.Block, decodeType interface{}) (interface{}, rs.TransformError) {
	cipherText, tErr := Decode(data, dat, decodeType)
	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in decode: %v", tErr.Detailedmessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	cfb := cipher.NewCFBDecrypter(block, iv)
	plainText := make([]byte, len(cipherText))
	cfb.XORKeyStream(plainText, cipherText)
	return string(plainText), rs.TransformError{}
}

func OFBDec(data rs.JSONQData, iv []byte, dat string, block cipher.Block, decodeType interface{}) (interface{}, rs.TransformError) {
	cipherText, tErr := Decode(data, dat, decodeType)
	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in decode: %v", tErr.Detailedmessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	cfb := cipher.NewOFB(block, iv)
	plainText := make([]byte, len(cipherText))
	cfb.XORKeyStream(plainText, cipherText)
	return string(plainText), rs.TransformError{}
}

func CTRDec(data rs.JSONQData, iv []byte, dat string, block cipher.Block, decodeType interface{}) (interface{}, rs.TransformError) {
	cipherText, tErr := Decode(data, dat, decodeType)
	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in decode: %v", tErr.Detailedmessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	cfb := cipher.NewCTR(block, iv)
	plainText := make([]byte, len(cipherText))
	cfb.XORKeyStream(plainText, cipherText)
	return string(plainText), rs.TransformError{}
}

func GCMDec(data rs.JSONQData, block cipher.Block, dat string, bs []byte, decodeType interface{}) (interface{}, rs.TransformError) {
	msg, tErr := Decode(data, dat, decodeType)
	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in decode: %v", tErr.Detailedmessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	if len(bs) != 12 {
		errMsg := fmt.Sprintf("IV length specified (%v) is invalid, Please pass the IV of size 12", bs)
		tErr = utils.PopulateTransFormError("1010", errMsg)
		logger.Log.Error(data.LocalData, errMsg)
		return nil, tErr
	}
	aesgcm, err := cipher.NewGCM(block)
	if err != nil {
		errMessage := fmt.Sprintf("Error while creating cipher")
		tErr := utils.PopulateTransFormError("1001", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	pt, err := aesgcm.Open(nil, bs, msg, nil)
	if err != nil {
		errMessage := fmt.Sprintf("Error while decrypting gcm")
		tErr := utils.PopulateTransFormError("1001", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	return string(pt), rs.TransformError{}
}

func DES3Dec(data rs.JSONQData, funcArgs map[string]interface{}, dat string) (interface{}, error) {

	ciphertext, _ := hex.DecodeString(dat)
	secretKey := funcArgs["encKey"]
	if secretKey == nil {
		secretKey = DES3Key
	}
	c, err := des.NewTripleDESCipher([]byte(secretKey.(string)))

	if err != nil {
		errMessage := fmt.Sprintf("decrypt NewTripleDESCipher(%d bytes) = %s", len(DES3Key), err)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, errors.New(errMessage)
	}
	plain := make([]byte, len(ciphertext))
	c.Decrypt(plain, ciphertext)
	decStr := string(plain[:])
	return decStr, err
}

type ecbDecrypter ecb

func NewECBDecrypter(b cipher.Block) cipher.BlockMode {
	return (*ecbDecrypter)(newECB(b))
}

func (x *ecbDecrypter) BlockSize() int { return x.blockSize }

func (x *ecbDecrypter) CryptBlocks(dst, src []byte) {
	if len(src)%x.blockSize != 0 {
		panic("crypto/cipher: input not full blocks")
	}
	if len(dst) < len(src) {
		panic("crypto/cipher: output smaller than input")
	}
	if len(src) == 0 {
		return
	}

	for len(src) > 0 {
		x.b.Decrypt(dst[:x.blockSize], src[:x.blockSize])
		src = src[x.blockSize:]
		dst = dst[x.blockSize:]
	}

}

func Decode(data rs.JSONQData, inputString string, decodeType interface{}) ([]byte, rs.TransformError) {
	var dat []byte
	var err error
	if decodeType != nil && strings.EqualFold(decodeType.(string), "hex") {
		dat, err = hex.DecodeString(inputString)
	} else if decodeType == nil || strings.EqualFold(decodeType.(string), "Base64") {
		dat, err = base64.StdEncoding.DecodeString(inputString)
	} else {
		errMsg := fmt.Sprintf("Invalid decode type. Please specify base64 or hex")
		tErr := utils.PopulateTransFormError("1010", errMsg)
		logger.Log.Error(data.LocalData, errMsg)
		return nil, tErr
	}
	if err != nil {
		errMessage := fmt.Sprintf("Given decode type %v doesn't fit for the text provided", decodeType)
		tErr := utils.PopulateTransFormError("1008", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	return dat, rs.TransformError{}
}
