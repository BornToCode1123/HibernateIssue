package functions

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	c "jocata_transform_plugin/constants"
	"os"

	logger "jocata_transform_plugin/log"
	par "jocata_transform_plugin/parse"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"net/http"
	"reflect"
	"strings"
	"time"

	"github.com/thedevsaddam/gojsonq/v2"
)

func updateUrlWithQueryParams(data rs.JSONQData, urlToBeCalled string, params interface{}) string {
	urlToBeCalled += "?"
	logger.Log.Trace(data.LocalData, "result params %v: ", params)
	logger.Log.Trace(data.LocalData, "map interface %v: ", params.(map[string]interface{}))
	for k, v := range params.(map[string]interface{}) {
		if v == nil {
			k = strings.ReplaceAll(k, " ", "%20")
			urlToBeCalled += fmt.Sprintf("%v=null&", k)
		} else {
			k = strings.ReplaceAll(k, " ", "%20")
			v = strings.ReplaceAll(v.(string), " ", "%20")
			urlToBeCalled += fmt.Sprintf("%v=%v&", k, v)
		}
	}

	logger.Log.Trace(data.LocalData, "url before appending %v: ", urlToBeCalled)
	updatedUrlToBeCalled := ""
	if len(urlToBeCalled) > 0 {
		updatedUrlToBeCalled = urlToBeCalled[:len(urlToBeCalled)-1]
	}
	return updatedUrlToBeCalled
}

func processResponse(data rs.JSONQData, response *http.Response, url string, err error, contentType string, hcd rs.HostConnectionDetails, timeTaken time.Duration) (interface{}, rs.TransformError) {

	if response == nil {
		logger.Log.Trace(data.LocalData, err)
		logger.Log.Trace(data.LocalData, "Empty response received while calling %v, %v", url, err)
		tErr := utils.PopulateTransFormError("1006", ("Empty response received while calling " + url + err.Error()))
		return rs.ExpressionResult{}, tErr
	}

	logger.Log.Trace(data.LocalData, "response after API Rest call %v: ", response)
	logger.Log.Trace(data.LocalData, "status :  %v", response.Status)
	logger.Log.Info(data.LocalData, "status code after api rest call :  %v", response.StatusCode)

	responseMap := make(map[string]interface{})
	headersMap := make(map[string]interface{})

	for key, val := range response.Header {
		for _, value := range val {
			headersMap[key] = value
		}
	}

	responseMap[c.HEADERS] = headersMap
	responseMap[c.STATUS_CODE] = response.StatusCode
	responseMap[c.ERROR] = nil
	responseMap[c.BODY] = nil
	responseMap[c.TIME_TAKEN] = timeTaken.Seconds()

	logger.Log.Trace(data.LocalData, "--------------------------------------------")
	logger.Log.Info(data.LocalData, "time taken for apiRest call %v", timeTaken.Seconds())
	logger.Log.Trace(data.LocalData, "--------------------------------------------")

	if err != nil {
		logger.Log.Trace(data.LocalData, "Error received while calling %v and detailed error %v,", url, err)
		responseMap["error"] = err
		return responseMap, rs.TransformError{}

	} else if response.StatusCode == http.StatusOK || response.StatusCode == http.StatusCreated {

		defer response.Body.Close()
		body, err := io.ReadAll(response.Body)
		logger.Log.Trace(data.LocalData, "response Body:  %v", string(body))
		if err != nil {
			logger.Log.Error(data.LocalData, "Error while reading response body : %v", err)
			tErr := utils.PopulateTransFormError("1001", err.Error())
			return nil, tErr
		}

		//RestCall Json Schema Validation
		logger.Log.Debug(data.LocalData, "----------------------Doing RestCall Json Schema Validation----------------------")
		if hcd.JsonSchema != nil {
			if _, tErr := utils.EvaluateJsonSchema(hcd.JsonSchema, body, nil); tErr.Detailedmessage != nil {
				logger.Log.Error(data.LocalData, "Error preparing jsonschema and payload:%v", tErr.Detailedmessage)
				return nil, tErr
			} else {
				logger.Log.Debug(data.LocalData, "Validation successful. Proceeding with transformation.")
			}
		}

		payload, err := par.ParseInput(data.LocalData, contentType, body)
		if err != nil {
			logger.Log.Error(data.LocalData, "Error while parsing the output : %v", err)
			tErr := utils.PopulateTransFormError("1009", err.Error())
			return nil, tErr
		}

		responseMap["body"] = payload

		logger.Log.Trace(data.LocalData, "Successful Rest call with : %v", url)
		return responseMap, rs.TransformError{}

	} else {
		if response.Body != nil {
			body, err := io.ReadAll(response.Body)
			if err != nil {
				tErr := utils.PopulateTransFormError("1001", err.Error())
				return nil, tErr
			}
			defer response.Body.Close()
			if string(body) == "{}" {
				body = []byte(response.Status)
			}
			responseMap["body"] = string(body)
			logger.Log.Trace(data.LocalData, "response after API Rest call %v : ", string(body))
			return responseMap, rs.TransformError{}
		}

		logger.Log.Trace(data.LocalData, " resp statusCode %v,url :   %v, respBody : %v", response.StatusCode, url, response.Body)
		tErr := utils.PopulateTransFormError("1009", (" Response status is other than 200 received while calling " + url))
		return rs.ExpressionResult{}, tErr
	}
}

func ApiRestCall(hcd rs.HostConnectionDetails, data rs.JSONQData) (interface{}, rs.TransformError) {

	connectionTimeout := time.Duration(hcd.ConnectionTimeout)
	readTimeout := time.Duration(hcd.ReadTimeout)
	insecureSkipVerify := hcd.AllowInsecureConnection
	retryCount := int(hcd.RetriggerCount)
	customHeaders := hcd.CustomHeaders
	var body interface{}

	urlToBeCalled, tErr := getHostUrl(hcd, data)
	if tErr.Detailedmessage != nil {
		return nil, tErr
	}

	if hcd.Body != "" && !hcd.IsDataSetOrFormTemplate {
		var err error
		body, err = utils.FindValue(hcd.Body, data)
		if err != nil {
			tErr := utils.PopulateTransFormError("1010", err.Error())
			return nil, tErr
		}
		logger.Log.Trace(data.LocalData, "request body received successfully")
	}

	contentInputType := "json"
	if hcd.ContentInputType != "" {
		contentInputType = hcd.ContentInputType
		logger.Log.Trace(data.LocalData, "contentInputType : %v", contentInputType)
	}

	contentOutputType := "json"
	if hcd.ContentOutputType != "" {
		contentOutputType = hcd.ContentOutputType
		logger.Log.Trace(data.LocalData, "contentOutputType : %v", contentOutputType)
	}

	header, err := utils.FindValue(hcd.Headers, data)
	if err != nil {
		tErr := utils.PopulateTransFormError("1010", err.Error())
		return nil, tErr
	}

	logger.Log.Trace(data.LocalData, "header : %v", header)

	if insecureSkipVerify {
		logger.Log.Trace(data.LocalData, "This connection is not secured")
	}

	client := NewRetryableClient(connectionTimeout, readTimeout, insecureSkipVerify, retryCount)

	var req *http.Request
	var req_err error

	logger.Log.Trace(data.LocalData, "entering into %v method ", hcd.MethodType)

	switch hcd.MethodType {

	case c.POST:
		{
			var bodyContent string
			if hcd.IsHostCall {
				bodyContent = hcd.RequestBody
			} else if hcd.IsDataSetOrFormTemplate {
				bodyContent = hcd.Body
			} else if body == nil {
				bodyContent = "{}"
			} else {
				bodyMap := make(map[string]interface{})
				if contentInputType == "text" {
					bodyMap["text"] = body
				} else {
					bodyMap = body.(map[string]interface{})
				}

				payload, err := par.ParseOutput(data.LocalData, contentInputType, bodyMap)

				if err != nil {
					tErr := utils.PopulateTransFormError("1009", err.Error())
					logger.Log.Error(data.LocalData, "Error While parsing request Body")
					return nil, tErr
				}

				bodyContent = string(payload)
				logger.Log.Trace(data.LocalData, "request Body before proceeding to to API Rest call : %v", bodyContent)
			}

			req, req_err = http.NewRequest(hcd.MethodType, urlToBeCalled, strings.NewReader(bodyContent))
			if req_err != nil {
				logger.Log.Error(data.LocalData, "Error in  calling POST request with url: %v", urlToBeCalled)
				logger.Log.Error(data.LocalData, "Error is: %v", req_err)
			}

			if header != nil {
				if reflect.ValueOf(header).Kind() == reflect.Map {
					logger.Log.Trace(data.LocalData, ".........headers.........")
					for key, value := range header.(map[string]interface{}) {
						logger.Log.Trace(data.LocalData, "%v : %v", key, value)
						req.Header.Set(key, value.(string))
					}
				} else {
					logger.Log.Error(data.LocalData, "Headers should be of map[string]interface{} ")
					tErr := utils.PopulateTransFormError("1001", "Headers should be of map")
					return rs.ExpressionResult{}, tErr
				}
			} else {
				logger.Log.Error(data.LocalData, "Empty headers recieved ")
				tErr := utils.PopulateTransFormError("1001", ("Empty headers recieved"))
				return rs.ExpressionResult{}, tErr
			}

			for key, value := range customHeaders {
				logger.Log.Trace(data.LocalData, "%v : %v", key, value)
				req.Header.Set(key, value.(string))
			}

			logger.Log.Info(data.LocalData, "Doing api rest call to : %v", string(urlToBeCalled))

			startTime := time.Now()
			postresponse, err := client.Do(req)
			duration := time.Since(startTime)

			logger.Log.Trace(data.LocalData, "request %v: ", req)
			return processResponse(data, postresponse, urlToBeCalled, err, contentOutputType, hcd, duration)
		}
	case c.GET:
		{
			if header != nil {
				if body != nil {
					urlToBeCalled = updateUrlWithQueryParams(data, urlToBeCalled, body)
					logger.Log.Info(data.LocalData, "updated URL with params : %v", urlToBeCalled)
					r, err := json.Marshal(body)
					params := string(r)
					if err != nil {
						logger.Log.Error(data.LocalData, "Error in getting  %v ", params)
					}
					req, req_err = http.NewRequest(hcd.MethodType, urlToBeCalled, nil)
				} else {
					logger.Log.Trace(data.LocalData, "no url params for GET call, final URL is : %v", urlToBeCalled)
					req, req_err = http.NewRequest(hcd.MethodType, urlToBeCalled, nil)
				}

				if req_err != nil {
					logger.Log.Error(data.LocalData, "Error while forming GET request: %v", req_err)
					tErr := utils.PopulateTransFormError("Error while forming GET request: ", req_err.Error())
					return rs.ExpressionResult{}, tErr
				}

				if reflect.ValueOf(header).Kind() == reflect.Map {
					for key, value := range header.(map[string]interface{}) {
						logger.Log.Trace(data.LocalData, "%v : %v", key, value)
						_, ok := value.(string)
						if !ok {
							logger.Log.Error(data.LocalData, "Getting error because of while adding the %v key, it's value should be text", key)
						}
						req.Header.Set(key, value.(string))
					}

				} else {
					logger.Log.Error(data.LocalData, "Headers should be in the form of Object only")
					tErr := utils.PopulateTransFormError("1001", "Headers should be form of object")
					return rs.ExpressionResult{}, tErr
				}

				for key, value := range customHeaders {
					logger.Log.Trace(data.LocalData, "%v : %v", key, value)
					req.Header.Set(key, value.(string))
				}
			} else {
				logger.Log.Error(data.LocalData, "Empty headers recieved ")
				tErr := utils.PopulateTransFormError("1001", ("Empty headers recieved"))
				return rs.ExpressionResult{}, tErr
			}

			logger.Log.Info(data.LocalData, "Doing api rest call to : %v", urlToBeCalled)
			startTime := time.Now()
			getresponse, err := client.Do(req) //  API Rest call..
			duration := time.Since(startTime)
			return processResponse(data, getresponse, urlToBeCalled, err, contentOutputType, hcd, duration)
		}
	default:
		{
			logger.Log.Error(data.LocalData, "un supported method type for API Rest call Function")
			tErr := utils.PopulateTransFormError("1002", "un supported method type for API Rest call Function")
			return rs.ExpressionResult{}, tErr
		}
	}
}

func getHostUrl(hcd rs.HostConnectionDetails, data rs.JSONQData) (hostUrl string, tErr rs.TransformError) {

	var url string
	if hcd.URLPattern != "" {
		urlPattern, err := utils.FindValue(hcd.URLPattern, data)
		if err != nil {
			tErr = utils.PopulateTransFormError("1010", err.Error())
			return
		}
		url = urlPattern.(string)
	}

	hostUrl = hcd.Host + url
	logger.Log.Trace(data.LocalData, "hostUrl : %v", hostUrl)

	return
}

func ConnectingToHost(payloadBytes []byte, localMap map[string]interface{}, hcd rs.HostConnectionDetails) ([]byte, rs.TransformError) {

	hcd.IsHostCall = true
	hcd.Headers = "headers@local"

	if hcd.DynamicUrl != "" {
		hcd.URLPattern = hcd.DynamicUrl
	} else {
		hcd.Host = hcd.Host + hcd.URLPattern
		hcd.URLPattern = ""
	}

	switch hcd.MethodType {
	case c.POST:
		hcd.RequestBody = string(payloadBytes)
	case c.GET:
		var bodyMap map[string]interface{}
		if err := json.Unmarshal(payloadBytes, &bodyMap); err != nil {
			msg := fmt.Errorf("failed to parse JSON body: %w", err)
			tErr := utils.PopulateTransFormError("1002", msg)
			return nil, tErr
		}
		hcd.RequestParams = bodyMap
	}

	arrData := gojsonq.New().JSONString(string("{}"))
	data := rs.JSONQData{
		Jqdata:               arrData,
		ShouldReset:          true,
		LocalData:            localMap,
		TransformedData:      nil,
		JsonIgnoreProperty:   false,
		JsonIgnoreAliasValue: "",
	}

	res, tErr := ApiRestCall(hcd, data)
	if tErr.Detailedmessage != nil {
		return nil, tErr
	}

	var response = make(map[string]interface{})
	var result = make(map[string]interface{})

	if res != nil {
		result = res.(map[string]interface{})
	}

	bodyBytes, _ := json.Marshal(result["body"])
	json.Unmarshal(bodyBytes, &response)

	response["hostResponse"] = result
	resultBytes, _ := json.Marshal(response)

	for key, value := range result["headers"].(map[string]interface{}) {
		if key != "Content-Length" && value != "Nonce" {
			localMap[c.RESPONSE_HEADERS].(map[string]interface{})[key] = value
		}
	}

	return resultBytes, rs.TransformError{}
}

func SetCustomHeadersInRequest(localMap map[string]interface{}, req *http.Request, customHeaders map[string]interface{}) {
	logger.Log.Debug(localMap, "writing custom headers")

	if checkKeys(customHeaders) {
		if add := customHeaders["add"]; add != nil {
			logger.Log.Trace(localMap, "adding headers from request level in add object")
			for key, val := range add.(map[string]interface{}) {
				logger.Log.Debug(localMap, " %v : %v", key, val)
				switch value := val.(type) {
				case string:
					req.Header.Add(key, value)
				default:
					logger.Log.Trace(localMap, "Invalid headers. Please check the format and try again.key : %v, value : %v ", key, value)
				}
			}
		}

		if update := customHeaders["update"]; update != nil {
			logger.Log.Trace(localMap, "adding headers from request level in update object")
			for key, val := range update.(map[string]interface{}) {
				logger.Log.Debug(localMap, " %v : %v", key, val)
				switch value := val.(type) {
				case string:
					req.Header.Set(key, value)
				default:
					logger.Log.Trace(localMap, "Invalid headers. Please check the format and try again.key : %v, value : %v ", key, value)
				}
			}
		}

		if deleteHeaders := customHeaders["delete"]; deleteHeaders != nil {
			logger.Log.Trace(localMap, "adding headers from request level in add object")
			for _, header := range deleteHeaders.([]interface{}) {
				delete(req.Header, header.(string))
			}
		}
	} else {
		for key, val := range customHeaders {
			logger.Log.Debug(localMap, " %v : %v", key, val)
			switch value := val.(type) {
			case string:
				req.Header.Set(key, value)
			default:
				logger.Log.Trace(localMap, "Invalid headers. Please check the format and try again.key : %v, value : %v ", key, value)
			}
		}
	}
}

func TransferReqBodyToResp(localMap map[string]interface{}, req *http.Request) *http.Response {
	logger.Log.Trace(localMap, "request Body %v", req.Body)
	resp := &http.Response{
		Body: io.NopCloser(bytes.NewBufferString("KrakenD Service")),
	}
	body, _ := io.ReadAll(req.Body)
	resp.Body = io.NopCloser(bytes.NewBuffer(body))
	resp.ContentLength = int64(len(body))
	resp.StatusCode = 200
	resp.Header = req.Header
	logger.Log.Trace(localMap, "response Body %v", resp.Body)
	return resp
}

// func prepareCertificate() (tls.Certificate, rs.TransformError) {
// 	logger.Log.Trace(localMap, "entered into prepareCertificate")
// 	var clientCert tls.Certificate
// 	// Load the client certificate and key
// 	// clientCertPath := os.Getenv("PUBLIC_KEY")
// 	// clientKeyPath := os.Getenv("PRIVATE_KEY")

// 	clientCertPath := "C:\\SSL\\Self\\certificate.pem"
// 	clientKeyPath := "C:\\SSL\\Self\\private_key.pem"

// 	clientCert, err := tls.LoadX509KeyPair(clientCertPath, clientKeyPath)
// 	if err != nil {
// 		errMessage := fmt.Sprintf("Error loading client certificate and key: %v\n", err)
// 		logger.Log.Error(data.LocalData, errMessage)
// 		tErr := utils.PopulateTransFormError("1002", errMessage)
// 		return clientCert, tErr
// 	}
// 	logger.Log.Trace(data.LocalData, "certififcate : %v", clientCert)
// 	return clientCert, rs.TransformError{}
// }

func UpdateResponseHeaderContentType(contentOutput string, w http.ResponseWriter) {
	ContentType := "Content-Type"
	json := "application/json"
	if contentOutput == "json" {
		w.Header().Set(ContentType, json)
	}
}

func checkKeys(inputMap map[string]interface{}) bool {
	requiredKeys := []string{"add", "update", "delete"}

	for _, key := range requiredKeys {
		if _, exists := inputMap[key]; exists {
			return true
		}
	}
	return false
}

func SetCustomHeadersInResponse(localMap, customHeaders map[string]interface{}) {
	reseponseHeadersLocal := localMap["responseHeaders"].(map[string]interface{})
	logger.Log.Debug(localMap, "writing custom headers")
	if checkKeys(customHeaders) {
		if add := customHeaders["add"]; add != nil {
			logger.Log.Trace(localMap, "adding headers from request level in add object")
			for key, val := range add.(map[string]interface{}) {
				logger.Log.Debug(localMap, " %v : %v", key, val)
				switch value := val.(type) {
				case string:
					reseponseHeadersLocal[key] = value
				default:
					logger.Log.Trace(localMap, "Invalid headers. Please check the format and try again.key : %v, value : %v ", key, value)
				}
			}
		}

		if update := customHeaders["update"]; update != nil {
			logger.Log.Trace(localMap, "adding headers from request level in update object")
			for key, val := range update.(map[string]interface{}) {
				logger.Log.Debug(localMap, " %v : %v", key, val)
				switch value := val.(type) {
				case string:
					reseponseHeadersLocal[key] = value
				default:
					logger.Log.Trace(localMap, "Invalid headers. Please check the format and try again.key : %v, value : %v ", key, value)
				}
			}
		}

		if deleteHeaders := customHeaders["delete"]; deleteHeaders != nil {
			logger.Log.Debug(localMap, "adding headers from request level in add object")
			for _, header := range deleteHeaders.([]interface{}) {
				delete(reseponseHeadersLocal, header.(string))
			}
		}
	} else {
		for key, val := range customHeaders {
			logger.Log.Debug(localMap, " %v : %v", key, val)
			switch value := val.(type) {
			case string:
				reseponseHeadersLocal[key] = value
			default:
				logger.Log.Trace(localMap, "Invalid headers. Please check the format and try again.key : %v, value : %v ", key, value)
			}
		}
	}
}

func CallPublish(localMap map[string]interface{}, token string, alias string, projectId string) (rs.Config, error) {
	logger.Log.Trace(localMap, "Entered to call CallPublish() to get the config with alias ", alias)
	client := &http.Client{}
	publishedURL := os.Getenv("GENERIC_HOST_URL") + "/publish/getPublishDtlByCfgAlias"
	profile := os.Getenv("PROFILE")
	publishReq, err := http.NewRequest("GET", publishedURL, nil)
	if err != nil {
		logger.Log.Trace(localMap, "error while creating published request")
		return rs.Config{}, errors.New("error while creating published request")
	}

	query := publishReq.URL.Query()
	query.Add("configAlias", alias)
	query.Add("projectId", projectId)
	query.Add("env", profile)
	publishReq.URL.RawQuery = query.Encode()

	publishReq.Header.Add("Accept", "application/json")
	publishReq.Header.Add("Content-Type", "application/json")
	publishReq.Header.Add("Authorization", "Bearer "+token)
	logger.Log.Trace(localMap, "publish request for /publish/getPublishDtlByCfgAlias :", publishReq)
	publishResponse, err := client.Do(publishReq)

	if err != nil {
		logger.Log.Error(localMap, "error ", err)
		logger.Log.Error(localMap, "response after error ", publishResponse)
		return rs.Config{}, errors.New("error : " + err.Error() + " while connecting with : " + publishReq.URL.RawQuery)
	}

	if publishResponse == nil {
		logger.Log.Error(localMap, "response is null after calling the /publish/getPublishDtlByCfgAlias")
		return rs.Config{}, errors.New("response is null after calling the /publish/getPublishDtlByCfgAlias")
	}

	defer publishResponse.Body.Close()
	publishBody, err := io.ReadAll(publishResponse.Body)
	if err != nil {
		logger.Log.Error(localMap, "error while reading published response ", err)
		return rs.Config{}, errors.New("error while reading published response")
	}

	if publishResponse.StatusCode != 200 {
		errMessage := "error while calling to the database to fetch the config " + string(publishBody)
		logger.Log.Error(localMap, errMessage)
		return rs.Config{}, errors.New(errMessage)
	}

	return par.ParseConfig(localMap, publishBody)
}
