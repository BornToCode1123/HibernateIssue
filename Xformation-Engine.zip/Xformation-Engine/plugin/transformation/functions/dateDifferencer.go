package functions

import (
	"fmt"
	"jocata_transform_plugin/constants"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"time"
)

func CalculateDifferenceBetweenDates(args map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	data.ResetJsonqData()
	var then time.Time
	var now time.Time
	var format string

	if args["type"] != nil {
		format = args["type"].(string)
	}

	if args["init"] != nil {
		args = args["init"].(map[string]interface{})
	}

	start := args["start"].(map[string]interface{})
	startValue := start["value"].(string)
	startformat := start["format"].(string)

	end := args["end"].(map[string]interface{})
	endValue := end["value"].(string)
	endformat := end["format"].(string)

	startDataVal, err := utils.FindValue(startValue, data)

	if err != nil {
		errMessage := fmt.Sprintf("in the function date differencer provided start date : %v", err)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}

	data.ResetJsonqData()
	endDataVal, err := utils.FindValue(endValue, data)

	if err != nil {
		errMessage := fmt.Sprintf("in the function date differencer provided start date : %v", err)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}

	if startDataVal == nil || endDataVal == nil {
		errMessage := fmt.Sprintf("startDate %v, or EndDate %v are null, so can't calculate the difference!", startDataVal, endDataVal)
		logger.Log.Error(data.LocalData, errMessage)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		return nil, tErr
	}

	startDate, err := DateFormat(data, startDataVal.(string), "yyyy-MM-dd", startformat)
	if err != nil {
		tErr := utils.PopulateTransFormError("1001", err.Error())
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	endDate, err := DateFormat(data, endDataVal.(string), "yyyy-MM-dd", endformat)
	if err != nil {
		tErr := utils.PopulateTransFormError("1001", err.Error())
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	if startDate != nil && endDate != nil {
		then, _ = time.Parse("2006-01-02", startDate.(string))
		now, _ = time.Parse("2006-01-02", endDate.(string))
	}

	result, err := GetDifference(data, now, then, format)
	if err != nil {
		tErr := utils.PopulateTransFormError("1001", err.Error())
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}

	return result, rs.TransformError{}
}

func CalculateDifferenceFromToday(args map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	var then time.Time
	var format string

	if args["type"] != nil {
		format = args["type"].(string)
	}

	if args["init"] != nil {
		args = args["init"].(map[string]interface{})
	}

	inputDate := args["value"].(string)
	inoutFormat := args["format"].(string)

	inputDateValue, err := utils.FindValue(inputDate, data)

	if err != nil {
		tErr := utils.PopulateTransFormError("1001", err.Error())
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}

	inputFormattedDate, err := DateFormat(data, inputDateValue.(string), "yyyy-MM-dd", inoutFormat)

	if inputFormattedDate != nil {
		then, _ = time.Parse("2006-01-02", inputFormattedDate.(string))
	}
	if err != nil {
		errMessage := fmt.Sprintf("in the function date differencer provided input date : %v", err)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}

	result, err := GetDifferenceFromToday(data, then, format)
	if err != nil {
		tErr := utils.PopulateTransFormError("1001", err.Error())
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	return result, rs.TransformError{}
}
func GetLastDate(date time.Time, typeOfDate string) string {

	switch typeOfDate {
	case "day":
		year, month := date.Year(), date.Month()
		lastDay := getLastDate(year, month)
		return lastDay.Format(dateFormats["dd-MM-yyyy"])
	}
	return ""
}

func getLastDate(year int, month time.Month) time.Time {
	yr, mon, day, _ := PlusMonths(year, int(month), 1, 1)
	kk, _ := PlusDays(yr, int(mon), day, -1)
	return kk
}

func IsDateEmpty(args map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	if args["init"] != nil {
		args = args["init"].(map[string]interface{})
	}
	if args["value"] == nil {
		errMessage := fmt.Sprintf("in function '%v'", constants.IS_EMPTY+" value key is missing in configuration.")
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	inputDate := args["value"].(string)
	inputDateValue, _ := utils.FindValue(inputDate, data)
	if inputDateValue == nil {
		return true, rs.TransformError{}
	}
	if str, ok := inputDateValue.(string); ok {
		return str == "", rs.TransformError{}
	}

	return false, rs.TransformError{}
}
