package functions

import (
	"fmt"
	"jocata_transform_plugin/constants"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"math"
	"strconv"
)

func FormatNumber(inputData map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function number")
	conversion := inputData["format"].(string)
	initValuesMap := inputData["init"].(map[string]interface{})
	var variable string
	var precision int
	var err error
	val := inputData["value"]
	if val != nil {
		precision = int(val.(float64))
	}
	var value interface{}
	if initValuesMap["value"] != nil {
		variable = initValuesMap["value"].(string)
		value, err = utils.FindValue(variable, data)
	}

	if err != nil && conversion != constants.IS_EMPTY {
		errMessage := fmt.Sprintf("in function '%v' %v", conversion, err.Error())
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}

	if data.JsonIgnoreProperty && value == nil && conversion != constants.IS_EMPTY {
		return nil, rs.TransformError{}
	}

	switch conversion {
	case "ceil":
		val, ok := value.(float64)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' : the %v is not a number", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return math.Ceil(val), rs.TransformError{}
	case "floor":
		val, ok := value.(float64)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' : the %v is not a number", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return math.Floor(val), rs.TransformError{}
	case "round":
		val, ok := value.(float64)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' : the %v is not a number", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return math.Round(val), rs.TransformError{}
	case "roundWithDecimal":
		val, ok := value.(float64)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' : the %v is not a number", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return Round(val, precision), rs.TransformError{}
	case "getNonDecimal":
		val, ok := value.(float64)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' : the %v is not a number", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return int64(val), rs.TransformError{}
	case "getDecimal":
		val, ok := value.(float64)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' : the %v is not a number", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		_, div := math.Modf(val)
		return div, rs.TransformError{}
	case "toText":

		switch res := value.(type) {
		case string:
			return res, rs.TransformError{}
		case float64:
			s := strconv.FormatFloat(res, 'g', 15, 64)
			return s, rs.TransformError{}
		}
		errMessage := fmt.Sprintf("Given value was %v Invalid for text conversion", value)
		tErr := utils.PopulateTransFormError("1001", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr

	case "toASCII":
		var s string
		switch res := value.(type) {
		case string:
			s = res
		case float64:
			s = strconv.FormatFloat(res, 'g', 15, 64)
		}

		if len(s) > 1 {
			errMessage := fmt.Sprintf("given value to find out the ASCII : %v, has more than one character", value)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		ascii := int(rune(s[0]))
		return ascii, rs.TransformError{}
	case constants.IS_EMPTY:
		if initValuesMap["value"] == nil {
			errMessage := fmt.Sprintf("in function '%v'", constants.IS_EMPTY+" value key is missing in configuration.")
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return value == nil, rs.TransformError{}
	default:
		errMessage := fmt.Sprintf("Given Format was  %v is Invalid for Keyword", conversion)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
}

func Round(val float64, precision int) float64 {
	return math.Round(val*(math.Pow10(precision))) / math.Pow10(precision)
}
