package functions

import (
	"bytes"
	"crypto/tls"
	"io"
	"math"
	"net"
	"net/http"
	"time"
)

var RetryCount = 0

func backoff(retries int) time.Duration {
	return time.Duration(math.Pow(2, float64(retries))) * time.Second
}

func shouldRetry(err error, resp *http.Response) bool {
	if err != nil {
		return true
	}

	if resp.StatusCode == http.StatusNotFound ||
		resp.StatusCode == http.StatusServiceUnavailable ||
		resp.StatusCode == http.StatusGatewayTimeout {
		return true
	}
	return false
}

func drainBody(resp *http.Response) {
	if resp.Body != nil {
		io.Copy(io.Discard, resp.Body)
		resp.Body.Close()
	}
}

type retryableTransport struct {
	RetryCount int
	transport  http.RoundTripper
}

func (t *retryableTransport) RoundTrip(req *http.Request) (*http.Response, error) {

	var bodyBytes []byte
	RetryCount = t.RetryCount

	if req.Body != nil {
		bodyBytes, _ = io.ReadAll(req.Body)
		req.Body = io.NopCloser(bytes.NewBuffer(bodyBytes))
	}

	resp, err := t.transport.RoundTrip(req)

	retries := 0

	for shouldRetry(err, resp) && retries < RetryCount {

		time.Sleep(backoff(retries))
		if resp != nil {
			drainBody(resp)
		}

		if req.Body != nil {
			req.Body = io.NopCloser(bytes.NewBuffer(bodyBytes))
		}
		resp, err = t.transport.RoundTrip(req)
		retries++
	}
	return resp, err
}

func NewRetryableClient(connectionTimeout, readTimeout time.Duration, insecureSkipVerify bool, retryCount int) *http.Client {

	transport := &retryableTransport{
		RetryCount: retryCount,
		transport: &http.Transport{
			Dial:                  (&net.Dialer{Timeout: connectionTimeout * time.Second}).Dial, // connectionTime
			ResponseHeaderTimeout: readTimeout * time.Second,                                    // read TimeOut
			TLSClientConfig: &tls.Config{
				InsecureSkipVerify: insecureSkipVerify, // insecurityVerify for the SSL certificate..
			},
		},
	}

	return &http.Client{
		Transport: transport,
	}
}
