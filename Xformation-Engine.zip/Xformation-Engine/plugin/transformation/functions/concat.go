package functions

import (
	"fmt"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"strings"
)

func ConcatData(funcArgs map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function concat")
	var toBeConcatenatedValue = make(map[string]interface{})
	if funcArgs["toBeConcatenatedValue"] != nil {
		toBeConcatenatedValue = funcArgs["toBeConcatenatedValue"].(map[string]interface{})
	} else {
		toBeConcatenatedValue = funcArgs
	}

	ConcatenatedValue := toBeConcatenatedValue["value"].(string)
	ConcatenatedValues := toBeConcatenatedValue["values"].([]interface{})
	var concatWith string
	conWith := toBeConcatenatedValue["concatWith"]
	if conWith != nil {
		concatWith = conWith.(string)
	} else {
		concatWith = ""
	}

	var finalString interface{}
	var concatMessage []string
	data.ResetJsonqData()
	var err error

	finalString, err = utils.FindValue(ConcatenatedValue, data)

	if err != nil {
		errMessage := fmt.Sprintf("in function 'concat' %v", err.Error())
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}

	if finalString != nil && finalString != "" {
		concatMessage = append(concatMessage, finalString.(string))
	}

	for _, field := range ConcatenatedValues {
		data.ResetJsonqData()
		fieldKey := field.(string)
		var value interface{}
		value, err = utils.FindValue(fieldKey, data)
		if err != nil {
			errMessage := fmt.Sprintf("in function 'concat' %v", err.Error())
			tErr := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		if value != nil {
			concatMessage = append(concatMessage, value.(string))
		}
	}
	if concatWith != "" {
		logger.Log.Trace(data.LocalData, "values are collected, concating with %v character", concatWith)
	} else {
		logger.Log.Trace(data.LocalData, "values are collected, concating without any character")
	}

	return strings.Join(concatMessage, concatWith), rs.TransformError{}
}
