package functions

import (
	"bytes"
	"errors"
	"fmt"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"math"
	"reflect"
	"regexp"
	"strconv"
	"strings"
)

func FormatCurrency(inputData map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function currency")
	outputFormat := inputData["format"].(string)
	initValuesMap := inputData["init"].(map[string]interface{})

	if initValuesMap != nil {
		var value interface{}
		var err error
		variable := initValuesMap["value"].(string)

		value, err = utils.FindValue(variable, data)
		if err != nil {
			tErr := utils.PopulateTransFormError("1010", err.Error())
			logger.Log.Error(data.LocalData, err.Error())
			return nil, tErr
		}
		var res interface{}

		if value != nil {
			if initValuesMap["format"] == "number" {
				res, err = FormattedValue(data, value, outputFormat)

			} else if initValuesMap["format"] == "text" {
				val, err := strconv.ParseFloat(value.(string), 64)
				if err != nil {
					intVar, _ := strconv.Atoi(value.(string))
					res, err = FormattedValue(data, intVar, outputFormat)
				}
				res, err = FormattedValue(data, val, outputFormat)

			} else if _, ok := LocaleInfo[initValuesMap["format"].(string)]; ok {
				val := UnformatNumber(value.(string), 2, "INR")
				valFloat, _ := strconv.ParseFloat(val, 64)
				res, err = FormattedValue(data, valFloat, outputFormat)
			} else {
				errMessage := fmt.Sprintf("Invalid input Format %v", initValuesMap["format"])
				tErr := utils.PopulateTransFormError("1001", errMessage)
				return nil, tErr
			}

			if err != nil {
				tErr := utils.PopulateTransFormError("1001", err.Error())
				logger.Log.Error(data.LocalData, err.Error())
				return nil, tErr
			}
			return res, rs.TransformError{}
		} else {
			errMessage := fmt.Sprintf("the Variable which is you provide %v is nil, or not in the payload", variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, err.Error())
			return nil, tErr
		}
	}
	errMessage := fmt.Sprintf("invalid init, Have, %v, Want init{}", inputData)
	tErr := utils.PopulateTransFormError("1001", errMessage)
	logger.Log.Error(data.LocalData, errMessage)
	return nil, tErr
}

func FormattedValue(data rs.JSONQData, value interface{}, outputFormat string) (interface{}, error) {
	formatDetails := LocaleInfo[outputFormat]
	ac := Accounting{Symbol: formatDetails.ComSymbol, Precision: formatDetails.FractionLength, Thousand: formatDetails.ThouSep, Decimal: formatDetails.DecSep}
	if outputFormat == "text" {
		valText := fmt.Sprintf("%v", value)
		return valText, nil
	} else if outputFormat == "number" {
		return value, nil
	} else if _, ok := LocaleInfo[outputFormat]; ok {
		return ac.FormatMoney(value), nil
	} else {
		errMessage := fmt.Sprintf("invalid output Format %v ", outputFormat)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, errors.New(errMessage)
	}
}

type Locale struct {
	Name           string // currency name
	FractionLength int    // default decimal length
	ThouSep        string // thousands seperator
	DecSep         string // decimal seperator
	SpaceSep       string // space seperator
	UTFSymbol      string // UTF symbol
	HTMLSymbol     string // HTML symbol
	ComSymbol      string // Common symbol
	Pre            bool   // symbol before or after currency
}

const empty string = ""

// all currency formats map

var LocaleInfo map[string]Locale = map[string]Locale{
	"AED": {"UAE Dirham", 2, ",", ".", " ", empty, empty, "Dhs.", true},
	"AFA": {"Afghani", 0, empty, empty, "060B", "&#x060B;", empty, "؋", true},
	"ALL": {"Lek", 2, empty, empty, "", empty, empty, "Lek ", true},
	"AMD": {"Armenian Dram", 2, ",", ".", "", empty, empty, "֏", false},
	"ANG": {"Antillian Guilder", 2, ".", ",", " ", "0192", "&#x0192;", "ƒ", true},
	"AOA": {"New Kwanza", 0, empty, empty, "", empty, empty, "Kz ", true},
	"ARS": {"Argentine Peso", 2, ".", ",", "", "20B1", "&#x20B1;", "$", true},
	"ATS": {"Schilling", 2, ".", ",", " ", empty, empty, "öS ", true},
	"AUD": {"Australian Dollar", 2, " ", ".", "", "0024", "&#x0024;", "$", true},
	"AWG": {"Aruban Guilder", 2, ",", ".", " ", "0192", "&#x0192;", "ƒ", true},
	"AZN": {"Azerbaijanian Manat", 2, empty, empty, "", empty, empty, "₼", true},
	"BAM": {"Convertible Marks", 2, ",", ".", "", empty, empty, "KM ", false},
	"BBD": {"Barbados Dollar", 2, empty, empty, "", "0024", "&#x0024;", "Bds$ ", true},
	"BDT": {"Taka", 2, ",", ".", " ", empty, empty, "Tk ", true},
	"BEF": {"Belgian Franc", 0, ".", "", " ", "20A3", "&#x20A3;", "BEF ", true},
	"BGN": {"Lev", 2, " ", ",", " ", empty, empty, "лв", false},
	"BHD": {"Bahraini Dinar", 3, ",", ".", " ", empty, empty, "د.ب", true},
	"BIF": {"Burundi Franc", 0, empty, empty, "", empty, empty, "FBu ", true},
	"BMD": {"Bermudian Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"BND": {"Brunei Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"BOB": {"Bolivian Boliviano", 2, ",", ".", "", empty, empty, "$b", true},
	"BRL": {"Brazilian Real", 2, ".", ",", " ", "0052 0024", "R$", "R$", true},
	"BSD": {"Bahamian Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"BTN": {"Bhutan Ngultrum", 2, empty, empty, "", empty, empty, "BTN ", true},
	"BWP": {"Pula", 2, ",", ".", "", empty, empty, "P", true},
	"BYR": {"Belarussian Ruble", 0, empty, empty, "", empty, empty, "p. ", true},
	"BZD": {"Belize Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"CAD": {"Canadian Dollar", 2, ",", ".", "", "0024", "&#x0024;", "CA$", true},
	"CDF": {"Franc Congolais", 2, empty, empty, "", empty, empty, "FC ", true},
	"CHF": {"Swiss Franc", 2, "'", ".", " ", empty, empty, "CHF ", true},
	"CLP": {"Chilean Peso", 0, ".", "", "", "20B1", "&#x20B1;", "$", true},
	"CNY": {"Yuan Renminbi", 2, ",", ".", "", "5713", "&#x5713;", "¥", true},
	"COP": {"Colombian Peso", 2, ".", ",", "", "20B1", "&#x20B1;", "$", true},
	"CRC": {"Costa Rican Colon", 2, ".", ",", " ", "20A1", "&#x20A1;", "₡", true},
	"CUP": {"Cuban Peso", 2, ",", ".", " ", "20B1", "&#x20B1;", "$", true},
	"CVE": {"Cape Verde Escudo", 0, empty, empty, "", empty, empty, "$", true},
	"CYP": {"Cyprus Pound", 2, ".", ",", "", "00A3", "&#x00A3;", "£", true},
	"CZK": {"Czech Koruna", 2, ".", ",", " ", empty, empty, "Kč", false},
	"DEM": {"Deutsche Mark", 2, ".", ",", "", empty, empty, "DM ", false},
	"DJF": {"Djibouti Franc", 0, empty, empty, "", empty, empty, "DJF ", true},
	"DKK": {"Danish Krone", 2, ".", ",", "", empty, empty, "kr.", true},
	"DOP": {"Dominican Peso", 2, ",", ".", " ", "20B1", "&#x20B1;", "$", true},
	"DZD": {"Algerian Dinar", 2, empty, empty, "", empty, empty, "DA", true},
	"ECS": {"Sucre", 0, empty, empty, "", empty, empty, "S.", true},
	"EEK": {"Kroon", 2, " ", ",", " ", empty, empty, "kr", false},
	"EGP": {"Egyptian Pound", 2, ",", ".", " ", "00A3", "&#x00A3;", "£", true},
	"ERN": {"Nakfa", 0, empty, empty, "", empty, empty, "NKf ", true},
	"ESP": {"Spanish Peseta", 0, ".", "", " ", "20A7", "&#x20A7;", "Ptas", false},
	"ETB": {"Ethiopian Birr", 0, empty, empty, "", empty, empty, "BR", true},
	"EUR": {"Euro", 2, ".", ",", "", "20AC", "&#x20AC;", "€", true},
	"FIM": {"Markka", 2, " ", ",", " ", empty, empty, "mk", false},
	"FJD": {"Fiji Dollar", 0, empty, empty, "", "0024", "&#x0024;", "FJ$", true},
	"FKP": {"Pound", 0, empty, empty, "", "00A3", "&#x00A3;", "£", true},
	"FRF": {"French Franc", 2, " ", ",", " ", "20A3", "&#x20A3;", "Fr", false},
	"GBP": {"Pound Sterling", 2, ",", ".", "", "00A3", "&#x00A3;", "£", true},
	"GEL": {"Lari", 0, empty, empty, "", empty, empty, "GEL ", true},
	"GHS": {"Cedi", 2, ",", ".", "", "20B5", "&#x20B5;", "₵", true},
	"GIP": {"Gibraltar Pound", 2, ",", ".", "", "00A3", "&#x00A3;", "£", true},
	"GMD": {"Dalasi", 0, empty, empty, "", empty, empty, "GMD ", true},
	"GNF": {"Guinea Franc", 0, empty, empty, empty, empty, empty, "FG", true},
	"GRD": {"Drachma", 2, ".", ",", " ", "20AF", "&#x20AF;", "GRD ", false},
	"GTQ": {"Quetzal", 2, ",", ".", "", empty, empty, "Q.", true},
	"GWP": {"Guinea-Bissau Peso", 0, empty, empty, empty, empty, empty, "GWP ", true},
	"GYD": {"Guyana Dollar", 0, empty, empty, "", "0024", "&#x0024;", "$", true},
	"HKD": {"Hong Kong Dollar", 2, ",", ".", "", "0024", "&#x0024;", "HK$", true},
	"HNL": {"Lempira", 2, ",", ".", " ", empty, empty, "L", true},
	"HRK": {"Kuna", 2, ".", ",", " ", empty, empty, "kn", false},
	"HTG": {"Gourde", 0, empty, empty, "", empty, empty, "G", true},
	"HUF": {"Forint", 0, ".", "", " ", empty, empty, "Ft", false},
	"IDR": {"Rupiah", 0, ".", ",", "", empty, empty, "Rp.", true},
	"IEP": {"Irish Pound", 2, ",", ".", "", "00A3", "&#x00A3;", "£", true},
	"ILS": {"New Israeli Sheqel", 2, ",", ".", " ", "20AA", "&#x20AA;", "₪", false},
	"INR": {"Indian Rupee", 2, ",", ".", "", "20A8", "&#x20A8;", "", false},
	"IQD": {"Iraqi Dinar", 3, empty, empty, "", empty, empty, "د.ع", true},
	"IRR": {"Iranian Rial", 2, ",", ".", " ", "FDFC", "&#xFDFC;", "﷼", true},
	"ISK": {"Iceland Krona", 2, ".", ",", " ", empty, empty, "kr", false},
	"ITL": {"Italian Lira", 0, ".", "", " ", "20A4", "&#x20A4;", "L.", true},
	"JMD": {"Jamaican Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"JOD": {"Jordanian Dinar", 3, ",", ".", " ", empty, empty, "JD", true},
	"JPY": {"Yen", 0, ",", "", "", "00A5", "&#x00A5;", "¥", true},
	"KES": {"Kenyan Shilling", 2, ",", ".", "", empty, empty, "Ksh", true},
	"KGS": {"Som", 0, empty, empty, "", empty, empty, "лв", true},
	"KHR": {"Riel", 2, empty, empty, "", "17DB", "&#x17DB;", "៛", true},
	"KMF": {"Comoro Franc", 0, empty, empty, "", empty, empty, "KMF ", true},
	"KPW": {"North Korean Won", 0, empty, empty, "", "20A9", "&#x20A9;", "₩", true},
	"KRW": {"Won", 0, ",", "", "", "20A9", "&#x20A9;", "₩", true},
	"KWD": {"Kuwaiti Dinar", 3, ",", ".", " ", empty, empty, "ك", true},
	"KYD": {"Cayman Islands Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"KZT": {"Tenge", 0, empty, empty, "", empty, empty, "₸", true},
	"LAK": {"Kip", 0, empty, empty, "", "20AD", "&#x20AD;", "₭", true},
	"LBP": {"Lebanese Pound", 0, " ", "", "", "00A3", "&#x00A3;", "ل.ل", false},
	"LKR": {"Sri Lanka Rupee", 0, empty, empty, "", "0BF9", "&#x0BF9;", "₨", true},
	"LRD": {"Liberian Dollar", 0, empty, empty, "", "0024", "&#x0024;", "$", true},
	"LSL": {"Lesotho Maloti", 0, empty, empty, "", empty, empty, "LSL ", true},
	"LTL": {"Lithuanian Litas", 2, " ", ",", " ", empty, empty, "Lt", false},
	"LUF": {"Luxembourg Franc", 0, "'", "", " ", "20A3", "&#x20A3;", "F", false},
	"LVL": {"Latvian Lats", 2, ",", ".", " ", empty, empty, "Ls", true},
	"LYD": {"Libyan Dinar", 0, empty, empty, "", empty, empty, "LD ", true},
	"MAD": {"Moroccan Dirham", 0, empty, empty, "", empty, empty, "MAD ", true},
	"MDL": {"Moldovan Leu", 0, empty, empty, "", empty, empty, "MDL ", true},
	"MGF": {"Malagasy Franc", 0, empty, empty, "", empty, empty, "MF", true},
	"MKD": {"Denar", 2, ",", ".", " ", empty, empty, "ден", false},
	"MMK": {"Kyat", 0, empty, empty, "", empty, empty, "K", true},
	"MNT": {"Tugrik", 0, empty, empty, "", "20AE", "&#x20AE;", "₮", true},
	"MOP": {"Pataca", 0, empty, empty, "", empty, empty, "MOP$", true},
	"MRO": {"Ouguiya", 0, empty, empty, "", empty, empty, "MRO ", true},
	"MTL": {"Maltese Lira", 2, ",", ".", "", "20A4", "&#x20A4;", "Lm", true},
	"MUR": {"Mauritius Rupee", 0, ",", "", "", "20A8", "&#x20A8;", "Rs", true},
	"MVR": {"Rufiyaa", 0, empty, empty, "", empty, empty, "MVR ", true},
	"MWK": {"Kwacha", 2, ",", ".", "", empty, empty, "MK ", true},
	"MXN": {"Mexican Peso", 2, ",", ".", " ", "0024", "&#x0024;", "$", true},
	"MYR": {"Malaysian Ringgit", 2, ",", ".", "", empty, empty, "RM", true},
	"MZN": {"Metical", 2, ".", ",", " ", empty, empty, "Mt", false},
	"NAD": {"Namibian Dollar", 0, empty, empty, "", "0024", "&#x0024;", "$", true},
	"NGN": {"Naira", 2, ",", ".", ".", "20A6", "&#x20A6;", "₦", true},
	"NIO": {"Cordoba Oro", 0, empty, empty, "", empty, empty, "C$", true},
	"NLG": {"Netherlands Guilder", 2, ".", ",", " ", "0192", "&#x0192;", "ƒ", true},
	"NOK": {"Norwegian Krone", 2, ".", ",", " ", "kr", "kr", "kr", true},
	"NPR": {"Nepalese Rupee", 2, ",", ".", " ", "20A8", "&#x20A8;", "Rs.", true},
	"NZD": {"New Zealand Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"OMR": {"Rial Omani", 3, ",", ".", " ", "FDFC", "&#xFDFC;", "RO", true},
	"PAB": {"Balboa", 0, empty, empty, "", empty, empty, "B/.", true},
	"PEN": {"Nuevo Sol", 2, ",", ".", " ", "S/.", "S/.", "S/.", true},
	"PGK": {"Kina", 0, empty, empty, "", empty, empty, "K", true},
	"PHP": {"Philippine Peso", 2, ",", ".", "", "20B1", "&#x20B1;", "₱", true},
	"PKR": {"Pakistan Rupee", 2, ",", ".", "", "20A8", "&#x20A8;", "Rs", true},
	"PLN": {"Zloty", 2, " ", ",", " ", empty, empty, "zł", false},
	"PTE": {"Portuguese Escudo", 0, ".", "", " ", empty, empty, " $", false},
	"PYG": {"Guarani", 0, empty, empty, "", "20B2", "&#x20B2;", "Gs", true},
	"QAR": {"Qatari Rial", 0, empty, empty, "", "FDFC", "&#xFDFC;", "﷼ ", true},
	"RON": {"Leu", 2, ".", ",", " ", empty, empty, "lei", false},
	"RSD": {"Serbian Dinar", 2, empty, empty, empty, empty, empty, "РСД", false},
	"RUB": {"Russian Ruble", 2, ".", ",", empty, "0440 0443 0431", "&#x0440;&#x0443;&#x0431;", "₽", true},
	"RWF": {"Rwanda Franc", 0, empty, empty, "", empty, empty, "RWF ", true},
	"SAC": {"S. African Rand Commerc.", 0, empty, empty, "", empty, empty, "SAC ", true},
	"SAR": {"Saudi Riyal", 2, ",", ".", " ", "FDFC", "&#xFDFC;", "﷼", true},
	"SBD": {"Solomon Islands Dollar", 0, empty, empty, "", "0024", "&#x0024;", "$", true},
	"SCR": {"Seychelles Rupee", 0, empty, empty, "", "20A8", "&#x20A8;", "₨", true},
	"SDG": {"Sudanese Dinar", 0, empty, empty, empty, empty, empty, "LSd", true},
	"SDP": {"Sudanese Pound", 0, empty, empty, "", empty, empty, "SDP ", true},
	"SEK": {"Swedish Krona", 2, " ", ",", " ", empty, empty, "kr", false},
	"SGD": {"Singapore Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"SHP": {"St Helena Pound", 0, empty, empty, "", "00A3", "&#x00A3;", "£", true},
	"SIT": {"Tolar", 2, ".", ",", " ", empty, empty, "SIT ", false},
	"SKK": {"Slovak Koruna", 2, " ", ",", " ", empty, empty, "Sk", false},
	"SLL": {"Leone", 0, empty, empty, "", empty, empty, "Le ", true},
	"SOS": {"Somali Shilling", 0, empty, empty, "", empty, empty, "S", true},
	"SRG": {"Surinam Guilder", 0, empty, empty, "", empty, empty, "SRG ", true},
	"STD": {"Dobra", 0, empty, empty, "", empty, empty, "DB", true},
	"SVC": {"El Salvador Colon", 2, ",", ".", "", "20A1", "&#x20A1;", "¢", true},
	"SYP": {"Syrian Pound", 0, empty, empty, "", "00A3", "&#x00A3;", "£", true},
	"SZL": {"Lilangeni", 2, "", ".", "", empty, empty, "E", true},
	"THB": {"Baht", 2, ",", ".", " ", "0E3F", "&#x0E3F;", "Bt", false},
	"TJR": {"Tajik Ruble", 0, empty, empty, "", empty, empty, "TJR ", true},
	"TJS": {"Somoni", 0, empty, empty, empty, empty, empty, "TJS ", true},
	"TMM": {"Manat", 0, empty, empty, "", empty, empty, "T", true},
	"TND": {"Tunisian Dinar", 3, empty, empty, "", empty, empty, "TND ", true},
	"TOP": {"Pa'anga", 2, ",", ".", " ", empty, empty, "$", true},
	"TPE": {"Timor Escudo", 0, empty, empty, empty, empty, empty, "TPE ", true},
	"TRY": {"Turkish Lira", 0, ",", "", "", "20A4", "&#x20A4;", "TL", false},
	"TTD": {"Trinidad and Tobago Dollar", 0, empty, empty, "", "0024", "&#x0024;", "TT$", true},
	"TWD": {"New Taiwan Dollar", 0, empty, empty, "", "0024", "&#x0024;", "NT$", true},
	"TZS": {"Tanzanian Shilling", 2, ",", ".", " ", empty, empty, "TZs", false},
	"UAH": {"Hryvnia", 2, " ", ",", "", "20B4", "&#x20B4", "UAH ", false},
	"UGX": {"Uganda Shilling", 0, empty, empty, "", empty, empty, "UGX", true},
	"USD": {"US Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"UYU": {"Peso Uruguayo", 2, ".", ",", "", "20B1", "&#x20B1;", "$", true},
	"UZS": {"Uzbekistan Sum", 0, empty, empty, "", empty, empty, "лв", true},
	"VEF": {"Bolivar", 2, ".", ",", " ", empty, empty, "Bs.", true},
	"VND": {"Dong", 2, ".", ",", " ", "20AB", "&#x20AB;", "₫", true},
	"VUV": {"Vatu", 0, ",", "", "", empty, empty, "VT", false},
	"WST": {"Tala", 0, empty, empty, "", empty, empty, "WST ", true},
	"XAF": {"CFA Franc BEAC", 0, empty, empty, "", empty, empty, "$", true},
	"XCD": {"East Caribbean Dollar", 2, ",", ".", "", "0024", "&#x0024;", "$", true},
	"XOF": {"CFA Franc BCEAO", 0, empty, empty, empty, empty, empty, "XOF ", true},
	"XPF": {"CFP Franc", 0, empty, empty, "", empty, empty, "XPF ", true},
	"YER": {"Yemeni Rial", 0, empty, empty, "", "FDFC", "&#xFDFC;", "﷼ ", true},
	"YUN": {"New Dinar", 0, empty, empty, "", empty, empty, "YUN ", true},
	"ZAR": {"Rand", 2, " ", ".", " ", "0052", "&#x0052;", "R", true},
	"ZMK": {"Kwacha", 0, empty, empty, "", empty, empty, "ZMK ", true},
	"ZRN": {"New Zaire", 0, empty, empty, empty, empty, empty, "ZRN ", true},
	"ZWD": {"Zimbabwe Dollar ", 2, " ", ".", "", "0024", "&#x0024;", "Z$", true},
}

//------------- Un_Formatted Functions------------------------

func UnformatNumber(n string, precision int, currency string) string {
	var lc Locale
	currency = strings.ToUpper(currency)

	if val, ok := LocaleInfo[currency]; ok {
		lc = val
	} else {
		panic("No  Info Found")
	}

	r := regexp.MustCompile(`[^0-9-., ]`) // Remove anything thats not a space, comma, or decimal
	num := r.ReplaceAllString(n, "${1}")

	r = regexp.MustCompile(fmt.Sprintf("\\%v", lc.ThouSep)) // Strip out thousands seperator, whatever it is
	num = r.ReplaceAllString(num, "${1}")

	// Replace decimal seperator with a decimal at specified precision
	if lc.DecSep != "." {
		r = regexp.MustCompile(`\,`)
		num = r.ReplaceAllString(num, ".")
	}

	num = setPrecision(num, precision)
	return num
}

func setPrecision(num string, precision int) string {
	p := fmt.Sprintf("%%.%vf", precision)
	num = strings.Trim(num, " ")
	v, _ := strconv.ParseFloat(num, 64)
	return fmt.Sprintf(p, v)
}

//---------------------- Formatted Functions ------------------------------

func formatNumberString(x string, precision int, thousand string, decimal string) string {
	lastIndex := strings.Index(x, ".") - 1

	if lastIndex < 0 {
		lastIndex = len(x) - 1
	}

	var buffer []byte
	var strBuffer bytes.Buffer

	j := 0
	for i := lastIndex; i >= 0; i-- {
		j++
		buffer = append(buffer, x[i])

		if j == 3 && i > 0 && !(i == 1 && x[0] == '-') {
			buffer = append(buffer, ',')
			j = 0
		}
	}

	for i := len(buffer) - 1; i >= 0; i-- {
		strBuffer.WriteByte(buffer[i])
	}
	result := strBuffer.String()

	if thousand != "," {
		result = strings.Replace(result, ",", thousand, -1)
	}

	extra := x[lastIndex+1:]
	if decimal != "." {
		extra = strings.Replace(extra, ".", decimal, 1)
	}

	return result + extra
}

func FormatNumberr(value interface{}, precision int, thousand string, decimal string) string {
	v := reflect.ValueOf(value)

	var x string
	switch v.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		x = fmt.Sprintf("%d", v.Int())
		if precision > 0 {
			x += "." + strings.Repeat("0", precision)
		}
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		x = fmt.Sprintf("%d", v.Uint())
		if precision > 0 {
			x += "." + strings.Repeat("0", precision)
		}
	case reflect.Float32, reflect.Float64:
		x = fmt.Sprintf(fmt.Sprintf("%%.%df", precision), v.Float())
	default:
		return ""
	}

	return formatNumberString(x, precision, thousand, decimal)
}

func FormatNumberInt(x int, precision int, thousand string, decimal string) string {
	var result string
	var minus bool

	if x == math.MinInt64 {
		return FormatNumberr(x, precision, thousand, decimal)
	}

	if x < 0 {
		minus = true
		x *= -1
	}

	for x >= 1000 {
		result = fmt.Sprintf("%s%03d%s", thousand, x%1000, result)
		x /= 1000
	}
	result = fmt.Sprintf("%d%s", x, result)

	if minus {
		result = "-" + result
	}

	if precision > 0 {
		result += decimal + strings.Repeat("0", precision)
	}

	return result
}

func FormatNumberFloat64(x float64, precision int, thousand string, decimal string) string {
	return formatNumberString(fmt.Sprintf(fmt.Sprintf("%%.%df", precision), x), precision, thousand, decimal)
}

// ----------------------------------     Accounting       ---------------------------
type Accounting struct {
	Symbol         string
	Precision      int
	Thousand       string
	Decimal        string
	Format         string
	FormatNegative string
	FormatZero     string
}

func (accounting *Accounting) init() {
	if accounting.Thousand == "" {
		accounting.Thousand = ","
	}

	if accounting.Decimal == "" {
		accounting.Decimal = "."
	}

	if accounting.Format == "" {
		accounting.Format = "%s%v"
	}

	if accounting.FormatNegative == "" {
		accounting.FormatNegative = strings.Replace(strings.Replace(accounting.Format, "-", "", -1), "%v", "-%v", -1)
	}

	if accounting.FormatZero == "" {
		accounting.FormatZero = "0"
	}
}

func (accounting *Accounting) formatMoneyString(formattedNumber string) string {
	var format string

	if formattedNumber[0] == '-' {
		format = accounting.FormatNegative
		formattedNumber = formattedNumber[1:]
	} else if formattedNumber == "0" {
		format = accounting.FormatZero
	} else {
		format = accounting.Format
	}

	result := strings.Replace(format, "%s", accounting.Symbol, -1)
	result = strings.Replace(result, "%v", formattedNumber, -1)

	return result
}

func (accounting *Accounting) FormatMoney(value interface{}) string {
	accounting.init()
	formattedNumber := FormatNumberr(value, accounting.Precision, accounting.Thousand, accounting.Decimal)
	return accounting.formatMoneyString(formattedNumber)
}

func (accounting *Accounting) FormatMoneyInt(value int) string {
	accounting.init()
	formattedNumber := FormatNumberInt(value, accounting.Precision, accounting.Thousand, accounting.Decimal)
	return accounting.formatMoneyString(formattedNumber)
}

func (accounting *Accounting) FormatMoneyFloat64(value float64) string {
	accounting.init()
	formattedNumber := FormatNumberFloat64(value, accounting.Precision, accounting.Thousand, accounting.Decimal)
	return accounting.formatMoneyString(formattedNumber)
}
