package functions

import (
	"fmt"
	"jocata_transform_plugin/constants"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"strconv"
)

func FormatBool(inputData map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	conversion := inputData["format"].(string)
	initValuesMap := inputData["init"].(map[string]interface{})
	var res interface{}
	var err error
	if initValuesMap != nil {
		if initValuesMap["value"] != nil {
			valueData := initValuesMap["value"].(string)
			res, err = utils.FindValue(valueData, data)
		}
	}

	if err != nil && conversion != constants.IS_EMPTY {
		errMessage := fmt.Sprintf(" function %v :  %v ", conversion, err)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	if data.JsonIgnoreProperty && res == nil && conversion != constants.IS_EMPTY {
		return nil, rs.TransformError{}
	}

	switch conversion {
	case "toText":
		boolValue, boolOk := res.(bool)
		textVal, textOk := res.(string)
		if !boolOk && textOk {
			_, err := strconv.ParseBool(textVal)
			if err != nil {
				errMessage := fmt.Sprintf(" function %v :  %v ", conversion, err)
				tErr := utils.PopulateTransFormError("1001", errMessage)
				logger.Log.Error(data.LocalData, errMessage)
				return nil, tErr
			}
			return textVal, rs.TransformError{}
		} else if !boolOk && !textOk {
			errMessage := fmt.Sprintf("Given value was %v Invalid for boolean to text conversion", res)
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}

		return strconv.FormatBool(boolValue), rs.TransformError{}
	case constants.IS_EMPTY:
		return isBoolEmpty(res, initValuesMap, data)
	default:
		errMessage := fmt.Sprintf("Given Type was  %v is Invalid for Keyword", conversion)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
}
func isBoolEmpty(textVal interface{}, initValuesMap map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	if initValuesMap["value"] == nil {
		errMessage := fmt.Sprintf("in function '%v'", constants.IS_EMPTY+" value key is missing in configuration.")
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	if textVal == nil {
		return true, rs.TransformError{}
	}
	return false, rs.TransformError{}
}
