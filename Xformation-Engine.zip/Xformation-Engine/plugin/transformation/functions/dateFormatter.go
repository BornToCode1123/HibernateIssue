package functions

import (
	"encoding/json"
	"errors"
	"fmt"

	"jocata_transform_plugin/constants"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"math"
	"strconv"
	"time"
)

func DateFormat(data rs.JSONQData, date string, dateFormat string, inputType string) (interface{}, error) {
	logger.Log.Trace(data.LocalData, "Entered into function date")
	localtime := time.Local

	var inputTypeLayout = dateFormats[inputType]
	var outputTypeLayout = dateFormats[dateFormat]
	if inputType == "unixTime" {
		i, err := strconv.ParseInt(date, 0, 64)
		if err != nil {
			logger.Log.Trace(data.LocalData, "Error while parsing text formatted unix date to number format %v", err)
			errMessage := fmt.Sprintf("Error While Formatting the Date:-  %v ", date)
			return "", errors.New(errMessage)
		}
		tm := time.Unix(i/1000, 0)
		return tm.Format(outputTypeLayout), nil
	} else {
		tm, err := time.ParseInLocation(inputTypeLayout, date, localtime)
		if err != nil {
			logger.Log.Error(data.LocalData, "Error while formatting time %v", err)
			errMessage := fmt.Sprintf("Error While Formatting the DateInput :-  %v , Date is %v ", inputTypeLayout, date)
			return "", errors.New(errMessage)
		}
		if outputTypeLayout == "unixTime" {
			return tm.UnixMilli(), nil
		}
		return tm.Format(outputTypeLayout), nil
	}
}

func DataFormat(inputData map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function date")
	var includeDifferenceValue bool
	currentTime1 := time.Now()
	currentTime := currentTime1.Local()
	var durationValue interface{}

	localtime := time.Local

	var increaseValue int

	startFormat := ""

	keyType := inputData["type"]
	if keyType == nil {
		logger.Log.Trace(data.LocalData, "type is not specified in the configuration. By default type is 'day'")
		inputData["type"] = "day"
	}
	keyType = inputData["type"].(string)

	if inputData["value"] != nil {
		variable := inputData["value"].(string)

		keyValue, err := utils.FindValue(variable, data)
		if err != nil {
			errMessage := fmt.Sprintf("while formatting date : %v", err)
			tErr := utils.PopulateTransFormError("1010", errMessage)
			return "", tErr
		}
		data.ResetJsonqData()

		if keyValue != nil {
			increaseValue, _ = strconv.Atoi(keyValue.(string))
		} else {
			logger.Log.Trace(data.LocalData, "value is not specified in the configuration. By default value is '0' ")
			increaseValue = 0
		}
	}

	includeDifference := inputData["includeDifference"]
	if includeDifference != nil {
		includeDifferenceValue = includeDifference.(bool)
	}

	initValues := inputData["init"]

	if initValues != nil {
		initValuesMap := initValues.(map[string]interface{})
		startFormat = dateFormats[initValuesMap["format"].(string)]

		v, ok := initValuesMap["value"].(float64)

		if ok {
			d, _ := json.Marshal(v)
			startDate := string(d)

			i, err := strconv.ParseInt(startDate, 10, 64)
			if err != nil {
				tErr := utils.PopulateTransFormError("1001", err)
				return nil, tErr
			}
			currentTime = time.UnixMilli(i)
		} else {
			var res interface{}
			var err error

			variable := initValuesMap["value"].(string)
			res, err = utils.FindValue(variable, data)
			if err != nil {
				errMessage := fmt.Sprintf("while formatting date : %v", err)
				tErr := utils.PopulateTransFormError("1010", errMessage)
				return "", tErr
			}

			if res != nil {
				if startFormat == "unixTime" {
					floatDate := int64(res.(float64))
					currentTime = time.UnixMilli(floatDate)
				} else if startFormat == "inMonths" || startFormat == "inYears" || startFormat == "inDays" {
					durationValue = res
					keyType = startFormat
				} else {
					currentTime, _ = time.ParseInLocation(startFormat, res.(string), localtime)
				}
			} else if !data.JsonIgnoreProperty {
				errMessage := fmt.Sprintf("the %v, value is null from the payload, we can't perform date formatting with the null values", variable)
				tErr := utils.PopulateTransFormError("1001", errMessage)
				return "", tErr
			} else {
				return nil, rs.TransformError{}
			}
		}

	}

	var outputFormat string
	if inputData["format"] != nil {
		_, ok := dateFormats[inputData["format"].(string)]
		if !ok {
			errMessage := fmt.Sprintf("the given format %v, is not valid ", inputData["format"])
			logger.Log.Error(data.LocalData, "the given format '%v' is currently not supporting", inputData["format"])
			tErr := utils.PopulateTransFormError("1001", errMessage)
			return "", tErr
		}
		outputFormat = dateFormats[inputData["format"].(string)]
	} else {
		outputFormat = dateFormats["dd-MM-yyyy"]
	}

	valueType := keyType.(string)
	switch valueType {
	case "month":
		newDate, tErr := increaseDate(data, currentTime, increaseValue, valueType, includeDifferenceValue)
		if tErr.Detailedmessage != nil {
			return nil, tErr
		}
		return getFormattedDate(data, newDate, outputFormat, valueType), rs.TransformError{}

	case "year":
		newDate, tErr := increaseDate(data, currentTime, increaseValue, valueType, includeDifferenceValue)
		if tErr.Detailedmessage != nil {
			return nil, tErr
		}
		return getFormattedDate(data, newDate, outputFormat, valueType), rs.TransformError{}

	case "day":
		newDate, tErr := increaseDate(data, currentTime, increaseValue, valueType, includeDifferenceValue)
		if tErr.Detailedmessage != nil {
			return nil, tErr
		}

		return getFormattedDate(data, newDate, outputFormat, valueType), rs.TransformError{}

	case "week":
		logger.Log.Error(data.LocalData, "function week is currently not supporting")
		// Need to Implement Functionality for week
	case "hour":
		logger.Log.Debug(data.LocalData, "Entered into hours increase function")
		newDate, tErr := increaseDate(data, currentTime, increaseValue, valueType, includeDifferenceValue)
		if tErr.Detailedmessage != nil {
			return nil, tErr
		}
		return getFormattedDate(data, newDate, outputFormat, valueType), rs.TransformError{}
		//return getFormattedDate(currentTime, outputFormat, "hours"), rs.TransformError{}
	case "minute":
		logger.Log.Debug(data.LocalData, "Entered into minute increase function")
		newDate, tErr := increaseDate(data, currentTime, increaseValue, valueType, includeDifferenceValue)
		if tErr.Detailedmessage != nil {
			return nil, tErr
		}
		return getFormattedDate(data, newDate, outputFormat, "minutes"), rs.TransformError{}
		//return getFormattedDate(currentTime, outputFormat, "minute"), rs.TransformError{}
	case "seconds":
		return getFormattedDate(data, currentTime, outputFormat, "seconds"), rs.TransformError{}
	case "inDays", "inYears", "inMonths":
		return Duration(durationValue, outputFormat, startFormat), rs.TransformError{}

	default:
		errMessage := fmt.Sprintf("Given Type was  %v is Invalid for Keyword", keyType)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	errMessage := fmt.Sprintf("Given Type was  %v is Invalid for Keyword", keyType)
	tErr := utils.PopulateTransFormError("1002", errMessage)
	logger.Log.Error(data.LocalData, errMessage)
	return nil, tErr
}

func Duration(value interface{}, outputFormat string, input string) interface{} {
	var res interface{}
	var digit float64
	if value != nil {
		digit = value.(float64)
	}
	switch outputFormat {
	case "inMonths":
		if input == "inYears" {
			res = digit * 12
		} else if input == "inMonths" {
			res = digit
		} else if input == "inDays" {
			res = digit * 30
		}
		return res

	case "inYears":
		if input == "inYears" {
			res = digit
		} else if input == "inMonths" {
			res = digit / 12
		} else if input == "inDays" {
			res = digit / 365.25
		}
		return res

	case "inDays":
		if input == "inYears" {
			res = digit * 365.25
		} else if input == "inMonths" {
			res = digit * 30
		} else if input == "inDays" {
			res = digit
		}
		return res

	default:
		return res

	}
}

func getFormattedDate(data rs.JSONQData, t time.Time, outputFormat string, format string) interface{} {

	switch outputFormat {
	case "unixTime":
		return float64(t.UnixMilli())
	case "month":
		return float64(t.Month())
	case "year":
		return float64(t.Year())
	case "day":
		return float64(t.Day())
	case "hours":
		return t.Hour()
	case "minutes":
		return t.Minute()
	case "seconds":
		return t.Second()
	case "diff":
		val, err := GetDifference(data, time.Now(), t, format)
		if err != nil {
			return err
		}
		return val
	case "getLastDate":
		return GetLastDate(t, format)
	default:
		return t.Format(outputFormat)
	}
}

var dateFormats = map[string]string{
	"inMonths":                   "inMonths",
	"inYears":                    "inYears",
	"inDays":                     "inDays",
	"dateDiff":                   "diff",
	"getMonth":                   "month",
	"getYear":                    "year",
	"getDay":                     "day",
	"yyyy-MM-dd":                 "2006-01-02",
	"yyyyMMdd":                   "20060102",
	"MMMM dd, yyyy":              "January 02, 2006",
	"dd MMMM yyyy":               "02 January 2006",
	"dd-MMM-yyyy":                "02-Jan-2006",
	"MM/dd/yy":                   "01/02/06",
	"MM/dd/yyyy":                 "01/02/2006",
	"dd/MM/yyyy":                 "02/01/2006",
	"MMddyy":                     "010206",
	"MMM-dd-yy":                  "Jan-02-06",
	"MMM-dd-yyyy":                "Jan-02-2006",
	"yy":                         "06",
	"MM":                         "01",
	"dd":                         "02",
	"MMM":                        "Jan",
	"EEE":                        "Mon",
	"EEEE":                       "Monday",
	"MMMM":                       "January",
	"MMM-yy":                     "Jan-06",
	"MM-yyyy":                    "01-2006",
	"MMM-yyyy":                   "Jan-2006",
	"MMM yyyy":                   "Jan 2006",
	"HH:mm":                      "15:04",
	"HH:mm:ss":                   "15:04:05",
	"K:mm a":                     "3:04 PM",
	"KK:mm:ss a":                 "03:04:05 PM",
	"yyyy-MM-dd'T'HH:mm:ss":      "2006-01-02T15:04:05",
	"yyyy-MM-ddTHH:mm:ssZ":       "2006-01-02T15:04:05-07:00",
	"d MMM yyyy HH:mm:ss":        "2 Jan 2006 15:04:05",
	"d MMM yyyy HH:mm":           "2 Jan 2006 15:04",
	"EEE, d MMM yyyy HH:mm:ss z": "Mon, 2 Jan 2006 15:04:05 MST",
	"dd-MM-yyyy":                 "02-01-2006",
	"unixTime":                   "unixTime",
	"ddMMyyyy":                   "02012006",
	"MMyyyy":                     "012006",
	"yyyy-MM-dd HH:mm:ss":        "2006-01-02 15:04:05",
	"yyyy-MM-dd'T'HH:mm:ssTZD":   "2006-01-02T15:04:05-07:00",
	"yyyy-MM-dd'T'HH:mm:ssZ":     "2006-01-02T15:04:05-0700",
	"yyyy-MM-dd'T'HH:mm:ss.Z":    "2006-01-02T15:04:05.0700",
	"yyyy-MM-dd'T'HH:mm:ss.TZD":  "2006-01-02T15:04:05Z07:00",
	"yyyy-MM-dd'T'HH:mm:ss.D":    "2006-01-02T15:04:05.000",
	"yyyy-MM-dd'T'HH:mm:ss.DZ":   "2006-01-02T15:04:05.000Z",
	"getLastDate":                "getLastDate",
	"yyyy-MM-ddZ":                "2006-01-02Z",
}

func DiffMonths(now time.Time, then time.Time) int {
	diffYears := now.Year() - then.Year()
	if diffYears == 0 {
		return int(now.Month() - then.Month())
	}

	if diffYears == 1 {
		return monthsTillEndOfYear(then) + int(now.Month())
	}

	yearsInMonths := (now.Year() - then.Year() - 1) * 12
	return yearsInMonths + monthsTillEndOfYear(then) + int(now.Month())
}

func monthsTillEndOfYear(then time.Time) int {
	return int(12 - then.Month())
}

func GetDifference(data rs.JSONQData, now time.Time, then time.Time, format string) (interface{}, error) {
	months := DiffMonths(now, then)
	duration := now.Sub(then)

	switch format {
	case "seconds":
		return duration.Seconds(), nil
	case "minutes":
		return duration.Minutes(), nil
	case "hours":
		return duration.Hours(), nil
	case "days":
		return float64(int64(duration.Hours() / 24)), nil
	case "weeks":
		return float64(int64(duration.Hours() / 24 / 7)), nil
	case "months":
		return float64(months), nil
	case "years":
		return float64(int64(duration.Hours() / 24 / 365.25)), nil
	default:
		errMessage := fmt.Sprintf("The format %v which is being used... is not supported", format)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, errors.New(errMessage)
	}
}

func GetDifferenceFromToday(data rs.JSONQData, then time.Time, format string) (interface{}, error) {
	months := DiffMonths(time.Now(), then)
	duration := time.Since(then)

	switch format {
	case "seconds":
		return duration.Seconds(), nil
	case "minutes":
		return duration.Minutes(), nil
	case "hours":
		return duration.Hours(), nil
	case "days":
		return float64(int64(duration.Hours() / 24)), nil
	case "weeks":
		return float64(int64(duration.Hours() / 24 / 7)), nil
	case "months":
		return float64(months), nil
	case "years":
		return getAge(then), nil
	default:
		errMessage := fmt.Sprintf("The format %v which is being used... is not supported", format)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, errors.New(errMessage)
	}
}

func getAge(birthDate time.Time) (age float64) {
	currentDate := time.Now()
	years := currentDate.Year() - birthDate.Year()

	if currentDate.Before(time.Date(currentDate.Year(), birthDate.Month(), birthDate.Day(), 0, 0, 0, 0, currentDate.Location())) {
		years--
	}

	months := int(currentDate.Month()) - int(birthDate.Month())
	if months < 0 {
		months += 12
	}

	days := currentDate.Day() - birthDate.Day()
	if days < 0 {
		lastMonth := currentDate.AddDate(0, -1, 0)
		days += lastMonth.Day()

		months--
		if months < 0 {
			months += 12
		}
	}
	if days == 1 {
		days += 1
	}
	age = float64(years) + float64(months)/12 + float64(days)/365.25
	return
}

func resolvePreviousValid(year int, month int, day int) (int, int, int, error) {

	if month == 2 && day > 28 {
		if year%4 == 0 {
			day = 29
		} else {
			day = 28
		}
	}

	return year, month, day, nil
}

func PlusMonths(year int, month int, day int, monthsToAdd int64) (int, int, int, error) {
	if monthsToAdd == 0 {
		return year, month, day, nil
	}

	monthCount := int64(year)*12 + int64(month-1)
	calcMonths := monthCount + monthsToAdd

	newYear := int(math.Floor(float64(calcMonths) / 12))
	newMonth := int(math.Mod(float64(calcMonths), 12)) + 1

	return resolvePreviousValid(newYear, newMonth, day)
}

func plusYears(year int, month int, day int, yearsToAdd int) (int, int, int, error) {
	if yearsToAdd == 0 {
		return year, month, day, nil
	}

	newYear := year + yearsToAdd

	return resolvePreviousValid(newYear, month, day)
}

func PlusDays(year, month, day int, daysToAdd int64) (time.Time, error) {
	if daysToAdd == 0 {
		return time.Date(year, time.Month(month), day, 0, 0, 0, 0, time.UTC), nil
	}

	initialDate := time.Date(year, time.Month(month), day, 0, 0, 0, 0, time.UTC)
	newDate := initialDate.AddDate(0, 0, int(daysToAdd))

	return newDate, nil
}

func PlusHours(data rs.JSONQData, date time.Time, hoursToAdd int64) (time.Time, error) {
	logger.Log.Debug(data.LocalData, "Entered into hours increase function")

	if hoursToAdd == 0 {
		return date, nil
	}
	newDate := date.Add(time.Duration(hoursToAdd) * time.Hour)
	logger.Log.Debug(data.LocalData, "hours : ", newDate)
	return newDate, nil
}

func PlusMinutes(data rs.JSONQData, date time.Time, minutesToAdd int64) (time.Time, error) {
	logger.Log.Debug(data.LocalData, "Entered into minute increase function")
	if minutesToAdd == 0 {
		return date, nil
	}
	newDate := date.Add(time.Duration(minutesToAdd) * time.Minute)
	logger.Log.Debug(data.LocalData, "minute : ", newDate)
	return newDate, nil
}

func increaseDate(data rs.JSONQData, date time.Time, increaseValue int, increaseType string, includeDifferece bool) (time.Time, rs.TransformError) {

	if increaseValue == 0 {
		return date, rs.TransformError{}
	}

	var emptyDate time.Time
	var day int

	hour, min, sec, nsec := date.Hour(), date.Minute(), date.Second(), date.Nanosecond()

	if includeDifferece && increaseType != "day" {
		day = 1
	} else {
		day = date.Day()
	}

	month, year := date.Month(), date.Year()

	switch increaseType {
	case "year":
		year, month, day, err := plusYears(year, int(month), day, increaseValue)
		if err != nil {
			errMessage := fmt.Sprintf("error whil increasing %v years, %v", increaseValue, err)
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return emptyDate, tErr
		}
		newDate := time.Date(year, time.Month(month), day, hour, min, sec, nsec, date.Location())
		return newDate, rs.TransformError{}
		//nanoSecons := time.Date(year, time.Month(month), day, 0, 0, 0, 0, date.Location())
		//return nanoSecons, rs.TransformError{}

	case "month":
		year, month, day, err := PlusMonths(year, int(month), day, int64(increaseValue))
		if err != nil {
			errMessage := fmt.Sprintf("error whil increasing %v months, %v", increaseValue, err)
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return emptyDate, tErr
		}
		newDate := time.Date(year, time.Month(month), day, hour, min, sec, nsec, date.Location())
		return newDate, rs.TransformError{}
		//nanoSecons := time.Date(year, time.Month(month), day, 0, 0, 0, 0, date.Location())
		//return nanoSecons, rs.TransformError{}

	case "day":
		increasedDate, err := PlusDays(year, int(month), day, int64(increaseValue))
		if err != nil {
			errMessage := fmt.Sprintf("error whil increasing %v days, %v", increaseValue, err)
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return emptyDate, tErr
		}
		newDate := time.Date(increasedDate.Year(), increasedDate.Month(), increasedDate.Day(), hour, min, sec, nsec, increasedDate.Location())
		return newDate, rs.TransformError{}
		//nanoSecons := time.Date(increasedDate.Year(), increasedDate.Month(), increasedDate.Day(), 0, 0, 0, 0, increasedDate.Location())
		//return nanoSecons, rs.TransformError{}

	case "hour":
		logger.Log.Debug(data.LocalData, "Entered into hours increase function")
		increasedDate, err := PlusHours(data, date, int64(increaseValue))
		if err != nil {
			errMessage := fmt.Sprintf("error while increasing %v hours, %v", increaseValue, err)
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return emptyDate, tErr
		}
		logger.Log.Debug(data.LocalData, "Increased date and time: ", increasedDate)

		return increasedDate, rs.TransformError{}

	case "minute":
		logger.Log.Debug(data.LocalData, "Entered into minutes increase function")
		increasedDate, err := PlusMinutes(data, date, int64(increaseValue))
		if err != nil {
			errMessage := fmt.Sprintf("error while increasing %v minutes, %v", increaseValue, err)
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return emptyDate, tErr
		}
		nanoSeconds := time.Date(increasedDate.Year(), increasedDate.Month(), increasedDate.Day(), increasedDate.Hour(), increasedDate.Minute(), increasedDate.Second(), 0, increasedDate.Location())
		return nanoSeconds, rs.TransformError{}

	default:
		errMessage := fmt.Sprintf("Given increasing value type  %v is currently not supporting", increaseType)
		logger.Log.Error(data.LocalData, errMessage)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return emptyDate, tErr
	}
}

func GetDateFormat(userDateFormat string) string {
	return dateFormats[userDateFormat]
}

func CreateDate(args map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	initObject := args[constants.INIT].(map[string]interface{})
	format := initObject[constants.FORMAT].(string)
	var createdDate string

	day, month, year, tErr := getInputParameters(initObject, data)
	if tErr.Detailedmessage != nil {
		return nil, tErr
	}

	parsedDate := time.Date(year, time.Month(month), day, 0, 0, 0, 0, time.Local)

	if format != "" {
		createdDate = parsedDate.Format(dateFormats[format])
	} else {
		createdDate = parsedDate.Format("02-01-2006")
	}

	return createdDate, rs.TransformError{}
}

func getInputParameters(initObject map[string]interface{}, data rs.JSONQData) (day, month, year int, tErr rs.TransformError) {
	values := initObject[constants.VALUES].(map[string]interface{})
	var convertedValue int
	for key, value := range values {
		res, err := utils.FindValue(value.(string), data)
		data.ResetJsonqData()
		if err != nil {
			errMessage := fmt.Sprintf("while retrieving create date inputs : %v", err.Error())
			tErr = utils.PopulateTransFormError("1010", errMessage)
			return
		}

		switch val := res.(type) {
		case string:
			num, err := strconv.Atoi(val)
			if err != nil {
				errMessage := fmt.Sprintf("while converting string parameter to date : %v", err.Error())
				tErr = utils.PopulateTransFormError("1010", errMessage)
				return
			}
			convertedValue = num
		case float64:
			convertedValue = int(val)
		case int:
			convertedValue = val
		}

		switch key {
		case constants.DAY:
			day = convertedValue
		case constants.MONTH:
			month = convertedValue
		case constants.YEAR:
			year = convertedValue
		}
	}
	return
}
