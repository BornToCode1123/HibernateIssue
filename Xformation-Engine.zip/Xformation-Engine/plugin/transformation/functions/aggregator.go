package functions

import (
	"encoding/json"
	"fmt"
	"jocata_transform_plugin/constants"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"math"
	"strconv"
	"strings"

	"github.com/thedevsaddam/gojsonq/v2"
)

func Aggregate(funcName string, funcArgs map[string]interface{}, filter rs.Filter, data rs.JSONQData, fn rs.ProcessExpression, innerTran rs.ProcessInnerTransform, statementPath string, processRules rs.ProcessRules) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Executing function %v ", funcName)
	data.ResetJsonqData()
	var array string
	var resultList []interface{}
	if funcArgs["arrayName"] != nil {
		array = funcArgs["arrayName"].(string)
	} else {
		array = funcArgs["value"].(string)
	}

	var result *gojsonq.JSONQ
	var err error
	var res interface{}
	var tEr rs.TransformError

	if strings.Contains(array, constants.LOCAL_OBJECT_IDENTIFIER) {
		dotPos := strings.Index(array, constants.LOCAL_OBJECT_IDENTIFIER)
		arrayName := array[:dotPos]
		res, err = utils.GetFromMap(data.LocalData, arrayName, data)
		if err == nil {
			d, marshalError := json.Marshal(res)
			if marshalError != nil {
				logger.Log.Error(data.LocalData, "Error while retrieving the data from local %v ", err.Error())
				tErr := utils.PopulateTransFormError("1001", marshalError.Error())
				return rs.ExpressionResult{}, tErr
			}
			arrData := gojsonq.New().JSONString(string(d))
			result = arrData
		}

	} else {
		result = data.Jqdata.From(array)
		err = data.Jqdata.Error()
	}

	if !data.JsonIgnoreProperty && err != nil {
		logger.Log.Error(data.LocalData, "Error while retrieving the data from response %v ", err.Error())
		tErr := utils.PopulateTransFormError("1001", err.Error())
		return rs.ExpressionResult{}, tErr
	} else if data.JsonIgnoreProperty && err != nil {
		logger.Log.Trace(data.LocalData, "JsonIgnoreProperty Executed for %v field", array)
		return nil, rs.TransformError{}
	}

	var val interface{}
	if list := result.Get(); list != nil {
		resultList = list.([]interface{})
	}
	var aggregate string
	if funcArgs["aggregate"] != nil {
		aggregate = funcArgs["aggregate"].(string)
		logger.Log.Trace(data.LocalData, "Aggregating the field %v ", aggregate)

		switch funcName {
		case constants.SUM:
			val, _, tEr = sum(aggregate, resultList, data, array, filter, innerTran, statementPath, processRules)
		case constants.MIN:
			val, tEr = min(aggregate, result, data, array, filter, innerTran, statementPath, processRules)
		case constants.MAX:
			val, tEr = max(aggregate, result, data, array, filter, innerTran, statementPath, processRules)
		case constants.AVG:
			val, tEr = avg(aggregate, resultList, data, array, filter, innerTran, statementPath, processRules)
		default:
			errMessage := fmt.Sprintf("The Function %v which is being used... is not implemented", funcName)
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, "%v ", errMessage)
			return rs.ExpressionResult{}, tErr
		}
	} else {
		switch funcName {
		case "count":
			val, tEr = count(resultList, data, filter, innerTran, statementPath, processRules)
		case "sum":
			val = result.Sum()
			_, tEr = jsonPropertyCheck(data, &err, result, aggregate, funcName, &val)
		case "min":
			val = result.Min()
			_, tEr = jsonPropertyCheck(data, &err, result, aggregate, funcName, &val)
		case "max":
			val = result.Max()
			_, tEr = jsonPropertyCheck(data, &err, result, aggregate, funcName, &val)
		case "avg":
			val = result.Avg()
			_, tEr = jsonPropertyCheck(data, &err, result, aggregate, funcName, &val)
		default:
			errMessage := fmt.Sprintf("The Function %v which is being used... is not implemented", funcName)
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return rs.ExpressionResult{}, tErr
		}
	}

	if tEr.Detailedmessage == nil {
		switch v := val.(type) {
		case int:
			return float64(v), tEr
		case int32:
			return float64(v), tEr
		case int64:
			return float64(v), tEr
		case float32:
			return float64(v), tEr
		case float64:
			return float64(v), tEr
		default:
			return nil, tEr
		}
	}

	return val, tEr
}

func jsonPropertyCheck(data rs.JSONQData, err *error, result *gojsonq.JSONQ, aggregate string, funcName string, val *interface{}) (interface{}, rs.TransformError) {
	*err = result.Error()
	if !data.JsonIgnoreProperty && *err != nil {
		errMessage := fmt.Sprintf("error while aggregating the %v, in function %v : %v , in one of the elemement in the array", aggregate, funcName, *err)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return rs.ExpressionResult{}, tErr
	} else if data.JsonIgnoreProperty && *err != nil {
		*val = nil
		logger.Log.Trace(data.LocalData, "JsonIgnoreProperty Executed")
		return val, rs.TransformError{}
	}
	return nil, rs.TransformError{}
}
func avg(key string, result []interface{}, data rs.JSONQData, arrayName string, filterConfig rs.Filter, innerTran rs.ProcessInnerTransform, statementPath string, processRules rs.ProcessRules) (float64, rs.TransformError) {
	var avg float64
	val, count, tEr := sum(key, result, data, arrayName, filterConfig, innerTran, statementPath, processRules)
	if tEr.Detailedmessage != nil {
		return 0, tEr
	}
	avg = val / count
	return avg, rs.TransformError{}
}
func ConvertStringToFloat(v string) (float64, error) {
	return strconv.ParseFloat(v, 64)
}

func sum(key string, resultList []interface{}, data rs.JSONQData, arrayName string, filterConfig rs.Filter, innerTran rs.ProcessInnerTransform, statementPath string, processRules rs.ProcessRules) (float64, float64, rs.TransformError) {
	var sum float64
	var count float64
	var logicalType string
	var filterConditions []rs.Rule
	var sumErr rs.TransformError
	if filterConfig.Id != nil {
		config := filterConfig
		condtionsConfig := config.Condition
		logicalType = condtionsConfig.VType
		filterConditions = condtionsConfig.Rules
	}

	checkAndUpdateRules(filterConditions)
	for _, listObject := range resultList {
		objectVal, err := utils.GetFromMap(listObject.(map[string]interface{}), key, data)
		if err != nil && !data.JsonIgnoreProperty {
			errorMap := utils.PopulateTransFormError("1010", "the key :"+key+", is not found in the payload specified path "+arrayName)
			logger.Log.Error(data.LocalData, errorMap.Detailedmessage)
			return 0, 0, errorMap
		} else if err != nil && data.JsonIgnoreProperty {
			objectVal = data.JsonIgnoreAliasValue
		}
		if filterConfig.Id != nil {
			responseBytes, _ := json.Marshal(listObject)
			arrData := gojsonq.New().JSONString(string(responseBytes))
			subData := rs.JSONQData{Jqdata: arrData, ShouldReset: true, LocalData: data.LocalData, TransformedData: data.TransformedData, ErrorConfig: data.ErrorConfig, JsonIgnoreProperty: data.JsonIgnoreProperty, ErrorData: data.ErrorData, JsonIgnoreAliasValue: data.JsonIgnoreAliasValue, IsExceptionHandled: data.IsExceptionHandled}

			res, tErr := processRules(logicalType, filterConditions, subData, innerTran, statementPath)
			if tErr.Detailedmessage != nil {
				return 0, 0, tErr
			}
			if res {
				sum, sumErr = calcuateSum(objectVal, sum, err, data)
				if sumErr.Detailedmessage != nil {
					return 0, 0, sumErr
				}
				count++
			}
		} else {
			sum, sumErr = calcuateSum(objectVal, sum, err, data)
			if sumErr.Detailedmessage != nil {
				return 0, 0, sumErr
			}
			count++
		}
	}

	return sum, count, rs.TransformError{}
}

func checkAndUpdateRules(filterConditions []rs.Rule) {
	for i := range filterConditions {

		if filterConditions[i].EType == "logical" {
			logicalCondition := filterConditions[i].RuleHolder.(rs.Condition)
			checkAndUpdateRules(logicalCondition.Rules)
		}
		if filterConditions[i].EType == "relational" {
			relational := filterConditions[i].RuleHolder.(rs.RelationalRule)
			lhsExp, ok := relational.Lhs.Holder.(rs.Literal)
			if ok {
				lhsExp.EType = constants.VARIABLE
				relational.Lhs.Holder = rs.Variable(lhsExp)
				relational.Lhs.EType = constants.VARIABLE
				filterConditions[i].RuleHolder = relational
			}
		}
	}
}

func calcuateSum(objectVal interface{}, sum float64, err error, data rs.JSONQData) (float64, rs.TransformError) {
	switch val := objectVal.(type) {
	case float64:
		sum += val
	case float32:
		sum += float64(val)
	case int:
		sum += float64(val)
	case int64:
		sum += float64(val)
	case string:
		v, err := ConvertStringToFloat(val)
		if err != nil {
			errMessage := fmt.Sprintf("the variable %v which is trying to use for calculate the sum, is not a number %v", val, err)
			errorMap := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return 0, errorMap
		}
		sum += v
	default:
		errMessage := fmt.Sprintf("the variable %v which is trying to use for calculate the sum, is not a number %v", val, err)
		errorMap := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return 0, errorMap
	}

	return sum, rs.TransformError{}
}

func min(key string, result *gojsonq.JSONQ, data rs.JSONQData, arrayName string, filterConfig rs.Filter, innerTran rs.ProcessInnerTransform, statementPath string, processRules rs.ProcessRules) (float64, rs.TransformError) {
	var min float64 = math.MaxFloat64
	var minVal float64
	var logicalType string
	var filterConditions []rs.Rule
	var minErr rs.TransformError
	if filterConfig.Id != nil {
		config := filterConfig
		condtionsConfig := config.Condition
		logicalType = condtionsConfig.VType
		filterConditions = condtionsConfig.Rules
	}

	checkAndUpdateRules(filterConditions)
	for _, listObject := range result.Get().([]interface{}) {
		objectVal, err := utils.GetFromMap(listObject.(map[string]interface{}), key, data)
		if err != nil && !data.JsonIgnoreProperty {
			errorMap := utils.PopulateTransFormError("1010", "the key :"+key+", is not found in the payload specified path "+arrayName)
			logger.Log.Error(data.LocalData, errorMap.Detailedmessage)
			return 0, errorMap
		} else if err != nil && data.JsonIgnoreProperty {
			objectVal = data.JsonIgnoreAliasValue
		}
		if filterConfig.Id != nil {
			responseBytes, _ := json.Marshal(listObject)
			arrData := gojsonq.New().JSONString(string(responseBytes))
			subData := rs.JSONQData{Jqdata: arrData, ShouldReset: true, LocalData: data.LocalData, TransformedData: data.TransformedData, ErrorConfig: data.ErrorConfig, JsonIgnoreProperty: data.JsonIgnoreProperty, ErrorData: data.ErrorData, JsonIgnoreAliasValue: data.JsonIgnoreAliasValue, IsExceptionHandled: data.IsExceptionHandled}

			res, tErr := processRules(logicalType, filterConditions, subData, innerTran, statementPath)
			if tErr.Detailedmessage != nil {
				return 0, tErr
			}
			if res {
				min, minErr = findMinValue(objectVal, minVal, err, data, min)
				if minErr.Detailedmessage != nil {
					return 0, minErr
				}
			}
		} else {
			min, minErr = findMinValue(objectVal, minVal, err, data, min)
			if minErr.Detailedmessage != nil {
				return 0, minErr
			}

		}

	}
	return min, rs.TransformError{}
}

func findMinValue(objectVal interface{}, minVal float64, err error, data rs.JSONQData, min float64) (float64, rs.TransformError) {
	switch val := objectVal.(type) {
	case float64:
		minVal = float64(val)
	case float32:
		minVal = float64(val)
	case int:
		minVal = float64(val)
	case int64:
		minVal = float64(val)
	case string:
		minVal, err = ConvertStringToFloat(val)
		if err != nil {
			errMessage := fmt.Sprintf("the variable %v which is trying to use for calculate the sum, is not a number %v", val, err)
			errorMap := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return 0, errorMap
		}
	default:
		errMessage := fmt.Sprintf("the variable %v which is trying to use for calculate the sum, is not a number %v", val, err)
		errorMap := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return 0, errorMap
	}
	if minVal < min {
		min = minVal
	}
	return min, rs.TransformError{}
}

func max(key string, result *gojsonq.JSONQ, data rs.JSONQData, arrayName string, filterConfig rs.Filter, innerTran rs.ProcessInnerTransform, statementPath string, processRules rs.ProcessRules) (float64, rs.TransformError) {
	var max float64 = -math.MaxFloat64
	var maxVal float64
	var logicalType string
	var filterConditions []rs.Rule
	var maxErr rs.TransformError
	if filterConfig.Id != nil {
		config := filterConfig
		condtionsConfig := config.Condition
		logicalType = condtionsConfig.VType
		filterConditions = condtionsConfig.Rules
	}

	checkAndUpdateRules(filterConditions)
	for _, listObject := range result.Get().([]interface{}) {
		objectVal, err := utils.GetFromMap(listObject.(map[string]interface{}), key, data)
		if err != nil && !data.JsonIgnoreProperty {
			errorMap := utils.PopulateTransFormError("1010", "the key :"+key+", is not found in the payload specified path "+arrayName)
			logger.Log.Error(data.LocalData, errorMap.Detailedmessage)
			return 0, errorMap
		} else if err != nil && data.JsonIgnoreProperty {
			objectVal = data.JsonIgnoreAliasValue
		}
		if filterConfig.Id != nil {
			responseBytes, _ := json.Marshal(listObject)
			arrData := gojsonq.New().JSONString(string(responseBytes))
			subData := rs.JSONQData{Jqdata: arrData, ShouldReset: true, LocalData: data.LocalData, TransformedData: data.TransformedData, ErrorConfig: data.ErrorConfig, JsonIgnoreProperty: data.JsonIgnoreProperty, ErrorData: data.ErrorData, JsonIgnoreAliasValue: data.JsonIgnoreAliasValue, IsExceptionHandled: data.IsExceptionHandled}

			res, tErr := processRules(logicalType, filterConditions, subData, innerTran, statementPath)
			if tErr.Detailedmessage != nil {
				return 0, tErr
			}
			if res {
				max, maxErr = findMaxValue(objectVal, maxVal, err, data, max)
				if maxErr.Detailedmessage != nil {
					return 0, maxErr
				}
			}
		} else {
			max, maxErr = findMaxValue(objectVal, maxVal, err, data, max)
			if maxErr.Detailedmessage != nil {
				return 0, maxErr
			}

		}

	}

	return max, rs.TransformError{}
}

func findMaxValue(objectVal interface{}, maxVal float64, err error, data rs.JSONQData, max float64) (float64, rs.TransformError) {
	switch val := objectVal.(type) {
	case float64:
		maxVal = float64(val)
	case float32:
		maxVal = float64(val)
	case int:
		maxVal = float64(val)
	case int64:
		maxVal = float64(val)
	case string:
		maxVal, err = ConvertStringToFloat(val)
		if err != nil {
			errMessage := fmt.Sprintf("the variable %v which is trying to use for calculate the sum, is not a number %v", val, err)
			errorMap := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return 0, errorMap
		}
	default:
		errMessage := fmt.Sprintf("the variable %v which is trying to use for calculate the sum, is not a number %v", val, err)
		errorMap := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return 0, errorMap
	}
	if maxVal > max {
		max = maxVal
	}
	return max, rs.TransformError{}
}
func count(resultList []interface{}, data rs.JSONQData, filterConfig rs.Filter, innerTran rs.ProcessInnerTransform, statementPath string, processRules rs.ProcessRules) (float64, rs.TransformError) {
	var count float64
	var logicalType string
	var filterConditions []rs.Rule
	if filterConfig.Id != nil {
		config := filterConfig
		condtionsConfig := config.Condition
		logicalType = condtionsConfig.VType
		filterConditions = condtionsConfig.Rules
	}

	checkAndUpdateRules(filterConditions)
	for _, listObject := range resultList {
		if filterConfig.Id != nil {
			responseBytes, _ := json.Marshal(listObject)
			arrData := gojsonq.New().JSONString(string(responseBytes))
			subData := rs.JSONQData{Jqdata: arrData, ShouldReset: true, LocalData: data.LocalData, TransformedData: data.TransformedData, ErrorConfig: data.ErrorConfig, JsonIgnoreProperty: data.JsonIgnoreProperty, ErrorData: data.ErrorData, JsonIgnoreAliasValue: data.JsonIgnoreAliasValue, IsExceptionHandled: data.IsExceptionHandled}

			res, tErr := processRules(logicalType, filterConditions, subData, innerTran, statementPath)
			if tErr.Detailedmessage != nil {
				return 0, tErr
			}
			if res {
				count++
			}
		} else {
			count++
		}
	}

	return count, rs.TransformError{}
}
