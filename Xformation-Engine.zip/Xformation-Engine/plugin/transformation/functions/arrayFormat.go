package functions

import (
	"encoding/json"
	"fmt"
	c "jocata_transform_plugin/constants"
	filt "jocata_transform_plugin/functions/filters"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"strings"

	"github.com/thedevsaddam/gojsonq/v2"
)

func FormatArray(inputData map[string]interface{}, data rs.JSONQData, fn rs.ProcessInnerTransform, con rs.ProcessCondition, filter rs.Filter, pe rs.ProcessExpression, processRules rs.ProcessRules, statementPath string) (interface{}, rs.TransformError) {
	functionName := inputData["format"].(string)
	var initValuesMap = make(map[string]interface{})

	if inputData["init"] != nil {
		initValuesMap = inputData["init"].(map[string]interface{})
	}

	var res interface{}
	var err error
	var aggData rs.JSONQData
	var valueData string
	if initValuesMap != nil && functionName != "iterate" {
		if (initValuesMap["value"] != nil) && (functionName != "jsonObjectList" && functionName != "getFilteredList") {
			valueData = initValuesMap["value"].(string)
			if strings.Contains(valueData, c.LOCAL_SEPARATOR) {
				dotPos := strings.Index(valueData, c.LOCAL_SEPARATOR)
				valueData = valueData[:dotPos]
				dat, err := json.Marshal(data.LocalData)

				if err != nil {
					logger.Log.Error(data.LocalData, "Error while retrieving the data from local %v ", err.Error())
					tErr := utils.PopulateTransFormError("1001", err.Error())
					return rs.ExpressionResult{}, tErr
				}
				arrData := gojsonq.New().JSONString(string(dat))
				aggData = rs.JSONQData{Jqdata: arrData}

			} else {
				aggData = data
			}

			res = aggData.Jqdata.Find(valueData)
			err = aggData.Jqdata.Error()

			if !data.JsonIgnoreProperty && err != nil && functionName != c.IS_EMPTY {
				logger.Log.Error(data.LocalData, "Error while finding arrayName in keyword list: %v  ", err.Error())
				errMessage := fmt.Sprintf("while finding arrayName %v, in the '%v' function,  : %v", valueData, functionName, err.Error())
				tErr := utils.PopulateTransFormError("1010", errMessage)
				return nil, tErr
			} else if data.JsonIgnoreProperty && err != nil && functionName != c.IS_EMPTY {
				logger.Log.Error(data.LocalData, "JsonIgnoreProperty Executed while finding : '%v' list", valueData)
				return nil, rs.TransformError{}
			}
		}
	}

	switch functionName {
	case "length":
		val, ok := (res.([]interface{}))
		if !ok {
			errMessage := fmt.Sprintf("the provided %v is not a array to perform function 'length' ", valueData)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return float64(len(val)), rs.TransformError{}

	case "push":
		var arr []interface{}
		if initValuesMap["values"] != nil {
			values := initValuesMap["values"].([]interface{})
			for _, variable := range values {
				data.ResetJsonqData()
				res, err = utils.FindValue(variable.(string), data)
				if err != nil {
					errMessage := fmt.Sprintf("in function 'push' %v ", err)
					tErr := utils.PopulateTransFormError("1001", errMessage)
					logger.Log.Error(data.LocalData, errMessage)
					return nil, tErr
				}
				arr = append(arr, res)
			}
		}
		return arr, rs.TransformError{}

	case "pop":
		s := res.([]interface{})
		if res != nil {
			_, ok := res.([]interface{})
			if !ok {
				errMessage := fmt.Sprintf("the provided %v is not a array to perform function 'pop' ", valueData)
				tErr := utils.PopulateTransFormError("1001", errMessage)
				logger.Log.Error(data.LocalData, errMessage)
				return nil, tErr
			}
		}
		popElement := s[len(s)-1]
		if len(s) > 0 {
			s = s[:len(s)-1]
		}
		utils.PushToMap(data.LocalData, valueData, nil, "list")
		utils.PushToMap(data.LocalData, valueData, s, "list")
		return popElement, rs.TransformError{}

	case "sort":

		var val interface{}
		if initValuesMap["sortBy"] == nil {
			val = aggData.Jqdata.Sort().Get()
		} else if initValuesMap["sortBy"] == "" {
			val = aggData.Jqdata.Sort().Get()
		} else {
			sortBy := initValuesMap["sortBy"].(string)
			val = aggData.Jqdata.SortBy(sortBy).Get()
		}
		err = aggData.Jqdata.Error()

		if err != nil {
			errMessage := fmt.Sprintf("while sorting the '%v' array :%v", valueData, err.Error())
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return val, rs.TransformError{}
	case "rsort":

		var val interface{}
		if initValuesMap["sortBy"] == nil {
			val = aggData.Jqdata.Sort("desc").Get()
		} else if initValuesMap["sortBy"] == "" {
			val = aggData.Jqdata.Sort("desc").Get()
		} else {
			sortBy := initValuesMap["sortBy"].(string)
			val = aggData.Jqdata.SortBy(sortBy, "desc").Get()
		}
		err := aggData.Jqdata.Error()
		if err != nil {
			errMessage := fmt.Sprintf("while reverse sorting the %v array :%v", valueData, err.Error())
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return val, rs.TransformError{}

	case c.SUM, c.MIN, c.MAX, c.AVG, c.COUNT:
		return Aggregate(functionName, initValuesMap, filter, data, pe, fn, statementPath, processRules)
	case "iterate":
		if initValuesMap["value"] != nil {
			array := initValuesMap["value"].(string)
			return IterateArray(array, initValuesMap, data, fn, pe, filter, con, processRules, statementPath)
		} else {
			var arr []interface{}
			if initValuesMap["transform"] == nil {
				tErr := utils.PopulateTransFormError("1002", "there is no arrayName.. So please supply the transform config")
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return arr, tErr
			}
			transConfig := initValuesMap["transform"].(map[string]interface{})

			abc, _ := json.Marshal(transConfig)
			transData := []byte(abc)
			var transform rs.Transform
			json.Unmarshal(transData, &transform)

			jsonProperty, jsonIgnoreAliasValue, err := utils.JsonIgnorePropAssign(data.LocalData, transform)
			if err != nil {
				tErr := utils.PopulateTransFormError("1009", "could not parse jsonIgnoreProperty value in transform")
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return "", tErr
			}

			iteratedData := data
			iteratedData.JsonIgnoreProperty = jsonProperty
			iteratedData.JsonIgnoreAliasValue = jsonIgnoreAliasValue
			var statementDetails = rs.StatementDetails{
				TransformType: c.TRANSFORM,
				StatementPath: statementPath,
			}

			tErr := fn(transform, iteratedData, &arr, statementDetails)
			if tErr.Detailedmessage != nil {
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return arr, tErr
			}
			return arr, rs.TransformError{}
		}
	case "multiSelect":

		values := initValuesMap["values"].([]interface{})
		return values, rs.TransformError{}

	case "create":
		var val interface{}
		var list []interface{}
		var size int
		variable := initValuesMap["size"].(string)
		if val, err = utils.FindValue(variable, data); err != nil {
			if err != nil {
				errMessage := fmt.Sprintf("while creating list based on the size : %v", err.Error())
				tErr := utils.PopulateTransFormError("1001", errMessage)
				logger.Log.Error(data.LocalData, errMessage)
				return nil, tErr
			}
		}
		floatVal, ok := val.(float64)
		if !ok {

		} else {
			size = int(floatVal)
		}

		for i := 1; i <= size; i++ {
			var EmptyMapp = make(map[string]interface{})
			list = append(list, EmptyMapp)
		}

		return list, rs.TransformError{}

	case "generateCombinations":
		listOfprimitives, ok := res.([]interface{})
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a array", functionName, valueData)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}

		var stringSlice []string
		for _, v := range listOfprimitives {
			stringSlice = append(stringSlice, v.(string))
		}

		var result []string
		var finalResult []interface{}

		GenerateCombinations(stringSlice, "", &result)
		for _, val := range result {
			finalResult = append(finalResult, val)
		}
		return finalResult, rs.TransformError{}

	case "reverse":
		list, ok := res.([]interface{})
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a array", functionName, valueData)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}

		reverseSlice(list)
		return list, rs.TransformError{}

	case "allStatements":
		res := `allStatements`
		return res, rs.TransformError{}

	case "getFilteredList":
		valueData = initValuesMap["value"].(string)
		res, err := utils.FindValue(valueData, data)
		if !data.JsonIgnoreProperty && err != nil {
			logger.Log.Error(data.LocalData, "Error while finding arrayName in keyword list: %v  ", err.Error())
			errMessage := fmt.Sprintf("while finding arrayName %v, in the '%v' function,  : %v", valueData, functionName, err.Error())
			tErr := utils.PopulateTransFormError("1010", errMessage)
			return nil, tErr
		} else if data.JsonIgnoreProperty && err != nil {
			logger.Log.Error(data.LocalData, "JsonIgnoreProperty Executed while finding : '%v' list", valueData)
			return nil, rs.TransformError{}
		}

		list, ok := res.([]interface{})
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a array", functionName, valueData)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return filt.Filter(filter, list, data, fn, processRules, statementPath)

	case "jsonObjectList":
		valueData = initValuesMap["value"].(string)
		var result interface{}
		err := json.Unmarshal([]byte(valueData), &result)
		if err != nil {
			errMessage := fmt.Sprintf(" in function '%v' : while converting string to json list : ", functionName)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return result, rs.TransformError{}
	case "clearTheList":
		return nil, rs.TransformError{}
	case c.IS_EMPTY:
		return checkListIsEmpty(res, initValuesMap, data)
	default:
		errMessage := fmt.Sprintf("Given Type was  %v is Invalid for Keyword", functionName)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
}

func reverseSlice(slice []interface{}) {
	for i, j := 0, len(slice)-1; i < j; i, j = i+1, j-1 {
		slice[i], slice[j] = slice[j], slice[i]
	}
}
func checkListIsEmpty(res interface{}, initValuesMap map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	if initValuesMap["value"] == nil {
		errMessage := fmt.Sprintf("in function '%v'", c.IS_EMPTY+" value key is missing in configuration.")
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	if res == nil {
		return true, rs.TransformError{}
	}

	switch val := res.(type) {
	case []interface{}:
		return len(val) == 0, rs.TransformError{}
	case []string:
		return len(val) == 0, rs.TransformError{}
	case []float64:
		return len(val) == 0, rs.TransformError{}
	}
	return false, rs.TransformError{}
}
