package functions

import (
	"fmt"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"strconv"
	"strings"
)

func Split(args map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function Split")
	var res []string
	var values []interface{}

	var dataValue string
	var variable string

	if args["dataValue"] != nil {
		variable = args["dataValue"].(string)
	} else {
		variable = args["value"].(string)
	}

	dataVal, err := utils.FindValue(variable, data)
	if !data.JsonIgnoreProperty && err != nil {
		errMessage := fmt.Sprintf("in function 'split' %v", err.Error())
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	} else if data.JsonIgnoreProperty && err != nil {
		logger.Log.Trace(data.LocalData, "JsonIgnoreProperty Executed for %v field ", variable)
		return nil, rs.TransformError{}
	}

	splitVal := args["splitby"]

	if dataVal != nil {
		dataValue = dataVal.(string)
	} else {
		return res, rs.TransformError{}
	}
	splitby, ok := splitVal.(float64)
	if ok {
		split := int(splitby)
		res = chunks(data, dataValue, split)
	} else {
		splitby := splitVal.(string)
		res = strings.Split(dataValue, splitby)
	}
	for _, val := range res {
		values = append(values, val)
	}
	return values, rs.TransformError{}
}

func SplitKeyword(data rs.JSONQData, value string, args map[string]interface{}) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function Split")
	var res = []interface{}{}
	splitVal := args["splitby"]
	splitby := splitVal.(string)

	value = strings.TrimSuffix(value, splitby)
	value = strings.TrimPrefix(value, splitby)
	values := strings.Split(value, splitby)

	for _, val := range values {
		res = append(res, val)
	}
	return res, rs.TransformError{}
}

func Chunk(data rs.JSONQData, value string, args map[string]interface{}) (interface{}, rs.TransformError) {

	splitVal := args["chunkby"]
	splitby, ok := splitVal.(float64)
	if !ok {
		val := splitVal.(string)
		splitby, _ = strconv.ParseFloat(strings.TrimSpace(val), 64)
	}
	split := int(splitby)
	res := chunks(data, value, split)
	return res, rs.TransformError{}
}

func chunks(data rs.JSONQData, s string, chunkSize int) []string {
	logger.Log.Trace(data.LocalData, "Entered into function chunk")
	if chunkSize >= len(s) {
		return []string{s}
	}
	var chunks []string
	chunk := make([]rune, chunkSize)
	len := 0
	for _, r := range s {
		chunk[len] = r
		len++
		if len == chunkSize {
			chunks = append(chunks, string(chunk))
			len = 0
		}
	}
	if len > 0 {
		chunks = append(chunks, string(chunk[:len]))
	}
	return chunks
}
