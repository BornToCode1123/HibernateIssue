package filters

import (
	"encoding/json"
	"errors"
	"fmt"

	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"

	"github.com/thedevsaddam/gojsonq/v2"
	"golang.org/x/exp/slices"
)

func BuildWhereclause(filterConfig rs.Filter, data rs.JSONQData, fn rs.ProcessExpression, innerTran rs.ProcessInnerTransform, statementPath string) rs.TransformError {

	config := filterConfig
	condtionsConfig := config.Condition
	logicalType := condtionsConfig.VType
	filterConditions := condtionsConfig.Rules
	for _, element := range filterConditions {
		condition := element
		data.ShouldReset = false
		jqp, tErr := buildJsonQueryParams(condition, data, fn, innerTran, statementPath)

		if tErr.Detailedmessage != nil {
			return tErr
		}

		if logicalType == "and" {
			data.Jqdata.Where(jqp.Lhs, jqp.Operator, jqp.Rhs)
		} else if logicalType == "or" {
			data.Jqdata.OrWhere(jqp.Lhs, jqp.Operator, jqp.Rhs)
		} else {
			tErr := utils.GetErrorObject("1002")
			tErr.Detailedmessage = fmt.Sprintf("The Logical operator %v being used.. is not implemented", logicalType)
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return tErr
		}
	}
	return rs.TransformError{}
}

func buildJsonQueryParams(conditionalRule rs.Rule, data rs.JSONQData, fn rs.ProcessExpression, innerTran rs.ProcessInnerTransform, statementPath string) (rs.JSONQueryParam, rs.TransformError) {
	condition := conditionalRule.RuleHolder.(rs.RelationalRule)
	evalLhs, lhserr := fn(condition.Lhs, data, innerTran, statementPath)
	evalRhs, rhserr := fn(condition.Rhs, data, innerTran, statementPath)
	operator := condition.Operator
	actualOp := operator.ActualValue
	var tErr rs.TransformError
	operatorType, err := getFilterOperator(data, actualOp)
	if err != nil {
		tErr = utils.PopulateTransFormError("1002", err.Error())
		return rs.JSONQueryParam{}, tErr
	}
	var message string

	if lhserr.Detailedmessage != nil {
		tErr = lhserr
		errMessage := fmt.Sprintf("On LHS , %v .!", lhserr.Detailedmessage.(string))
		message = message + errMessage
	}

	if rhserr.Detailedmessage != nil {
		tErr = rhserr
		errMessage := fmt.Sprintf("On RHS , %v .!", rhserr.Detailedmessage.(string))
		message = message + errMessage
	}

	if len(message) > 0 {
		tErr.Detailedmessage = message
		return rs.JSONQueryParam{}, tErr
	} else {
		return rs.JSONQueryParam{Lhs: evalLhs.Evalue.(string), Operator: operatorType, Rhs: evalRhs.Evalue}, rs.TransformError{}
	}

}

func getFilterOperator(data rs.JSONQData, operator string) (string, error) {
	arrayOfOperators := []string{"==", ">", "<", "!=", ">=", "<="}
	result := slices.Contains(arrayOfOperators, operator)
	var actualOp string

	if result {
		if operator == "==" {
			actualOp = "="
		} else {
			actualOp = operator
		}
	} else {
		if operator == "=" {
			errMessage := fmt.Sprintf("The Relational operator %v being used..  Use == for equality ", operator)
			return "", errors.New(errMessage)
		} else {
			errMessage := fmt.Sprintf("The Relational operator %v being used.. is not implemented", operator)
			logger.Log.Error(data.LocalData, errMessage)
			return "", errors.New(errMessage)
		}
	}

	return actualOp, nil
}

func Filter(filterConfig rs.Filter, arrayData []interface{}, data rs.JSONQData, innerTran rs.ProcessInnerTransform, processRules rs.ProcessRules, statementPath string) ([]interface{}, rs.TransformError) {
	var updatetdArray = []interface{}{}
	config := filterConfig
	condtionsConfig := config.Condition
	logicalType := condtionsConfig.VType
	filterConditions := condtionsConfig.Rules

	if len(condtionsConfig.Rules) == 0 {
		return arrayData, rs.TransformError{}
	}

	for _, record := range arrayData {
		responseBytes, _ := json.Marshal(record)
		arrData := gojsonq.New().JSONString(string(responseBytes))
		subData := rs.JSONQData{Jqdata: arrData, ShouldReset: true, LocalData: data.LocalData, TransformedData: data.TransformedData, ErrorConfig: data.ErrorConfig, JsonIgnoreProperty: data.JsonIgnoreProperty, ErrorData: data.ErrorData, JsonIgnoreAliasValue: data.JsonIgnoreAliasValue, IsExceptionHandled: data.IsExceptionHandled}

		res, tErr := processRules(logicalType, filterConditions, subData, innerTran, statementPath)
		if tErr.Detailedmessage != nil {
			return nil, tErr
		}
		if res {
			updatetdArray = append(updatetdArray, record)
		}
	}

	return updatetdArray, rs.TransformError{}
}
