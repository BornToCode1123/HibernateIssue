package functions

import (
	b64 "encoding/base64"
	"encoding/json"
	"fmt"
	"jocata_transform_plugin/constants"
	logger "jocata_transform_plugin/log"
	par "jocata_transform_plugin/parse"
	rs "jocata_transform_plugin/structs"
	utils "jocata_transform_plugin/utils"
	"regexp"
	"strconv"
	"strings"

	"github.com/clbanning/mxj"
	"github.com/iancoleman/strcase"
)

func FormatString(inputData map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function Text")
	conversion := inputData["format"].(string)
	var initValuesMap map[string]interface{}
	if inputData["init"] != nil {
		initValuesMap = inputData["init"].(map[string]interface{})
	}

	var res interface{}
	var err error
	var variable string
	if initValuesMap["value"] != nil {
		variable = initValuesMap["value"].(string)
		res, err = utils.FindValue(variable, data)
	}

	if err != nil && conversion != constants.IS_EMPTY {
		errMessage := fmt.Sprintf("in function '%v' %v", conversion, err.Error())
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}

	if data.JsonIgnoreProperty && res == nil && conversion != "concat" && conversion != "generateUUID" && conversion != constants.IS_EMPTY {
		logger.Log.Trace(data.LocalData, "JsonIgnoreProperty Executed for %v field ", variable)
		return nil, rs.TransformError{}
	}

	switch conversion {
	case "trim":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return strings.TrimSpace(value), rs.TransformError{}
	case "toUpperCase":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return strings.ToUpper(value), rs.TransformError{}
	case "toLowerCase":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return strings.ToLower(value), rs.TransformError{}
	case "toPascalCase":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return strcase.ToCamel(value), rs.TransformError{}

	case "toCamelCase":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return strcase.ToLowerCamel(value), rs.TransformError{}

	case "toSnakeCase":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return strcase.ToSnake(value), rs.TransformError{}

	case "toKebabCase":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return strcase.ToKebab(value), rs.TransformError{}

	case "toNumber":

		switch value := res.(type) {
		case float64:
			return value, rs.TransformError{}
		case string:
			value = strings.ReplaceAll(value, ",", "")
			intValue, err := strconv.ParseFloat(value, 64)
			if err != nil {
				logger.Log.Error(data.LocalData, "Error while parsing text to number %v", err)
				return float64(0), rs.TransformError{}
			}
			return intValue, rs.TransformError{}
		default:
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
	case "toBoolean":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		boolValue, err := strconv.ParseBool(value)
		if err != nil {
			logger.Log.Error(data.LocalData, "Error while parsing text to bool %v", err)
			return false, rs.TransformError{}
		}
		return boolValue, rs.TransformError{}
	case "isNumber":

		switch value := res.(type) {
		case float64:
			return true, rs.TransformError{}
		case string:
			_, err := strconv.ParseFloat(value, 64)
			if err != nil {
				logger.Log.Trace(data.LocalData, "Error while parsing text to number %v", err)
				return false, rs.TransformError{}
			}
			return true, rs.TransformError{}
		default:
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return false, tErr
		}

	case "isBoolean":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		_, err := strconv.ParseBool(value)
		if err != nil {
			logger.Log.Error(data.LocalData, "Error while parsing text to bool %v", err)
			return false, rs.TransformError{}
		}
		return true, rs.TransformError{}
	case "toJson":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		var mp interface{}
		err := json.Unmarshal([]byte(value), &mp)
		if err != nil {
			errMessage := fmt.Sprintf(" in function '%v' : %v ", conversion, err)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return mp, rs.TransformError{}

	case "decode":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		des, ee := b64.StdEncoding.DecodeString(value)
		if ee != nil {
			logger.Log.Error(data.LocalData, ee.Error)
			print(ee.Error())
		}
		return string(des), rs.TransformError{}

	case "encode":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		encodedStr := b64.StdEncoding.EncodeToString([]byte(value))
		return string(encodedStr), rs.TransformError{}

	case "replace":
		data.ResetJsonqData()
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		fields := initValuesMap["fields"].(map[string]interface{})

		for f, fv := range fields {
			data.ResetJsonqData()
			fv := fv.(string)

			res, err = utils.FindValue(fv, data)
			if err != nil {
				errMessage := fmt.Sprintf("in function '%v' %v", conversion, err.Error())
				tErr := utils.PopulateTransFormError("1010", errMessage)
				logger.Log.Error(data.LocalData, errMessage)
				return nil, tErr
			}
			if res != nil {
				fv = res.(string)
			}
			value = strings.ReplaceAll(value, f, fv)
		}
		return value, rs.TransformError{}

	case "toXml":
		value, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		map1, err := mxj.NewMapXmlSeq([]byte(value))
		if err != nil {
			logger.Log.Error(data.LocalData, err.Error)
			tErr := utils.PopulateTransFormError("1001", err.Error())
			return nil, tErr
		}
		return map1.Old(), rs.TransformError{}
	case "statementId":
		res, err := utils.GetFromMap(data.LocalData, "statementId", data)
		if err != nil {
			errMessage := fmt.Sprintf("in keyword 'statementId' : %v", err)
			tErr := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return rs.ExpressionResult{}, tErr
		}
		return res, rs.TransformError{}

	case "getNullValue":
		return nil, rs.TransformError{}
	case "generateUUID":
		UUIDType := initValuesMap["type"].(string)
		UUIDSize := initValuesMap["size"].(float64)
		UUID, err := utils.GetUUID(data, UUIDType, UUIDSize)
		if err != nil {
			tErr := utils.PopulateTransFormError("1001", err.Error())
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return "", tErr
		}
		return UUID, rs.TransformError{}

	case "concat":
		return ConcatData(initValuesMap, data)
	case "split":
		var val string
		if res != nil {
			val = res.(string)
		}
		return SplitKeyword(data, val, initValuesMap)
	case "chunk":
		var val string
		if res != nil {
			val = res.(string)
		}
		return Chunk(data, val, initValuesMap)
	case "fromJson":
		value, ok := res.(map[string]interface{})
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a Object", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		jsn, err := json.Marshal(value)

		if err != nil {
			errMessage := fmt.Sprintf(" in function '%v' while converting into text %v ", conversion, err)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return string(jsn), rs.TransformError{}
	case "fromXml":
		value, ok := res.(map[string]interface{})
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a Object", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		result := par.AddSeqToMap(value)
		sjjs, _ := json.Marshal(result)
		xm, _ := mxj.NewMapJson(sjjs)
		z, err := xm.XmlSeq()
		if err != nil {
			errMessage := fmt.Sprintf(" in function '%v' while converting into text %v ", conversion, err)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		cc := string(z)
		return cc, rs.TransformError{}
	case "hasSubString":
		data.ResetJsonqData()
		str, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		if initValuesMap["subString"] != nil {
			variable = initValuesMap["subString"].(string)
			res, err = utils.FindValue(variable, data)
		} else {
			errMessage := fmt.Sprintf("in function '%v' SubString is nil", conversion)
			tErr := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}

		if err != nil {
			errMessage := fmt.Sprintf("in function '%v' %v", conversion, err.Error())
			tErr := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		substr, ok := res.(string)
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}

		return strings.Contains(str, substr), rs.TransformError{}

	case "subString":
		textVal, ok := res.(string)
		startIndex := int(initValuesMap["startIndex"].(float64))
		endIndex := int(initValuesMap["endIndex"].(float64))
		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		if endIndex < len(textVal) && startIndex < len(textVal) && startIndex < endIndex {
			return textVal[startIndex:endIndex], rs.TransformError{}
		} else {
			errMessage := "Given Index values in substring function are greater than length of the actual text"
			tErr := utils.PopulateTransFormError("1002", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}

	case "indexOf":
		textVal, ok := res.(string)

		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		subString := initValuesMap["subString"].(string)
		index := strings.Index(textVal, subString)
		return float64(index), rs.TransformError{}

	case "length":
		textVal, ok := res.(string)

		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		return float64(len(textVal)), rs.TransformError{}
	case "regex":
		textVal, ok := res.(string)

		if !ok {
			errMessage := fmt.Sprintf(" in function '%v' :the provided %v is not a string", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		format := initValuesMap["format"].(string)
		pattern := regexp.MustCompile(format)
		valid := pattern.MatchString(textVal)

		return valid, rs.TransformError{}
	case constants.IS_EMPTY:
		return isTextEmpty(res, initValuesMap, data)
	default:
		errMessage := fmt.Sprintf("Given Format was  %v is Invalid for Keyword", conversion)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
}
func isTextEmpty(textVal interface{}, initValuesMap map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	if initValuesMap["value"] == nil {
		errMessage := fmt.Sprintf("in function '%v'", constants.IS_EMPTY+" value key is missing in configuration.")
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	if textVal == nil {
		return true, rs.TransformError{}
	}
	if str, ok := textVal.(string); ok {
		return str == "", rs.TransformError{}
	}
	return false, rs.TransformError{}
}
