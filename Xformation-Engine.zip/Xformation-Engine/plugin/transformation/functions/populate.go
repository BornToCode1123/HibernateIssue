package functions

import (
	"fmt"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"strings"
)

func PopulateFields(args map[string]interface{}, data rs.JSONQData) (map[string]interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function Populate")
	fields := args["fields"].([]interface{})
	var sfields []string
	for _, field := range fields {
		f := field.(string)
		sfields = append(sfields, f)
	}
	var result = make(map[string]interface{})
	for _, f := range sfields {
		data.ResetJsonqData()
		str := strings.Split(f, " as ")
		var value interface{}
		var err error
		for i, val := range str {
			if i == 0 {
				variable := strings.TrimSpace(val)
				value, err = utils.FindValue(variable, data)
				if !data.JsonIgnoreProperty && err != nil {
					errMessage := fmt.Sprintf("in function 'populate' %v", err.Error())
					tErr := utils.PopulateTransFormError("1010", errMessage)
					logger.Log.Error(data.LocalData, errMessage)
					return nil, tErr
				} else if data.JsonIgnoreProperty && err != nil {
					logger.Log.Trace(data.LocalData, "JsonIgnoreProperty Executed for %v field ", variable)
					value = data.JsonIgnoreAliasValue
				}
			} else {
				key := strings.TrimSpace(val)
				utils.PushToMap(result, key, value, "map")
			}
		}
	}
	return result, rs.TransformError{}
}

func Populate(args map[string]interface{}, data rs.JSONQData) (map[string]interface{}, rs.TransformError) {
	var result = make(map[string]interface{})
	logger.Log.Trace(data.LocalData, "Entered into function Populate")
	fields := args["fields"].(map[string]interface{})
	for key, variable := range fields {
		data.ResetJsonqData()
		value, err := utils.FindValue(variable.(string), data)
		if err != nil {
			errMessage := fmt.Sprintf("in function 'populate' %v", err.Error())
			tErr := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		}
		utils.PushToMap(result, key, value, "map")
	}
	return result, rs.TransformError{}
}
