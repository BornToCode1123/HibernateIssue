package functions

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/des"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"strings"
)

// nonce or IV
// var bites = []byte{35, 46, 57, 24, 85, 35, 24, 74, 87, 35, 88, 98, 66, 32, 14, 05}
var bites = "1234567890123456"
var bytesDES = "12345678"
var nonceGCM = "123456789012"

// secretkeys
const AESSecretKey string = "abc&1*~#^2^#s0^=)^^7%b34"
const DESSecretKey string = "zyx1mo3b"
const AESGCMSecretKey string = "AES256Key-32Characters1234567890"
const DES3Key string = "zyx1mo3bzyx1mo3bzyx1mo3b"

func Encrypt(funcArgs map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function encrypt")
	var iv string
	var encData interface{}
	var tErr rs.TransformError
	variable := funcArgs["value"].(string)

	dataVal, err := utils.FindValue(variable, data)
	if !data.JsonIgnoreProperty && err != nil {
		errMessage := fmt.Sprintf("in function 'encrypt' %v", err.Error())
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return rs.ExpressionResult{}, tErr
	} else if data.JsonIgnoreProperty && err != nil {
		return rs.ExpressionResult{}, rs.TransformError{}
	}

	mJson, err := json.Marshal(dataVal)
	if err != nil {
		errMsg := fmt.Sprintf("data provided cannot be parsed")
		tErr := utils.PopulateTransFormError("1008", errMsg)
		logger.Log.Error(data.LocalData, errMsg)
		return nil, tErr
	}
	jsonStr := string(mJson)
	encType := funcArgs["encType"]

	if encType == nil {
		errMessage := fmt.Sprintf("Encryption type cannot be empty")
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	switch encType {

	case "AES":
		encData, tErr = modeEncryption(data, jsonStr, funcArgs, iv, "AES")

	case "DES":
		encData, tErr = modeEncryption(data, jsonStr, funcArgs, iv, "DES")

	case "3DES":
		encData, tErr = modeEncryption(data, jsonStr, funcArgs, iv, "3DES")

	default:
		errMessage := fmt.Sprintf("The encryption type  %v specified in the json is invalid", encType)
		logger.Log.Error(data.LocalData, errMessage)
		tErr = utils.PopulateTransFormError("1002", errMessage)
	}

	return encData, tErr
}

func blockCipherCreation(data rs.JSONQData, cipherType string, secretKey string) (cipher.Block, rs.TransformError) {
	var block cipher.Block
	var err error
	var tErr rs.TransformError

	if cipherType == "AES" {
		block, err = aes.NewCipher([]byte(secretKey))
	} else if cipherType == "DES" {
		block, err = des.NewCipher([]byte(secretKey))
	} else if cipherType == "3DES" {
		block, err = des.NewTripleDESCipher([]byte(secretKey))
	} else {
		errMsg := fmt.Sprintf("Invalid encryption type %v", cipherType)
		tErr = utils.PopulateTransFormError("1002", errMsg)
	}
	if err != nil {
		errMsg := fmt.Sprintf("Invalid secretkey %v passed for the cipher type %v", secretKey, cipherType)
		tErr = utils.PopulateTransFormError("1010", errMsg)
		logger.Log.Error(data.LocalData, errMsg)
	}
	return block, tErr
}

func modeEncryption(data rs.JSONQData, jsonStr string, funcArgs map[string]interface{}, iv string, encType string) (interface{}, rs.TransformError) {
	var res interface{}
	var errorMsg string
	var tErr rs.TransformError
	plainText := []byte(jsonStr)
	secretKey := funcArgs["encKey"]
	encodeType := funcArgs["encodeType"]
	encMode := funcArgs["encMode"]

	if encMode == nil {
		encMode = "CBC"
	}
	if encMode == "GCM" && encType != "AES" {
		errMessage := fmt.Sprintf("GCM mode is applicable only for encryption type AES")
		tErr := utils.PopulateTransFormError("1010", errMessage)
		return nil, tErr
	}
	// setting default Secret key & IV if they are not provided
	secretKey, iv, tErr = defaultSecretAndIV(data, encType, encMode, secretKey, funcArgs, iv)
	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in getting secretkey and IV while encryption ----%v", tErr.Detailedmessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	if encType == "AES" && encMode != "GCM" && len(iv) != 16 {
		errorMsg = fmt.Sprintf("IV length specified is incorrect, please pass the IV of size 16")
	} else if encType == "AES" && encMode == "GCM" && len(iv) != 12 {
		errorMsg = fmt.Sprintf("IV length specified is incorrect, please pass the IV of size 12")
	} else if (encType == "DES" || encType == "3DES") && len(iv) != 8 {
		errorMsg = fmt.Sprintf("IV length specified is incorrect, please pass the IV of size 8")
	}
	if errorMsg != "" {
		tErr = utils.PopulateTransFormError("1010", errorMsg)
		logger.Log.Error(data.LocalData, errorMsg)
		return nil, tErr
	}
	bs := []byte(iv)

	block, tErr := blockCipherCreation(data, encType, secretKey.(string))
	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = fmt.Sprintf("error in creation of Cipher %v", tErr.Detailedmessage)
		logger.Log.Error(data.LocalData, tErr.Detailedmessage)
		return nil, tErr
	}
	switch encMode {
	case "ECB":
		res, tErr = ECBEnc(data, plainText, block, encodeType)

	case "CBC":
		res, tErr = CBCEnc(data, bs, plainText, block, encodeType)

	case "CFB":
		res, tErr = CFBEnc(data, bs, jsonStr, block, encodeType)

	case "OFB":
		res, tErr = OFBEnc(data, bs, jsonStr, block, encodeType)

	case "CTR":
		res, tErr = CTREnc(data, bs, jsonStr, block, encodeType)

	case "GCM":
		if encType == "AES" && secretKey == nil {
			secretKey = AESGCMSecretKey
		}
		return AESGCM(data, secretKey.(string), bs, jsonStr, block, encodeType)

	default:
		errMsg := fmt.Sprintf("The encryption mode  %v specified in the json is invalid", encMode)
		logger.Log.Error(data.LocalData, errMsg)
		tErr = utils.PopulateTransFormError("1002", errMsg)
	}

	return res, tErr
}

func AESGCM(data rs.JSONQData, secretKey string, bs []byte, plainText string, block cipher.Block, encodeType interface{}) (interface{}, rs.TransformError) {
	var tErr rs.TransformError
	aesgcm, err := cipher.NewGCM(block)
	if err != nil {
		errMsg := fmt.Sprintf("GCM block creation issue")
		tErr = utils.PopulateTransFormError("1010", errMsg)
	}
	ciphertext := aesgcm.Seal(nil, bs, []byte(plainText), nil)
	encodedValue, tErr := Encode(data, ciphertext, encodeType)
	return encodedValue, tErr
}

func CBCEnc(data rs.JSONQData, bs []byte, plainText []byte, block cipher.Block, encodeType interface{}) (interface{}, rs.TransformError) {
	cbc := cipher.NewCBCEncrypter(block, bs)
	paddedData := PKCS5Padding([]byte(plainText), aes.BlockSize)
	cbc.CryptBlocks(paddedData, paddedData)
	encodedValue, tErr := Encode(data, paddedData, encodeType)
	return encodedValue, tErr
}

func ECBEnc(data rs.JSONQData, plainText []byte, block cipher.Block, encodeType interface{}) (interface{}, rs.TransformError) {
	ecb := NewECBEncrypter(block)
	content := []byte(plainText)
	content = PKCS5Padding(content, block.BlockSize())
	crypted := make([]byte, len(content))
	ecb.CryptBlocks(crypted, content)
	encodedValue, tErr := Encode(data, crypted, encodeType)
	return encodedValue, tErr
}

func CFBEnc(data rs.JSONQData, bs []byte, jsonStr string, block cipher.Block, encodeType interface{}) (interface{}, rs.TransformError) {
	plainText := []byte(jsonStr)
	cfb := cipher.NewCFBEncrypter(block, bs)
	cipherText := make([]byte, len(plainText))
	cfb.XORKeyStream(cipherText, plainText)
	encodedValue, tErr := Encode(data, cipherText, encodeType)
	return encodedValue, tErr
}

func OFBEnc(data rs.JSONQData, bs []byte, jsonStr string, block cipher.Block, encodeType interface{}) (interface{}, rs.TransformError) {
	plainText := []byte(jsonStr)
	ofb := cipher.NewOFB(block, bs)
	cipherText := make([]byte, len(plainText))
	ofb.XORKeyStream(cipherText, plainText)
	encodedValue, tErr := Encode(data, cipherText, encodeType)
	return encodedValue, tErr
}

func CTREnc(data rs.JSONQData, bs []byte, jsonStr string, block cipher.Block, encodeType interface{}) (interface{}, rs.TransformError) {
	plainText := []byte(jsonStr)
	ctr := cipher.NewCTR(block, bs)
	cipherText := make([]byte, len(plainText))
	ctr.XORKeyStream(cipherText, plainText)
	encodedValue, tErr := Encode(data, cipherText, encodeType)
	return encodedValue, tErr
}

func DES3Enc(data rs.JSONQData, jsonStr string, funcArgs map[string]interface{}) (interface{}, error) {
	secretKey := funcArgs["encKey"]
	if secretKey == nil {
		secretKey = DES3Key
	}
	c, err := des.NewTripleDESCipher([]byte(DES3Key))
	if err != nil {
		errMessage := fmt.Sprintf("encrypt NewTripleDESCipher(%d bytes) = %s", len(DES3Key), err)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, errors.New(errMessage)
	}
	out := make([]byte, len([]byte(jsonStr)))
	c.Encrypt(out, []byte(jsonStr))
	return hex.EncodeToString(out), err
}

func PKCS5Trimming(encrypt []byte) []byte {
	padding := encrypt[len(encrypt)-1]
	return encrypt[:len(encrypt)-int(padding)]
}

func PKCS5Padding(ciphertext []byte, blockSize int) []byte {
	padding := blockSize - len(ciphertext)%blockSize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(ciphertext, padtext...)
}

func PKCS5UnPadding(src []byte) []byte {
	length := len(src)
	unpadding := int(src[length-1])
	return src[:(length - unpadding)]
}

func pkcs7Pad(data rs.JSONQData, b []byte, blocksize int) ([]byte, error) {
	if blocksize <= 0 {
		errMessage := "Invalid Block size"
		logger.Log.Error(data.LocalData, errMessage)
		return nil, errors.New(errMessage)
	}
	if b == nil || len(b) == 0 {
		errMessage := fmt.Sprintf("Invalid PKCS7 Data")
		logger.Log.Error(data.LocalData, errMessage)
		return nil, errors.New(errMessage)
	}
	n := blocksize - (len(b) % blocksize)
	pb := make([]byte, len(b)+n)
	copy(pb, b)
	copy(pb[len(b):], bytes.Repeat([]byte{byte(n)}, n))
	return pb, nil
}

func pkcs7Unpad(b []byte, blocksize int) ([]byte, error) {
	errMsg1 := fmt.Sprintf("Invalid PKCS7 Block SizeData")
	errMsg2 := fmt.Sprintf("Invalid PKCS7 Data")
	errMsg3 := fmt.Sprintf("Invalid PKCS7 padding")

	if blocksize <= 0 {
		return nil, errors.New(errMsg1)
	}
	if b == nil || len(b) == 0 {
		return nil, errors.New(errMsg2)
	}
	if len(b)%blocksize != 0 {
		return nil, errors.New(errMsg3)
	}
	c := b[len(b)-1]
	n := int(c)
	if n == 0 || n > len(b) {
		return nil, errors.New(errMsg3)
	}
	for i := 0; i < n; i++ {
		if b[len(b)-n+i] != c {
			return nil, errors.New(errMsg3)
		}
	}
	return b[:len(b)-n], nil
}

func Encode(data rs.JSONQData, inputString []byte, encodeType interface{}) (string, rs.TransformError) {
	if encodeType != nil && strings.EqualFold(encodeType.(string), "hex") {
		return hex.EncodeToString(inputString), rs.TransformError{}
	} else if encodeType == nil || strings.EqualFold(encodeType.(string), "Base64") {
		return base64.StdEncoding.EncodeToString(inputString), rs.TransformError{}
	} else {
		errMsg := fmt.Sprintf("Invalid encode type. Please specify base64 or hex")
		logger.Log.Error(data.LocalData, errMsg)
		tErr := utils.PopulateTransFormError("1010", errMsg)
		return "", tErr
	}

}

func defaultSecretAndIV(data rs.JSONQData, encDectype string, mode interface{}, secretKey interface{}, funcArgs map[string]interface{}, iv string) (interface{}, string, rs.TransformError) {
	if (funcArgs["iv"] != nil && funcArgs["iv"] == "") || (secretKey != nil && secretKey == "") {
		errMsg := fmt.Sprintf("Provided IV or secret key is incorrect")
		logger.Log.Error(data.LocalData, errMsg)
		tErr := utils.PopulateTransFormError("1010", errMsg)
		return nil, "", tErr
	}

	if encDectype == "AES" && mode != "GCM" && secretKey == nil {
		secretKey = AESSecretKey
	} else if encDectype == "AES" && mode == "GCM" && secretKey == nil {
		secretKey = AESGCMSecretKey
	} else if encDectype == "DES" && secretKey == nil {
		secretKey = DESSecretKey
	} else if encDectype == "3DES" && secretKey == nil {
		secretKey = DES3Key
	}

	if funcArgs["iv"] != nil {
		iv = funcArgs["iv"].(string)
	} else if (funcArgs["iv"] == nil) && encDectype == "AES" && mode != "GCM" {
		iv = string(bites)
	} else if (funcArgs["iv"] == nil) && encDectype == "AES" && mode == "GCM" {
		iv = string(nonceGCM)
	} else if (funcArgs["iv"] == nil) && (encDectype == "DES" || encDectype == "3DES") {
		iv = string(bytesDES)
	}
	return secretKey, iv, rs.TransformError{}
}

type ecb struct {
	b         cipher.Block
	blockSize int
	tmp       []byte
}

func newECB(b cipher.Block) *ecb {
	return &ecb{
		b:         b,
		blockSize: b.BlockSize(),
		tmp:       make([]byte, b.BlockSize()),
	}
}

type ecbEncrypter ecb

// NewECBEncrypter returns a BlockMode which encrypts in elecronic codebook (ECB)
// mode, using the given Block (Cipher).
func NewECBEncrypter(b cipher.Block) cipher.BlockMode {
	return (*ecbEncrypter)(newECB(b))
}

func (x *ecbEncrypter) BlockSize() int { return x.blockSize }

func (x *ecbEncrypter) CryptBlocks(dst, src []byte) {

	if len(src)%x.blockSize != 0 {
		panic("crypto/cipher: input not full blocks")
	}

	if len(dst) < len(src) {
		panic("crypto/cipher: output smaller than input")
	}

	for len(src) > 0 {
		x.b.Encrypt(dst[:x.blockSize], src[:x.blockSize])
		src = src[x.blockSize:]
		dst = dst[x.blockSize:]
	}
}
