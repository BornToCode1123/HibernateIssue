package functions

import (
	c "jocata_transform_plugin/constants"
	rs "jocata_transform_plugin/structs"
	"strings"
)

func DataSetCall(hcd rs.HostConnectionDetails, data rs.JSONQData) (interface{}, rs.TransformError) {

	hcd.Host += c.Dataset_url
	hcd.ContentInputType = c.JSON
	hcd.ContentOutputType = c.JSON
	hcd.MethodType = c.POST
	hcd.URLPattern = ""
	hcd.IsDataSetOrFormTemplate = true
	return ApiRestCall(hcd, data)
}

func FormTemplateCall(hcd rs.HostConnectionDetails, data rs.JSONQData) (interface{}, rs.TransformError) {

	if strings.EqualFold(hcd.FormTemplateType, c.FETCH) {
		hcd.Host += c.FormTemplate_Get_Url
	} else {
		hcd.Host += c.FormTemplate_Save_Url
	}
	hcd.ContentInputType = c.JSON
	hcd.ContentOutputType = c.JSON
	hcd.MethodType = c.POST
	hcd.URLPattern = ""
	hcd.IsDataSetOrFormTemplate = true

	return ApiRestCall(hcd, data)
}
