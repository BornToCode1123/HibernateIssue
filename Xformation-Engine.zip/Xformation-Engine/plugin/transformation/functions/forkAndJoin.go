package functions

import (
	c "jocata_transform_plugin/constants"
	rs "jocata_transform_plugin/structs"
	"sync"
)

func ProcessForkStatement(forkStatement rs.Fork, data rs.JSONQData, statementDetails rs.StatementDetails, transformStatements rs.TransformStatements) rs.StatementsResult {
	var wg sync.WaitGroup
	result := forkAndJoin(forkStatement, data, &wg, statementDetails, transformStatements)
	return result
}

func forkAndJoin(forkStatement rs.Fork, data rs.JSONQData, wg *sync.WaitGroup, statementDetails rs.StatementDetails, transformStatements rs.TransformStatements) rs.StatementsResult {

	var allSectionsResult rs.StatementsResult
	results := make([]rs.StatementsResult, len(forkStatement.Statements))
	wg.Add(len(forkStatement.Statements))
	for i, statement := range forkStatement.Statements {
		if statement.EType == `SectionalStatement` {
			sectionalStatement := rs.Transform{Statements: statement.Section.Statements, Id: statement.Section.Id, Name: statement.Section.Name}
			statementDetails.TransformType = c.TRANSFORM
			go func(index int, statements []rs.Statement) {
				defer wg.Done()
				result := transformStatements(sectionalStatement, data, statementDetails)
				results[index] = result
			}(i, forkStatement.Statements)
		}
	}
	wg.Wait()

	for _, result := range results {
		allSectionsResult.StatementResults = append(allSectionsResult.StatementResults, result.StatementResults...)
		if result.TransFormError.Detailedmessage != nil {
			allSectionsResult.TransFormError = result.TransFormError
		}
	}

	return allSectionsResult
}
