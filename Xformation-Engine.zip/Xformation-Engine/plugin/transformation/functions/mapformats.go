package functions

import (
	"encoding/json"
	"fmt"
	"jocata_transform_plugin/constants"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
)

func getKeys(dataMap map[string]interface{}) []interface{} {

	keys := make([]interface{}, 0, len(dataMap))
	for k := range dataMap {
		keys = append(keys, k)
	}
	return keys
}

func getValues(dataMap map[string]interface{}) []interface{} {
	values := make([]interface{}, len(dataMap))
	idx := 0
	for _, value := range dataMap {
		values[idx] = value
		idx++
	}
	return values
}

func FormatMap(inputData map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	logger.Log.Trace(data.LocalData, "Entered into function map")
	conversion := inputData["format"].(string)
	var initValuesMap = make(map[string]interface{})
	if inputData["init"] != nil {
		initValuesMap = inputData["init"].(map[string]interface{})
	}
	var value map[string]interface{}
	var res interface{}
	var err error
	var variable string
	if initValuesMap["value"] != nil && (conversion != "jsonObjectMap") {
		variable := initValuesMap["value"].(string)
		res, err = utils.FindValue(variable, data)
	}
	if err != nil && conversion != constants.IS_EMPTY {
		errMessage := fmt.Sprintf("in function '%v' %v", conversion, err.Error())
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}

	if res != nil {
		_, ok := res.(map[string]interface{})
		if !ok && conversion != "putValueByKey" {
			errMessage := fmt.Sprintf("in function '%v', %v is not a map", conversion, variable)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return nil, tErr
		} else if conversion != "putValueByKey" {
			value = res.(map[string]interface{})
		}
	}

	logger.Log.Trace(data.LocalData, "Executing function %v", conversion)
	switch conversion {
	case "getKeySet":
		return getKeys(value), rs.TransformError{}
	case "getValueSet":
		return getValues(value), rs.TransformError{}
	case "length":
		return float64(len(value)), rs.TransformError{}
	case "populate":
		return Populate(initValuesMap, data)
	case "deleteFromMap":
		return deleteFromMap(initValuesMap, res.(map[string]interface{})), rs.TransformError{}
	case "putValueByKey":
		return pushValueByKey(initValuesMap, res, data)
	case "getValueByKey":
		return getValueByKey(initValuesMap, value, data)
	case constants.IS_EMPTY:
		return checkMapIsEmpty(value, initValuesMap, data)
	case "jsonObjectMap":
		var result interface{}
		switch ObjectMap := initValuesMap["value"].(type) {
		case string:
			err := json.Unmarshal([]byte(ObjectMap), &result)
			if err != nil {
				errMessage := fmt.Sprintf(" in function '%v' : while converting string to json map : ", conversion)
				tErr := utils.PopulateTransFormError("1001", errMessage)
				logger.Log.Error(data.LocalData, errMessage)
				return nil, tErr
			}
			return result, rs.TransformError{}
		case map[string]interface{}:
			return ObjectMap, rs.TransformError{}
		}
		return result, rs.TransformError{}

	case "clearTheMap":
		return nil, rs.TransformError{}
	default:
		errMessage := fmt.Sprintf("Given Format was  %v is Invalid for Keyword", conversion)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
}

func deleteFromMap(initValuesMap map[string]interface{}, dataMap map[string]interface{}) map[string]interface{} {
	key := initValuesMap["key"].(string)
	delete(dataMap, key)
	return dataMap
}

func pushValueByKey(initValuesMap map[string]interface{}, res interface{}, data rs.JSONQData) (map[string]interface{}, rs.TransformError) {
	key := initValuesMap["key"].(string)

	resultMap := make(map[string]interface{})

	variable, err := utils.FindValue(key, data)
	if err != nil {
		errMessage := fmt.Sprintf("in function '%v' %v", "putValueByKey", err.Error())
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}

	resultMap[variable.(string)] = res
	return resultMap, rs.TransformError{}
}

func getValueByKey(initValuesMap map[string]interface{}, value map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	key := initValuesMap["key"].(string)
	variable, err := utils.FindValue(key, data)
	if err != nil {
		errMessage := fmt.Sprintf("in function '%v' %v", "pushValueByKey", err.Error())
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	res, err := utils.GetFromMap(value, variable.(string), data)
	if err != nil {
		logger.Log.Error(data.LocalData, err.Error())
		tErr := utils.PopulateTransFormError("1010", err.Error())
		logger.Log.Error(data.LocalData, err.Error())
		return nil, tErr
	}
	return res, rs.TransformError{}
}

func checkMapIsEmpty(res map[string]interface{}, initValuesMap map[string]interface{}, data rs.JSONQData) (interface{}, rs.TransformError) {
	if initValuesMap["value"] == nil {
		errMessage := fmt.Sprintf("in function '%v'", constants.IS_EMPTY+" value key is missing in configuration.")
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
	if res == nil {
		return true, rs.TransformError{}
	}
	return len(res) == 0, rs.TransformError{}
}
