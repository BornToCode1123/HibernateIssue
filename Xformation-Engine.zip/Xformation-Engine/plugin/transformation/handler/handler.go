package handler

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	c "jocata_transform_plugin/constants"
	fns "jocata_transform_plugin/functions"
	"jocata_transform_plugin/khazaam"
	logger "jocata_transform_plugin/log"
	par "jocata_transform_plugin/parse"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/transform"
	"jocata_transform_plugin/utils"
	"net/http"
	"os"
	"strings"
	"time"
)

func PluginHandler(w http.ResponseWriter, req *http.Request, pluginConfig rs.Plugin, localMap map[string]interface{}, initMap *map[string]interface{}) error {
	var (
		startTime          = time.Now()
		statusCode         = http.StatusOK
		transformedBytes   []byte
		tErr               rs.TransformError
		isExceptionHandled bool
	)

	localMap[c.RESPONSE_HEADERS] = make(map[string]interface{})
	transformedBytes, tErr = processTransformPlugin(req, pluginConfig, initMap, localMap)

	if tErr.Detailedmessage != nil {
		if len(pluginConfig.Request.Errors.Statements) != 0 {
			utils.PopulateErrorData(0, "Transform Error", tErr, localMap)
			transformedBytes, isExceptionHandled = transform.HandleException(tErr, localMap, pluginConfig.Request)
		}

		if !isExceptionHandled {
			if os.Getenv("DEBUG_ENABLE") == "true" {
				TransformError := map[string]interface{}{
					c.CODE:             tErr.Code,
					c.MESSAGE:          tErr.Message,
					c.DETAILED_MESSAGE: c.SYSTEM_ADMIN_ERROR_MESSAGE,
					c.TRACE:            tErr.Detailedmessage,
					c.SUB_CODE:         tErr.Subcode,
				}
				transformedBytes, _ = json.Marshal(TransformError)
			} else {
				tErr.Detailedmessage = c.SYSTEM_ADMIN_ERROR_MESSAGE
				transformedBytes = par.ParseErrortoBytes(localMap, tErr, pluginConfig.Request.ContentOutputType)
			}
		}
	}

	fns.UpdateResponseHeaderContentType(pluginConfig.Request.ContentOutputType, w)
	statusCode = utils.GetHttpStatusCode(localMap)
	w.WriteHeader(statusCode)
	logger.Log.Debug(localMap, "resp Body : %v", string(transformedBytes))
	io.Copy(w, bytes.NewBuffer(transformedBytes))

	if responseHeaders := localMap["responseHeaders"].(map[string]interface{}); len(responseHeaders) > 0 {
		logger.Log.Trace(localMap, "Writing the headers from response headers map")
		for key, val := range responseHeaders {
			if key != "Content-Length" && key != "Nonce" {
				switch value := val.(type) {
				case string:
					logger.Log.Trace(localMap, "key : %v, value : %v", key, value)
					w.Header().Set(key, value)
				}
			}
		}
	}

	duration := time.Since(startTime)

	logger.Log.Info(localMap, "-----------------------------------------------")
	logger.Log.Info(localMap, "----------------------total time taken for the transfomation : %v----------------------", duration)
	logger.Log.Info(localMap, "----------------------end----------------------")
	return nil
}

func processTransformPlugin(req *http.Request, pluginConfig rs.Plugin, initMap *map[string]interface{}, localMap map[string]interface{}) (transformedBytes []byte, tErr rs.TransformError) {

	defer func() {
		if err := recover(); err != nil {
			logMessge := fmt.Sprint("techincal error occured : ", err)
			tErr = utils.PopulateTransFormError("1001", logMessge)
			logger.Log.Error(localMap, "panic recovered %v", logMessge)
			utils.PrintStackTrace(localMap)
			return
		}
	}()

	logger.Log.Info(localMap, "----------------------Intercepted the request----------------------")
	versionDetailsMessge := fmt.Sprintf("---------------------- API-Transformation Running at version %v ----------------------", c.ENIGINE_VERSION)
	logger.Log.Debug(localMap, versionDetailsMessge)

	uiBuilderEnabled := os.Getenv("UI_BUILDER_ENABLED")
	var payload []byte
	delete(req.Header, "Accept-Encoding")

	var (
		err     error
		isValid = false
	)
	hostProperties := pluginConfig.HostProperties

	if strings.Contains(hostProperties.Endpoint, "{") {
		url := req.URL.Path
		logger.Log.Trace(localMap, "---------url----------  %v", url)
		localMap["pathVariables"], err = utils.GetPathVariables(hostProperties.Endpoint, url)
		if err != nil {
			tErr = utils.PopulateTransFormError("1112", err.Error())
			logger.Log.Error(localMap, err.Error())
			return
		}
		logger.Log.Trace(localMap, "Received dynamic url. path variables added successfully : %v", localMap["pathVariables"])
	}

	logger.Log.Trace(localMap, "Received Headers through request : %v", req.Header)

	token := req.Header.Get("Authorization")
	if uiBuilderEnabled == c.TRUE && token == "" {
		utils.PopulateTransFormError("1112", "token is missing from the request.")
		logger.Log.Error(localMap, "invalid token")
		return
	}

	if pluginConfig.Init != nil && pluginConfig.Init.HolderConfig != nil {
		logger.Log.Trace(localMap, "Enter into Init Section")

		initConfig := *pluginConfig.Init
		if uiBuilderEnabled == c.TRUE {
			transformInitConfig := pluginConfig.Init.HolderConfig.(rs.Transform)
			if transformInitConfig.Id != nil {
				initTransformIdInt := transformInitConfig.Id.(float64)
				initTransformId := fmt.Sprintf("%v", int(initTransformIdInt))
				projectId := fmt.Sprintf("%v", int(hostProperties.ProjectId))
				initConfig, err = fns.CallPublish(localMap, token, initTransformId, projectId)
				if err != nil {
					tErr = utils.PopulateTransFormError("1112", err.Error())
					logger.Log.Error(localMap, err.Error())
					return
				}
			}
		}

		tErr = khazaam.TransformInit(initConfig, payload, req.Header, localMap)
		if tErr.Detailedmessage != nil {
			return
		}
	}

	if pluginConfig.Request.HolderConfig != nil {
		requestConfig := pluginConfig.Request

		if uiBuilderEnabled == c.TRUE {
			transformReqConfig := pluginConfig.Request.HolderConfig.(rs.Transform)
			if transformReqConfig.Id != nil {
				reqTransformIdInt := transformReqConfig.Id.(float64)
				reqTransformId := fmt.Sprintf("%v", int(reqTransformIdInt))
				projectId := fmt.Sprintf("%v", int(hostProperties.ProjectId))
				requestConfig, err = fns.CallPublish(localMap, token, reqTransformId, projectId)
				if err != nil {
					tErr = utils.PopulateTransFormError("1112", c.SYSTEM_ADMIN_ERROR_MESSAGE)
					logger.Log.Error(localMap, err.Error())
					return
				}
			}
		}

		if requestConfig.Headers != nil {
			logger.Log.Debug(localMap, "received custom headers from configuration, writing them in request headers")
			fns.SetCustomHeadersInRequest(localMap, req, requestConfig.Headers)
		}

		if requestConfig.Id != nil {
			if req.Body != nil {
				if hostProperties.OriginMethod == c.GET {
					urlValues := req.URL.Query()
					params := utils.ProcessParams(urlValues)
					payload, _ = json.Marshal(params)
					logger.Log.Debug(localMap, "GET payload, %v", string(payload))
				} else {
					payload, _ = io.ReadAll(req.Body)
				}

				if requestConfig.JsonSchema != nil && len(requestConfig.JsonSchema) != 0 {
					logger.Log.Debug(localMap, "----------------------Doing Json Schema Validation For Request Transformation ----------------------")
					isValid, tErr = transform.ProcessJsonSchema(payload, requestConfig.JsonSchema, localMap, requestConfig)
					if !isValid {
						return
					}
				}

				logger.Log.Debug(localMap, "----------------------Doing the request transformation----------------------")
				logger.Log.Trace(localMap, "timeout : %v", hostProperties.Timeout)
				logger.Log.Trace(localMap, "payload, %v", string(payload))
				transformedBytes, tErr = khazaam.TransformRequest(requestConfig, payload, req.Header, localMap, initMap)

				if par.IsthisUserException(localMap, requestConfig.ContentOutputType, transformedBytes) {
					logger.Log.Info(localMap, "modified user Exception is: %v", string(transformedBytes))
					return
				}
				if tErr.Detailedmessage != nil {
					return
				}

			} else {
				tErr = utils.PopulateTransFormError("1007", "request body is missed in request")
				logger.Log.Error(localMap, "Request Body Missed in Request")
				return
			}
		}
	}

	if !pluginConfig.RequestBodyasResponse {
		transformedBytes, tErr = fns.ConnectingToHost(transformedBytes, localMap, hostProperties.HostConnectionDetails)
	}

	if tErr.Detailedmessage != nil {
		tErr = utils.PopulateTransFormError("1006", c.SYSTEM_ADMIN_ERROR_MESSAGE)
		logger.Log.Error(localMap, tErr.Detailedmessage)
		return

	} else if pluginConfig.Response.HolderConfig != nil {
		responseConfig := pluginConfig.Response

		if uiBuilderEnabled == c.TRUE {
			var err error
			traformRespConfig := responseConfig.HolderConfig.(rs.Transform)
			if traformRespConfig.Id != nil {
				respTransformIdInt := traformRespConfig.Id.(float64)
				respTransformId := fmt.Sprintf("%v", int(respTransformIdInt))
				projectId := fmt.Sprintf("%v", int(hostProperties.ProjectId))
				responseConfig, err = fns.CallPublish(localMap, token, respTransformId, projectId)
				if err != nil {
					tErr = utils.PopulateTransFormError("1112", c.SYSTEM_ADMIN_ERROR_MESSAGE)
					logger.Log.Error(localMap, err.Error())
					return
				}
			}
		}

		if responseConfig.Id != nil {
			if responseConfig.Headers != nil {
				logger.Log.Trace(localMap, "Wrting custom response headers")
				fns.SetCustomHeadersInResponse(localMap, responseConfig.Headers)
			}

			if len(responseConfig.JsonSchema) != 0 {
				logger.Log.Debug(localMap, "----------------------Doing Json Schema Validation For Response Transformation----------------------")
				isValid, tErr = transform.ProcessJsonSchema(transformedBytes, responseConfig.JsonSchema, localMap, responseConfig)
				if !isValid && tErr.Detailedmessage != nil {
					return
				}
			}

			logger.Log.Debug(localMap, "----------------------Doing the response transformation----------------------")
			return khazaam.TransformResponse(responseConfig, transformedBytes, nil, localMap, initMap)
		}
	}
	return
}
