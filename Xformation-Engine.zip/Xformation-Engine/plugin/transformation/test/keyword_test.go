package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestKeywordWithDayAndIncludeTrueWithInit(t *testing.T) {
	fmt.Println("---------------enterd keyword_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithDayAndIncludeTrueWithInit)
	assert.Equal(t, (results), cfg.TestKeywordWithDayAndIncludeTrueWithInit1)
}

func TestKeywordWithDayAndIncludeFalseWithInit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithDayAndIncludeFalseWithInit)
	assert.Equal(t, (results), cfg.TestKeywordWithDayAndIncludeFalseWithInit1)
}
func TestKeywordWithMonthAndIncludeTrueWithInit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithMonthAndIncludeTrueWithInit)
	assert.Equal(t, (results), cfg.TestKeywordWithMonthAndIncludeTrueWithInit1)
}
func TestKeywordWithMonthAndIncludeFalseWithInit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithMonthAndIncludeFalseWithInit)
	assert.Equal(t, (results), cfg.TestKeywordWithMonthAndIncludeFalseWithInit1)
}
func TestKeywordWithYearAndIncludeFalseWithInit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithYearAndIncludeFalseWithInit)
	assert.Equal(t, (results), cfg.TestKeywordWithYearAndIncludeFalseWithInit1)
}
func TestKeywordWithYearAndIncludeTrueWithInit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithYearAndIncludeTrueWithInit)
	assert.Equal(t, (results), cfg.TestKeywordWithYearAndIncludeTrueWithInit1)
}

func TestKeywordWithMonthAndIncludeTrueWithOutInit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithMonthAndIncludeTrueWithOutInit)
	fmt.Println("res :", results)
	// assert.Equal(t, results, cfg.TestKeywordWithMonthAndIncludeTrueWithOutInit1)//
	// date keyword working on present date. we cant't compare.!
}
func TestKeywordWithMonthAndIncludeFalseWithOutInit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithMonthAndIncludeFalseWithOutInit)
	assert.Equal(t, len((results)), len(cfg.TestKeywordWithMonthAndIncludeFalseWithOutInit1))
}

func TestKeywordWithMonthAndWithOutInclude(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithMonthAndWithOutInclude)
	assert.Equal(t, len((results)), len(cfg.TestKeywordWithMonthAndWithOutInclude1))
}

func TestKeywordWithMonthAndWithOutValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.TestKeywordWithMonthAndWithOutValue)
	assert.Equal(t, len((results)), len(cfg.TestKeywordWithMonthAndWithOutValue1))
}

func TestKeywordDateWithPayloadUnixValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	results := runTestCase(fileContent, cfg.DateTesting1)
	assert.Equal(t, (results), cfg.TestKeywordDateWithPayloadUnixValue)
}

func TestCurrencyKeyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	results := runTestCase(fileContent, cfg.CurrencyConf)
	assert.Equal(t, (results), cfg.TestCurrencyKeyword)
}
func TestCurrencyKeywordText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	results := runTestCase(fileContent, cfg.CurrencyConfText)
	assert.Equal(t, (results), cfg.TestCurrencyKeywordText)
}

func TestCurrencyKeywordINRtoUSD(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	results := runTestCase(fileContent, cfg.CurrencyConfUSD)
	assert.Equal(t, (results), cfg.TestCurrencyKeywordINRtoUSD)
}

func TestCurrencyKeywordUSDtoNUmber(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	results := runTestCase(fileContent, cfg.CurrencyConfNumber)
	assert.Equal(t, (results), cfg.TestCurrencyKeywordUSDtoNUmber)
}

func TestCurrencyKeywordLocalNumberToText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	results := runTestCase(fileContent, cfg.CurrencyConfLOcalNUmberToUsd)
	assert.Equal(t, (results), cfg.TestCurrencyKeywordLocalNumberToText)
}

func TestCurrencyKeywordWithZero(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	results := runTestCase(fileContent, cfg.CurrencyConfLOcalZeroNUmberToUsd)
	assert.Equal(t, (results), cfg.TestCurrencyKeywordWithZero)
}

func TestCurrencyKeywordWithNull(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	results := runTestCase(fileContent, cfg.CurrencyConfLOcalWithNull)
	assert.Equal(t, (results), cfg.TestCurrencyKeywordWithNull)
}
