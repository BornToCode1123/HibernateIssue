package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestConcatWithOneValue(t *testing.T) {
	fmt.Println("---------------enterd concat_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/conf6.json")

	result := runTestCase(fileContent, cfg.ConfigConcatWithOneValue)

	assert.Equal(t, (result), cfg.TestConcatWithOneValue)
}

func TestConcatWithMultipleValues(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf6.json")

	results := runTestCase(fileContent, cfg.ConfigConcatWithMultipleValue)
	fmt.Println("res :", results)
	assert.Equal(t, (results), cfg.TestConcatWithMultipleValues)

}

// func TestConcatWithCharacterAndValues(t *testing.T) {
// 	InitLogger()

// 	fileContent, err := ioutil.ReadFile("./payloads/conf6.json")
// 	if err != nil {
// 		log.Fatal(err)
// 	}

// 	payload := string(fileContent)
// 	var configJson rs.JsonConf

// 	err1 := json.Unmarshal([]byte(cfg.ConcatWithLOcalValues), &configJson)
// 	if err1 != nil {
// 		log.Fatal(err.Error())
// 	}

// 	headers := make(map[string]interface{})
// 	headers["flag"] = "yes"
// 	headers["authenticationKey"] = "123456789"
// 	headers["processCode"] = 1230

// 	localMap := make(map[string]interface{})

// 	result, _ := khazaam.ConvertConfigToKhazaamSpecification(configJson, payload, headers, localMap)
// 	assert.Equal(t, getTransformedData(result), cfg.TestConcatWithLocalValues)
// }
