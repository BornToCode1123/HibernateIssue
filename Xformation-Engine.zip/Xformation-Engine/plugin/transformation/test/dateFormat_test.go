package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"
	"time"

	"github.com/magiconair/properties/assert"
)

func TestDateKeywordCurrentDate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf6.json")

	currentTime := time.Now()
	formattedDate := currentTime.Format("02-01-2006")
	currentDate := fmt.Sprintf(`{"finalValue":"` + formattedDate + `"}`)
	result := runTestCase(fileContent, cfg.TestCurrentDate)
	assert.Equal(t, (result), currentDate)
}

func TestDateKeywordIssue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")
	result := runTestCase(fileContent, cfg.DateKeywordConfig)
	assert.Equal(t, (result), cfg.TestKeyeordDate)
}

func TestDateWithNullValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.DateWithNullValue)
	assert.Equal(t, (result), cfg.TestDateWithNullValue)
}

func TestDateFromateForMonth(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.DateFromatForMonth)
	assert.Equal(t, (result), cfg.TestDateFromateForMonth)
}

func TestUnixTimeForInteger(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.UnixDateFormatter)
	assert.Equal(t, (result), cfg.TestUnixTimeForInteger)
}

func TestIncreaingMonths(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.IncreasingAllDatesFormats)
	assert.Equal(t, (result), cfg.TestIncreaingMonths)
}

func TestIncreaingDateWtihHoursFormat(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.IncreaseDaysWithHours)
	assert.Equal(t, (result), cfg.TestIncreaingDateWtihHoursFormat)
}

func TestIncreaingDayZero(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.IncreasingDay)
	assert.Equal(t, (result), cfg.TestIncreaingDay)
}

func TestGetLastDate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.GetLastDate)
	assert.Equal(t, (result), cfg.TestGetLastDate)
}

func TestIncreaingHours(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingHoursConfig)
	assert.Equal(t, (results), (cfg.Test_IncreasingHours))
}

func TestIncreaingHours1(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingHoursConfig1)
	assert.Equal(t, (results), (cfg.Test_IncreasingHours1))
}

func TestIncreaingHours2(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingHoursConfig2)
	assert.Equal(t, (results), (cfg.Test_IncreasingHours2))
}

func TestIncreaingHours3(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingHoursConfig3)
	assert.Equal(t, (results), (cfg.Test_IncreasingHours3))

}

func TestIncreaingHours4(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingHoursConfig4)
	assert.Equal(t, (results), (cfg.Test_IncreasingHours4))

}

func TestIncreaingHours5(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingHoursConfig5)
	assert.Equal(t, (results), (cfg.Test_IncreasingHours5))

}

func TestIncreaingMinute(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingMinuteConfig)
	assert.Equal(t, (results), (cfg.Test_IncreasingMinute))

}

func TestIncreaingMinute1(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingMinuteConfig1)
	assert.Equal(t, (results), (cfg.Test_IncreasingMinute1))
}

func TestIncreaingMinute2(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingMinuteConfig2)
	assert.Equal(t, (results), (cfg.Test_IncreasingMinute2))
}

func TestIncreaingMinute3(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingMinuteConfig3)
	assert.Equal(t, (results), (cfg.Test_IncreasingMinute3))
}

func TestIncreaingMinute4(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingMinute)
	assert.Equal(t, (results), (cfg.Test_IncreasingMinute4))

}

func TestIncreaingDayAndHours(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingDayAndHour)
	assert.Equal(t, (results), (cfg.Test_IncreasingDayAndHour))
}

func TestIncreaingMonthAndHours(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingMonth)
	assert.Equal(t, (results), (cfg.Test_IncreasingMonthAndHours))
}

func TestIncreaingYearsAndHours(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IncreasingYear)
	assert.Equal(t, (results), (cfg.Test_IncreaingYearAndHours))
}

func TestCheckDateFormat(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.CheckDateFormatConfig)
	assert.Equal(t, (result), cfg.TestCheckDateFormat)
}

func TestCheckDateFormatConfigNotEqualsConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.CheckDateFormatConfigNotEqualsConfig)
	assert.Equal(t, (result), cfg.TestCheckDateFormatConfigNotEqualsConfig)
}

func TestDateDifferenceWithTwoLoaclVariables(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.CheckDateFormatConfig)
	assert.Equal(t, (result), cfg.TestCheckDateFormat)
}

func TestDateDifferenceWithCurrentDate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.CalculateDifferenceWithCurrentDate)
	fmt.Println(result)
	// assert.Equal(t, (result), cfg.TestCheckDateFormatWithCurrentDate)
}

func TestDateDifferenceWithCurrentDateInMonths(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.CalculateDifferenceWithCurrentDateInMonths)
	fmt.Println(result)
	// assert.Equal(t, (result), cfg.TestCheckDateFormatWithCurrentDateInMOnths)
}

func TestDateNewFormatddMMyyyyz(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.DateNewFormatddMMyyz)
	assert.Equal(t, (result), cfg.TestDateNewFormatddMMyyyyz)
}

func TestCreatingDateWithIndividualParameters(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.CreatingDateWithIndividualParameters)
	assert.Equal(t, (result), cfg.TestCreatingDateWithIndividualParameters)
}

func TestDateDifferenceWithCurrentDateInYears(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.DateDifferenceFromTodayInYears)
	fmt.Println(result)
	// assert.Equal(t, (result), cfg.TestDateDifferenceWithCurrentDateInYears)
}

func TestDateDifferenceWithCurrentDateInYearsWithDecimal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.TestConfigDifferenceWithYears)
	fmt.Println(result)
	// assert.Equal(t, (result), cfg.TestDateDifferenceWithCurrentDateInYearsWithDecimal)
}

func TestDateIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.CheckDateIsEmptyConfig)
	assert.Equal(t, (result), cfg.TestIsEmptyForKeywords)
}

func TestDateIsEmptyForKeyNotPresent(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.TestDateIsEmptyForKeyNotPresent)
	assert.Equal(t, (result), cfg.TestIsEmptyForKeywords)
}

func TestDateIsEmptyForValueKeyNotPresentInConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runTestCase(fileContent, cfg.TestDateIsEmptyForValueKeyNotPresentInConfig)
	assert.Equal(t, (result), cfg.TestKeyNotPresentInConfigForIsEmpty)
}
