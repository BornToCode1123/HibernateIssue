package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestIgnorePropertyKeywordText(t *testing.T) {
	fmt.Println("---------------enterd jsonIgnoreProperty_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyKeywordText)
	assert.Equal(t, results, cfg.TestIgnorePropertyKeywordText)
}

func TestIgnorePropertyKeywordNumber(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyKeywordNumber)
	assert.Equal(t, results, cfg.TestIgnorePropertyKeywordNumber)
}

func TestIgnorePropertyKeywordDate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyKeywordDate)
	assert.Equal(t, results, cfg.TestIgnorePropertyKeywordDate)
}

func TestIgnorePropertyKeywordList(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyKeywordList)
	assert.Equal(t, results, cfg.TestIgnorePropertyKeywordList)
}

func TestIgnorePropertyKeywordMap(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyKeywordMap)
	assert.Equal(t, results, cfg.TestIgnorePropertyKeywordMap)
}

func TestIgnorePropertyFunctionConcatValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyFunctionConcatValue)
	assert.Equal(t, results, cfg.TestIgnorePropertyFunctionConcatValue)
}

func TestIgnorePropertyFunctionConcatValuesList(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyFunctionConcatValuesList)
	assert.Equal(t, results, cfg.TestIgnorePropertyFunctionConcatValuesList)
}

func TestIgnorePropertyFunctionSum(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyFunctionSumWithAliasAsNull)
	assert.Equal(t, results, cfg.TestIgnorePropertyFunctionSumWithAliasAsNull)
}

func TestIgnorePropertyFunctionAvg(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyFunctionAvg)
	assert.Equal(t, results, cfg.TestIgnorePropertyFunctionAvg)
}

func TestIgnorePropertyFunctionCount(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IgnorePropertyFunctionCount)
	assert.Equal(t, results, cfg.TestIgnorePropertyFunctionCount)
}

func TestKeyNotPresentForFunctionMin(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestKeyNotPresentForFunctionMinConfig)
	assert.Equal(t, results, cfg.TestKeyNotPresentForFunctionMinOutput)
}

func TestIgnorePropertyForFunctionMin(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestIgnorePropertyForFunctionMinConfig)
	assert.Equal(t, results, cfg.TestIgnoreAliasPropertyForFunctionMinOutput)
}
