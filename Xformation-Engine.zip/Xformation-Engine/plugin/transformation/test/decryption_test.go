package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestDecryptAESECB(t *testing.T) {
	fmt.Println("---------------enterd decryption_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigAESECB)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecryptAESCBC(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigAESCBC)
	assert.Equal(t, (result), cfg.TestDecrypt)

}

func TestDecryptAESCFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigAESCFB)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecryptAESOFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigAESOFB)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecryptAESCTR(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigAESCTR)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecryptDESCBC(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigDESCBC)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecryptDESECB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigDESECB)
	assert.Equal(t, (result), cfg.TestDecrypt)

}

func TestDecryptDESCFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigDESCFB)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecryptDESOFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigDESOFB)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecryptDESCTR(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigDESCTR)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecryptAESGCM(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfigAESGCM)
	assert.Equal(t, (result), cfg.TestDecrypt)
}

func TestDecrypt3DESECB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfig3DESECB)
	assert.Equal(t, (result), cfg.TestDecrypt)
	// println("results " + result)
}

func TestDecrypt3DESCBC(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfig3DESCBC)
	assert.Equal(t, (result), cfg.TestDecrypt)
	// println("results " + result)
}

func TestDecrypt3DESCFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfig3DESCFB)
	assert.Equal(t, (result), cfg.TestDecrypt)
	// println("results " + result)
}

func TestDecrypt3DESOFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfig3DESOFB)
	assert.Equal(t, (result), cfg.TestDecrypt)
	// println("results " + result)
}

func TestDecrypt3DESCTR(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptConfig3DESCTR)
	assert.Equal(t, (result), cfg.TestDecrypt)
	// println("results " + result)
}

func TestDecryptDecTypeNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptDecTypeNotGiven)
	assert.Equal(t, (result), cfg.TestDecryptDecTypeNotGiven)
}

func TestDecryptDecModeNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptDecModeNotGiven)
	assert.Equal(t, (result), cfg.TestDecryptDecModeNotGiven)
}

func TestDecryptIVNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptIVNotGiven)
	assert.Equal(t, (result), cfg.TestDecryptIVNotGiven)
}

func TestDecryptDecKeyNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptDecKeyNotGiven)
	assert.Equal(t, (result), cfg.TestDecryptDecKeyNotGiven)
}

func TestDecryptDecodeTypeNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptDecodeTypeNotGiven)
	assert.Equal(t, (result), cfg.TestDecryptDecodeTypeNotGiven)
}

func TestDecryptIVIncorrect(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptIVIncorrect)
	assert.Equal(t, (result), cfg.TestDecryptIVIncorrect)
}

func TestDecryptAESGCMIncorrectIV(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptAESGCMIncorrectIV)
	assert.Equal(t, (result), cfg.TestDecryptAESGCMIncorrectIV)
}

func TestDecryptDESGCM(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptDESGCM)
	assert.Equal(t, (result), cfg.TestDecryptDESGCM)
}

func TestDecryptEncKeyIncorrect(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.DecryptIncorrectEncKey)
	assert.Equal(t, (result), cfg.TestDecryptEncKeyIncorrect)
}
