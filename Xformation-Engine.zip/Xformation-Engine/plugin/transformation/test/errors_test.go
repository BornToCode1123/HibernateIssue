package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestAppendingMultipleErrorsDebugTrue(t *testing.T) {
	fmt.Println("---------------enterd errors_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/conf4.json")

	result := runTestCase(fileContent, cfg.AppendingMultipleErrorsDebugTrue)
	assert.Equal(t, (result), cfg.TestAppendingMultipleErrorsDebugTrue)
}

func TestAppendingMultipleErrorsDebugFalse(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf4.json")

	result := runTestCase(fileContent, cfg.AppendingMultipleErrorsDebugFalse)
	assert.Equal(t, (result), cfg.TestAppendingMultipleErrorsDebugFalse)
}

func TestAppendingMultipleErrorsDebugTrueOrFalseMandatoryTrue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf4.json")

	result := runTestCase(fileContent, cfg.DebugTrueOrFalseMandatoryTrue)
	assert.Equal(t, (result), cfg.TestAppendingMultipleErrorsDebugTrueOrFalseMandatoryTrue)
}

func TestErrorParsingXml(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.ErrorParsing)
	assert.Equal(t, len(result), len(cfg.TestErrorParsingXml))
}

func TestErrorStatement(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf4.json")

	result := runTestCase(fileContent, cfg.ErrorStatement)
	assert.Equal(t, (result), cfg.TestErrorStatement)
}

func TestErrorStatementInnertTransform(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.ErrorStatementInsideTransForm)
	assert.Equal(t, (result), cfg.UserException)
}

func TestUserExceptionError(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.UserExceptionError)
	assert.Equal(t, (result), cfg.UserExceptionMultipleInnerStatements)
}

func TestUserExceptionReqiuerdMessage(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.ExceptionMessageCreating)
	assert.Equal(t, (result), cfg.TestUserExceptionReqiuerdMessage)
}

func TestExceptionErrorTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.ErrorSectionTesting)
	assert.Equal(t, (result), cfg.TestExceptionErrorSectionThrow)
}

func TestErrorRecoveryAndContinue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.ErrorsSectionTest)
	assert.Equal(t, (result), cfg.TestErrorRecoverAndContinue)
}

func TestMultiSelectStaticArray(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.TestMultiSelectStaticArray)
	assert.Equal(t, (result), cfg.TestStaticMultiSelectArray)
}

func TestMultiSelectStaticArrayAndCheckingError(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.TestMultiSelectStaticArrayAndTesting)
	assert.Equal(t, (result), cfg.TestMutiSelectArray)
}

func TestMultiSelectStaticArrayAndCheckingErrorspecific(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.TestMultiSelectStaticArrayAndTesting2)
	assert.Equal(t, (result), cfg.TestMutiSelectArray)
}

func TestRecursiveError(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.ErrorRecursive)
	assert.Equal(t, results, cfg.TestRecursiveError)
}

func TestErrorMessageWithName(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.TestErrorMessageWithStatementName)
	assert.Equal(t, results, cfg.TestErrorMessageWithName)
}

func TestExceptionRecursiveIssue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.ErrorRecursiveConfig)
	assert.Equal(t, results, cfg.TestExceptionRecursiveIssue)
}

func TestIterateIsideThrowingError(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.IterateIsideThrowingError)
	assert.Equal(t, results, cfg.TestErrorThrowingInsideTransformation)
}

func TestRecursiveErrorWhileEnteredIntoExceptionHandling(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.RecursiveErrorConfig)
	assert.Equal(t, results, cfg.TransformErrors)
}
