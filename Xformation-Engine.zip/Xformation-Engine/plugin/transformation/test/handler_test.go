package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"os"

	"testing"

	"github.com/magiconair/properties/assert"
)

func TestEndpointConfigForHostCallWithDynamicUrl(t *testing.T) {
	fmt.Println("---------------enterd handler_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runPluginTestCase(fileContent, cfg.TestHostCallConfiguration)
	assert.Equal(t, result, (cfg.TestEndpointConfigForHostCall))

}

func TestEndpointConfigForHostCallWithUrlPattern(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	result := runPluginTestCase(fileContent, cfg.TestEndpointConfigurationWithUrlPattern)
	assert.Equal(t, result, (cfg.TestEndpointConfigForHostCall))

}

func TestEndpointConfigForWithoutConnectingAnyHost(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/handlerConfig.json")

	result := runPluginTestCase(fileContent, cfg.TestEndpointConfigurationWithoutConnectingHost)
	assert.Equal(t, result, (cfg.TestEndpointConfigForWithoutConnectingAnyHost))

}

func TestJsonSchemaValidation(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/handlerConfig.json")

	result := runPluginTestCase(fileContent, cfg.TestConJsonSchemaValidation)
	assert.Equal(t, result, (cfg.TestJsonSchemaValidation))
}

func TestJsonSchemValidationExceptionHandling(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/handlerConfig.json")

	result := runPluginTestCase(fileContent, cfg.Test_JsonSchemaExceptionHandling)
	assert.Equal(t, result, (cfg.TestJsonSchemValidationExceptionHandling))
}

func TestResponseSchemaValidation(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/handlerConfig.json")

	result := runPluginTestCase(fileContent, cfg.ResponseSchemaValidation)
	assert.Equal(t, result, (cfg.TestResponseSchemaValidation))
}

func TestPreExecutionOfJsonObjectList(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/handlerConfig.json")

	result := runPluginTestCase(fileContent, cfg.TestPreExecutionOfOfJsonObject)
	assert.Equal(t, result, (cfg.TestPreExecutionOfJsonObjectList))

}

func TestPreInitObjectMapAndList(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BRE_Payload.json")

	result := runPluginTestCase(fileContent, cfg.BRE_Endpoint_conf)
	assert.Equal(t, result, (cfg.TestPreInitObjectMapAndList))

}

func TestPreInit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BRE_Payload.json")

	result := runPluginTestCase(fileContent, cfg.BRE_Endpoint_conf)
	assert.Equal(t, result, (cfg.TestPreInitObjectMapAndList))

}

func Test_UI_Builder_Enabled_True(t *testing.T) {
	InitLogger()

	os.Setenv("GENERIC_HOST_URL", "http://192.168.0.242:2020/APIGateway/dlp")
	os.Setenv("PROFILE", "DEV")
	os.Setenv("UI_BUILDER_ENABLED", "true")

	fileContent := ("./payloads/BRE_Payload.json")

	result := runPluginTestCase(fileContent, cfg.TestingEndpoint_UI_Builder_Enabled_True)
	assert.Equal(t, result, (cfg.Test_UI_Builder_Enabled_True))

}

func Test_UI_Builder_Enabled_True_And_DEBUG_MODE_TRUE(t *testing.T) {
	InitLogger()

	os.Setenv("GENERIC_HOST_URL", "http://192.168.0.242:2020/APIGateway/dlp")
	os.Setenv("PROFILE", "DEV")
	os.Setenv("UI_BUILDER_ENABLED", "true")
	os.Setenv("DEBUG_ENABLE", "true")

	fileContent := ("./payloads/BRE_Payload.json")

	result := runPluginTestCase(fileContent, cfg.TestingEndpoint_UI_Builder_Enabled_True)
	assert.Equal(t, result, (cfg.Test_UI_Builder_Enabled_True_And_DEBUG_MODE_TRUE))

	os.Setenv("GENERIC_HOST_URL", "http://192.168.0.242:2020/APIGateway/dlp")
	os.Setenv("PROFILE", "DEV")
	os.Setenv("UI_BUILDER_ENABLED", "false")
	os.Setenv("DEBUG_ENABLE", "false")

}

func TestRequestAndResponseHeaders(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BRE_Payload.json")

	result := runPluginTestCase(fileContent, cfg.TestRequestAndResponseHeadersConfig)
	assert.Equal(t, result, (cfg.TestRequestAndResponseHeaders))

}

func TestUrlEncodedRequestToServerAndThroughAPIRestCall(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BRE_Payload.json")

	result := runUrlEncodePluginTestCase(fileContent, cfg.TestUrlEncodedRequestConfig)
	assert.Equal(t, result, (cfg.TestUrlEncodedRequestToServerAndThroughAPIRestCall))

}

func TestUrlEncodedRequestForHostCall(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BRE_Payload.json")

	result := runUrlEncodePluginTestCase(fileContent, cfg.TestUrlEncodedRequestForHostCallConfig)
	assert.Equal(t, result, (cfg.TestUrlEncodedRequestForHostCall))

}

func TestContentOutputTypeAsUrlEncoded(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BRE_Payload.json")

	result := runUrlEncodePluginTestCase(fileContent, cfg.TestContentOutputTypeAsUrlEncodedConfig)
	assert.Equal(t, len(result), (len(cfg.TestContentOutputTypeAsUrlEncoded)))

}

func TestUrlEncodedResponseAsJson(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BRE_Payload.json")

	result := runPluginTestCase(fileContent, cfg.TestUrlEncodedResponseAsJsonConfig)
	assert.Equal(t, result, (cfg.TestUrlEncodedResponseAsJson))

}
