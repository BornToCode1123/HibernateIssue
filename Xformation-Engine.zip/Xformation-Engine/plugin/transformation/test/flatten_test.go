package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestUploadDocument(t *testing.T) {
	fmt.Println("---------------enterd flatten_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/uploadDocument.json")
	results := runTestCase(fileContent, cfg.UploadDocument2)
	assert.Equal(t, (results), cfg.UploadDocument1)
}
func TestPrimitiveArrayt(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/uploadDocument.json")
	results := runTestCase(fileContent, cfg.UploadDocument2)
	assert.Equal(t, (results), cfg.UploadDocument1)
}
func TestUploadDocFlatJsonSingKey(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/uploadDocument.json")
	results := runTestCase(fileContent, cfg.UplodDocument)
	assert.Equal(t, (results), cfg.TestUploadDocFlatJsonError)
}

func TestJsonUnFlatten(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/uploadDocument.json")
	results := runTestCase(fileContent, cfg.JsonUnFlatten)
	assert.Equal(t, (results), cfg.TestJsonUnFlatten) // done
}

func TestJsonFlatten(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/uploadDocumentUnflatten.json")
	results := runTestCase(fileContent, cfg.JsonFlatten)
	assert.Equal(t, (results), cfg.TestJsonFlatten) // done
}

func TestJsonUnFlatJsonContentInput(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/uploadDocument.json")
	results := runTestCase(fileContent, cfg.JsonUnFlatjsonContentInput)
	assert.Equal(t, (results), cfg.TestJsonUnFlatJsonContentInput) // done
}

func TestJsonUnflattenResponseArray(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/swaraArr.json")
	results := runTestCase(fileContent, cfg.JsonUnFlatResponseArray)
	assert.Equal(t, (results), cfg.TestJsonUnflattenResponseArray) // done
}

func TestJsonflattenResponseArrayObjects(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/swaraArr.json")
	results := runTestCase(fileContent, cfg.JsonFlatResponseArrayObjects)
	assert.Equal(t, (results), cfg.TestJsonflattenResponseArrayObjects) // done
}

func TestJsonUnflattenResponseArrayObjects(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/uploadDocFlatArrayResp.json")
	results := runTestCase(fileContent, cfg.JsonUnFlatResponseArrayObjects)
	assert.Equal(t, (results), cfg.TestJsonUnflattenResponseArrayObjects)
}

func TestFlattenArrayToUnFlatten(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/uploadDocFlatArrayResp.json")
	results := runTestCase(fileContent, cfg.JsonFlattenArrayToUnFlattenArray)
	assert.Equal(t, (results), cfg.TestJsonUnflattenResponseArrayObjects)
}

func TestJsonUnFlattenArray(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/flatJson.json")
	results := runTestCase(fileContent, cfg.JsonUnFlatten)
	assert.Equal(t, (results), cfg.TestJsonUnFlattenArray)
}

func TestLoanDetailsJson_to_flatJson(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/flatJson.json")
	runTestCase(fileContent, cfg.JsonUnFlatten)
}
func TestHugeJsonFlattening(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/loanDetailsHugeJson.json")
	runTestCase(fileContent, cfg.TestLoanDetailsHugeJson)
}

func TestHugeJsonUnFlattening(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/loanDetailsHugeflatJson.json")
	runTestCase(fileContent, cfg.TestLoanDetailsHugeJsonUNFlattening)
}

func TestNestedArrayUnFlattening(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/nestedArryUnFlatteining.json")
	results := runTestCase(fileContent, cfg.TestLoanDetailsHugeJsonUNFlattening)
	assert.Equal(t, (results), cfg.NestedArrayUnFlattening)
}

func TestFilterEmployeess(t *testing.T) {
	fmt.Println("---------------enterd filter_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListOfEmployees)
	fmt.Println("res :", results)
	// assert.Equal(t, (results), cfg.TestListLength)

}
