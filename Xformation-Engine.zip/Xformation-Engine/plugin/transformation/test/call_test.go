package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestGetCallWithUrlPattern(t *testing.T) {
	fmt.Println("---------------enterd call_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.GetURLUrlWithurlPattern)
	assert.Equal(t, results, (cfg.GetURLUrlWithurlPatternAndWithoutUrlPattern))
}

func TestGetCallWithoutUrlPattern(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.GetURLWithoutUrlPattern)
	assert.Equal(t, results, (cfg.GetURLUrlWithurlPatternAndWithoutUrlPattern))
}

func TestGetUrlWithError(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.GetURLWithError)
	assert.Equal(t, results, (cfg.TestGetUrlWithError))
}

func TestGetCallWithPost(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/callPayload.json")

	results := runTestCase(fileContent, cfg.PostURL1)
	assert.Equal(t, results, cfg.TestGetCallWithPost)
}

func TestGetCallWithBody(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/callPayload.json")

	results := runTestCase(fileContent, cfg.GetWithBodyUrl)
	assert.Equal(t, results, cfg.TestGetCallWithBody)
}

func TestGetCallWithBodyAndAddingCustomGenericHeadersfromProfile(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/callPayload.json")

	results := runTestCase(fileContent, cfg.CustomHeaders)
	assert.Equal(t, results, cfg.TestGetCallWithBody)
}

func TestConsumingResponseHeaders(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/callPayload.json")

	results := runTestCase(fileContent, cfg.ConsumingResponseHeaders)
	assert.Equal(t, (results), (cfg.TestConsumingResponseHeaders))
}

func TestConsumingResponseHeadersIntoMainHostHeaders(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/callPayload.json")

	results := runTestCase(fileContent, cfg.AddingAPICallRespHeadersIntoMainHostHeaders)
	assert.Equal(t, (results), (cfg.TestConsumingResponseHeadersIntoMainHostHeaders))
}

func TestUrlEncodedRequestHeaderNotPassed(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/callPayload.json")

	results := runTestCase(fileContent, cfg.TestUrlEncodedRequestForSimpleJsonCallConfig)
	assert.Equal(t, (results), (cfg.TestUrlEncodedRequestHeaderNotPassed))
}

// Need to implement the SSL..

// func TestConnectingSecureConnectionWithSSLCertificate(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/callPayload.json")

// 	results := runTestCase(fileContent, cfg.ConnectionSSL)
// 	fmt.Println(results)
// 	// assert.Equal(t, len(results), len(cfg.TestConsumingResponseHeaders))
// }
