package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestConsumerScreenCondition(t *testing.T) {
	fmt.Println("---------------enterd screen_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/consumerCibil.json")

	results := runTestCase(fileContent, cfg.Consumer)
	assert.Equal(t, (results), cfg.TestConsumerScreenCondition)
}

func TestCIBILConsumerAFFM(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/CIBILConsumer.json")

	results := runTestCase(fileContent, cfg.CIBILConsumerAFFM)
	assert.Equal(t, (results), cfg.TestCIBILConsumerAFFM)
}

func TestCIBILConsumerBRE(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/CIBILConsumer.json")

	results := runTestCase(fileContent, cfg.CIBILConsumerBRE)
	assert.Equal(t, (results), cfg.TestCIBILConsumerBRE)
}

func TestCIBILCommercialAFFM(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/CIBILCommercial.json")

	results := runTestCase(fileContent, cfg.CIBILCommercialAFFM)
	assert.Equal(t, (results), cfg.TestCIBILCommercialAFFM)
}

func TestCIBILCommercialBRE(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/CIBILCommercial.json")

	results := runTestCase(fileContent, cfg.CIBILCommercialBRE)
	assert.Equal(t, (results), cfg.TestCIBILCommercialBRE)
}

func TestPerfiosAFFMv1(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Perfiosv1.json")

	results := runTestCase(fileContent, cfg.PerfiosAFFMv1)
	assert.Equal(t, (results), cfg.TestPerfiosAFFMv1)
}

func TestPerfiosBREv1(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Perfiosv1.json")

	results := runTestCase(fileContent, cfg.PerfiosBREv1)
	assert.Equal(t, (results), cfg.TestPerfiosBREv1)
}

func TestPerfiosAFFMv2(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Perfiosv2.json")

	results := runTestCase(fileContent, cfg.PerfiosAFFMv2)
	assert.Equal(t, (results), cfg.TestPerfiosAFFMv2)
}

func TestPerfiosBREv2(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Perfiosv2.json")

	results := runTestCase(fileContent, cfg.PerfiosBREv2)
	assert.Equal(t, (results), cfg.TestPerfiosBREv2)
}

func TestPerfiosAFFMv3(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Perfiosv3.json")

	results := runTestCase(fileContent, cfg.PerfiosAFFMv3)
	assert.Equal(t, (results), cfg.TestPerfiosAFFMv3)
}

func TestPerfiosBREv3(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Perfiosv3.json")

	results := runTestCase(fileContent, cfg.PerfiosBREv3)
	assert.Equal(t, (results), cfg.TestPerfiosBREv3)
}

func TestTMBCollectMapKey(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/TMBRequest.json")

	results := runTestCase(fileContent, cfg.TMBConfiguration)
	fmt.Println("res", results)
	// assert.Equal(t, (results), cfg.TestPerfiosBREv3)
}

func TestWioApplication(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/WioApplication.json")

	results := runTestCase(fileContent, cfg.WioApplication)
	fmt.Println("res", results)
	// assert.Equal(t, (results), cfg.TestPerfiosBREv3)
}

func TestPNBConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/pnbAdharIssue.json")

	results := runTestCase(fileContent, cfg.PNBConfigurationAdhaarIssue)
	fmt.Println("res", results)
	// assert.Equal(t, (results), cfg.TestPerfiosBREv3)
}

func TestBLScreenConfigIterateIssue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BLConfigFile.json")

	results := runTestCase(fileContent, cfg.TestBlConfigIssueIterate)
	assert.Equal(t, (results), cfg.TestBLScreenConfigIterateIssue)
}

func TestEmptyArrayIssue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BLConfigFile.json")

	results := runTestCase(fileContent, cfg.EmptyArray)
	assert.Equal(t, (results), cfg.TestEmptyArrayIssue)
}

func TestEmptyListLocal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BLConfigFile.json")

	results := runTestCase(fileContent, cfg.EmptyArrayLocal)
	assert.Equal(t, (results), cfg.TestEmptyListLocal)
}
func TestABHFLAppendingObjectBasedOnCondition(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/AbhflgstPayload.json")

	results := runTestCase(fileContent, cfg.AbhflIssue)
	assert.Equal(t, (results), cfg.AbhflIssues)
}

func TestArithmaticBasedOnConditionIssue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/AbhflgstPayload.json")
	results := runTestCase(fileContent, cfg.TMBArithematicConditionBased)
	assert.Equal(t, (results), cfg.TestArithematicBasedOnCondition)

}

func TestAssigningPrefixToGenericFacilityTypes(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/AbhflgstPayload.json")
	results := runTestCase(fileContent, cfg.TestAddingPrefixToExposureTypes)
	assert.Equal(t, (results), cfg.TestAssigningPrefixToGenericFacilityTypes)
}

func TestParsingXmlWithExtraSlash(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/parsingXmlExtraSlash.xml")
	results := runTestCase(fileContent, cfg.PrsingXmlWithExtraSlash)
	fmt.Println(results)
	// assert.Equal(t, (results), cfg.TestAssigningPrefixToGenericFacilityTypes)
}

func TestConvertingJsonToXmlWithDifferentCaseJson(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/differentTypeJson.json")
	results := runTestCase(fileContent, cfg.PrsingXmlWithExtraSlash)
	fmt.Println(results)
	// assert.Equal(t, (results), cfg.TestAssigningPrefixToGenericFacilityTypes)
}

func TestCreatingXMLWithAttribute(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BLPayLoad.json")
	results := runTestCase(fileContent, cfg.CreatingXMLWithAttribute)
	assert.Equal(t, len(results), len(cfg.TestCreatingXMLWithAttribute))
}

func TestNumericMonthArithematic(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BLPayLoad.json")
	results := runTestCase(fileContent, cfg.TestINcreasingarithmaticMonth)
	assert.Equal(t, (results), cfg.TestNumericMonthArithematic)
}
