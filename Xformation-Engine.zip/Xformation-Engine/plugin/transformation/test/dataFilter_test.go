package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func Test_FilterEmployees(t *testing.T) {
	fmt.Println("---------------enterd filter_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/filterPayload.json")

	results := runTestCase(fileContent, cfg.ListOfEmployees)
	assert.Equal(t, (results), cfg.Test_FilterEmployees)
}

func Test_FilterEmployeesWithMultipleRulegroups(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/filterPayload.json")

	results := runTestCase(fileContent, cfg.ListOfEmployeesFilteringBasedOnMultiplerules)
	assert.Equal(t, (results), cfg.Test_FilterEmployeesWithMultipleRulegroups)
}

func Test_FilterWithEmptyObject(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/filterPayload.json")

	results := runTestCase(fileContent, cfg.TestFilterWithEmptyObject)
	assert.Equal(t, (results), cfg.Test_FilterWithEmptyObject)
}

func Test_GetFilterListFunction(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/filterPayload.json")

	results := runTestCase(fileContent, cfg.GetFilteredListFunction)
	assert.Equal(t, (results), cfg.Test_GetFilterListFunction)
}

func Test_GetFilterListWithEmptyresult(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/filterPayload.json")

	results := runTestCase(fileContent, cfg.GetFilteredListWithEmptyResult)
	assert.Equal(t, (results), cfg.Test_GetFilterListWithEmptyresult)
}
