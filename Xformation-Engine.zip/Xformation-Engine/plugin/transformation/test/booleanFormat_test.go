package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestBooleanToText(t *testing.T) {
	fmt.Println("---------------enterd booleanFormat_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.BooleanToText)
	assert.Equal(t, results, cfg.TestBooleanToText)
}

func TestTextToText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.Text_To_ToText)
	assert.Equal(t, results, cfg.TestTextToText)
}

func TestBoolIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.CheckBoolIsEmpty)
	assert.Equal(t, results, cfg.TestIsEmptyForKeywords)
}

func TestBoolIsEmptyForKeyNotPresent(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.CheckBoolIsEmptyForKeyNotPresent)
	assert.Equal(t, results, cfg.TestIsEmptyForKeywords)
}

func TestBoolValueKeyNotPresentInConfigForIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestBoolValueKeyNotPresentInConfigForIsEmpty)
	assert.Equal(t, results, cfg.TestKeyNotPresentInConfigForIsEmpty)
}
