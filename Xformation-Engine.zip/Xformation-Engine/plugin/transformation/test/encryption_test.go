package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestEncryptAESCBC(t *testing.T) {
	fmt.Println("---------------enterd encryption_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigAESCBC)
	assert.Equal(t, (result), cfg.TestEncryptAESCBC)
}

func TestEncryptAESECB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigAESECB)
	assert.Equal(t, (result), cfg.TestEncryptAESECB)
}

func TestEncryptAESCFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigAESCFB)
	assert.Equal(t, (result), cfg.TestEncryptAESCFB)
}

func TestEncryptAESOFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigAESOFB)
	assert.Equal(t, (result), cfg.TestEncryptAESOFB)
}

func TestEncryptAESCTR(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigAESCTR)
	assert.Equal(t, (result), cfg.TestEncryptAESCTR)
}

func TestEncryptAESGCM(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigAESGCM)
	assert.Equal(t, (result), cfg.TestEncryptAESGCM)
}

func TestEncryptDESCBC(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigDESCBC)
	assert.Equal(t, (result), cfg.TestEncryptDESCBC)
}

func TestEncryptDESECB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigDESECB)
	assert.Equal(t, (result), cfg.TestEncryptDESECB)
}

func TestEncryptDESOFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigDESOFB)
	assert.Equal(t, (result), cfg.TestEncryptDESOFB)
}

func TestEncryptDESCTR(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigDESCTR)
	assert.Equal(t, (result), cfg.TestEncryptDESCTR)
}

func TestEncryptDESCFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptConfigDESCFB)
	assert.Equal(t, (result), cfg.TestEncryptDESCFB)
}

func TestEncrypt3DESECB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.Encrypt3DESECB)
	assert.Equal(t, (result), cfg.TestEncrypt3DESECB)
}

func TestEncrypt3DESCBC(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.Encrypt3DESCBC)
	assert.Equal(t, (result), cfg.TestEncrypt3DESCBC)
}

func TestEncrypt3DESCFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.Encrypt3DESCFB)
	assert.Equal(t, (result), cfg.TestEncrypt3DESCFB)
}

func TestEncrypt3DESOFB(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.Encrypt3DESOFB)
	assert.Equal(t, (result), cfg.TestEncrypt3DESOFB)
}

func TestEncrypt3DESCTR(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.Encrypt3DESCTR)
	assert.Equal(t, (result), cfg.TestEncrypt3DESCTR)
}

func TestEncryptEncTypeNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptEncTypeNotGiven)
	assert.Equal(t, (result), cfg.TestEncryptEncTypeNotGiven)
}

func TestEncryptEncTypeIncorrect(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptEncTypeIncorrect)
	assert.Equal(t, (result), cfg.TestEncryptEncTypeIncorrect)
}

func TestEncryptEncModeNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptEncModeNotGiven)
	assert.Equal(t, (result), cfg.TestEncryptEncModeNotGiven)
}

func TestEncryptEncModeIncorrect(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptEncModeIncorrect)
	assert.Equal(t, (result), cfg.TestEncryptEncModeIncorrect)
}

func TestEncryptEncodeTypeNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptEncodeTypeNotGiven)
	assert.Equal(t, (result), cfg.TestEncryptEncodeTypeNotGiven)
}

func TestEncryptEncodeTypeIncorrect(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptEncodeTypeIncorrect)
	assert.Equal(t, (result), cfg.TestEncryptEncodeTypeIncorrect)
}

func TestEncryptIVNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptIVNotGiven)
	assert.Equal(t, (result), cfg.TestEncryptIVNotGiven)
}

func TestEncryptEncKeyNotGiven(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptEncKeyNotGiven)
	assert.Equal(t, (result), cfg.TestEncryptEncKeyNotGiven)
}

func TestEncryptIVIncorrect(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptIVIncorrect)
	assert.Equal(t, (result), cfg.TestEncryptIVIncorrect)
}

func TestEncryptAESGCMIncorrectIV(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptAESGCMIncorrectIV)
	assert.Equal(t, (result), cfg.TestEncryptAESGCMIncorrectIV)
}

func TestEncryptDESGCM(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptDESGCM)
	assert.Equal(t, (result), cfg.TestEncryptDESGCM)
}

func TestEncryptEncKeyIncorrect(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encrypt.json")

	result := runTestCase(fileContent, cfg.EncryptEncKeyIncorrect)
	assert.Equal(t, (result), cfg.TestEncryptEncKeyIncorrect)
}
