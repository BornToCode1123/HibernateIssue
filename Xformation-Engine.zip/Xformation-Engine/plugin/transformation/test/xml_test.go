package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func Test_XmlInput_XmlOutput_WithText(t *testing.T) {
	fmt.Println("---------------enterd xml_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.xml")

	results := runTestCase(fileContent, cfg.SimpleXMLConfig)
	assert.Equal(t, (results), cfg.TestSimpleXMLTestCase)
}

func Test_XmlInput_JsonOutput_Withtext(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.xml")

	results := runTestCase(fileContent, cfg.XmlInputJsonOutput)
	assert.Equal(t, (results), cfg.Test_XmlInput_JsonOutput_Withtext)
}

func Test_JsonInput_Xmloutput_WithText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/NewApplication.json")
	results := runTestCase(fileContent, cfg.JsonInpuXmlOutput)
	assert.Equal(t, (results), cfg.Test_JsonInput_Xmloutput_WithText)
}

func Test_Both_Attr_Text(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.xml")
	results := runTestCase(fileContent, cfg.XMlAttr)
	assert.Equal(t, (results), cfg.Test_Both_Attr_Text)
}

func Test_XmlPayload_XML_Output(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.xml")
	results := runTestCase(fileContent, cfg.XMLToXml)
	assert.Equal(t, (results), cfg.Test_XmlPayload_XML_Output)
}

func Test_XmlPayload_Reading(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/PlXmlPayload.xml")
	results := runTestCase(fileContent, cfg.XML_to_XMl)
	assert.Equal(t, len(results), 7181)
}

func Test_XmlPayload_NameSpaces(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/XmlNameSpaces.xml")
	results := runTestCase(fileContent, cfg.XML_NameSpaces)
	assert.Equal(t, len(results), len(cfg.Test_XmlPayload_NameSpaces))
}

func Test_Xml_Headers_test(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/sampleXml.xml")
	results := runTestCase(fileContent, cfg.XML_NameSpaces)
	assert.Equal(t, (results), cfg.Test_Xml_Headers_test)
}

func Test_Xml_To_Json(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/xmlFile.xml")
	results := runTestCase(fileContent, cfg.XmlToJson)
	assert.Equal(t, (results), cfg.XmlToJsonConvertion)
}

func Test_Json_to_Xml(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/xmlConvertedToJson.json")
	results := runTestCase(fileContent, cfg.JsonToXml)
	assert.Equal(t, (len(results)), len(cfg.Test_Json_to_Xml))
}

func Test_xml_Missing_Json(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/missingXml.xml")
	results := runTestCase(fileContent, cfg.XmlToJson)
	assert.Equal(t, results, cfg.Test_xml_Missing_Json)
}

func Test_json_Missing_xml(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/missingJson.json")
	results := runTestCase(fileContent, cfg.JsonToXml)

	assert.Equal(t, len(results), len(cfg.Test_json_Missing_xml))
}

func Test_Xml_Error(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/missingJson.json")
	results := runTestCase(fileContent, cfg.JsonToXmlError)
	assert.Equal(t, len(results), len(cfg.TestXmlError))
}

func Test_Xml_With_CData(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/XmlWithCData.xml")
	results := runTestCase(fileContent, cfg.SimpleXmlCData)
	assert.Equal(t, results, cfg.Test_Xml_With_CData)
}

func Test_Xml_YBL_Project(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/YBLProject_LoanAccouuntCreation.xml")
	results := runTestCase(fileContent, cfg.YBLDisburs)
	assert.Equal(t, results, cfg.YBLXml)
}

func Test_xml_replace(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")
	results := runTestCase(fileContent, cfg.TextReplace)
	assert.Equal(t, len(results), 1081)
}

func Test_xml_sample(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")
	results := runTestCase(fileContent, cfg.Test_xml)
	fmt.Println("res", results)
	// assert.Equal(t, len(results), 1081)
}

func Test_xml_Numeric_conversionAndBool(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")
	results := runTestCase(fileContent, cfg.XmlNumericConversion)
	assert.Equal(t, len(results), 134)
}
func Test_ReadingArrayOfXMLWithAttribute(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ArrayOfXml.xml")
	results := runTestCase(fileContent, cfg.XmlToJson)
	assert.Equal(t, (results), cfg.Test_ReadingArrayOfXMLWithAttribute)
}

// func Test_Text_converting_xml(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/dataSciencePayload.txt")
// 	// start := time.Now()
// 	results := runTestCase(fileContent, cfg.TestTextConvertingXml)

// 	// end := time.Now()
// 	// diff := end.Sub(start)
// 	// fmt.Println("main difference :", diff.Seconds(), " seconds")
// 	fmt.Println(results)
// 	// assert.Equal(t, len(results), 134)
// }
