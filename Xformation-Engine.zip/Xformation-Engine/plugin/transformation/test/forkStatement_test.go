package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestForkStatementTesting(t *testing.T) {
	fmt.Println("---------------enterd forkStatement_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ForkStatementConfig)
	assert.Equal(t, (results), cfg.TestForkStatementTesting)
}
