package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestBooleanTextToText(t *testing.T) {
	fmt.Println("---------------enterd misc_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.BooleanTextToText)
	assert.Equal(t, results, cfg.TestBooleanTextToText)
}

func TestBooleanOtherTextToText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.BooleanOtherTextToText)
	assert.Equal(t, results, cfg.TestBooleanOtherToText)
}

func TestBooleanNumberToText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.BooleanNumberToText)
	assert.Equal(t, results, cfg.TestBooleanNumberToText)
}

func TestNumberNumericTextToText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumericTextToText)
	assert.Equal(t, results, cfg.TestNumberNumericTextToText)
}

func TestNumberNonNumericTextToText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NonNumericTextToText)
	assert.Equal(t, results, cfg.TestNumberNonNumericTextToText)
}

func TestConditionEmptyString(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.EmptyStringComparison)
	assert.Equal(t, results, cfg.TestEmptyStringComparison)
}

func TestCIBILCommSectionalStatement(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/CIBILCommercial.json")

	results := runTestCase(fileContent, cfg.CIBILCommSectionalStatement)
	assert.Equal(t, results, cfg.TestCIBILCommSectionalStatement)
}

func TestPanicRecovery(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/CIBILCommercial.json")

	results := runTestCase(fileContent, cfg.PanicRecvery)
	assert.Equal(t, results, cfg.TestPanicRecovery)
}
