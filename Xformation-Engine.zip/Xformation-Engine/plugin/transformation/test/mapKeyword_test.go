package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestMapKeySet(t *testing.T) {
	fmt.Println("---------------enterd mapKeyword_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MapGetKeySet)
	assert.Equal(t, len(results), 343)
}

func TestMapValueSet(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MapGetValuesSet)
	assert.Equal(t, len(results), 137)

}

func TestMapValuesSet(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/mapValues.json")

	results := runTestCase(fileContent, cfg.MapValueSset)
	assert.Equal(t, len(results), 73)

}
func TestMapLength(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MapLength)
	assert.Equal(t, (results), cfg.TestMapLength)
}

func TestMapWithNullValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MapWithNullValue)
	assert.Equal(t, (results), cfg.TestMapWithNullValue)
}

func TestMapWithPushValueByKey(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MapPushValueByKey)
	assert.Equal(t, (results), cfg.PushValueByKey)
}

func TestMapDeleteFromMap(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MapDeleteFromMap)
	assert.Equal(t, (results), cfg.TestDeleteFromMap)
}

func TestMapWithGetValueByKey(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.GetValueByKey)
	assert.Equal(t, (results), cfg.TestGetValueByKeys)
}

func TestMapJsonObjectMap(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.JsonObjectMap)
	assert.Equal(t, (results), cfg.TestMapJsonObjectMap)
}

func TestMakeTheMapEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MakeTheMapEmpty)
	assert.Equal(t, (results), cfg.TestMakeTheMapEmpty)
}

func TestMapContainsKey(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MapContainsKey)
	assert.Equal(t, (results), cfg.TestMapContainsKey)
}

func TestMapIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.CheckMapIsEmpty)
	assert.Equal(t, (results), cfg.TestIsEmptyForKeywords)
}

func TestMapIsEmptyForKeyNotPresent(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestMapIsEmptyForKeyNotPresent)
	assert.Equal(t, (results), cfg.TestIsEmptyForKeywords)
}

func TestMapIsEmptyForValueKeyNotPresentInConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestMapIsEmptyForValueKeyNotPresentInConfig)
	assert.Equal(t, (results), cfg.TestKeyNotPresentInConfigForIsEmpty)
}
