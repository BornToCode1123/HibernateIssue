package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestCreateObjectsInArray(t *testing.T) {
	fmt.Println("---------------enterd transform_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/conf4.json")

	results := runTestCase(fileContent, cfg.TransConfig4)
	assert.Equal(t, (results), cfg.TestCreateObjectsInArray)
}

func TestAppendArrayObjects(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf2.json")

	results := runTestCase(fileContent, cfg.TransConfig2)
	assert.Equal(t, (results), cfg.TestAppendArrayObjects)
}
