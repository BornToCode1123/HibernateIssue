package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestArrayObjectCountTesting(t *testing.T) {
	fmt.Println("---------------enterd functions_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayObjectCountConfig)
	assert.Equal(t, (results), cfg.TestArrayObjectCountTesting)
}

func TestPrimitiveArrayCountStringTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PrimitiveArrayCountStringConfig)
	assert.Equal(t, (results), cfg.TestPrimitiveArrayCountStringTesting)
}

func TestPrimitiveArrayCountNumberTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PrimitiveArrayCountNumberConfig)
	assert.Equal(t, (results), cfg.TestPrimitiveArrayCountNumberTesting)
}

func TestFilterCountNumberTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterCountNumberConfig)
	assert.Equal(t, (results), cfg.TestFilterCountNumberTesting)
}

func TestFilterCountNumber1Testing(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterCountNumber1Config)
	assert.Equal(t, (results), cfg.TestFilterCountNumber1Testing)
}

func TestEmptyArrayCountTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptyArrayCountConfig)
	assert.Equal(t, (results), cfg.TestEmptyArrayCountTesting)
}

func TestNullCountTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NilCountConfig)
	assert.Equal(t, (results), cfg.TestNullCountTesting)
}

func TestArraySumTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArraySumConfig)
	assert.Equal(t, (results), cfg.TestArraySumTesting)
}

func TestPrimitiveArraySumTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PrimitiveArraySumConfig)
	assert.Equal(t, (results), cfg.TestPrimitiveArraySumTesting)
}

func TestEmptyArraySumTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptyArraySumConfig)
	assert.Equal(t, (results), cfg.TestEmptyArraySumTesting)
}

func TestValueMissingArraySumTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ValueMissingArraySumConfig)
	assert.Equal(t, (results), cfg.TestValueMissingArraySumTesting)
}

func TestNullSumTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NilSumConfig)
	assert.Equal(t, (results), cfg.TestNullSumTesting)
}

func TestStringSumTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.StringSumConfig)
	assert.Equal(t, (results), cfg.TestStringSumTesting)
}

func TestFilterSumTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterSumNumberConfig)
	assert.Equal(t, (results), cfg.TestFilterSumTesting)
}

func TestFilterSum1Testing(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterSumWithUnknownNumberConfig)
	assert.Equal(t, (results), cfg.TestFilterSum1Testing)
}

func TestNestedConditionFiltersForSumCountMinMaxAvg(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestNestedConditionFiltersForSumCountMinMaxAvgConfig)
	assert.Equal(t, (results), cfg.TestNestedConditionFiltersForSumCountMinMaxAvgTesting)
}

func TestFilterPrimitiveArraySumTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterPrimitiveArraySumConfig)
	assert.Equal(t, (results), cfg.TestFilterPrimitiveArraySumTesting)
}

func TestArrayObjectAvgTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayObjectAvgConfig)
	assert.Equal(t, (results), cfg.TestArrayObjectAvgTesting)
}

func TestLocalArrayObjectAvgConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalArrayObjectAvgConfig)
	assert.Equal(t, (results), cfg.TestLocalArrayObjectAvgConfigTesting)
}

func TestPrimitiveArrayAvgTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PrimitiveArrayAvgConfig)
	assert.Equal(t, (results), cfg.TestPrimitiveArrayAvgTesting)
}

func TestNullAvgTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NilAvgConfig)
	assert.Equal(t, (results), cfg.TestNullAvgTesting)
}

func TestFilterAvgNumberTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterAvgNumberConfig)
	assert.Equal(t, (results), cfg.TestFilterAvgNumberTesting)
}

func TestFilterAvgDummyNumberTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterAvgDummyNumberConfig)
	assert.Equal(t, (results), cfg.TestFilterAvgDummyNumberTesting)
}

func TestArrayObjectMaxTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayObjectMaxConfig)
	assert.Equal(t, (results), cfg.TestArrayObjectMaxTesting)
}

func TestLocalArrayObjectMaxConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalArrayObjectMaxConfig)
	assert.Equal(t, (results), cfg.TestLocalArrayObjectMaxConfigTesting)
}

func TestEmptyArrayMaxTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptyArrayMaxConfig)
	assert.Equal(t, (results), cfg.TestEmptyArrayMaxTesting)
}

func TestPrimitiveArrayMaxTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PrimitiveArrayMaxConfig)
	assert.Equal(t, (results), cfg.TestPrimitiveArrayMaxTesting)
}

func TestNullMaxTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NilMaxConfig)
	assert.Equal(t, (results), cfg.TestNullMaxTesting)
}

func TestFilterMaxNumberTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterMaxNumberConfig)
	assert.Equal(t, (results), cfg.TestFilterMaxNumberTesting)
}

func TestLocalFilterMaxNumberConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalFilterMaxNumberConfig)
	assert.Equal(t, (results), cfg.TestLocalFilterMaxNumberConfigTesting)
}

func TestFilterPrimitiveArrayMaxTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterPrimitiveArrayMaxConfig)
	assert.Equal(t, (results), cfg.TestFilterPrimitiveArrayMaxTesting)
}

func TestArrayObjectMinTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayObjectMinConfig)
	assert.Equal(t, (results), cfg.TestArrayObjectMinTesting)
}

func TestLocalArrayObjectMinConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalArrayObjectMinConfig)
	assert.Equal(t, (results), cfg.TestLocalArrayObjectMinConfigTesting)
}

func TestEmptyArrayMinTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptyArrayMinConfig)
	assert.Equal(t, (results), cfg.TestEmptyArrayMinTesting)
}

func TestPrimitiveArrayMinTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PrimitiveArrayMinConfig)
	assert.Equal(t, (results), cfg.TestPrimitiveArrayMinTesting)
}

func TestNullMinTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NilMinConfig)
	assert.Equal(t, (results), cfg.TestNullMinTesting)
}

func TestFilterMinNumberTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterMinNumberConfig)
	assert.Equal(t, (results), cfg.TestFilterMinNumberTesting)
}

func TestLocalFilterMinNumberConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalFilterMinNumberConfig)
	assert.Equal(t, (results), cfg.TestLocalFilterMinNumberConfigTesting)
}

func TestFilterPrimitiveArrayMinTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterPrimitiveArrayMinConfig)
	assert.Equal(t, (results), cfg.TestFilterPrimitiveArrayMinTesting)
}

func TestPopulateSampleTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PopulateSample1)
	assert.Equal(t, (results), cfg.TestPopulateSampleTesting)
}

func TestPopulateLocalTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PopulateLocal1)
	assert.Equal(t, (results), cfg.TestPopulateLocalTesting)
}

func TestPopulateLocalandDataTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PopulateLocalandData1)
	assert.Equal(t, (results), cfg.TestPopulateLocalandDataTesting)
}

func TestPopulateEmptyFieldsTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PopulateEmptyFields1)
	assert.Equal(t, (results), cfg.TestPopulateEmptyFieldsTesting)
}

func TestLocalDataSplitConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalDataSplitConfig)
	assert.Equal(t, (results), cfg.TestLocalDataSplitConfigTesting)
}

func TestDataSplitConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.DataSplitConfig)
	assert.Equal(t, (results), cfg.TestDataSplitConfigTesting)
}

func TestCommaSplitTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.CommaSplitConfig)
	assert.Equal(t, (results), cfg.TestCommaSplitTesting)
}

func TestEmptySplitTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptySplitConfig)
	assert.Equal(t, (results), cfg.TestEmptySplitTesting)
}

func TestOneSplitTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.OneSplitConfig)
	assert.Equal(t, (results), cfg.TestOneSplitTesting)
}

func TestStringConcatTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.StringConcatConfig)
	assert.Equal(t, (results), cfg.TestStringConcatTesting)
}

func TestEmptyConcatTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptyConcatConfig)
	assert.Equal(t, (results), cfg.TestEmptyConcatTesting)
}

func TestStringMultipleConcatConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.StringMultipleConcatConfig)
	assert.Equal(t, (results), cfg.TestStringMultipleConcatConfigTesting)
}

func TestStringConcatWithCharactersConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.StringConcatWithCharactersConfig)
	assert.Equal(t, (results), cfg.TestStringConcatWithCharactersConfigTesting)
}

func TestLocalStringConcatConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalStringConcatConfig)
	assert.Equal(t, (results), cfg.TestLocalStringConcatConfigTesting)
}

func TestFormatDateAndTimeTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FormatDateAndTimeConfig)
	assert.Equal(t, (results), cfg.TestFormatDateAndTimeTesting)
}

func TestFormatDateAndTime1Testing(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FormatDateAndTime1Config)
	assert.Equal(t, (results), cfg.TestFormatDateAndTime1Testing)
}

func TestFormatDateAndTime2Testing(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FormatDateAndTime2Config)
	assert.Equal(t, (results), cfg.TestFormatDateAndTime2Testing)
}

func TestLocalFormatDateAndTimeConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalFormatDateAndTimeConfig)
	assert.Equal(t, (results), cfg.TestLocalFormatDateAndTimeConfigTesting)
}

func TestDateDifferenceTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.DateDifferenceConfig)
	assert.Equal(t, (results), cfg.TestDateDifferenceTesting)
}

func TestLocalDateDifferenceYearsTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalDateDifferenceYears)
	assert.Equal(t, (results), cfg.TestLocalDateDifferenceYearsTesting)
}

func TestLocalDateDifferenceWithDaysTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalDateDifferenceWithDays)
	assert.Equal(t, (results), cfg.TestLocalDateDifferenceWithDaysTesting)
}

// func TestCollectTesting(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/Functions.json")

// 	results := runTestCase(fileContent, cfg.CollectConfig)
// 	assert.Equal(t, (results), cfg.TestCollectTesting)
// }

func TestIterateFieldsChangeTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IterateFieldsChangeConfig)
	assert.Equal(t, (results), cfg.TestIterateFieldsChangeTesting)
}

// func TestIterateOtherFieldsChangeConfigTesting(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/Functions.json")

// 	results := runTestCase(fileContent, cfg.IterateOtherFieldsChangeConfig)
// 	assert.Equal(t, (results), cfg.TestIterateOtherFieldsChangeConfigTesting)

// 	fmt.Println("res : ", (results))
// }

func TestIterateFieldsEmptyConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.IterateFieldsEmptyConfig)
	assert.Equal(t, (results), cfg.TestIterateFieldsEmptyConfigTesting)

}

func TestFilterIterateConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterIterateConfig)
	assert.Equal(t, (results), cfg.TestFilterIterateConfigTesting)

}

func TestFilterIterateFieldsTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.FilterIterateFields)
	assert.Equal(t, (results), cfg.TestFilterIterateFieldsTesting)

}

func TestLocalIterateFilterFieldsTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalIterateFilterFields)
	assert.Equal(t, (results), cfg.TestLocalIterateFilterFieldsTesting)

}

func TestIterate1ConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.Iterate1Config)
	assert.Equal(t, (results), cfg.TestIterate1ConfigTesting)

}

func TestTransformIterateLocalTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TransformIterateLocal)
	assert.Equal(t, (results), cfg.TestTransformIterateLocalTesting)

}

func TestBreakIterateWithPayloadbynameTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.BreakIterateWithPayloadbyname)
	assert.Equal(t, (results), cfg.TestBreakIterateWithPayloadbynameTesting)
}

func TestEmptyarrayBreakIterateTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptyarrayBreakIterate)
	assert.Equal(t, (results), cfg.TestEmptyarrayBreakIterateTesting)
}

func TestNullarrayBreakIterateTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NullarrayBreakIterate)
	assert.Equal(t, (results), cfg.TestNullarrayBreakIterateTesting)
}

func TestTransformEmptyStatementsIterateTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TransformEmptyStatementsIterate)
	assert.Equal(t, (results), cfg.TestTransformEmptyStatementsIterateTesting)
}

func TestLowerConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LowerConfig)
	assert.Equal(t, (results), cfg.TestLowerConfigTesting)
}

func TestLocalLowerConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalLowerConfig)
	assert.Equal(t, (results), cfg.TestLocalLowerConfigTesting)
}

// func TestLowerNumberConfigTesting(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/Functions.json")

// 	results := runTestCase(fileContent, cfg.LowerNumberConfig)
// 	assert.Equal(t, (results), cfg.TestLowerNumberConfigTesting)
// }

func TestUpperConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.UpperConfig)
	assert.Equal(t, (results), cfg.TestUpperConfigTesting)
}

func TestLocalUpperConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalUpperConfig)
	assert.Equal(t, (results), cfg.TestLocalUpperConfigTesting)
}

// func TestUpperNumberConfigTesting(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/Functions.json")

// 	results := runTestCase(fileContent, cfg.UpperNumberConfig)
// 	assert.Equal(t, (results), cfg.TestUpperNumberConfigTesting)

// 	fmt.Println("res : ", (results))
// }

func TestCamelCaseConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.CamelCaseConfig)
	assert.Equal(t, (results), cfg.TestCamelCaseConfigTesting)
}

func TestLocalCamelCaseConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalCamelCaseConfig)
	assert.Equal(t, (results), cfg.TestLocalCamelCaseConfigTesting)
}

// func TestCamelCaseIntegerConfigTesting(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/Functions.json")

// 	results := runTestCase(fileContent, cfg.CamelCaseIntegerConfig)
// 	assert.Equal(t, (results), cfg.TestCamelCaseIntegerConfigTesting)

// 	fmt.Println("res : ", (results))
// }

func TestTextToNumberConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TextToNumberConfig)
	assert.Equal(t, (results), cfg.TestTextToNumberConfigTesting)
}

func TestTextToNumberLocalConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TextToNumberLocalConfig)
	assert.Equal(t, (results), cfg.TestTextToNumberLocalConfigTesting)
}

// func TestTextToNumberIntegerConfigTesting(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/Functions.json")

// 	results := runTestCase(fileContent, cfg.TextToNumberIntegerConfig)
// 	assert.Equal(t, (results), cfg.TestTextToNumberIntegerConfigTesting)
// }

func TestNumberToTextConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NumberToTextConfig)
	assert.Equal(t, (results), cfg.TestNumberToTextConfigTesting)
}

func TestNumberToTextLocalConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NumberToTextLocalConfig)
	assert.Equal(t, (results), cfg.TestNumberToTextLocalConfigTesting)
}

// func TestNumberToTextStringConfigTesting(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/Functions.json")

// 	results := runTestCase(fileContent, cfg.NumberToTextStringConfig)
// 	assert.Equal(t, (results), cfg.TestNumberToTextStringConfigTesting)
// }

func TestNumberCeilConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NumberCeilConfig)
	assert.Equal(t, (results), cfg.TestNumberCeilConfigTesting)
}

func TestLocalNumberCeilConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalNumberCeilConfig)
	assert.Equal(t, (results), cfg.TestLocalNumberCeilConfigTesting)
}

func TestNumberFloorConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NumberFloorConfig)
	assert.Equal(t, (results), cfg.TestNumberFloorConfigTesting)
}

func TestLocalNumberFloorConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalNumberFloorConfig)
	assert.Equal(t, (results), cfg.TestLocalNumberFloorConfigTesting)
}

func TestNumberRoundConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NumberRoundConfig)
	assert.Equal(t, (results), cfg.TestNumberRoundConfigTesting)
}

func TestLocalNumberRoundConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalNumberRoundConfig)
	assert.Equal(t, (results), cfg.TestLocalNumberRoundConfigTesting)
}

func TestNumberRoundWithDecimalConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NumberRoundWithDecimalConfig)
	assert.Equal(t, (results), cfg.TestNumberRoundWithDecimalConfigTesting)
}

func TestLocalNumberRoundWithDecimalConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalNumberRoundWithDecimalConfig)
	assert.Equal(t, (results), cfg.TestLocalNumberRoundWithDecimalConfigTesting)
}

func TestNumberGetNonDecimalConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NumberGetNonDecimalConfig)
	assert.Equal(t, (results), cfg.TestNumberGetNonDecimalConfigTesting)
}

func TestLocalNumberGetNonDecimalConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalNumberGetNonDecimalConfig)
	assert.Equal(t, (results), cfg.TestLocalNumberGetNonDecimalConfigTesting)
}

func TestNumberGetDecimalConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NumberGetDecimalConfig)
	assert.Equal(t, (results), cfg.TestNumberGetDecimalConfigTesting)
}

func TestLocalNumberGetDecimalConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalNumberGetDecimalConfig)
	assert.Equal(t, (results), cfg.TestLocalNumberGetDecimalConfigTesting)
}

func TestDateKeyword1ConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.DateKeyword1Config)
	assert.Equal(t, (results), cfg.TestDateKeyword1ConfigTesting)
}

func TestDateKeyword2ConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.DateKeyword2Config)
	assert.Equal(t, (results), cfg.TestDateKeyword2ConfigTesting)
}

func TestDateKeyword3ConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.DateKeyword3Config)
	assert.Equal(t, (results), cfg.TestDateKeyword3ConfigTesting)
}

func TestLocalDateKeywordConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalDateKeywordConfig)
	assert.Equal(t, (results), cfg.TestLocalDateKeywordConfigTesting)
}

func TestPrimitiveArraySortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PrimitiveArraySorting)
	assert.Equal(t, (results), cfg.TestPrimitiveArraySortingTesting)
}

func TestArrayStringSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayStringSorting)
	assert.Equal(t, (results), cfg.TestArrayStringSortingTesting)
}

func TestArrayObjectSortTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayObjectSort)
	assert.Equal(t, (results), cfg.TestArrayObjectSortTesting)
}

func TestSortStringsLocaltTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.SortStringsLocal)
	assert.Equal(t, (results), cfg.TestSortStringsLocaltTesting)
}

func TestSortByObjectsLocaltTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.SortByObjectsLocal)
	assert.Equal(t, (results), cfg.TestSortByObjectsLocaltTesting)
}

func TestArrayObjectMissingSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayObjectMissingSorting)
	assert.Equal(t, (results), cfg.TestArrayObjectMissingSortingTesting)
}

func TestEmptyArraySortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptyArraySorting)
	assert.Equal(t, (results), cfg.TestEmptyArraySortingTesting)
}

func TestNullArraySortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NullArraySorting)
	assert.Equal(t, (results), cfg.TestNullArraySortingTesting)
}

func TestArrayMultipleObjectsSingleValueSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayMultipleObjectsSingleValueSorting)
	assert.Equal(t, (results), cfg.TestArrayMultipleObjectsSingleValueSortingTesting)
}

func TestPrimitiveArrayRSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.PrimitiveArrayRSorting)
	assert.Equal(t, (results), cfg.TestPrimitiveArrayRSortingTesting)
}

func TestArrayStringRSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayStringRSorting)
	assert.Equal(t, (results), cfg.TestArrayStringRSortingTesting)
}

func TestArrayObjectRSortTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayObjectRSort)
	assert.Equal(t, (results), cfg.TestArrayObjectRSortTesting)
}

func TestRSortStringsLocaltTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.RSortStringsLocal)
	assert.Equal(t, (results), cfg.TestRSortStringsLocaltTesting)
}

func TestRSortByObjectsLocaltTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.RSortByObjectsLocal)
	assert.Equal(t, (results), cfg.TestRSortByObjectsLocaltTesting)
}

func TestArrayObjectMissingRSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayObjectMissingRSorting)
	assert.Equal(t, (results), cfg.TestArrayObjectMissingRSortingTesting)
}

func TestEmptyArrayRSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.EmptyArrayRSorting)
	assert.Equal(t, (results), cfg.TestEmptyArrayRSortingTesting)
}

func TestNullArrayRSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.NullArrayRSorting)
	assert.Equal(t, (results), cfg.TestNullArrayRSortingTesting)
}

func TestArrayMultipleObjectsSingleValueRSortingTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.ArrayMultipleObjectsSingleValueRSorting)
	assert.Equal(t, (results), cfg.TestArrayMultipleObjectsSingleValueRSortingTesting)
}

func TestTestKeyword_TrimTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestKeyword_Trim)
	assert.Equal(t, (results), cfg.TestTestKeyword_TrimTesting)
}

func TestLocalTestKeyword_TrimTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalTestKeyword_Trim)
	assert.Equal(t, (results), cfg.TestLocalTestKeyword_TrimTesting)
}

func TestKeyword_tobooleanTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestKeyword_toboolean)
	assert.Equal(t, (results), cfg.TestKeyword_tobooleanTesting)
}

func TestLocalTestKeyword_tobooleanTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalTestKeyword_toboolean)
	assert.Equal(t, (results), cfg.TestLocalTestKeyword_tobooleanTesting)
}

func TestKeyword_isnumberFalseTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestKeyword_isnumberFalse)
	assert.Equal(t, (results), cfg.TestKeyword_isnumberFalseTesting)
}

func TestLocalTestKeyword_isnumberFalseTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalTestKeyword_isnumberFalse)
	assert.Equal(t, (results), cfg.TestLocalTestKeyword_isnumberFalseTesting)
}

func TestKeyword_isnumberTrueTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestKeyword_isnumberTrue)
	assert.Equal(t, (results), cfg.TestKeyword_isnumberTrueTesting)
}

func TestLocalTestKeyword_isnumberTrueTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalTestKeyword_isnumberTrue)
	assert.Equal(t, (results), cfg.TestLocalTestKeyword_isnumberTrueTesting)
}

func TestKeyword_isbooleanfalseTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestKeyword_isbooleanfalse)
	assert.Equal(t, (results), cfg.TestKeyword_isbooleanfalseTesting)
}

func TestLocalTestKeyword_isbooleanfalseTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalTestKeyword_isbooleanfalse)
	assert.Equal(t, (results), cfg.TestLocalTestKeyword_isbooleanfalseTesting)
}

func TestKeyword_isbooleanTrueTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.TestKeyword_isbooleanTrue)
	assert.Equal(t, (results), cfg.TestKeyword_isbooleanTrueTesting)
}

func TestLocalTestKeyword_isbooleanTrueTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.LocalTestKeyword_isbooleanTrue)
	assert.Equal(t, (results), cfg.TestLocalTestKeyword_isbooleanTrueTesting)
}

func TestBooleantoTextTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.BooleantoText)
	assert.Equal(t, (results), cfg.TestBooleantoTextTesting)
}

func TestMapLengthsTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.MapLengths)
	assert.Equal(t, (results), cfg.TestMapLengthsTesting)
}

func TestSimpleKeywordsTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.DummyConfig)
	assert.Equal(t, (results), cfg.AllkeyWords)
}
