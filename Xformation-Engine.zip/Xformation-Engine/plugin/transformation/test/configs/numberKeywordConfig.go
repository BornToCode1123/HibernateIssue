package configs

const NumberRound = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Nellie",
        "statements" : [ {
          "id" : "171052232736638",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "round",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Giovanna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "171053390104233"
      },
      "id" : "171051613019438"
    } ]
  }
}`

const NumberToTextSalary = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tommie",
        "statements" : [ {
          "id" : "172918384639885",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "salary"
                }
              }
            }
          },
          "name" : "Keaton"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "172912266225366"
      },
      "id" : "172912702810137"
    } ]
  }
}`

const NumberCeil = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Mike",
        "statements" : [ {
          "id" : "174313538122786",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "ceil",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Karl"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "174319065848693"
      },
      "id" : "174319120257445"
    } ]
  }
}`

const NonNumericTextToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lelia",
        "statements" : [ {
          "id" : "175351788846796",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "number2"
                }
              }
            }
          },
          "name" : "Kitty"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "175356356716381"
      },
      "id" : "175351683538191"
    } ]
  }
}`

const NumberRoundwithDecimal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gerhard",
        "statements" : [ {
          "id" : "177007494600463",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "roundWithDecimal",
                "value" : 2,
                "init" : {
                  "value" : "prnctofOstooverallamnt"
                }
              }
            }
          },
          "name" : "Aryanna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "177002256711543"
      },
      "id" : "177005467675876"
    } ]
  }
}`

const NumericTextToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Emilio",
        "statements" : [ {
          "id" : "178242524219349",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "number1"
                }
              }
            }
          },
          "name" : "Orrin"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "178245226134165"
      },
      "id" : "178249294707101"
    } ]
  }
}`

const NumberFloor = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Precious",
        "statements" : [ {
          "id" : "179062804766069",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "floor",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Sim"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "179066811112439"
      },
      "id" : "179065338482145"
    } ]
  }
}`

const NumberGetDecimal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Efrain",
        "statements" : [ {
          "id" : "179605548947846",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getDecimal",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Coleman"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "179606304752163"
      },
      "id" : "179604925860950"
    } ]
  }
}`

const NumberGetNonDecimal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tony",
        "statements" : [ {
          "id" : "180103652063823",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getNonDecimal",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Dora"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "180105720492612"
      },
      "id" : "180104205513099"
    } ]
  }
}`

const NumberToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kobe",
        "statements" : [ {
          "id" : "180813762538393",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Reta"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "180818094966989"
      },
      "id" : "180819834427891"
    } ]
  }
}`

const NumberWithNullValue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Coty",
        "statements" : [ {
          "id" : "181386205380372",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "krakend"
                }
              }
            }
          },
          "name" : "Lottie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "181383741877122"
      },
      "id" : "181383898054879"
    } ]
  }
}`

const NumberTextConvertToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Coty",
        "statements" : [ {
          "id" : "181386205380372",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "number111"
                }
              }
            }
          },
          "name" : "Lottie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "181383741877122"
      },
      "id" : "181383898054879"
    } ]
  }
}`

const NumberToAsciiValue = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "jsonIgnoreProperty": false,
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Coty",
                  "statements": [
                      {
                          "id": "181386205380372",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "finalText",
                                  "dataType": "number"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataValue": "number",
                                  "dataType": "number",
                                  "keywordArguments": {
                                      "format": "toASCII",
                                      "init": {
                                          "value": "applicantName"
                                      }
                                  }
                              }
                          },
                          "name": "Lottie"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "181383741877122"
              },
              "id": "181383898054879"
          }
      ]
  }
}`

const CheckNumberIsEmptyConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "number",
                      "keywordArguments": {
                        "init": {
                          "value": "krakend"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check number is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": true,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const CheckNumberIsEmptyConfigForKeyNotPresent = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "number",
                      "keywordArguments": {
                        "init": {
                          "value": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check number is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const TestNumberValueKeyNotPresentInConfigForIsEmpty = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "number",
                      "keywordArguments": {
                        "init": {
                          "valuef": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check number is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`
