package configs

const ArrayObjectCountConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Nikki",
        "statements" : [ {
          "id" : "147816641874129",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "numberofratings",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Mohammad"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "147814612794603"
      },
      "id" : "147811216491423"
    } ]
  }
}`

const PrimitiveArrayCountNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jackie",
        "statements" : [ {
          "id" : "149874498464371",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalnumbercount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "name"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Dianna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "149876500020151"
      },
      "id" : "149878653395322"
    } ]
  }
}`

const FilterCountNumber1Config = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Elinore",
        "statements" : [ {
          "id" : "151761040439731",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "numberofratingwith10",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "151769538782223",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 1
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Emilia"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "151764782421915"
      },
      "id" : "151767409143753"
    } ]
  }
}`

const FilterCountNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Beulah",
        "statements" : [ {
          "id" : "153607460107051",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "numberofratingwith10",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "153606066507753",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 10
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Alfonzo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "153608379585138"
      },
      "id" : "153609107900819"
    } ]
  }
}`

const NilCountConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lester",
        "statements" : [ {
          "id" : "154871930932031",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalcount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores2"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Stephania"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "154877711978059"
      },
      "id" : "154879851694330"
    } ]
  }
}`

const EmptyArrayCountConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ramiro",
        "statements" : [ {
          "id" : "155847938340276",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalnamescount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores1"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Evelyn"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "155844469775112"
      },
      "id" : "155844176601945"
    } ]
  }
}`

const PrimitiveArrayCountStringConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Esther",
        "statements" : [ {
          "id" : "157184287579380",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalnamescount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "names"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Xzavier"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "157186443706872"
      },
      "id" : "157185236190539"
    } ]
  }
}`
