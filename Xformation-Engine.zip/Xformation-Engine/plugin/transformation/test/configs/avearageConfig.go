package configs

const PrimitiveArrayAvgConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jude",
        "statements" : [ {
          "id" : "179678180496677",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "avearage",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "name"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Hilbert"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "179671109515652"
      },
      "id" : "179677159332427"
    } ]
  }
}`

const ValueMissingArrayAvgConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Mattie",
        "statements" : [ {
          "id" : "181448553131688",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "total",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "akhil.Score",
                  "aggregate" : "score"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Garfield"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "181503103780639"
      },
      "id" : "181502660761696"
    } ]
  }
}`

const FilterAvgDummyNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Nyasia",
        "statements" : [ {
          "id" : "182757438310239",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "numberofavgratingwith1",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "182759313652146",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 1
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Dell"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "182752996788272"
      },
      "id" : "182754530465467"
    } ]
  }
}`

const FilterAvgNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Chelsie",
        "statements" : [ {
          "id" : "184274020686176",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "numberofavgratingwith10",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "184278538930124",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 10
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Stacy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "184278702036131"
      },
      "id" : "184275025723613"
    } ]
  }
}`

const LocalArrayObjectAvgConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Christina",
        "statements" : [ {
          "id" : "185703257308175",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "ratingsAvearage",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Annie"
        }, {
          "id" : "186362086522437",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "AvearageLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "ratingsAvearage@local",
              "dataType" : "text"
            }
          },
          "name" : "Isabelle"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "186377349556593"
      },
      "id" : "186377575884342"
    } ]
  }
}`

const StringAvgConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Genoveva",
        "statements" : [ {
          "id" : "187335754257029",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "total",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores3",
                  "aggregate" : "value"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Precious"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "187339202968210"
      },
      "id" : "187334559347456"
    } ]
  }
}`

const NilAvgConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : "true",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Dameon",
        "statements" : [ {
          "id" : "187772158786789",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalcount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores3"
                },
                "format" : "sum"
              }
            }
          },
          "name" : "Glenna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "187775595942663"
      },
      "id" : "187779629752015"
    } ]
  }
}`

const ArrayObjectAvgConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : "false",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Catherine",
        "statements" : [ {
          "id" : "188256797430528",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "ratingsAvearage",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Dayna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "188257886727641"
      },
      "id" : "188252813436116"
    } ]
  }
}`

const EmptyArrayAvgConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "America",
        "statements" : [ {
          "id" : "188843722260589",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "total2",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores1"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Sigrid"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "188847805111394"
      },
      "id" : "188848520761759"
    } ]
  }
}`
