package configs 

const PopulateLocal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ophelia",
        "statements" : [ {
          "id" : "476378257452697",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "text",
              "dataValue" : "name"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "Javed"
            }
          },
          "name" : "Dan"
        }, {
          "id" : "477285985334854",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "number",
              "dataValue" : "age"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "number",
              "dataValue" : 22
            }
          },
          "name" : "Sherman"
        }, {
          "id" : "478291498935277",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "text",
              "dataValue" : "role"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "developer"
            }
          },
          "name" : "Leonel"
        }, {
          "id" : "479167811200293",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "customerAge" : "age@local",
                    "designation" : "role@local",
                    "customerName" : "name@local"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Petra"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "479167866796808"
      },
      "id" : "479165019184941"
    } ]
  }
}`

const MultipleObjects = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Alessia",
        "statements" : [ {
          "id" : "482049731642816",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.name",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "javeed",
              "dataType" : "map"
            }
          },
          "name" : "Lavina"
        }, {
          "id" : "482632444810976",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.age",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "23",
              "dataType" : "map"
            }
          },
          "name" : "Cornell"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "482632688956196"
      },
      "id" : "482632493519856"
    } ]
  }
}`

const MultiplePopulate = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Otis",
        "statements" : [ {
          "id" : "484685381017780",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "customerName" : "name"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Vernice"
        }, {
          "id" : "485155802045733",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "keyword",
              "dataValue" : "none",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "customer.customerAge" : "age"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Josephine"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "485156671467539"
      },
      "id" : "485156523604146"
    } ]
  }
}`

const ObjectMapWithArray = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kiley",
        "statements" : [ {
          "id" : "487109167521659",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.details.presonalDetails.name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "name",
              "dataType" : "text"
            }
          },
          "name" : "Ayden"
        }, {
          "id" : "487828982234177",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.ratings",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customer.ratings",
              "dataType" : "list"
            }
          },
          "name" : "Geovanni"
        }, {
          "id" : "488251007315022",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.ratings",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customer.scores",
              "dataType" : "list"
            }
          },
          "name" : "Ernesto"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "488252647803040"
      },
      "id" : "488255851089413"
    } ]
  }
}`

const PopulateEmptyFields = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : false,
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tre",
        "statements" : [ {
          "id" : "489178255195791",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : { }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Cordell"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "489242084298986"
      },
      "id" : "489246676936765"
    } ]
  }
}`

const AppendObjects = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Elisabeth",
        "statements" : [ {
          "id" : "490275103463585",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.details",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customer",
              "dataType" : "map"
            }
          },
          "name" : "Orion"
        }, {
          "id" : "490821217480982",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.details",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "employe",
              "dataType" : "map"
            }
          },
          "name" : "Genoveva"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "490825445320394"
      },
      "id" : "490829542424514"
    } ]
  }
}`

const PopulateSample = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Micheal",
        "statements" : [ {
          "id" : "492015193268399",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "customerAge" : "age",
                    "designation" : "role",
                    "customerName" : "name"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Samantha"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "492019874270728"
      },
      "id" : "492019102674351"
    } ]
  }
}`

const PopulateLocalandData = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jaquelin",
        "statements" : [ {
          "id" : "493008682818244",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "text",
              "dataValue" : "name"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "Javed"
            }
          },
          "name" : "Telly"
        }, {
          "id" : "493438589495445",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "number",
              "dataValue" : "age"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "number",
              "dataValue" : 22
            }
          },
          "name" : "Shaina"
        }, {
          "id" : "493977619806829",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "text",
              "dataValue" : "role"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "developer"
            }
          },
          "name" : "Earnestine"
        }, {
          "id" : "494639263187091",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "customerAge" : "age@local",
                    "designation" : "role",
                    "customerName" : "name@local"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Maggie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "494632200823549"
      },
      "id" : "494631920410896"
    } ]
  }
}`

