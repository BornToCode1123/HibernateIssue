package configs 

const DummyConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Alyson",
        "statements" : [ {
          "id" : "146397723026568",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "defaultNumberValue",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "number"
            }
          },
          "name" : "Marilou"
        }, {
          "id" : "147259485342344",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "defaultTextValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text"
            }
          },
          "name" : "Cecil"
        }, {
          "id" : "148004733148575",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "defaultMapValue",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "map"
            }
          },
          "name" : "Annamae"
        }, {
          "id" : "148599982175177",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "defaulBooleanValue",
              "dataType" : "boolean"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "boolean",
              "dataType" : "boolean"
            }
          },
          "name" : "Jonathon"
        }, {
          "id" : "149183209958375",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "defaultArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list"
            }
          },
          "name" : "Manuela"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "149185288318508"
      },
      "id" : "149181984168806"
    } ]
  }
}`

