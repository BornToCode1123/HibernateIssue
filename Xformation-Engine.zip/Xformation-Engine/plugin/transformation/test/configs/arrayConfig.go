package configs

const ListLength = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "jsonIgnoreProperty" : "false",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Bella",
        "statements" : [ {
          "id" : "775244778044485",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "length",
                "init" : {
                  "value" : "arrayData"
                }
              }
            }
          },
          "name" : "Hiram"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "775249509725749"
      },
      "id" : "775246266491610"
    } ]
  }
}`

const SortBy = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Birdie",
        "statements" : [ {
          "id" : "777087684931930",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArrayByProperty",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "profitability_ratios",
                  "sortBy" : "year"
                }
              }
            }
          },
          "name" : "Kathryn"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "777086812055070"
      },
      "id" : "777084833651945"
    } ]
  }
}`

const KeywordList = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ramiro",
        "statements" : [ {
          "id" : "779364895382155",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArrayByProperty",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list"
            }
          },
          "name" : "Johann"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "779361965131867"
      },
      "id" : "779369297900525"
    } ]
  }
}`

const ListPop = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Claude",
        "statements" : [ {
          "id" : "780864877093456",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "garbageString",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "12345",
              "dataType" : "text"
            }
          },
          "name" : "Erick"
        }, {
          "id" : "782059137242725",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "garbageArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "garbageString@local",
                  "splitby" : ""
                },
                "format" : "split"
              }
            }
          },
          "name" : "Cleta"
        }, {
          "id" : "783613755645824",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "popelement",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "pop",
                "init" : {
                  "value" : "garbageArray@local"
                }
              }
            }
          },
          "name" : "Pauline"
        },  {
          "id" : "782844441125110",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "garbageArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "garbageArray@local",
              "dataType" : "list"
            }
          },
          "name" : "Michelle"
        }],
        "jsonIgnoreAliasValue" : null,
        "id" : "783612987944802"
      },
      "id" : "783616489867811"
    } ]
  }
}`

const ListLengthEmptyArray = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "ignoreNullFields" : true,
  "transform" : {
    "id" : "transform_custodetails",
    "jsonIgnoreProperty" : "false",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Angel",
        "statements" : [ {
          "id" : "785189753844858",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "length",
                "init" : {
                  "value" : "emptyArray"
                }
              }
            }
          },
          "name" : "Clemens"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "785189539811675"
      },
      "id" : "785185673358830"
    } ]
  }
}`

const ListPush = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Aaron",
        "statements" : [ {
          "id" : "786493412366609",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "pushedArray",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "push",
                "init" : {
                  "values" : [ "name", "mobile" ]
                }
              }
            }
          },
          "name" : "Lysanne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "786498232627348"
      },
      "id" : "786499904075937"
    } ]
  }
}`

const SortLocalStrings = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : "true",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Janice",
        "statements" : [ {
          "id" : "787478426290787",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "array",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "array",
              "dataType" : "list"
            }
          },
          "name" : "Levi"
        }, {
          "id" : "787814562130394",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "array@local"
                }
              }
            }
          },
          "name" : "Fiona"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "787814396285101"
      },
      "id" : "787817715548412"
    } ]
  }
}`

const ListSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Victoria",
        "statements" : [ {
          "id" : "788502819709594",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "array"
                }
              }
            }
          },
          "name" : "Dillon"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "788509270207233"
      },
      "id" : "788505748658651"
    } ]
  }
}`

const SortMap = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Raphaelle",
        "statements" : [ {
          "id" : "789305287209574",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArray",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "MonthlyData2"
                }
              }
            }
          },
          "name" : "Jewel"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "789304474995320"
      },
      "id" : "789307936277680"
    } ]
  }
}`

const SortLocalByProperty = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ewell",
        "statements" : [ {
          "id" : "790063989276922",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "profitability_ratios",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "profitability_ratios",
              "dataType" : "list"
            }
          },
          "name" : "Fermin"
        }, {
          "id" : "790433419052304",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArrayByProperty",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "profitability_ratios@local",
                  "sortBy" : "year"
                }
              }
            }
          },
          "name" : "Reggie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "790437160025770"
      },
      "id" : "790438307506696"
    } ]
  }
}`

const ListPushObject = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Carlos",
        "statements" : [ {
          "id" : "791395662973993",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "pushedArray",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "push",
                "init" : {
                  "values" : [ "MonthlyData" ]
                }
              }
            }
          },
          "name" : "Rod"
        }, {
          "id" : "792235713708644",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "pushedArray",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "push",
                "init" : {
                  "values" : [ "MonthlyData" ]
                }
              }
            }
          },
          "name" : "Brooks"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "792236633168384"
      },
      "id" : "792236669184363"
    } ]
  }
}`

const ListWithNullValue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ruth",
        "statements" : [ {
          "id" : "793451072498081",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalResult",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "list1",
                  "sortBy" : "year"
                }
              }
            }
          },
          "name" : "Marisol"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "793452915095416"
      },
      "id" : "793455021664323"
    } ]
  }
}`

const CreatingEmptyList = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Esmeralda",
                  "statements": [
                    {
                      "id" : "790063989276922",
                      "@type" : "AssignmentStatement",
                      "assignment" : {
                        "@type" : "SimpleAssignmentStatement",
                        "lhs" : {
                          "@type" : "declare",
                          "dataValue" : "size",
                          "dataType" : "list"
                        },
                        "operator" : {
                          "actualValue" : "="
                        },
                        "rhs" : {
                          "@type" : "literal",
                          "dataValue" : 6,
                          "dataType" : "list"
                        }
                      },
                      "name" : "Fermin"
                    },
                      {
                          "id": "421765311988163",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "array",
                                  "dataType": "list"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataValue": "list",
                                  "dataType": "list",
                                  "keywordArguments": {
                                      "format": "create",
                                      "init": {
                                          "size": "size@local"
                                      }
                                  }
                              }
                          },
                          "name": "Eula"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "421777337944566"
              },
              "id": "421774291141420"
          }
      ]
  }
}`

const CreatingEmptyListWithCount = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Esmeralda",
                  "statements": [
                    {
                      "id" : "432458486717590",
                      "@type" : "AssignmentStatement",
                      "assignment" : {
                        "@type" : "SimpleAssignmentStatement",
                        "lhs" : {
                          "@type" : "declare",
                          "dataValue" : "size",
                          "dataType" : "number"
                        },
                        "operator" : {
                          "actualValue" : "="
                        },
                        "rhs" : {
                          "@type" : "keyword",
                          "dataValue" : "list",
                          "dataType" : "number",
                          "keywordArguments" : {
                            "format" : "count",
                            "init" : {
                              "value" : "array"
                            }
                          }
                        }
                      },
                      "name" : "Ardith"
                    } ,
                      {
                          "id": "421765311988163",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "array",
                                  "dataType": "list"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataValue": "list",
                                  "dataType": "list",
                                  "keywordArguments": {
                                      "format": "create",
                                      "init": {
                                          "size": "size@local"
                                      }
                                  }
                              }
                          },
                          "name": "Eula"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "421777337944566"
              },
              "id": "421774291141420"
          }
      ]
  }
}`

const SplittedArrayOverriding = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "contentOutputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "dKjIu",
                  "statements": [
                      {
                          "id": "120681417833007",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataValue": "randomValue",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataValue": "random",
                                  "dataType": "text"
                              }
                          },
                          "name": "pIkgN"
                      },
                      {
                          "id": "120763124061764",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "declare",
                                  "dataValue": "proGrpCollCoverList",
                                  "dataType": "list"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataType": "list",
                                  "dataValue": "text",
                                  "keywordArguments": {
                                      "init": {
                                          "value": "proGrpCollCover",
                                          "splitby": ","
                                      },
                                      "format": "split"
                                  }
                              }
                          },
                          "name": "YvEcA"
                      },
                      {
                          "id": "120765686181309",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataType": "list",
                                  "dataValue": "proGrpCollCoverList"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataType": "text",
                                  "dataValue": "list",
                                  "keywordArguments": {
                                      "format": "push",
                                      "init": {
                                          "values": [
                                              "randomValue@local"
                                          ]
                                      }
                                  }
                              }
                          },
                          "name": "IAoTW"
                      },
                      {
                          "id": "120767469481927",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "literal",
                                  "dataType": "list",
                                  "dataValue": "proGrpCollCoverList"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "local",
                                  "dataType": "list",
                                  "dataValue": "proGrpCollCoverList"
                              }
                          },
                          "name": "NCPND"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "120767053218034"
              },
              "id": "120762441520158"
          }
      ]
  },
  "id": "120767357323891"
}`

const Shuffle = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Brenna",
        "statements" : [
           {
          "id" : "693563357661903",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "KRI",
              "dataType" : "text"
            }
          },
          "name" : "Olga"
        }, 
        {
          "id": "988253987098401",
          "@type": "AssignmentStatement",
          "assignment": {
              "@type": "SimpleAssignmentStatement",
              "lhs": {
                  "@type": "declare",
                  "dataValue": "nameCharacters",
                  "dataType": "list"
              },
              "operator": {
                  "actualValue": "="
              },
              "rhs": {
                  "@type": "keyword",
                  "dataType": "list",
                  "dataValue": "text",
                  "keywordArguments": {
                      "init": {
                          "value": "name@local",
                          "splitby": ""
                      },
                      "format": "split"
                  }
              }
          },
          "name": "Christa"
      },{
          "id" : "693999264665773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "generateCombinations",
                "init" : {
                  "value" : "nameCharacters@local"
                }
              }
            }
          },
          "name" : "Kaycee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "693993877376356"
      },
      "id" : "693993093750514"
    } ]
  }
}`

const ShufflingWords = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Brenna",
        "statements" : [
           {
          "id" : "693563357661903",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "ABC,PQR,XYZ",
              "dataType" : "text"
            }
          },
          "name" : "Olga"
        }, 
        {
          "id": "988253987098401",
          "@type": "AssignmentStatement",
          "assignment": {
              "@type": "SimpleAssignmentStatement",
              "lhs": {
                  "@type": "declare",
                  "dataValue": "nameCharacters",
                  "dataType": "list"
              },
              "operator": {
                  "actualValue": "="
              },
              "rhs": {
                  "@type": "keyword",
                  "dataType": "list",
                  "dataValue": "text",
                  "keywordArguments": {
                      "init": {
                          "value": "name@local",
                          "splitby": ","
                      },
                      "format": "split"
                  }
              }
          },
          "name": "Christa"
      },{
          "id" : "693999264665773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "generateCombinations",
                "init" : {
                  "value" : "nameCharacters@local"
                }
              }
            }
          },
          "name" : "Kaycee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "693993877376356"
      },
      "id" : "693993093750514"
    } ]
  }
}`

const ReverseArray = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Brenna",
        "statements" : [
           {
          "id" : "693563357661903",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "A,B,C",
              "dataType" : "text"
            }
          },
          "name" : "Olga"
        }, 
        {
          "id": "988253987098401",
          "@type": "AssignmentStatement",
          "assignment": {
              "@type": "SimpleAssignmentStatement",
              "lhs": {
                  "@type": "declare",
                  "dataValue": "nameCharacters",
                  "dataType": "list"
              },
              "operator": {
                  "actualValue": "="
              },
              "rhs": {
                  "@type": "keyword",
                  "dataType": "list",
                  "dataValue": "text",
                  "keywordArguments": {
                      "init": {
                          "value": "name@local",
                          "splitby": ","
                      },
                      "format": "split"
                  }
              }
          },
          "name": "Christa"
      },{
          "id" : "693999264665773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "shuffledStrings",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "generateCombinations",
                "init" : {
                  "value" : "nameCharacters@local"
                }
              }
            }
          },
          "name" : "Kaycee"
        } ,
        {
          "id" : "693999264665773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "shuffledStrings",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "generateCombinations",
                "init" : {
                  "value" : "nameCharacters@local"
                }
              }
            }
          },
          "name" : "Kaycee"
        } ,
        {
          "id" : "693999264665773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "reversedStrings",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "reverse",
                "init" : {
                  "value" : "shuffledStrings@local"
                }
              }
            }
          },
          "name" : "Kaycee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "693993877376356"
      },
      "id" : "693993093750514"
    } ]
  }
}`

const JsonObjectList = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
    "id": "transform_custodetails",
    "jsonIgnoreProperty": "false",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1729669920415592,
        "name": "BidBall",
        "@type": "AssignmentStatement",
        "mandatory": true,
        "assignment": {
          "lhs": {
            "@type": "literal",
            "dataType": "text",
            "dataValue": "listOfRecords"
          },
          "rhs": {
            "@type": "keyword",
            "dataType": "list",
            "dataValue": "list",
            "keywordArguments": {
              "init": {
                "value": "[{\"min_app_score\":0,\"max_app_score\":265,\"min_cibil_score\":0,\"max_cibil_score\":999,\"amount\":0},{\"min_app_score\":266,\"max_app_score\":300,\"min_cibil_score\":0,\"max_cibil_score\":730,\"amount\":0},{\"min_app_score\":266,\"max_app_score\":300,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":100000},{\"min_app_score\":266,\"max_app_score\":300,\"min_cibil_score\":760,\"max_cibil_score\":999,\"amount\":150000},{\"min_app_score\":301,\"max_app_score\":310,\"min_cibil_score\":0,\"max_cibil_score\":699,\"amount\":0},{\"min_app_score\":301,\"max_app_score\":310,\"min_cibil_score\":700,\"max_cibil_score\":730,\"amount\":100000},{\"min_app_score\":301,\"max_app_score\":310,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":150000},{\"min_app_score\":301,\"max_app_score\":310,\"min_cibil_score\":761,\"max_cibil_score\":999,\"amount\":200000},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":0,\"max_cibil_score\":649,\"amount\":0},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":650,\"max_cibil_score\":699,\"amount\":75000},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":700,\"max_cibil_score\":730,\"amount\":150000},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":200000},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":761,\"max_cibil_score\":999,\"amount\":250000},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":0,\"max_cibil_score\":649,\"amount\":0},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":650,\"max_cibil_score\":699,\"amount\":100000},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":700,\"max_cibil_score\":730,\"amount\":200000},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":250000},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":761,\"max_cibil_score\":999,\"amount\":250000},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":0,\"max_cibil_score\":649,\"amount\":0},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":650,\"max_cibil_score\":699,\"amount\":150000},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":700,\"max_cibil_score\":730,\"amount\":250000},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":250000},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":761,\"max_cibil_score\":999,\"amount\":250000}]"
              },
              "format": "jsonObjectList"
            }
          },
          "operator": {
            "actualValue": "="
          }
        }
      }
    ]
  }
}`

const MakeTheListEmpty = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": 1729669920415592,
              "name": "BidBall",
              "@type": "AssignmentStatement",
              "mandatory": true,
              "assignment": {
                  "lhs": {
                      "@type": "declare",
                      "dataType": "text",
                      "dataValue": "listOfRecords"
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataType": "list",
                      "dataValue": "list",
                      "keywordArguments": {
                          "init": {
                              "value": "[{\"min_app_score\":0,\"max_app_score\":265,\"min_cibil_score\":0,\"max_cibil_score\":999,\"amount\":0},{\"min_app_score\":266,\"max_app_score\":300,\"min_cibil_score\":0,\"max_cibil_score\":730,\"amount\":0},{\"min_app_score\":266,\"max_app_score\":300,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":100000},{\"min_app_score\":266,\"max_app_score\":300,\"min_cibil_score\":760,\"max_cibil_score\":999,\"amount\":150000},{\"min_app_score\":301,\"max_app_score\":310,\"min_cibil_score\":0,\"max_cibil_score\":699,\"amount\":0},{\"min_app_score\":301,\"max_app_score\":310,\"min_cibil_score\":700,\"max_cibil_score\":730,\"amount\":100000},{\"min_app_score\":301,\"max_app_score\":310,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":150000},{\"min_app_score\":301,\"max_app_score\":310,\"min_cibil_score\":761,\"max_cibil_score\":999,\"amount\":200000},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":0,\"max_cibil_score\":649,\"amount\":0},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":650,\"max_cibil_score\":699,\"amount\":75000},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":700,\"max_cibil_score\":730,\"amount\":150000},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":200000},{\"min_app_score\":311,\"max_app_score\":330,\"min_cibil_score\":761,\"max_cibil_score\":999,\"amount\":250000},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":0,\"max_cibil_score\":649,\"amount\":0},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":650,\"max_cibil_score\":699,\"amount\":100000},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":700,\"max_cibil_score\":730,\"amount\":200000},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":250000},{\"min_app_score\":331,\"max_app_score\":345,\"min_cibil_score\":761,\"max_cibil_score\":999,\"amount\":250000},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":0,\"max_cibil_score\":649,\"amount\":0},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":650,\"max_cibil_score\":699,\"amount\":150000},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":700,\"max_cibil_score\":730,\"amount\":250000},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":731,\"max_cibil_score\":760,\"amount\":250000},{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":761,\"max_cibil_score\":999,\"amount\":250000}]"
                          },
                          "format": "jsonObjectList"
                      }
                  },
                  "operator": {
                      "actualValue": "="
                  }
              }
          },
          {
              "id": 1729669920415592,
              "name": "BidBall",
              "@type": "AssignmentStatement",
              "mandatory": true,
              "assignment": {
                  "lhs": {
                      "@type": "declare",
                      "dataType": "text",
                      "dataValue": "listOfRecords"
                  },
                  "rhs": {
                    "@type": "keyword",
                    "dataType": "list",
                    "dataValue": "list",
                    "keywordArguments": {
                        "format": "clearTheList"
                    }        
                  },
                  "operator": {
                      "actualValue": "="
                  }
              }
          },
          {
              "id": "693563357661903",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataValue": "listOfRecords",
                      "dataType": "list"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "local",
                      "dataValue": "listOfRecords",
                      "dataType": "list"
                  }
              },
              "name": "Olga"
          }
      ]
  }
}`

const FindingIndexesOfEveryIteration = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": "132909467889492",
        "@type": "AssignmentStatement",
        "assignment": {
          "@type": "SimpleAssignmentStatement",
          "lhs": {
            "@type": "declare",
            "dataValue": "size",
            "dataType": "number"
          },
          "operator": {
            "actualValue": "="
          },
          "rhs": {
            "@type": "literal",
            "dataValue": 5,
            "dataType": "number"
          }
        },
        "name": "Jayce"
      },
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": false,
          "name": "Esmeralda",
          "statements": [
            {
              "id": "421765311988163",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "declare",
                  "dataValue": "array",
                  "dataType": "list"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataValue": "list",
                  "dataType": "list",
                  "keywordArguments": {
                    "format": "create",
                    "init": {
                      "size": "size@local"
                    }
                  }
                }
              },
              "name": "Eula"
            },
            {
              "id": "133772825940283",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "literal",
                  "dataValue": "listOfObjects",
                  "dataType": "list"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataType": "list",
                  "dataValue": "list",
                  "keywordArguments": {
                    "init": {
                      "transform": {
                        "id": "transformation",
                        "name": "transformation",
                        "statements": [
                          {
                            "@type": "SectionalStatement",
                            "section": {
                              "jsonIgnoreProperty": false,
                              "name": "Vita",
                              "statements": [
                                {
                                  "id": "132909467889492",
                                  "@type": "AssignmentStatement",
                                  "assignment": {
                                    "@type": "SimpleAssignmentStatement",
                                    "lhs": {
                                      "@type": "literal",
                                      "dataValue": "currentIndexValue",
                                      "dataType": "text"
                                    },
                                    "operator": {
                                      "actualValue": "="
                                    },
                                    "rhs": {
                                      "@type": "local",
                                      "dataValue": "currentIndex",
                                      "dataType": "text"
                                    }
                                  },
                                  "name": "Jayce"
                                }
                              ],
                              "jsonIgnoreAliasValue": null,
                              "id": "133772777341059"
                            },
                            "id": "133776481744347"
                          }
                        ]
                      },
                      "value": "array@local"
                    },
                    "format": "iterate"
                  }
                }
              },
              "name": "Maurice"
            }
          ],
          "jsonIgnoreAliasValue": null,
          "id": "421777337944566"
        },
        "id": "421774291141420"
      }
    ]
  }
}`

const CheckListIsEmpty = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "list",
                      "keywordArguments": {
                        "init": {
                          "value": "emptyArray"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check list is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": true,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const TestListIsEmptyForKeyNotPresent = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "list",
                      "keywordArguments": {
                        "init": {
                          "value": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check list is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`
const TestListIsEmptyForValueKeyNotPresentInConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "list",
                      "keywordArguments": {
                        "init": {
                          "valuef": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check list is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const IterationInsideTheBehaviourOfConfig = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "contentOutputType": "json",
    "transform": {
        "jsonIgnoreProperty": false,
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "136569493287775",
                "@type": "AssignmentStatement",
                "assignment": {
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "latest_list",
                        "dataType": "list"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "keyword",
                        "dataType": "list",
                        "dataValue": "list",
                        "keywordArguments": {
                            "init": {
                                "value": "employees",
                                "transform": {
                                    "id": "transform_config_2",
                                    "name": "transform Consumer Communication Address Details",
                                    "statements": [
                                        {
                                            "id": "136564593687724",
                                            "@type": "AssignmentStatement",
                                            "assignment": {
                                                "@type": "SimpleAssignmentStatement",
                                                "lhs": {
                                                    "@type": "declare",
                                                    "dataValue": "abc",
                                                    "dataType": "map"
                                                },
                                                "operator": {
                                                    "actualValue": "="
                                                },
                                                "rhs": {
                                                    "@type": "keyword",
                                                    "dataValue": "value",
                                                    "dataType": "map"
                                                }
                                            },
                                            "name": "Chet"
                                        },
                                        {
                                            "id": "136564593687724",
                                            "@type": "AssignmentStatement",
                                            "assignment": {
                                                "@type": "SimpleAssignmentStatement",
                                                "lhs": {
                                                    "@type": "keyword",
                                                    "dataValue": "none",
                                                    "dataType": "map"
                                                },
                                                "operator": {
                                                    "actualValue": "="
                                                },
                                                "rhs": {
                                                    "@type": "local",
                                                    "dataValue": "abc",
                                                    "dataType": "map"
                                                }
                                            },
                                            "name": "Chet"
                                        }
                                    ]
                                }
                            },
                            "format": "iterate"
                        }
                    }
                },
                "name": "Jaeden"
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "literal",
                        "dataValue": "latest_list",
                        "dataType": "list"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "local",
                        "dataValue": "latest_list",
                        "dataType": "list"
                    }
                }
            }
        ]
    }
}`

const IterateWithTransformChangingTheExistingBehaviourUsingConfig = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "contentOutputType": "json",
    "transform": {
        "jsonIgnoreProperty": false,
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "136569493287775",
                "@type": "AssignmentStatement",
                "assignment": {
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "latest_list",
                        "dataType": "list"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "keyword",
                        "dataType": "list",
                        "dataValue": "list",
                        "keywordArguments": {
                            "init": {
                                "value": "employees",
                                "transform": {
                                    "id": "transform_config_2",
                                    "name": "transform Consumer Communication Address Details",
                                    "statements": [
                                        {
                                            "id": "136564593687724",
                                            "@type": "AssignmentStatement",
                                            "assignment": {
                                                "@type": "SimpleAssignmentStatement",
                                                "lhs": {
                                                    "@type": "declare",
                                                    "dataValue": "abc",
                                                    "dataType": "map"
                                                },
                                                "operator": {
                                                    "actualValue": "="
                                                },
                                                "rhs": {
                                                    "@type": "keyword",
                                                    "dataValue": "value",
                                                    "dataType": "map"
                                                }
                                            },
                                            "name": "Chet"
                                        },
                                         
                                        {
                                            "id": "136564593687724",
                                            "@type": "AssignmentStatement",
                                            "assignment": {
                                                "@type": "SimpleAssignmentStatement",
                                                "lhs": {
                                                    "@type": "keyword",
                                                    "dataValue": "none",
                                                    "dataType": "map"
                                                },
                                                "operator": {
                                                    "actualValue": "="
                                                },
                                                "rhs": {
                                                    "@type": "local",
                                                    "dataValue": "abc",
                                                    "dataType": "map"
                                                }
                                            },
                                            "name": "Chet"
                                        },
                                        {
              "id": 1729669920415592,
              "name": "BidBall",
              "@type": "AssignmentStatement",
              "mandatory": true,
              "assignment": {
                  "lhs": {
                      "@type": "declare",
                      "dataType": "map",
                      "dataValue": "abc"
                  },
                  "rhs": {
                    "@type": "keyword",
                    "dataType": "map",
                    "dataValue": "map",
                    "keywordArguments": {
                        "format": "clearTheMap"
                    }        
                  },
                  "operator": {
                      "actualValue": "="
                  }
              }
          }
                                    ]
                                }
                            },
                            "format": "iterate"
                        }
                    }
                },
                "name": "Jaeden"
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "literal",
                        "dataValue": "latest_list",
                        "dataType": "list"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "local",
                        "dataValue": "latest_list",
                        "dataType": "list"
                    }
                }
            }
        ]
    }
}`
