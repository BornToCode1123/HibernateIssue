package configs

const CurrencyConfLOcalNUmberToUsd1 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Laury",
        "statements" : [ {
          "id" : "133607106314892",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "formattedAmountLocal",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 456,
              "dataType" : "number"
            }
          },
          "name" : "Alessandra"
        }, {
          "id" : "134172674178792",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "formattedAmount",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "currency",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "USD",
                "init" : {
                  "format" : "number",
                  "value" : "formattedAmountLocal@local"
                }
              }
            }
          },
          "name" : "Graham"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "134179180937712"
      },
      "id" : "134177046334275"
    } ]
  }
}`

const CurrencyINRConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Holden",
        "statements" : [ {
          "id" : "136232333377017",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "formattedAmount",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "currency",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "INR",
                "init" : {
                  "format" : "number",
                  "value" : "creditedAmount"
                }
              }
            }
          },
          "name" : "Lura"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "136233787412234"
      },
      "id" : "136234280743546"
    } ]
  }
}`

const CurrencyConfLOcalZeroNUmberToUsd1 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Rosamond",
        "statements" : [ {
          "id" : "138373954554687",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "formattedAmountLocal",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 0,
              "dataType" : "number"
            }
          },
          "name" : "Rico"
        }, {
          "id" : "138772772191203",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "formattedAmount",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "currency",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "USD",
                "init" : {
                  "format" : "number",
                  "value" : "formattedAmountLocal@local"
                }
              }
            }
          },
          "name" : "Brendan"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "138775709884771"
      },
      "id" : "138776381682988"
    } ]
  }
}`

const CurrencyINRTextConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Aron",
        "statements" : [ {
          "id" : "139972586828371",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "formattedAmount",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "currency",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "INR",
                "init" : {
                  "format" : "text",
                  "value" : "creditedAmountText"
                }
              }
            }
          },
          "name" : "Stan"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "139976326687476"
      },
      "id" : "139974947158039"
    } ]
  }
}`

const CurrencyConfLOcalWithNull1 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Opal",
        "statements" : [ {
          "id" : "140725723326121",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "formattedAmount",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "currency",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "USD",
                "init" : {
                  "format" : "text",
                  "value" : "formattedAmountNUll"
                }
              }
            }
          },
          "name" : "Mustafa"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "140727617820681"
      },
      "id" : "140721747184806"
    } ]
  }
}`

const CurrencyFormatTestingInINR = `{
  "version": "1",
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_config_1",
      "name": "customerResponse",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Cecilia",
                  "statements": [
                      {
                          "id": "totalExposure-2.1",
                          "@type": "AssignmentStatement",
                          "name": "Stephania",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "totalExposure_formatted",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataValue": "currency",
                                  "dataType": "text",
                                  "keywordArguments": {
                                      "format": "INR",
                                      "init": {
                                          "format": "text",
                                          "value": "amountOfSalary"
                                      }
                                  }
                              }
                          }
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "996305009517531"
              },
              "id": "996308253226701"
          }
      ]
  },
  "delete": {},
  "extract": {}
}`
