package configs

const GenerateUUIDWithJsonIgnoreTrue = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "@type": "SectionalStatement",
                "section": {
                    "jsonIgnoreProperty": true,
                    "name": "Jayme",
                    "statements": [
                        {
                            "id": "423593227207476",
                            "@type": "AssignmentStatement",
                            "assignment": {
                                "@type": "SimpleAssignmentStatement",
                                "lhs": {
                                    "@type": "literal",
                                    "dataValue": "finalText",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "="
                                },
                                "rhs": {
                                    "@type": "keyword",
                                    "dataValue": "text",
                                    "dataType": "text",
                                    "keywordArguments": {
                                        "format": "generateUUID",
                                        "init": {
                                            "type": "numeric",
                                            "size": 16
                                        }
                                    }
                                }
                            },
                            "name": "Annetta"
                        }
                    ],
                    "jsonIgnoreAliasValue": null,
                    "id": "423597673948755"
                },
                "id": "423591358698329"
            }
        ]
    }
}`

const XMLTempleteObjectMakingList = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "contentOutputType": "json",
    "transform": {
        "jsonIgnoreProperty": false,
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "name": "xmlResp",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "xmlResponseLocal",
                        "dataType": "text"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "variable",
                        "dataValue": "xmlResponse",
                        "dataType": "text"
                    }
                }
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "name": "xmlResp",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "custDetailsObject",
                        "dataType": "text"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "variable",
                        "dataValue": "xmlResponse.FIXML.Body.executeFinacleScriptResponse.executeFinacleScript_CustomData.CUST_DETAILS",
                        "dataType": "text"
                    }
                }
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "name": "xmlResp",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "xmlResponseLocal.FIXML.Body.executeFinacleScriptResponse.executeFinacleScript_CustomData",
                        "dataType": "map"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "literal",
                        "dataValue": null,
                        "dataType": "map"
                    }
                }
            },
            {
                "id": "136569493287775",
                "@type": "AssignmentStatement",
                "assignment": {
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "xmlResponseLocal.FIXML.Body.executeFinacleScriptResponse.executeFinacleScript_CustomData.CUST_DETAILS",
                        "dataType": "list"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "keyword",
                        "dataType": "list",
                        "dataValue": "list",
                        "keywordArguments": {
                            "init": {
                                "transform": {
                                    "id": "transform_config_2",
                                    "name": "transform Consumer Communication Address Details",
                                    "statements": [
                                        {
                                            "id": "136564593687724",
                                            "@type": "AssignmentStatement",
                                            "assignment": {
                                                "@type": "SimpleAssignmentStatement",
                                                "lhs": {
                                                    "@type": "keyword",
                                                    "dataValue": "none",
                                                    "dataType": "map"
                                                },
                                                "operator": {
                                                    "actualValue": "=",
                                                    "expressionType": "SimpleAssignment",
                                                    "dataType": "text"
                                                },
                                                "rhs": {
                                                    "@type": "variable",
                                                    "dataValue": "custDetailsObject@local",
                                                    "dataType": "map"
                                                }
                                            },
                                            "name": "Chet"
                                        }
                                    ]
                                }
                            },
                            "format": "iterate"
                        }
                    }
                },
                "name": "Jaeden"
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "xmlResponseLocalData",
                        "dataType": "map"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "variable",
                        "dataValue": "xmlResponseLocal@local",
                        "dataType": "map"
                    }
                }
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "literal",
                        "dataValue": "xmlresponseAfterListNull",
                        "dataType": "map"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "keyword",
                        "dataValue": "value",
                        "dataType": "map"
                    }
                }
            }
        ]
    }
}`

const LocalReferenceWithnormalReference = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "contentOutputType": "json",
    "transform": {
        "jsonIgnoreProperty": false,
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "name": "xmlResp",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "detailsLocal",
                        "dataType": "text"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "variable",
                        "dataValue": "details",
                        "dataType": "text"
                    }
                }
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "declare",
                        "dataValue": "detailsLocal.name",
                        "dataType": "text"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "literal",
                        "dataValue": "Akash",
                        "dataType": "text"
                    }
                }
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "literal",
                        "dataValue": "detailsLocal",
                        "dataType": "text"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "variable",
                        "dataValue": "detailsLocal@local",
                        "dataType": "text"
                    }
                }
            },
            {
                "id": "8",
                "@type": "AssignmentStatement",
                "assignment": {
                    "@type": "SimpleAssignmentStatement",
                    "lhs": {
                        "@type": "literal",
                        "dataValue": "details",
                        "dataType": "text"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "variable",
                        "dataValue": "details",
                        "dataType": "text"
                    }
                }
            }
        ]
    }
}`

const TestEmptyStringSplit = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "contentOutputType": "json",
    "transform": {
        "jsonIgnoreAliasValue" : "",
        "jsonIgnoreProperty": true,
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "113232367055881",
                "@type": "AssignmentStatement",
                "assignment": {
                    "lhs": {
                        "@type": "literal",
                        "dataType": "list",
                        "dataValue": "splittedSolIdList"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "keyword",
                        "dataType": "list",
                        "dataValue": "text",
                        "keywordArguments": {
                            "init": {
                                "value": "formTemplateResponse2.solId",
                                "splitby": ""
                            },
                            "format": "split"
                        }
                    }
                },
                "name": "KnVvH"
            }
        ]
    }
}`
const TestArithematicInCondition = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "contentOutputType": "json",
  "transform": {
      "jsonIgnoreAliasValue" : "",
      "jsonIgnoreProperty": true,
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
         {
    "id": "1738074912325932",
    "name": "TAKING MAX OF INDIVIDUAL AND JOINT HL LAP SANCTION AMOUNT",
    "@type": "ConditionalStatement",
    "toogleSwitchValue": false,
    "condition": {
        "@type": "logical",
        "type": "and",
        "rules": [
            {
                "@type": "relational",
                "lhs": {
                    "@type": "literal",
                    "dataValue": 55,
                    "dataType": "number"
                },
                "operator": {
                    "actualValue": ">="
                },
                "rhs": {
                    "structure": {
                        "@type": "arithmetic",
                        "dataType": "*",
                        "variables": [
                            {
                                "@type": "literal",
                                "dataValue": 10,
                                "dataType": "number"
                            },
                            {
                                "@type": "literal",
                                "dataValue": 0.5,
                                "dataType": "number"
                            }
                        ]
                    },
                    "dataType": "number",
                    "@type": "expression"
                }
            }
        ]
    },
    "mandatory": true,
    "success": {
        "id": "110544194608133",
        "name": "IllSport"
    },
    "failure": {
        "id": "300643007463504",
        "name": "FaithPad"
    }
}
      ]
  }
}`
const TestFilterBug = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "contentOutputType": "json",
    "transform": {
        "jsonIgnoreAliasValue" : "",
        "jsonIgnoreProperty": false,
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            
                {
                    "id": 1728742149011305,
                    "name": "firstSection",
                    "@type": "SectionalStatement",
                    "section": {
                        "id": 146047136581860,
                        "name": "firstSection",
                        "statements": [
                            {
                                "id": 1728742149011305,
                                "name": "nestedSection",
                                "@type": "SectionalStatement",
                                "section": {
                                    "id": 146047136581860,
                                    "name": "nestedSection",
                                    "statements": [
                                        {
                                            "id": 1728742166277381,
                                            "name": "BeamPlate",
                                            "@type": "AssignmentStatement",
                                            "mandatory": true,
                                            "assignment": {
                                                "lhs": {
                                                    "@type": "literal",
                                                    "dataType": "text",
                                                    "dataValue": "F_Name"
                                                },
                                                "rhs": {
                                                    "@type": "literal",
                                                    "dataType": "text",
                                                    "dataValue": "Pratima"
                                                },
                                                "operator": {
                                                    "actualValue": "="
                                                }
                                            }
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                },
                {
                    "id": 1728742130757594,
                    "name": "secondSection",
                    "@type": "SectionalStatement",
                    "section": {
                        "id": 262439789847357,
                        "name": "secondSection",
                        "statements": [
                            {
                                "id": 1728742180346577,
                                "name": "CreamChance",
                                "@type": "AssignmentStatement",
                                "mandatory": true,
                                "assignment": {
                                    "lhs": {
                                        "@type": "literal",
                                        "dataType": "text",
                                        "dataValue": "L-Name"
                                    },
                                    "rhs": {
                                        "@type": "literal",
                                        "dataType": "text",
                                        "dataValue": "Javed"
                                    },
                                    "operator": {
                                        "actualValue": "="
                                    }
                                }
                            }
                        ]
                    }
                },
                {
                    "id": 1728742172105469,
                    "name": "thirdSection",
                    "@type": "SectionalStatement",
                    "section": {
                        "id": 695247064687125,
                        "name": "thirdSection",
                        "statements": [
                            {
                                "id": 1728742188015284,
                                "name": "RankStay",
                                "@type": "AssignmentStatement",
                                "mandatory": true,
                                "assignment": {
                                    "lhs": {
                                        "@type": "literal",
                                        "dataType": "text",
                                        "dataValue": "M_Name"
                                    },
                                    "rhs": {
                                        "@type": "literal",
                                        "dataType": "text",
                                        "dataValue": "akash"
                                    },
                                    "operator": {
                                        "actualValue": "="
                                    }
                                }
                            }
                        ]
                    }
                }
            
        ]
    }
}`

const TestConditionWithrules = `{
    "id": 884602368828668,
    "name": "SMFBURSURGELIGIBILITY",
    "@type": "transform",
    "debug": false,
    "errors": {
      "id": 884602368828668,
      "name": "ErrorStatement",
      "statements": [
        {
          "id": 893594662210874,
          "name": "STATEMENT 889025713857323",
          "@type": "SectionalStatement",
          "section": {
            "id": 889029890352177,
            "name": "SECTION Statement 889029890352177",
            "statements": [],
            "jsonIgnoreProperty": false
          },
          "mandatory": true
        }
      ],
      "jsonIgnoreProperty": false
    },
    "headers": {},
    "version": 9,
    "transform": {
      "id": 884602368828668,
      "name": "SMFBURSURGELIGIBILITY",
      "statements": [
        {
          "id": 1729589859856643,
          "name": "SMFBURSURGELIGIBILITYRF",
          "@type": "SectionalStatement",
          "section": {
            "id": 258854645121675,
            "name": "SMFBURSURGELIGIBILITYRF",
            "statements": [
              {
                "id": 1729665712735872,
                "name": "Overdue in Credit Card and Gold Loan Rule",
                "@type": "SectionalStatement",
                "section": {
                  "id": 408152416387011,
                  "name": "Overdue in Credit Card and Gold Loan Rule",
                  "statements": [
                    {
                      "id": 1729669693742863,
                      "name": "HotEdge",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "text",
                          "dataValue": "overdue_ccglacc_result"
                        },
                        "rhs": {
                          "@type": "literal",
                          "dataType": "text",
                          "dataValue": "Approve"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729669920415592,
                      "name": "BidBall",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "text",
                          "dataValue": "over_due"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "filter": {
                            "id": 1729669913449410,
                            "name": "Add Filter",
                            "condition": {
                              "type": "and",
                              "@type": "logical",
                              "rules": [
                                {
                                  "lhs": {
                                    "@type": "literal",
                                    "dataType": "text",
                                    "dataValue": "ACCOUNT-INFOS.ACCOUNT-INFO.OWNERSHIP-IND"
                                  },
                                  "rhs": {
                                    "@type": "literal",
                                    "dataType": "text",
                                    "dataValue": "Guarantor"
                                  },
                                  "@type": "relational",
                                  "operator": {
                                    "actualValue": "!="
                                  }
                                }
                              ]
                            }
                          },
                          "dataType": "list",
                          "dataValue": "list",
                          "keywordArguments": {
                            "init": {
                              "break": {
                                "type": "and",
                                "@type": "logical",
                                "rules": [
                                  {
                                    "lhs": {
                                      "@type": "local",
                                      "dataType": "text",
                                      "dataValue": "overdue_ccglacc_result"
                                    },
                                    "rhs": {
                                      "@type": "literal",
                                      "dataType": "text",
                                      "dataValue": "Reject"
                                    },
                                    "@type": "relational",
                                    "operator": {
                                      "actualValue": "=="
                                    }
                                  }
                                ]
                              },
                              "value": "CNS-QUAD-MERGE-REPORT.REPORT-SEGMENT.ACCOUNT-HISTORIES.ACCOUNT-HISTORY",
                              "transform": {
                                "id": "210499190416143",
                                "name": "Iterate 709052",
                                "statements": [
                                  {
                                    "id": 1729670210713065,
                                    "name": "FrontMove",
                                    "@type": "AssignmentStatement",
                                    "mandatory": true,
                                    "assignment": {
                                      "lhs": {
                                        "@type": "declare",
                                        "dataType": "date",
                                        "dataValue": "current_date"
                                      },
                                      "rhs": {
                                        "@type": "keyword",
                                        "dataType": "date",
                                        "dataValue": "date",
                                        "keywordArguments": {
                                          "format": "dd-MM-yyyy"
                                        },
                                        "functionLabelName": "DD-MM-YYYY (31-12-1998)"
                                      },
                                      "operator": {
                                        "actualValue": "="
                                      }
                                    }
                                  },
                                  {
                                    "id": 1729670245692172,
                                    "name": "LabTale",
                                    "@type": "AssignmentStatement",
                                    "mandatory": true,
                                    "assignment": {
                                      "lhs": {
                                        "@type": "declare",
                                        "dataType": "date",
                                        "dataValue": "date_reported"
                                      },
                                      "rhs": {
                                        "@type": "variable",
                                        "dataType": "date",
                                        "dataValue": "ACCOUNT-INFOS.ACCOUNT-INFO.DATE-REPORTED"
                                      },
                                      "operator": {
                                        "actualValue": "="
                                      }
                                    }
                                  },
                                  {
                                    "id": 1729678633780738,
                                    "log": {
                                      "level": "INFO",
                                      "messages": [
                                        {
                                          "@type": "literal",
                                          "dataType": "number",
                                          "dataValue": 111
                                        },
                                        {
                                          "@type": "local",
                                          "dataType": "date",
                                          "dataValue": "current_date"
                                        },
                                        {
                                          "@type": "local",
                                          "dataType": "date",
                                          "dataValue": "date_reported"
                                        }
                                      ]
                                    },
                                    "name": "HotGround",
                                    "@type": "LogStatement",
                                    "mandatory": true
                                  },
                                  {
                                    "id": 1729670365383120,
                                    "name": "NeckBoot",
                                    "@type": "AssignmentStatement",
                                    "mandatory": true,
                                    "assignment": {
                                      "lhs": {
                                        "@type": "declare",
                                        "dataType": "number",
                                        "dataValue": "acc_age"
                                      },
                                      "rhs": {
                                        "@type": "keyword",
                                        "dataType": "date",
                                        "dataValue": "date",
                                        "keywordArguments": {
                                          "init": {
                                            "end": {
                                              "value": "date_reported@local",
                                              "format": "dd-MM-yyyy"
                                            },
                                            "start": {
                                              "value": "current_date@local",
                                              "format": "dd-MM-yyyy"
                                            }
                                          },
                                          "type": "months",
                                          "format": "dateDiff"
                                        },
                                        "functionLabelName": "Difference between two dates"
                                      },
                                      "operator": {
                                        "actualValue": "="
                                      }
                                    }
                                  },
                                  {
                                    "id": 1729685366909258,
                                    "name": "Overdue amount null handling",
                                    "@type": "ConditionalStatement",
                                    "failure": {
                                      "id": 114329235621725,
                                      "name": "NewsDock",
                                      "statements": [
                                        {
                                          "id": 1729685441719239,
                                          "name": "GunSale",
                                          "@type": "AssignmentStatement",
                                          "mandatory": true,
                                          "assignment": {
                                            "lhs": {
                                              "@type": "declare",
                                              "dataType": "number",
                                              "dataValue": "overdue_amt"
                                            },
                                            "rhs": {
                                              "@type": "keyword",
                                              "dataType": "number",
                                              "dataValue": "text",
                                              "keywordArguments": {
                                                "init": {
                                                  "value": "AMOUNTS.AMOUNT.AMOUNT-OVERDUE"
                                                },
                                                "format": "toNumber"
                                              },
                                              "functionLabelName": "Convert text to number"
                                            },
                                            "operator": {
                                              "actualValue": "="
                                            }
                                          }
                                        }
                                      ],
                                      "jsonIgnoreProperty": false
                                    },
                                    "success": {
                                      "id": 724677171182762,
                                      "name": "WetStep",
                                      "statements": [
                                        {
                                          "id": 1729685428523529,
                                          "name": "ShockStream",
                                          "@type": "AssignmentStatement",
                                          "mandatory": true,
                                          "assignment": {
                                            "lhs": {
                                              "@type": "declare",
                                              "dataType": "number",
                                              "dataValue": "overdue_amt"
                                            },
                                            "rhs": {
                                              "@type": "literal",
                                              "dataType": "number",
                                              "dataValue": 0
                                            },
                                            "operator": {
                                              "actualValue": "="
                                            }
                                          }
                                        }
                                      ],
                                      "jsonIgnoreProperty": false
                                    },
                                    "condition": {
                                      "type": "and",
                                      "@type": "logical",
                                      "rules": [
                                        {
                                          "lhs": {
                                            "@type": "variable",
                                            "dataType": "text",
                                            "dataValue": "AMOUNTS.AMOUNT.AMOUNT-OVERDUE"
                                          },
                                          "rhs": {
                                            "@type": "keyword",
                                            "dataType": "text",
                                            "dataValue": "text",
                                            "keywordArguments": {},
                                            "functionLabelName": ""
                                          },
                                          "@type": "relational",
                                          "operator": {
                                            "actualValue": "=="
                                          }
                                        }
                                      ]
                                    },
                                    "mandatory": true
                                  },
                                  {
                                    "id": 1729670543557927,
                                    "name": "CC and GL overdue in last 12m rule",
                                    "@type": "ConditionalStatement",
                                    "failure": {
                                      "id": 154488426633388,
                                      "name": "RoundFur",
                                      "statements": [],
                                      "jsonIgnoreProperty": false
                                    },
                                    "success": {
                                      "id": 757826519838189,
                                      "name": "RedBlue",
                                      "statements": [
                                        {
                                          "id": 1729670751878275,
                                          "name": "MomScience",
                                          "@type": "AssignmentStatement",
                                          "mandatory": true,
                                          "assignment": {
                                            "lhs": {
                                              "@type": "declare",
                                              "dataType": "text",
                                              "dataValue": "overdue_ccglacc_result"
                                            },
                                            "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "Reject"
                                            },
                                            "operator": {
                                              "actualValue": "="
                                            }
                                          }
                                        }
                                      ],
                                      "jsonIgnoreProperty": false
                                    },
                                    "condition": {
                                      "type": "and",
                                      "@type": "logical",
                                      "rules": [
                                        {
                                          "lhs": {
                                            "@type": "local",
                                            "dataType": "number",
                                            "dataValue": "acc_age"
                                          },
                                          "rhs": {
                                            "@type": "literal",
                                            "dataType": "number",
                                            "dataValue": 12
                                          },
                                          "@type": "relational",
                                          "operator": {
                                            "actualValue": "<="
                                          }
                                        },
                                        {
                                          "lhs": {
                                            "@type": "local",
                                            "dataType": "number",
                                            "dataValue": "overdue_amt"
                                          },
                                          "rhs": {
                                            "@type": "literal",
                                            "dataType": "number",
                                            "dataValue": 5000
                                          },
                                          "@type": "relational",
                                          "operator": {
                                            "actualValue": ">"
                                          }
                                        }
                                      ]
                                    },
                                    "mandatory": true
                                  }
                                ],
                                "jsonIgnoreProperty": false,
                                "jsonIgnoreAliasValue": null
                              }
                            },
                            "format": "iterate"
                          },
                          "functionLabelName": "Iterate each element"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    }
                  ],
                  "jsonIgnoreProperty": false
                },
                "mandatory": true
              },
              {
                "id": 1729751428832163,
                "name": "Cibil Score Validation Rule",
                "@type": "SectionalStatement",
                "section": {
                  "id": 718279110275639,
                  "name": "Cibil Score Validation Rule",
                  "statements": [
                    {
                      "id": 1729751428183618,
                      "name": "BeamLuck",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "number",
                          "dataValue": "cibil_score"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "dataType": "number",
                          "dataValue": "text",
                          "keywordArguments": {
                            "init": {
                              "value": "CNS-QUAD-MERGE-REPORT.REPORT-SEGMENT.CREDIT-SCORES.CREDIT-SCORE.SCORE"
                            },
                            "format": "toNumber"
                          },
                          "functionLabelName": "Convert text to number"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729751680692012,
                      "name": "Cibil score Rule",
                      "@type": "ConditionalStatement",
                      "failure": {
                        "id": 785311813967399,
                        "name": "FlightHead",
                        "statements": [
                          {
                            "id": 1729751712803947,
                            "name": "FirmRanch",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "declare",
                                "dataType": "text",
                                "dataValue": "cibil_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Approve"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ],
                        "jsonIgnoreProperty": false
                      },
                      "success": {
                        "id": 581747487166414,
                        "name": "TopFish",
                        "statements": [
                          {
                            "id": 1729751756162807,
                            "name": "DearForm",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "declare",
                                "dataType": "text",
                                "dataValue": "cibil_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Reject"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ],
                        "jsonIgnoreProperty": false
                      },
                      "condition": {
                        "type": "or",
                        "@type": "logical",
                        "rules": [
                          {
                            "lhs": {
                              "@type": "local",
                              "dataType": "number",
                              "dataValue": "cibil_score"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "number",
                              "dataValue": 700
                            },
                            "@type": "relational",
                            "operator": {
                              "actualValue": "<"
                            }
                          },
                          {
                            "lhs": {
                              "@type": "local",
                              "dataType": "number",
                              "dataValue": "cibil_score"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "number",
                              "dataValue": 0
                            },
                            "@type": "relational",
                            "operator": {
                              "actualValue": "=="
                            }
                          },
                          {
                            "lhs": {
                              "@type": "local",
                              "dataType": "number",
                              "dataValue": "cibil_score"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "number",
                              "dataValue": -1
                            },
                            "@type": "relational",
                            "operator": {
                              "actualValue": "=="
                            }
                          }
                        ]
                      },
                      "mandatory": true
                    }
                  ],
                  "jsonIgnoreProperty": false
                },
                "mandatory": true
              },
              {
                "id": 1729752100602550,
                "name": "Employee Type Validation",
                "@type": "SectionalStatement",
                "section": {
                  "id": 160165469808850,
                  "name": "Employee Type Validation",
                  "statements": [
                    {
                      "id": 1729752136844243,
                      "name": "OddReach",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "text",
                          "dataValue": "employee_type"
                        },
                        "rhs": {
                          "@type": "variable",
                          "dataType": "text",
                          "dataValue": "CUSTOMER.EMPTYPE"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729752117089609,
                      "name": "Emp type Rule",
                      "@type": "ConditionalStatement",
                      "failure": {
                        "id": 273341714721562,
                        "name": "GrossThigh",
                        "statements": [
                          {
                            "id": 1729752177119242,
                            "name": "GreatStrength",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "declare",
                                "dataType": "text",
                                "dataValue": "emp_type_rule_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Reject"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ],
                        "jsonIgnoreProperty": false
                      },
                      "success": {
                        "id": 925533360868340,
                        "name": "TrunkPlan",
                        "statements": [
                          {
                            "id": 1729752165974433,
                            "name": "TallTrace",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "declare",
                                "dataType": "text",
                                "dataValue": "emp_type_rule_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Approve"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ],
                        "jsonIgnoreProperty": false
                      },
                      "condition": {
                        "type": "or",
                        "@type": "logical",
                        "rules": [
                          {
                            "lhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "employee_type"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "Salaried"
                            },
                            "@type": "relational",
                            "operator": {
                              "actualValue": "=="
                            }
                          },
                          {
                            "lhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "employee_type"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "Self Employed"
                            },
                            "@type": "relational",
                            "operator": {
                              "actualValue": "=="
                            }
                          }
                        ]
                      },
                      "mandatory": true
                    }
                  ],
                  "jsonIgnoreProperty": false
                },
                "mandatory": true
              },
              {
                "id": 1729752467805143,
                "name": "Overdue in Other Accounts Validation",
                "@type": "SectionalStatement",
                "section": {
                  "id": 822978926579399,
                  "name": "Overdue in Other Accounts Validation",
                  "statements": [
                    {
                      "id": 1729752440546248,
                      "name": "ColdStore",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "text",
                          "dataValue": "overdue_other_acc_result"
                        },
                        "rhs": {
                          "@type": "literal",
                          "dataType": "text",
                          "dataValue": "Approve"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729752564009843,
                      "name": "DearDose",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "text",
                          "dataValue": "overdue_amt"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "filter": {
                            "id": 1729752617877845,
                            "name": "Add Filter",
                            "condition": {
                              "type": "and",
                              "@type": "logical",
                              "rules": [
                                {
                                  "lhs": {
                                    "@type": "literal",
                                    "dataType": "text",
                                    "dataValue": "ACCOUNT-INFOS.ACCOUNT-INFO.OWNERSHIP-IND"
                                  },
                                  "rhs": {
                                    "@type": "literal",
                                    "dataType": "text",
                                    "dataValue": "Guarantor"
                                  },
                                  "@type": "relational",
                                  "operator": {
                                    "actualValue": "!="
                                  }
                                }
                              ]
                            }
                          },
                          "dataType": "list",
                          "dataValue": "list",
                          "keywordArguments": {
                            "init": {
                              "break": {
                                "type": "and",
                                "@type": "logical",
                                "rules": [
                                  {
                                    "lhs": {
                                      "@type": "local",
                                      "dataType": "text",
                                      "dataValue": "overdue_other_acc_result"
                                    },
                                    "rhs": {
                                      "@type": "literal",
                                      "dataType": "text",
                                      "dataValue": "Reject"
                                    },
                                    "@type": "relational",
                                    "operator": {
                                      "actualValue": "=="
                                    }
                                  }
                                ]
                              },
                              "value": "CNS-QUAD-MERGE-REPORT.REPORT-SEGMENT.ACCOUNT-HISTORIES.ACCOUNT-HISTORY",
                              "transform": {
                                "id": "146739172349071",
                                "name": "Iterate 731218",
                                "statements": [
                                  {
                                    "id": 1729752778542857,
                                    "name": "DriedBlack",
                                    "@type": "AssignmentStatement",
                                    "mandatory": true,
                                    "assignment": {
                                      "lhs": {
                                        "@type": "declare",
                                        "dataType": "number",
                                        "dataValue": "current_date"
                                      },
                                      "rhs": {
                                        "@type": "keyword",
                                        "dataType": "date",
                                        "dataValue": "date",
                                        "keywordArguments": {
                                          "format": "dd-MM-yyyy"
                                        },
                                        "functionLabelName": "DD-MM-YYYY (31-12-1998)"
                                      },
                                      "operator": {
                                        "actualValue": "="
                                      }
                                    }
                                  },
                                  {
                                    "id": 1729753037803459,
                                    "name": "PackCloth",
                                    "@type": "AssignmentStatement",
                                    "mandatory": true,
                                    "assignment": {
                                      "lhs": {
                                        "@type": "declare",
                                        "dataType": "date",
                                        "dataValue": "date_reported"
                                      },
                                      "rhs": {
                                        "@type": "variable",
                                        "dataType": "date",
                                        "dataValue": "ACCOUNT-INFOS.ACCOUNT-INFO.DATE-REPORTED"
                                      },
                                      "operator": {
                                        "actualValue": "="
                                      }
                                    }
                                  },
                                  {
                                    "id": 1729753078831052,
                                    "name": "LampSlot",
                                    "@type": "AssignmentStatement",
                                    "mandatory": true,
                                    "assignment": {
                                      "lhs": {
                                        "@type": "declare",
                                        "dataType": "number",
                                        "dataValue": "acc_age"
                                      },
                                      "rhs": {
                                        "@type": "keyword",
                                        "dataType": "date",
                                        "dataValue": "date",
                                        "keywordArguments": {
                                          "init": {
                                            "end": {
                                              "value": "date_reported@local",
                                              "format": "dd-MM-yyyy"
                                            },
                                            "start": {
                                              "value": "current_date@local",
                                              "format": "dd-MM-yyyy"
                                            }
                                          },
                                          "type": "months",
                                          "format": "dateDiff"
                                        },
                                        "functionLabelName": "Difference between two dates"
                                      },
                                      "operator": {
                                        "actualValue": "="
                                      }
                                    }
                                  },
                                  {
                                    "id": 1729753143488511,
                                    "name": "Overdue_othacc_rule",
                                    "@type": "ConditionalStatement",
                                    "failure": {
                                      "id": 0,
                                      "name": "TourFate"
                                    },
                                    "success": {
                                      "id": 981358183234345,
                                      "name": "GoodSort",
                                      "statements": [
                                        {
                                          "id": 1729753202039390,
                                          "name": "OddAisle",
                                          "@type": "AssignmentStatement",
                                          "mandatory": true,
                                          "assignment": {
                                            "lhs": {
                                              "@type": "declare",
                                              "dataType": "text",
                                              "dataValue": "overdue_other_acc_result"
                                            },
                                            "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "Reject"
                                            },
                                            "operator": {
                                              "actualValue": "="
                                            }
                                          }
                                        }
                                      ],
                                      "jsonIgnoreProperty": false
                                    },
                                    "condition": {
                                      "type": "and",
                                      "@type": "logical",
                                      "rules": [
                                        {
                                          "lhs": {
                                            "@type": "local",
                                            "dataType": "number",
                                            "dataValue": "acc_age"
                                          },
                                          "rhs": {
                                            "@type": "literal",
                                            "dataType": "number",
                                            "dataValue": 12
                                          },
                                          "@type": "relational",
                                          "operator": {
                                            "actualValue": "<="
                                          }
                                        },
                                        {
                                          "lhs": {
                                            "@type": "variable",
                                            "dataType": "text",
                                            "dataValue": "AMOUNTS.AMOUNT.AMOUNT-OVERDUE"
                                          },
                                          "rhs": {
                                            "@type": "keyword",
                                            "dataType": "text",
                                            "dataValue": "text",
                                            "keywordArguments": {},
                                            "functionLabelName": ""
                                          },
                                          "@type": "relational",
                                          "operator": {
                                            "actualValue": "!="
                                          }
                                        },
                                        {
                                          "lhs": {
                                            "@type": "keyword",
                                            "dataType": "number",
                                            "dataValue": "text",
                                            "keywordArguments": {
                                              "init": {
                                                "value": "AMOUNTS.AMOUNT.AMOUNT-OVERDUE"
                                              },
                                              "format": "toNumber"
                                            },
                                            "functionLabelName": "Convert text to number"
                                          },
                                          "rhs": {
                                            "@type": "literal",
                                            "dataType": "number",
                                            "dataValue": 1000
                                          },
                                          "@type": "relational",
                                          "operator": {
                                            "actualValue": ">"
                                          }
                                        }
                                      ]
                                    },
                                    "mandatory": true
                                  }
                                ],
                                "jsonIgnoreProperty": false,
                                "jsonIgnoreAliasValue": null
                              }
                            },
                            "format": "iterate"
                          },
                          "functionLabelName": "Iterate each element"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    }
                  ],
                  "jsonIgnoreProperty": false
                },
                "mandatory": true
              },
              {
                "id": 1729753347979994,
                "name": "Min Age Validation",
                "@type": "SectionalStatement",
                "section": {
                  "id": 926365372082885,
                  "name": "Min Age Validation",
                  "statements": [
                    {
                      "id": 1729753421964525,
                      "name": "BushFile",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "date",
                          "dataValue": "current_date"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "dataType": "date",
                          "dataValue": "date",
                          "keywordArguments": {
                            "format": "yyyy-MM-dd"
                          },
                          "functionLabelName": "YYYY-MM-DD (1998-12-31)"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729753386853586,
                      "name": "KindCrew",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "date",
                          "dataValue": "date_of_birth"
                        },
                        "rhs": {
                          "@type": "variable",
                          "dataType": "date",
                          "dataValue": "CUSTOMER.DOB"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729753460646863,
                      "name": "WarmCore",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "number",
                          "dataValue": "age_of_applicant"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "dataType": "date",
                          "dataValue": "date",
                          "keywordArguments": {
                            "init": {
                              "end": {
                                "value": "date_of_birth@local",
                                "format": "yyyy-MM-dd"
                              },
                              "start": {
                                "value": "current_date@local",
                                "format": "yyyy-MM-dd"
                              }
                            },
                            "type": "years",
                            "format": "dateDiff"
                          },
                          "functionLabelName": "Difference between two dates"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729753555122442,
                      "name": "TreeScene",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "text",
                          "dataValue": "min_age_result"
                        },
                        "rhs": {
                          "@type": "literal",
                          "dataType": "text",
                          "dataValue": "Approve"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729753646979499,
                      "name": "Min age rule",
                      "@type": "ConditionalStatement",
                      "failure": {
                        "id": 0,
                        "name": "StrongNet"
                      },
                      "success": {
                        "id": 346089429133018,
                        "name": "ToughDeck",
                        "statements": [
                          {
                            "id": 1729753567297500,
                            "name": "FunCost",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "declare",
                                "dataType": "text",
                                "dataValue": "min_age_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Reject"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ],
                        "jsonIgnoreProperty": false
                      },
                      "condition": {
                        "type": "and",
                        "@type": "logical",
                        "rules": [
                          {
                            "lhs": {
                              "@type": "local",
                              "dataType": "number",
                              "dataValue": "age_of_applicant"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "number",
                              "dataValue": 21
                            },
                            "@type": "relational",
                            "operator": {
                              "actualValue": "<"
                            }
                          }
                        ]
                      },
                      "mandatory": true
                    }
                  ],
                  "jsonIgnoreProperty": false
                },
                "mandatory": true
              },
              {
                "id": 1729755036572236,
                "name": "Bureau Surrogate Rules",
                "@type": "SectionalStatement",
                "section": {
                  "id": 353882911303220,
                  "name": "Bureau Surrogate Rules",
                  "statements": [
                    {
                      "id": 1729765750602059,
                      "name": "Bureau age rule",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 637425585145982,
                        "name": "Bureau age rule",
                        "statements": [
                          {
                            "id": 1729765789244812,
                            "name": "BellChill",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "declare",
                                "dataType": "number",
                                "dataValue": "ab"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "number",
                                "dataValue": 0
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          },
                          {
                            "id": 1729765807587850,
                            "name": "MadSilk",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "declare",
                                "dataType": "text",
                                "dataValue": "aaaaaa"
                              },
                              "rhs": {
                                "@type": "keyword",
                                "dataType": "list",
                                "dataValue": "list",
                                "keywordArguments": {
                                  "init": {
                                    "break": {
                                      "type": "and",
                                      "@type": "logical",
                                      "rules": [
                                        {
                                          "lhs": {
                                            "@type": "local",
                                            "dataType": "number",
                                            "dataValue": "ab"
                                          },
                                          "rhs": {
                                            "@type": "literal",
                                            "dataType": "number",
                                            "dataValue": 12
                                          },
                                          "@type": "relational",
                                          "operator": {
                                            "actualValue": ">"
                                          }
                                        }
                                      ]
                                    },
                                    "value": "aaaa",
                                    "transform": {
                                      "id": "249616222289536",
                                      "name": "Iterate 438884",
                                      "statements": [
                                        {
                                          "id": 1729765993570735,
                                          "name": "WetGene",
                                          "@type": "AssignmentStatement",
                                          "mandatory": true,
                                          "assignment": {
                                            "lhs": {
                                              "@type": "declare",
                                              "dataType": "number",
                                              "dataValue": "age"
                                            },
                                            "rhs": {
                                              "@type": "keyword",
                                              "dataType": "date",
                                              "dataValue": "date",
                                              "keywordArguments": {
                                                "init": {
                                                  "end": {
                                                    "value": "aa",
                                                    "format": "yyyy-MM-dd"
                                                  },
                                                  "start": {
                                                    "value": "aa",
                                                    "format": "yyyy-MM-dd"
                                                  }
                                                },
                                                "type": "months",
                                                "format": "dateDiff"
                                              },
                                              "functionLabelName": "Difference between two dates"
                                            },
                                            "operator": {
                                              "actualValue": "="
                                            }
                                          }
                                        },
                                        {
                                          "id": 1729766039265487,
                                          "name": "DustFog",
                                          "@type": "ConditionalStatement",
                                          "failure": {
                                            "id": 0,
                                            "name": "KingRoot"
                                          },
                                          "success": {
                                            "id": 746243133854693,
                                            "name": "RightAisle",
                                            "statements": [
                                              {
                                                "id": 1729766077593670,
                                                "name": "WrongYouth",
                                                "@type": "AssignmentStatement",
                                                "mandatory": true,
                                                "assignment": {
                                                  "lhs": {
                                                    "@type": "declare",
                                                    "dataType": "number",
                                                    "dataValue": "ab"
                                                  },
                                                  "rhs": {
                                                    "@type": "local",
                                                    "dataType": "number",
                                                    "dataValue": "age"
                                                  },
                                                  "operator": {
                                                    "actualValue": "="
                                                  }
                                                }
                                              }
                                            ],
                                            "jsonIgnoreProperty": false
                                          },
                                          "condition": {
                                            "type": "and",
                                            "@type": "logical",
                                            "rules": [
                                              {
                                                "lhs": {
                                                  "@type": "local",
                                                  "dataType": "number",
                                                  "dataValue": "age"
                                                },
                                                "rhs": {
                                                  "@type": "local",
                                                  "dataType": "number",
                                                  "dataValue": "ab"
                                                },
                                                "@type": "relational",
                                                "operator": {
                                                  "actualValue": ">"
                                                }
                                              }
                                            ]
                                          },
                                          "mandatory": true
                                        }
                                      ],
                                      "jsonIgnoreProperty": false,
                                      "jsonIgnoreAliasValue": null
                                    }
                                  },
                                  "format": "iterate"
                                },
                                "functionLabelName": "Iterate each element"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ],
                        "jsonIgnoreProperty": false
                      },
                      "mandatory": true
                    }
                  ],
                  "jsonIgnoreProperty": false
                },
                "mandatory": true
              },
              {
                "id": 1729754615103895,
                "name": "Bureau Surg Rule Group",
                "@type": "SectionalStatement",
                "section": {
                  "id": 519026852724834,
                  "name": "Bureau Surg Rule Group",
                  "statements": [
                    {
                      "id": 1729754744863637,
                      "name": "Rule Group 1",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 674131133517642,
                        "name": "Rule Group 1",
                        "statements": [
                          {
                            "id": 1729754839606721,
                            "name": "GreenSpeed",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "min_age_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "min_age_result"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          },
                          {
                            "id": 1729754819236836,
                            "name": "LongNose",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "overdue_other_acc_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "overdue_other_acc_result"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          },
                          {
                            "id": 1729754894468681,
                            "name": "TeaSeal",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "emp_type_rule_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "emp_type_rule_result"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          },
                          {
                            "id": 1729754867751683,
                            "name": "DoubtLife",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "cibil_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "cibil_result"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          },
                          {
                            "id": 1729754894098665,
                            "name": "BigPant",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "overdue_ccglacc_result"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "overdue_ccglacc_result"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ],
                        "jsonIgnoreProperty": false
                      },
                      "mandatory": true
                    },
                    {
                      "id": 1729764990952143,
                      "name": "ChipMove",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "date",
                          "dataValue": "xyz"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "dataType": "date",
                          "dataValue": "date",
                          "keywordArguments": {
                            "format": "dd-MM-yyyy"
                          },
                          "functionLabelName": "DD-MM-YYYY (31-12-1998)"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729765066077270,
                      "name": "TrueQuest",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "date",
                          "dataValue": "xyz"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "dataType": "date",
                          "dataValue": "date",
                          "keywordArguments": {
                            "init": {
                              "value": "xyz@local",
                              "format": "dd-MM-yyyy"
                            },
                            "type": "year",
                            "value": "-1",
                            "format": "dd-MM-yyyy"
                          },
                          "functionLabelName": "DD-MM-YYYY (31-12-1998)"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729764693470777,
                      "name": "SteelBridge",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "list",
                          "dataValue": "dateee"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "filter": {
                            "id": 1729764655029844,
                            "name": "Add Filter",
                            "condition": {
                              "type": "and",
                              "@type": "logical",
                              "rules": [
                                {
                                  "lhs": {
                                    "@type": "variable",
                                    "dataType": "date",
                                    "dataValue": "d"
                                  },
                                  "rhs": {
                                    "@type": "local",
                                    "dataType": "date",
                                    "dataValue": "xyz"
                                  },
                                  "@type": "relational",
                                  "operator": {
                                    "actualValue": "<="
                                  }
                                }
                              ]
                            }
                          },
                          "dataType": "number",
                          "dataValue": "list",
                          "keywordArguments": {
                            "init": {
                              "value": "a.b.c"
                            },
                            "format": "min"
                          },
                          "functionLabelName": "Get lowest value from the list"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    },
                    {
                      "id": 1729764911594647,
                      "name": "ParkRight",
                      "@type": "AssignmentStatement",
                      "mandatory": true,
                      "assignment": {
                        "lhs": {
                          "@type": "declare",
                          "dataType": "number",
                          "dataValue": "number"
                        },
                        "rhs": {
                          "@type": "keyword",
                          "dataType": "number",
                          "dataValue": "list",
                          "keywordArguments": {
                            "init": {
                              "value": "dateee@local"
                            },
                            "format": "length"
                          },
                          "functionLabelName": "Calculate list length"
                        },
                        "operator": {
                          "actualValue": "="
                        }
                      }
                    }
                  ],
                  "jsonIgnoreProperty": false
                },
                "mandatory": true
              }
            ],
            "jsonIgnoreProperty": false
          },
          "mandatory": true
        }
      ],
      "jsonIgnoreProperty": false
    },
    "contentInputType": "json",
    "ignoreNullFields": false,
    "contentOutputType": "json"
  }`

const PanicErrorRecovery = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "contentOutputType": "json",
    "errors": {
        "id": 884602368828668,
        "name": "ErrorStatement",
        "statements": [
            {
                "id": 893594662210874,
                "name": "STATEMENT 889025713857323",
                "@type": "SectionalStatement",
                "section": {
                    "id": 889029890352177,
                    "name": "SECTION Statement 889029890352177",
                    "statements": [
                        {
                            "id": "1738074912325932",
                            "name": "TAKING MAX OF INDIVIDUAL AND JOINT HL LAP SANCTION AMOUNT",
                            "@type": "ConditionalStatement",
                            "toogleSwitchValue": false,
                            "condition": {
                                "@type": "logical",
                                "type": "and",
                                "rules": [
                                    {
                                        "@type": "relational",
                                        "rhs": {
                                            "@type": "keyword",
                                            "dataType": "text",
                                            "dataValue": "statementId"
                                        },
                                        "operator": {
                                            "actualValue": "contains"
                                        },
                                        "lhs": {
                                            "@type": "keyword",
                                            "dataType": "list",
                                            "dataValue": "list",
                                            "keywordArguments": {
                                                "format": "allStatements"
                                            }
                                        }
                                    }
                                ]
                            },
                            "mandatory": true,
                            "success": {
                                "id": "110544194608133",
                                "name": "IllSport",
                                "statements": [
                                    {
                                        "id": "1",
                                        "@type": "AssignmentStatement",
                                        "assignment": {
                                            "lhs": {
                                                "@type": "literal",
                                                "dataType": "text",
                                                "dataValue": "jsonErrors"
                                            },
                                            "operator": {
                                                "actualValue": "="
                                            },
                                            "rhs": {
                                                "@type": "local",
                                                "dataType": "text",
                                                "dataValue": "currentError.detailedMessage"
                                            }
                                        }
                                    }
                                ]
                            },
                            "failure": {
                                "id": "300643007463504",
                                "name": "FaithPad"
                            }
                        }
                    ],
                    "jsonIgnoreProperty": false
                },
                "mandatory": true
            }
        ],
        "jsonIgnoreProperty": false
    },
    "transform": {
        "jsonIgnoreAliasValue": "",
        "jsonIgnoreProperty": true,
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "1738074912325932",
                "name": "TAKING MAX OF INDIVIDUAL AND JOINT HL LAP SANCTION AMOUNT",
                "@type": "ConditionalStatement",
                "toogleSwitchValue": false,
                "condition": {
                    "@type": "logical",
                    "type": "and",
                    "rules": [
                        {
                            "@type": "expression",
                            "lhs": {
                                "@type": "keyword",
                                "dataValue": "list",
                                "dataType": "list"
                            },
                            "operator": {
                                "actualValue": "contains"
                            },
                            "rhs": {
                                "@type": "literal",
                                "dataValue": null,
                                "dataType": "text"
                            },
                            "dataType": "number"
                        }
                    ]
                },
                "mandatory": true,
                "success": {
                    "id": "110544194608133",
                    "name": "IllSport"
                },
                "failure": {
                    "id": "300643007463504",
                    "name": "FaithPad"
                }
            }
        ]
    }
}`
