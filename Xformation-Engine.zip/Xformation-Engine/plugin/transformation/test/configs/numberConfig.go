package configs 

const NumberFloorConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tanya",
        "statements" : [ {
          "id" : "790524995528359",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "floor",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Katrine"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "790523839306655"
      },
      "id" : "790524507544481"
    } ]
  }
}`

const NumberRoundWithDecimalConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Sheila",
        "statements" : [ {
          "id" : "792766505826930",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "roundWithDecimal",
                "value" : 2,
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Leon"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "792765855627243"
      },
      "id" : "792762957317520"
    } ]
  }
}`

const NumberGetDecimalConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ludie",
        "statements" : [ {
          "id" : "794131018847367",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getDecimal",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Vincenzo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "794131762922293"
      },
      "id" : "794134343532391"
    } ]
  }
}`

const LocalNumberCeilConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Wellington",
        "statements" : [ {
          "id" : "795597742848081",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "rate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "ceil",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Shanel"
        }, {
          "id" : "796009439596112",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "NumberCeilLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "rate@local",
              "dataType" : "text"
            }
          },
          "name" : "Myrna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "796002391050716"
      },
      "id" : "796003476290524"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const LocalNumberRoundConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ted",
        "statements" : [ {
          "id" : "797032165482870",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "rate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "round",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Alta"
        }, {
          "id" : "797707198064904",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "NumberRoundLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "rate@local",
              "dataType" : "text"
            }
          },
          "name" : "Leanna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "797707202086305"
      },
      "id" : "797705990236528"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const LocalNumberGetNonDecimalConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Dejah",
        "statements" : [ {
          "id" : "799042508023269",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "rate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getNonDecimal",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Lera"
        }, {
          "id" : "799345113644719",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "getNonDecimalLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "rate@local",
              "dataType" : "text"
            }
          },
          "name" : "Annetta"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "799347740438787"
      },
      "id" : "799341446548357"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const LocalNumberRoundWithDecimalConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Natalia",
        "statements" : [ {
          "id" : "799906626122470",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "rate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "roundWithDecimal",
                "value" : 2,
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Randi"
        }, {
          "id" : "800144287646512",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "roundWithDecimalLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "rate@local",
              "dataType" : "text"
            }
          },
          "name" : "Frieda"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "800141291803906"
      },
      "id" : "800145859797938"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const NumberGetNonDecimalConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Addison",
        "statements" : [ {
          "id" : "800708248271588",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getNonDecimal",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Maria"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "800701905739376"
      },
      "id" : "800702724441360"
    } ]
  }
}`

const NumberRoundConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Bart",
        "statements" : [ {
          "id" : "801292339841315",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "round",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Enid"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "801294023239543"
      },
      "id" : "801295431332752"
    } ]
  }
}`

const NumberCeilConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Dillan",
        "statements" : [ {
          "id" : "801853996308773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "ceil",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "William"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "801859233252336"
      },
      "id" : "801856996144715"
    } ]
  }
}`

const LocalNumberFloorConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Hunter",
        "statements" : [ {
          "id" : "802451538015384",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "rate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "floor",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Kraig"
        }, {
          "id" : "802832107745485",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "NumberFloorLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "rate@local",
              "dataType" : "text"
            }
          },
          "name" : "Isac"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "802835250865625"
      },
      "id" : "802831326651351"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const LocalNumberGetDecimalConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Howard",
        "statements" : [ {
          "id" : "803728346252971",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "rate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getDecimal",
                "init" : {
                  "value" : "rate"
                }
              }
            }
          },
          "name" : "Samir"
        }, {
          "id" : "804155646126357",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "getNonDecimalLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "rate@local",
              "dataType" : "text"
            }
          },
          "name" : "Jamil"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "804154056122736"
      },
      "id" : "804151610314395"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

