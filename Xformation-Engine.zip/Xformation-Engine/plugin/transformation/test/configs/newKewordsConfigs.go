package configs

const Iterate_With_Fields_Keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Esmeralda",
        "statements" : [ {
          "id" : "421765311988163",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "chart",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "iterate",
                "init" : {
                  "value" : "array",
                  "fields" : {
                    "score" : "rank",
                    "player" : "name"
                  }
                }
              }
            }
          },
          "name" : "Eula"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "421777337944566"
      },
      "id" : "421774291141420"
    } ]
  }
}`

const GenerateUUID_Keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jayme",
        "statements" : [ {
          "id" : "423593227207476",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "generateUUID",
                "init" : {
                  "type" : "numeric",
                  "size" : 16
                }
              }
            }
          },
          "name" : "Annetta"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "423597673948755"
      },
      "id" : "423591358698329"
    } ]
  }
}`

const Populate_Keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Zoe",
        "statements" : [ {
          "id" : "425561919125641",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "keyword",
              "dataValue" : "none",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "map",
              "keywordArguments" : {
                "format" : "populate",
                "init" : {
                  "fields" : {
                    "employee.name" : "fName",
                    "employee.age" : "userAge"
                  }
                }
              }
            }
          },
          "name" : "Rosa"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "425567990585808"
      },
      "id" : "425564057154919"
    } ]
  }
}`

const Avg_Keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Bettie",
        "statements" : [ {
          "id" : "426913055934304",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "avg",
                "init" : {
                  "value" : "array",
                  "aggregate" : "rank"
                }
              }
            }
          },
          "name" : "Shaylee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "426915255619765"
      },
      "id" : "426917528387065"
    } ]
  }
}`

const Max_keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Orval",
        "statements" : [ {
          "id" : "428719768295311",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "max",
                "init" : {
                  "value" : "array",
                  "aggregate" : "rank"
                }
              }
            }
          },
          "name" : "Kolby"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "428719555549274"
      },
      "id" : "428713727536718"
    } ]
  }
}`

const Chunk_keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Virginie",
        "statements" : [ {
          "id" : "429964143313861",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "chunk",
                "init" : {
                  "value" : "IDNumber",
                  "chunkby" : 3
                }
              }
            }
          },
          "name" : "Blanche"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "429965004507995"
      },
      "id" : "429963046801631"
    } ]
  }
}`

const Chunk_keyword_By_String = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Virginie",
        "statements" : [ {
          "id" : "429964143313861",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "chunk",
                "init" : {
                  "value" : "IDNumber",
                  "chunkby" : "3"
                }
              }
            }
          },
          "name" : "Blanche"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "429965004507995"
      },
      "id" : "429963046801631"
    } ]
  }
}`

const DateDiff_Keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Arlene",
        "statements" : [ {
          "id" : "431569662787560",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "dateDiff",
                "type" : "months",
                "init" : {
                  "start" : {
                    "value" : "first1",
                    "format" : "dd-MM-yyyy"
                  },
                  "end" : {
                    "value" : "second2",
                    "format" : "dd-MM-yyyy"
                  }
                }
              }
            }
          },
          "name" : "Jammie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "431568414438506"
      },
      "id" : "431563345487393"
    } ]
  }
}`

const Split_keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Maximillia",
        "statements" : [ {
          "id" : "432053472625161",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "split",
                "init" : {
                  "value" : "Address",
                  "splitby" : "/"
                }
              }
            }
          },
          "name" : "Arnold"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "432052918302573"
      },
      "id" : "432054611479361"
    } ]
  }
}`

const Count_keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Mina",
        "statements" : [ {
          "id" : "432458486717590",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "count",
                "init" : {
                  "value" : "array"
                }
              }
            }
          },
          "name" : "Ardith"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "432458830393400"
      },
      "id" : "432451565515585"
    } ]
  }
}`

const TextStatementID = `{
  "version" : 3.3,
  "debug" : false,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "json",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_employeeDetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Clementina",
        "statements" : [ {
          "id" : "433071916141502",
          "mandatory" : true,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "errors",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "errorfbuuas",
              "dataType" : "text"
            }
          },
          "name" : "Hunter"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "433071542569642"
      },
      "id" : "433073186240242"
    } ]
  },
  "errors" : {
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Marguerite",
        "statements" : [ {
          "condition" : {
            "@type" : "logical",
            "type" : "and",
            "rules" : [ {
              "@type" : "relational",
              "lhs" : {
                "@type" : "keyword",
                "dataType" : "text",
                "dataValue" : "statementId"
              },
              "operator" : {
                "actualValue" : "=="
              },
              "rhs" : {
                "@type" : "keyword",
                "dataType" : "text",
                "dataValue" : "statementId"
              }
            } ]
          },
          "@type" : "ConditionalStatement",
          "success" : {
            "name" : "transformation",
            "statements" : [ {
              "@type" : "SectionalStatement",
              "section" : {
                "jsonIgnoreProperty" : false,
                "name" : "Cleo",
                "statements" : [ {
                  "id" : "433796587042862",
                  "@type" : "AssignmentStatement",
                  "assignment" : {
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "statementId"
                    },
                    "operator" : {
                      "actualValue" : "="
                    },
                    "rhs" : {
                      "@type" : "keyword",
                      "dataType" : "text",
                      "dataValue" : "text",
                      "keywordArguments" : {
                        "format" : "statementId"
                      }
                    }
                  },
                  "name" : "Nicholaus"
                } ],
                "jsonIgnoreAliasValue" : null,
                "id" : "433797196613716"
              },
              "id" : "433798139472761"
            } ],
            "id" : "433798354364253"
          },
          "failure" : null,
          "id" : "exception1"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "433791476158511"
      },
      "id" : "433799723235296"
    } ]
  }
}`

const Concat_Keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Damaris",
        "statements" : [ {
          "id" : "434444352452829",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "concat",
                "init" : {
                  "value" : "fName",
                  "concatWith" : "-",
                  "values" : [ "mName", "lName" ]
                }
              }
            }
          },
          "name" : "Enid"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "434445916098661"
      },
      "id" : "434448009938927"
    } ]
  }
}`

const Iterate_With_Transform_Keyword_without_arrayName = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ewell",
        "statements" : [ {
          "id" : "435253848564733",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "chart",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "iterate",
                "init" : {
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "transform Consumer Communication Address Details",
                    "statements" : [ {
                      "id" : "1",
                      "@type" : "AssignmentStatement",
                      "assignment" : {
                        "@type" : "SimpleAssignmentStatement",
                        "lhs" : {
                          "@type" : "literal",
                          "dataValue" : "firstName",
                          "dataType" : "text"
                        },
                        "operator" : {
                          "actualValue" : "="
                        },
                        "rhs" : {
                          "@type" : "variable",
                          "dataValue" : "fName",
                          "dataType" : "text"
                        }
                      }
                    }, {
                      "id" : "1",
                      "@type" : "AssignmentStatement",
                      "assignment" : {
                        "@type" : "SimpleAssignmentStatement",
                        "lhs" : {
                          "@type" : "literal",
                          "dataValue" : "middleName",
                          "dataType" : "text"
                        },
                        "operator" : {
                          "actualValue" : "="
                        },
                        "rhs" : {
                          "@type" : "variable",
                          "dataValue" : "mName",
                          "dataType" : "text"
                        }
                      }
                    } ]
                  }
                }
              }
            }
          },
          "name" : "Ciara"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "435258710721351"
      },
      "id" : "435253043013977"
    } ]
  }
}`

const Sum_keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lucile",
        "statements" : [ {
          "id" : "436276371144287",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "sum",
                "init" : {
                  "value" : "array",
                  "aggregate" : "rank"
                }
              }
            }
          },
          "name" : "Johanna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "436277452539867"
      },
      "id" : "436279185235746"
    } ]
  }
}`

const Sum_keyword_Without_Aggregation = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lucile",
        "statements" : [ {
          "id" : "436276371144287",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "sum",
                "init" : {
                  "value" : "prim"
                }
              }
            }
          },
          "name" : "Johanna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "436277452539867"
      },
      "id" : "436279185235746"
    } ]
  }
}`

const Min_Keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Demarcus",
        "statements" : [ {
          "id" : "437223321252612",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "min",
                "init" : {
                  "value" : "array",
                  "aggregate" : "rank"
                }
              }
            }
          },
          "name" : "Princess"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "437223940876562"
      },
      "id" : "437225717557758"
    } ]
  }
}`

const TextGetNullValue = `{
  "version" : 3.3,
  "debug" : false,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "json",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_employeeDetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Cristina",
        "statements" : [ {
          "id" : "437715744004708",
          "mandatory" : true,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "format" : "getNullValue"
              }
            }
          },
          "name" : "Arjun"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "437716632880355"
      },
      "id" : "437717015938568"
    } ]
  }
}`

const IterateWithTransformFilter = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gust",
        "statements" : [ {
          "id" : "438311299178962",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "chart",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "filter" : {
                "id" : "filter_config_1",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "variable",
                      "dataType" : "number",
                      "dataValue" : "rank"
                    },
                    "operator" : {
                      "actualValue" : "<="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : 9,
                      "dataType" : "number"
                    }
                  } ]
                }
              },
              "keywordArguments" : {
                "format" : "iterate",
                "init" : {
                  "value" : "array",
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "transform Consumer Communication Address Details",
                    "statements" : [ {
                      "id" : "1",
                      "@type" : "AssignmentStatement",
                      "assignment" : {
                        "@type" : "SimpleAssignmentStatement",
                        "lhs" : {
                          "@type" : "literal",
                          "dataValue" : "player",
                          "dataType" : "text"
                        },
                        "operator" : {
                          "actualValue" : "="
                        },
                        "rhs" : {
                          "@type" : "variable",
                          "dataValue" : "name",
                          "dataType" : "text"
                        }
                      }
                    }, {
                      "id" : "1",
                      "@type" : "AssignmentStatement",
                      "assignment" : {
                        "@type" : "SimpleAssignmentStatement",
                        "lhs" : {
                          "@type" : "literal",
                          "dataValue" : "score",
                          "dataType" : "text"
                        },
                        "operator" : {
                          "actualValue" : "="
                        },
                        "rhs" : {
                          "@type" : "variable",
                          "dataValue" : "rank",
                          "dataType" : "text"
                        }
                      }
                    } ]
                  }
                }
              }
            }
          },
          "name" : "Holden"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "438319961817059"
      },
      "id" : "438311214346684"
    } ]
  }
}`

const Sum_with_filter_keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Torrance",
        "statements" : [ {
          "id" : "438888323547385",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "number",
              "filter" : {
                "id" : "filter_config_1",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "rank"
                    },
                    "operator" : {
                      "actualValue" : "<="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : 9,
                      "dataType" : "number"
                    }
                  } ]
                }
              },
              "keywordArguments" : {
                "format" : "sum",
                "init" : {
                  "value" : "array",
                  "aggregate" : "rank"
                }
              }
            }
          },
          "name" : "Margret"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "438883377154484"
      },
      "id" : "438882501293373"
    } ]
  }
}`

const Iterate_With_Transform_Keyword = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Haylie",
        "statements" : [ {
          "id" : "439433851364007",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "chart",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "iterate",
                "init" : {
                  "value" : "array",
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "transform Consumer Communication Address Details",
                    "statements" : [ {
                      "id" : "1",
                      "@type" : "AssignmentStatement",
                      "assignment" : {
                        "@type" : "SimpleAssignmentStatement",
                        "lhs" : {
                          "@type" : "literal",
                          "dataValue" : "player",
                          "dataType" : "text"
                        },
                        "operator" : {
                          "actualValue" : "="
                        },
                        "rhs" : {
                          "@type" : "variable",
                          "dataValue" : "name",
                          "dataType" : "text"
                        }
                      }
                    }, {
                      "id" : "1",
                      "@type" : "AssignmentStatement",
                      "assignment" : {
                        "@type" : "SimpleAssignmentStatement",
                        "lhs" : {
                          "@type" : "literal",
                          "dataValue" : "score",
                          "dataType" : "text"
                        },
                        "operator" : {
                          "actualValue" : "="
                        },
                        "rhs" : {
                          "@type" : "variable",
                          "dataValue" : "rank",
                          "dataType" : "text"
                        }
                      }
                    } ]
                  }
                }
              }
            }
          },
          "name" : "Wilbert"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "439431998376527"
      },
      "id" : "439434121126194"
    } ]
  }
}`

const TextAllStatementIds = `{
  "version": 3.3,
  "debug": false,
  "@type": "transform",
  "contentInputType": "json",
  "contentOutputType": "json",
  "transform": {
      "jsonIgnoreProperty": false,
      "id": "transform_employeeDetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Clementina",
                  "statements": [
                      {
                          "id": "433071916141502",
                          "mandatory": true,
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "errors",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "variable",
                                  "dataValue": "errorfbuuas",
                                  "dataType": "text"
                              }
                          },
                          "name": "Hunter"
                      },
                      {
                        "id": "433071989141502",
                        "mandatory": true,
                        "@type": "AssignmentStatement",
                        "assignment": {
                            "lhs": {
                                "@type": "literal",
                                "dataValue": "name",
                                "dataType": "text"
                            },
                            "operator": {
                                "actualValue": "="
                            },
                            "rhs": {
                                "@type": "literal",
                                "dataValue": "javed",
                                "dataType": "text"
                            }
                        },
                        "name": "Hunter"
                    },
                    {
                      "id": "12345674524123",
                      "mandatory": true,
                      "@type": "AssignmentStatement",
                      "assignment": {
                          "lhs": {
                              "@type": "literal",
                              "dataValue": "age",
                              "dataType": "text"
                          },
                          "operator": {
                              "actualValue": "="
                          },
                          "rhs": {
                              "@type": "variable",
                              "dataValue": "javed",
                              "dataType": "text"
                          }
                      },
                      "name": "Hunter"
                  }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "433071542569642"
              },
              "id": "433073186240242"
          }
      ]
  },
  "errors": {
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Marguerite",
                  "statements": [
                      {
                          "condition": {
                              "@type": "logical",
                              "type": "and",
                              "rules": [
                                  {
                                      "@type": "relational",
                                      "rhs": {
                                          "@type": "keyword",
                                          "dataType": "text",
                                          "dataValue": "statementId"
                                      },
                                      "operator": {
                                          "actualValue": "contains"
                                      },
                                      "lhs":  {
                                        "@type": "keyword",
                                        "dataType": "list",
                                        "dataValue": "list",
                                        "keywordArguments": {
                                            "format": "allStatements"
                                        }
                                    }
                                  }
                              ]
                          },
                          "@type": "ConditionalStatement",
                          "success": {
                              "name": "transformation",
                              "statements": [
                                  {
                                      "@type": "SectionalStatement",
                                      "section": {
                                          "jsonIgnoreProperty": false,
                                          "name": "Cleo",
                                          "statements": [
                                              {
                                                  "id": "433796587042862",
                                                  "@type": "AssignmentStatement",
                                                  "assignment": {
                                                      "lhs": {
                                                          "@type": "literal",
                                                          "dataType": "text",
                                                          "dataValue": "status"
                                                      },
                                                      "operator": {
                                                          "actualValue": "="
                                                      },
                                                      "rhs": {
                                                        "@type": "literal",
                                                        "dataType": "text",
                                                        "dataValue": "exception resolved"
                                                    }
                                                  },
                                                  "name": "Nicholaus"
                                              }
                                          ],
                                          "jsonIgnoreAliasValue": null,
                                          "id": "433797196613716"
                                      },
                                      "id": "433798139472761"
                                  }
                              ],
                              "id": "433798354364253"
                          },
                          "failure": null,
                          "id": "exception1"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "433791476158511"
              },
              "id": "433799723235296"
          }
      ]
  }
}`

const DateDiffInDays = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Arlene",
        "statements" : [ {
          "id" : "431569662787560",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "dateDiff",
                "type" : "days",
                "init" : {
                  "start" : {
                    "value" : "first1",
                    "format" : "dd-MM-yyyy"
                  },
                  "end" : {
                    "value" : "second2",
                    "format" : "dd-MM-yyyy"
                  }
                }
              }
            }
          },
          "name" : "Jammie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "431568414438506"
      },
      "id" : "431563345487393"
    } ]
  }
}`

const Exponentiation = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "147293709782404",
              "@type": "AssignmentStatement",
              "assignment": {
                  "@type": "SimpleAssignmentStatement",
                  "lhs": {
                      "@type": "literal",
                      "dataValue": "exponentiation",
                      "dataType": "number"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "expression",
                      "structure": {
                          "@type": "arithmetic",
                          "dataType": "^",
                          "variables": [
                              {
                                  "@type": "literal",
                                  "dataType": "number",
                                  "dataValue": 2
                              },
                              {
                                  "@type": "literal",
                                  "dataType": "number",
                                  "dataValue": 2
                              },
                              {
                                "@type": "literal",
                                "dataType": "number",
                                "dataValue": 2
                            }
                          ]
                      },
                      "dataType": "number"
                  }
              },
              "name": "Felicia"
          }
      ]
  }
}`

const Modulas = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "147293709782404",
              "@type": "AssignmentStatement",
              "assignment": {
                  "@type": "SimpleAssignmentStatement",
                  "lhs": {
                      "@type": "literal",
                      "dataValue": "modulas",
                      "dataType": "number"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "expression",
                      "structure": {
                          "@type": "arithmetic",
                          "dataType": "%",
                          "variables": [
                              {
                                  "@type": "literal",
                                  "dataType": "number",
                                  "dataValue": 24
                              },
                              {
                                  "@type": "literal",
                                  "dataType": "number",
                                  "dataValue": 5
                              }
                          ]
                      },
                      "dataType": "number"
                  }
              },
              "name": "Felicia"
          }
      ]
  }
}`

const Split_keyword_With_Suffix = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Maximillia",
        "statements" : [ {
          "id" : "432053472625161",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "splitList",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "split",
                "init" : {
                  "value" : "someVal",
                  "splitby" : "/"
                }
              }
            }
          },
          "name" : "Arnold"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "432052918302573"
      },
      "id" : "432054611479361"
    } ]
  }
}`

const EnvironmentVariables = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "@type": "SectionalStatement",
                "section": {
                    "jsonIgnoreProperty": false,
                    "name": "Maximillia",
                    "statements": [
                        {
                            "id": "432053472625161",
                            "@type": "AssignmentStatement",
                            "assignment": {
                                "@type": "SimpleAssignmentStatement",
                                "lhs": {
                                    "@type": "literal",
                                    "dataValue": "name",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "="
                                },
                                "rhs": {
                                    "@type": "environment",
                                    "dataValue": "Mohd Javed Pasha",
                                    "dataType": "text"
                                }
                            },
                            "name": "Arnold"
                        }
                    ],
                    "jsonIgnoreAliasValue": null,
                    "id": "432052918302573"
                },
                "id": "432054611479361"
            }
        ]
    }
}`
