package configs

const TextToNumberIntegerConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Bria",
        "statements" : [ {
          "id" : "935659513067487",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Number",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toNumber",
                "init" : {
                  "value" : "mobile1"
                }
              }
            }
          },
          "name" : "Elliott"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "935656440779917"
      },
      "id" : "935651835359811"
    } ]
  }
}`

const TextToNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Stacey",
        "statements" : [ {
          "id" : "939086894859055",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Number",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toNumber",
                "init" : {
                  "value" : "mobile"
                }
              }
            }
          },
          "name" : "Amari"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "939083450067940"
      },
      "id" : "939084961078846"
    } ]
  }
}`

const TextToNumberLocalConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lucienne",
        "statements" : [ {
          "id" : "941131587838642",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "experience1",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toNumber",
                "init" : {
                  "value" : "experience1"
                }
              }
            }
          },
          "name" : "Patricia"
        }, {
          "id" : "942001905859003",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Experience",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "inMonths",
                "init" : {
                  "value" : "experience1@local",
                  "format" : "inYears"
                }
              }
            }
          },
          "name" : "Tania"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "942004554162311"
      },
      "id" : "942009773991291"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

