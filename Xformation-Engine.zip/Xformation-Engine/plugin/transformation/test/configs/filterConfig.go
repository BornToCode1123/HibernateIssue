package configs

const ListOfEmployees = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "transform": {
        "id": "transform_custodetails",
        "jsonIgnoreProperty": "false",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": 1729669920415592,
                "name": "BidBall",
                "@type": "AssignmentStatement",
                "mandatory": true,
                "assignment": {
                    "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "HighSalariedEmployees"
                    },
                    "rhs": {
                        "@type": "keyword",
                        "filter": {
                            "id": 1729669913449410,
                            "name": "Add Filter",
                            "condition": {
                                "type": "and",
                                "@type": "logical",
                                "rules": [
                                    {
                                        "lhs": {
                                            "@type": "variable",
                                            "dataType": "number",
                                            "dataValue": "salary"
                                        },
                                        "rhs": {
                                            "@type": "literal",
                                            "dataType": "number",
                                            "dataValue": 1000000
                                        },
                                        "@type": "relational",
                                        "operator": {
                                            "actualValue": ">="
                                        }
                                    }
                                ]
                            }
                        },
                        "dataType": "list",
                        "dataValue": "list",
                        "keywordArguments": {
                            "init": {
                                "value": "employeesDetails",
                                "transform": {
                                    "id": "210499190416143",
                                    "name": "Iterate 709052",
                                    "statements": [
                                        {
                                            "id": 1729670245692172,
                                            "name": "LabTale",
                                            "@type": "AssignmentStatement",
                                            "mandatory": true,
                                            "assignment": {
                                                "lhs": {
                                                    "@type": "keyword",
                                                    "dataType": "map",
                                                    "dataValue": "none"
                                                },
                                                "rhs": {
                                                    "@type": "keyword",
                                                    "dataType": "map",
                                                    "dataValue": "value"
                                                },
                                                "operator": {
                                                    "actualValue": "="
                                                }
                                            }
                                        }
                                    ],
                                    "jsonIgnoreProperty": false,
                                    "jsonIgnoreAliasValue": null
                                }
                            },
                            "format": "iterate"
                        },
                        "functionLabelName": "Iterate each element"
                    },
                    "operator": {
                        "actualValue": "="
                    }
                }
            }
        ]
    }
}`

const ListOfEmployeesFilteringBasedOnMultiplerules = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "transform": {
        "id": "transform_custodetails",
        "jsonIgnoreProperty": "false",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": 1729669920415592,
                "name": "BidBall",
                "@type": "AssignmentStatement",
                "mandatory": true,
                "assignment": {
                    "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "HighSalariedEmployees"
                    },
                    "rhs": {
                        "@type": "keyword",
                        "filter": {
                            "id": 1729669913449410,
                            "name": "Add Filter",
                            "condition": {
                                "type": "and",
                                "@type": "logical",
                                "rules": [
                                    {
                                        "@type": "logical",
                                        "type": "and",
                                        "rules": [
                                            {
                                                "@type": "logical",
                                                "type": "and",
                                                "rules": [
                                                    {
                                                        "@type": "relational",
                                                        "lhs": {
                                                            "@type": "variable",
                                                            "dataType": "text",
                                                            "dataValue": "city"
                                                        },
                                                        "rhs": {
                                                            "@type": "literal",
                                                            "dataType": "text",
                                                            "dataValue": "Hyderabad"
                                                        },
                                                        "operator": {
                                                            "actualValue": "=="
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "@type": "logical",
                                                "type": "and",
                                                "rules": [
                                                    {
                                                        "@type": "relational",
                                                        "lhs": {
                                                            "@type": "variable",
                                                            "dataType": "number",
                                                            "dataValue": "salary"
                                                        },
                                                        "rhs": {
                                                            "@type": "literal",
                                                            "dataType": "number",
                                                            "dataValue": 1000000
                                                        },
                                                        "operator": {
                                                            "actualValue": ">"
                                                        }
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            }
                        },
                        "dataType": "list",
                        "dataValue": "list",
                        "keywordArguments": {
                            "init": {
                                "value": "employeesDetails",
                                "transform": {
                                    "id": "210499190416143",
                                    "name": "Iterate 709052",
                                    "statements": [
                                        {
                                            "id": 1729670245692172,
                                            "name": "LabTale",
                                            "@type": "AssignmentStatement",
                                            "mandatory": true,
                                            "assignment": {
                                                "lhs": {
                                                    "@type": "keyword",
                                                    "dataType": "map",
                                                    "dataValue": "none"
                                                },
                                                "rhs": {
                                                    "@type": "keyword",
                                                    "dataType": "map",
                                                    "dataValue": "value"
                                                },
                                                "operator": {
                                                    "actualValue": "="
                                                }
                                            }
                                        }
                                    ],
                                    "jsonIgnoreProperty": false,
                                    "jsonIgnoreAliasValue": null
                                }
                            },
                            "format": "iterate"
                        },
                        "functionLabelName": "Iterate each element"
                    },
                    "operator": {
                        "actualValue": "="
                    }
                }
            }
        ]
    }
}`

const TestFilterWithEmptyObject = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "transform": {
        "id": "transform_custodetails",
        "jsonIgnoreProperty": "false",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": 1729669920415592,
                "name": "BidBall",
                "@type": "AssignmentStatement",
                "mandatory": true,
                "assignment": {
                    "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "HighSalariedEmployees"
                    },
                    "rhs": {
                        "@type": "keyword",
                        "filter": {},
                        "dataType": "list",
                        "dataValue": "list",
                        "keywordArguments": {
                            "init": {
                                "value": "employeesDetails",
                                "transform": {
                                    "id": "210499190416143",
                                    "name": "Iterate 709052",
                                    "statements": [
                                        {
                                            "id": 1729670245692172,
                                            "name": "LabTale",
                                            "@type": "AssignmentStatement",
                                            "mandatory": true,
                                            "assignment": {
                                                "lhs": {
                                                    "@type": "keyword",
                                                    "dataType": "map",
                                                    "dataValue": "none"
                                                },
                                                "rhs": {
                                                    "@type": "keyword",
                                                    "dataType": "map",
                                                    "dataValue": "value"
                                                },
                                                "operator": {
                                                    "actualValue": "="
                                                }
                                            }
                                        }
                                    ],
                                    "jsonIgnoreProperty": false,
                                    "jsonIgnoreAliasValue": null
                                }
                            },
                            "format": "iterate"
                        },
                        "functionLabelName": "Iterate each element"
                    },
                    "operator": {
                        "actualValue": "="
                    }
                }
            }
        ]
    }
}`

const GetFilteredListFunction = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
        {
          "id": 1729669920415592,
          "name": "BidBall",
          "@type": "AssignmentStatement",
          "mandatory": true,
          "assignment": {
            "lhs": {
              "@type": "literal",
              "dataType": "text",
              "dataValue": "HighSalariedEmployees"
            },
            "rhs": {
              "@type": "keyword",
              "filter": {
                "id": 1729669913449410,
                "name": "Add Filter",
                "condition": {
                  "type": "and",
                  "@type": "logical",
                  "rules": [
                    {
                      "lhs": {
                        "@type": "variable",
                        "dataType": "number",
                        "dataValue": "salary"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "number",
                        "dataValue": 2000000
                      },
                      "@type": "relational",
                      "operator": {
                        "actualValue": ">="
                      }
                    }
                  ]
                }
              },
              "dataType": "list",
              "dataValue": "list",
              "keywordArguments": {
                "init": {
                  "value": "employeesDetails"
                },
                "format": "getFilteredList"
              }
            },
            "operator": {
              "actualValue": "="
            }
          }
        }
      ]
    }
  }`

const GetFilteredListWithEmptyResult = `{
    "version": 3.3,
    "@type": "transform",
    "contentInputType": "json",
    "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
        {
          "id": 1729669920415592,
          "name": "BidBall",
          "@type": "AssignmentStatement",
          "mandatory": true,
          "assignment": {
            "lhs": {
              "@type": "literal",
              "dataType": "text",
              "dataValue": "HighSalariedEmployees"
            },
            "rhs": {
              "@type": "keyword",
              "filter": {
                "id": 1729669913449410,
                "name": "Add Filter",
                "condition": {
                  "type": "and",
                  "@type": "logical",
                  "rules": [
                    {
                      "lhs": {
                        "@type": "variable",
                        "dataType": "number",
                        "dataValue": "salary"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "number",
                        "dataValue": -2000000
                      },
                      "@type": "relational",
                      "operator": {
                        "actualValue": "<="
                      }
                    }
                  ]
                }
              },
              "dataType": "list",
              "dataValue": "list",
              "keywordArguments": {
                "init": {
                  "value": "employeesDetails"
                },
                "format": "getFilteredList"
              }
            },
            "operator": {
              "actualValue": "="
            }
          }
        }
      ]
    }
  }`
