package configs

const PrimitiveArrayMinConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Haylie",
        "statements" : [ {
          "id" : "666902023502514",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalnumbercount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "name"
                },
                "format" : "min"
              }
            }
          },
          "name" : "Andreanne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "666901053907024"
      },
      "id" : "666904620757793"
    } ]
  }
}`

const FilterPrimitiveArrayMinConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Eden",
        "statements" : [ {
          "id" : "668747492000756",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "minrating",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "668746879592115",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "!="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 1
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "name"
                },
                "format" : "min"
              }
            }
          },
          "name" : "Kaylah"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "668747300533960"
      },
      "id" : "668746859211861"
    } ]
  }
}`

const FilterMinNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Carlo",
        "statements" : [ {
          "id" : "670381981746312",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "minrating",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "670381983952589",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "!="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 4
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "min"
              }
            }
          },
          "name" : "Ada"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "670388622249605"
      },
      "id" : "670385841744362"
    } ]
  }
}`

const LocalArrayObjectMinConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jacques",
        "statements" : [ {
          "id" : "672039637369290",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "ratingsMinimum",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "min"
              }
            }
          },
          "name" : "Noe"
        }, {
          "id" : "672713619702483",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "MinimunLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "ratingsMinimum@local",
              "dataType" : "text"
            }
          },
          "name" : "Alyson"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "672715982850703"
      },
      "id" : "672711115618617"
    } ]
  }
}`

const NilMinConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Grant",
        "statements" : [ {
          "id" : "674347984563124",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalcount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores2"
                },
                "format" : "min"
              }
            }
          },
          "name" : "Kimberly"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "674346206000244"
      },
      "id" : "674349826291190"
    } ]
  }
}`

const LocalFilterMinNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Magdalen",
        "statements" : [ {
          "id" : "675442471772246",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "minrating",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "675445829146816",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "!="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 4
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "min"
              }
            }
          },
          "name" : "Lucas"
        }, {
          "id" : "675784770492000",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "LocalFilterMinimum",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "minrating@local",
              "dataType" : "text"
            }
          },
          "name" : "Kendall"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "675788870168794"
      },
      "id" : "675788420110599"
    } ]
  }
}`

const ArrayObjectMinConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Eldridge",
        "statements" : [ {
          "id" : "676384283982726",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "ratingsMinimum",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "min"
              }
            }
          },
          "name" : "Alanna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "676385700189802"
      },
      "id" : "676386468306776"
    } ]
  }
}`

const EmptyArrayMinConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Amari",
        "statements" : [ {
          "id" : "676955197235083",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "ratingsMinimum1",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores1"
                },
                "format" : "min"
              }
            }
          },
          "name" : "Ines"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "676952981425455"
      },
      "id" : "676953438048244"
    } ]
  }
}`
