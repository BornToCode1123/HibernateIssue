package configs

const DateDifferenceWrongFormatConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Oran",
        "statements" : [ {
          "id" : "477033237278266",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "difference_between_date",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "date",
              "keywordArguments" : {
                "init" : {
                  "start" : {
                    "value" : "startDate",
                    "format" : "dd-MM-yyyy"
                  },
                  "end" : {
                    "value" : "endDate1",
                    "format" : "dd-MM-yyyy"
                  }
                },
                "format" : "dateDiff",
                "type" : "months"
              }
            }
          },
          "name" : "Antonetta"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "477049226468241"
      },
      "id" : "477049904831042"
    } ]
  }
}`

const DateDifferenceConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kiel",
        "statements" : [ {
          "id" : "478699908811169",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "difference_between_date",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "date",
              "keywordArguments" : {
                "init" : {
                  "start" : {
                    "value" : "startDate",
                    "format" : "dd-MM-yyyy"
                  },
                  "end" : {
                    "value" : "endDate",
                    "format" : "dd-MM-yyyy"
                  }
                },
                "format" : "dateDiff",
                "type" : "months"
              }
            }
          },
          "name" : "Cordell"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "478691600425302"
      },
      "id" : "478691829992140"
    } ]
  }
}`

const EmptyDateDifferenceConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gianni",
        "statements" : [ {
          "id" : "480629850551989",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "difference_between_date",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "date",
              "keywordArguments" : {
                "init" : {
                  "start" : {
                    "value" : "first1",
                    "format" : "dd-MM-yyyy"
                  },
                  "end" : {
                    "value" : "second2",
                    "format" : "dd-MM-yyyy"
                  }
                },
                "format" : "dateDiff",
                "type" : "months"
              }
            }
          },
          "name" : "Audreanne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "480624452852513"
      },
      "id" : "480629554518483"
    } ]
  }
}`

const LocalDateDifferenceYears = `{
  "version" : "1",
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "abc",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Larue",
        "statements" : [ {
          "id" : "481966703559174",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "startDate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "01-01-2000",
              "dataType" : "text"
            }
          },
          "name" : "Aniyah"
        }, {
          "id" : "482487549726087",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "endDate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "01-01-2023",
              "dataType" : "text"
            }
          },
          "name" : "Carmela"
        }, {
          "id" : "482988616914244",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "difference_between_date",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "date",
              "keywordArguments" : {
                "init" : {
                  "start" : {
                    "value" : "startDate@local",
                    "format" : "dd-MM-yyyy"
                  },
                  "end" : {
                    "value" : "endDate@local",
                    "format" : "dd-MM-yyyy"
                  }
                },
                "format" : "dateDiff",
                "type" : "years"
              }
            }
          },
          "name" : "Jacklyn"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "482983242607263"
      },
      "id" : "482982171681771"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const LocalDateDifferenceWithDays = `{
  "version" : "1",
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "abc",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Aditya",
        "statements" : [ {
          "id" : "483934060798434",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "startDate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "01-01-2023",
              "dataType" : "text"
            }
          },
          "name" : "Faye"
        }, {
          "id" : "484356669380440",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "endDate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "01-01-2023",
              "dataType" : "text"
            }
          },
          "name" : "Carolanne"
        }, {
          "id" : "484717280711043",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "difference_between_date",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "date",
              "keywordArguments" : {
                "init" : {
                  "start" : {
                    "value" : "startDate@local",
                    "format" : "dd-MM-yyyy"
                  },
                  "end" : {
                    "value" : "endDate@local",
                    "format" : "dd-MM-yyyy"
                  }
                },
                "format" : "dateDiff",
                "type" : "days"
              }
            }
          },
          "name" : "Elvie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "484712018884041"
      },
      "id" : "484719736159843"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`
