package configs

const LocalIterateFilterFields = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "Filter the Date Repsonse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Madyson",
        "statements" : [ {
          "id" : "495544467128352",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "response",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "response",
              "dataType" : "list"
            }
          },
          "name" : "Isabel"
        }, {
          "id" : "496184996625586",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "FilteredData",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "496185387807077",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "dateClosed"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "yes",
                      "dataType" : "text"
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "dateClosed" : "dateClosed"
                  },
                  "value" : "response@local"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Bryce"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "496184317234681"
      },
      "id" : "496184588814646"
    } ]
  },
  "delete" : { },
  "extract" : { },
  "errors" : { }
}`

const IterateFieldsEmptyConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Orval",
        "statements" : [ {
          "id" : "498192401801154",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.ratings",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "fields" : { },
                  "value" : "scores"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Tyrell"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "498193079588413"
      },
      "id" : "498197163676013"
    } ]
  }
}`

const BreakIterateWithPayloadbyname = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Roxane",
        "statements" : [ {
          "id" : "501021881150494",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "iteratedListbybreakcondition",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                    "break": {
                        "@type": "logical",
                        "type": "and",
                        "rules": [
                            {
                                "@type": "relational",
                                "lhs": {
                                    "@type": "keyword",
                                    "dataValue": "value",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "=="
                                },
                                "rhs": {
                                    "@type": "literal",
                                    "dataValue": "sai",
                                    "dataType": "text"
                                }
                            }
                        ]
                    },
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Adriana",
                        "statements" : [ {
                          "id" : "501029105913128",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "name",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataValue" : "value",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Velda"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "501023004052495"
                      },
                      "id" : "501027546611106"
                    } ]
                  },
                  "value" : "names"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Agnes"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "501023202067510"
      },
      "id" : "501026499436032"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TransformEmptyStatementsIterate = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "Filter the Date Repsonse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Edmund",
        "statements" : [ {
          "id" : "502856323849613",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "ArrayDetails",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "Array Details",
                    "statements" : [ ]
                  },
                  "value" : "response"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Eula"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "502856614375249"
      },
      "id" : "502855369550716"
    } ]
  },
  "delete" : { },
  "extract" : { },
  "errors" : { }
}`

const FilterIterateFields = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "Filter the Date Repsonse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Danika",
        "statements" : [ {
          "id" : "504843049114064",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "FilteredData",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "504845485414821",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "dateClosed"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "yes",
                      "dataType" : "text"
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "dateClosed" : "dateClosed"
                  },
                  "value" : "response"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Eda"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "504842560952621"
      },
      "id" : "504848116526990"
    } ]
  },
  "delete" : { },
  "extract" : { },
  "errors" : { }
}`

const Iterate1Config = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "Filter the Date Repsonse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Leonardo",
        "statements" : [ {
          "id" : "506089828175278",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "ArrayDetails",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "transform Consumer Communication Address Details",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Flossie",
                        "statements" : [ {
                          "id" : "506087830039917",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "amountOverdue",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "amountOverdue",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Oren"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "506081634337972"
                      },
                      "id" : "506084843204194"
                    } ]
                  },
                  "value" : "response"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Brendan"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "506086096911741"
      },
      "id" : "506095946990684"
    } ]
  },
  "delete" : { },
  "extract" : { },
  "errors" : { }
}`

const EmptyarrayBreakIterate = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Caroline",
        "statements" : [ {
          "id" : "507411648093247",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "iteratedListbybreakcondition",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                    "break": {
                        "@type": "logical",
                        "type": "and",
                        "rules": [
                            {
                                "@type": "relational",
                                "lhs": {
                                    "@type": "keyword",
                                    "dataValue": "value",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "=="
                                },
                                "rhs": {
                                    "@type": "literal",
                                    "dataValue": "sai",
                                    "dataType": "text"
                                }
                            }
                        ]
                    },
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Charlotte",
                        "statements" : [ {
                          "id" : "507413492323148",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "name",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataValue" : "value",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Seth"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "507418402922606"
                      },
                      "id" : "507412804329066"
                    } ]
                  },
                  "value" : "scores1"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Flavie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "507411028024007"
      },
      "id" : "507419135365755"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const IterateOtherFieldsChangeConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Hazel",
        "statements" : [ {
          "id" : "508091185862197",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.ratings",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "comment" : "messages"
                  },
                  "value" : "scores4"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Newton"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "508092435436983"
      },
      "id" : "508093071475507"
    } ]
  }
}`

const IterateFieldsChangeConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Enola",
        "statements" : [ {
          "id" : "509018673252742",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.ratings",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "comment" : "message"
                  },
                  "value" : "scores4"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Grady"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "509012123715774"
      },
      "id" : "509016491370136"
    } ]
  }
}`

const TransformIterateLocal = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "Filter the Date Repsonse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Otilia",
        "statements" : [ {
          "id" : "510392301480715",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "response",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "response",
              "dataType" : "list"
            }
          },
          "name" : "Martine"
        }, {
          "id" : "511694797366139",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "FilteredData",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "511692186382035",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "variable",
                      "dataType" : "text",
                      "dataValue" : "dateClosed"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "yes",
                      "dataType" : "text"
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "transform",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Lucile",
                        "statements" : [ {
                          "id" : "511685041540954",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "dateClosed",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "dateClosed",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Lacey"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "511684919691856"
                      },
                      "id" : "511694505757098"
                    } ]
                  },
                  "value" : "response@local"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Marshall"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "511697493185188"
      },
      "id" : "511692830957102"
    } ]
  },
  "delete" : { },
  "extract" : { },
  "errors" : { }
}`

const BreakIteratebyvalue = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kraig",
        "statements" : [ {
          "id" : "512795834871729",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "iteratedListbybreakcondition",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                    "break": {
                        "@type": "logical",
                        "type": "and",
                        "rules": [
                            {
                                "@type": "relational",
                                "lhs": {
                                    "@type": "local",
                                    "dataValue": "sum",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "=="
                                },
                                "rhs": {
                                    "@type": "literal",
                                    "dataValue": 3,
                                    "dataType": "text"
                                }
                            }
                        ]
                    },
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Javon",
                        "statements" : [ {
                          "id" : "512633491405552",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "name",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataValue" : "value",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Theron"
                        }, {
                          "id" : "512791544425907",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "declare",
                              "dataValue" : "sum",
                              "dataType" : "number"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "expression",
                              "structure" : {
                                "@type" : "arithmetic",
                                "dataType" : "+",
                                "variables" : [ {
                                  "@type" : "local",
                                  "dataType" : "number",
                                  "dataValue" : "sum"
                                }, {
                                  "@type" : "literal",
                                  "dataType" : "number",
                                  "dataValue" : 1
                                } ]
                              },
                              "dataType" : "number"
                            }
                          },
                          "name" : "Jamil"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "512798019545327"
                      },
                      "id" : "512792815062671"
                    } ]
                  },
                  "value" : "names"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Daphnee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "512791713240205"
      },
      "id" : "512792917135407"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const FilterIterateConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "Filter the Date Repsonse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Werner",
        "statements" : [ {
          "id" : "513911610075376",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "FilteredData",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "513919490358584",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "variable",
                      "dataType" : "text",
                      "dataValue" : "dateClosed"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "yes",
                      "dataType" : "text"
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "transform",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Caleb",
                        "statements" : [ {
                          "id" : "513903000289011",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "dateClosed",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "dateClosed",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Jerrell"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "513909972829752"
                      },
                      "id" : "513915764576331"
                    } ]
                  },
                  "value" : "response"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Joanne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "513913792847546"
      },
      "id" : "513911118128903"
    } ]
  },
  "delete" : { },
  "extract" : { },
  "errors" : { }
}`

const NullarrayBreakIterate = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kim",
        "statements" : [ {
          "id" : "516318311870247",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "iteratedListbybreakcondition",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                    "break": {
                        "@type": "logical",
                        "type": "and",
                        "rules": [
                            {
                                "@type": "relational",
                                "lhs": {
                                    "@type": "keyword",
                                    "dataValue": "value",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "=="
                                },
                                "rhs": {
                                    "@type": "literal",
                                    "dataValue": "sai",
                                    "dataType": "text"
                                }
                            }
                        ]
                    },
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Marisol",
                        "statements" : [ {
                          "id" : "516312441201891",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "name",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataValue" : "value",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Vicky"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "516316845358670"
                      },
                      "id" : "516316076385507"
                    } ]
                  },
                  "value" : "scores2"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Elenora"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "516318183174656"
      },
      "id" : "516318305515613"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`
