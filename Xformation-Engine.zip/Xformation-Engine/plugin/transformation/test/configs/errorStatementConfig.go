package configs

const TestMultiSelectStaticArrayAndTesting2 = `{
  "id": "transform_custodetails",
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "contentOutputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "13",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "text",
                      "dataValue": "status Code"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "literal",
                      "dataType": "text",
                      "dataValue": "200"
                  }
              }
          },
          {
              "id": "1703587489795597",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "text",
                      "dataValue": "status"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "variable",
                      "dataType": "text",
                      "dataValue": "147ddf"
                  }
              }
          }
      ]
  },
  "errors": {
      "statements": [
          {
              "id": 1,
              "@type": "ConditionalStatement",
              "condition": {
                  "@type": "logical",
                  "type": "and",
                  "rules": [
                      {
                          "@type": "relational",
                          "rhs": {
                              "@type": "keyword",
                              "dataValue": "statementId",
                              "dataType": "text"
                          },
                          "operator": {
                              "actualValue": "contains"
                          },
                          "lhs": {
                              "@type": "keyword",
                              "dataType": "list",
                              "dataValue": "list",
                              "keywordArguments": {
                                  "init": {
                                      "values": [
                                          "1703587489795597"
                                      ]
                                  },
                                  "format": "multiSelect"
                              }
                          }
                      }
                  ]
              },
              "success": {
                  "statements": [
                      {
                          "id": "1",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "literal",
                                  "dataType": "number",
                                  "dataValue": "status"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "number",
                                  "dataValue": "condition is success in specific handling"
                              }
                          }
                      }
                  ]
              }
          },
          {
              "id": 1,
              "@type": "ConditionalStatement",
              "condition": {
                  "@type": "logical",
                  "type": "and",
                  "rules": [
                      {
                          "@type": "relational",
                          "rhs": {
                              "@type": "keyword",
                              "dataValue": "statementId",
                              "dataType": "text"
                          },
                          "operator": {
                              "actualValue": "contains"
                          },
                          "lhs": {
                              "@type": "keyword",
                              "dataType": "list",
                              "dataValue": "list",
                              "keywordArguments": {
                                  "init": {
                                      "values": [
                                          "1703587489795597",
                                          "1703587489795598"
                                      ]
                                  },
                                  "format": "multiSelect"
                              }
                          }
                      }
                  ]
              },
              "success": {
                  "statements": [
                      {
                          "id": "1",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "literal",
                                  "dataType": "number",
                                  "dataValue": "status"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "number",
                                  "dataValue": "condition is success in generic handling"
                              }
                          }
                      }
                  ]
              }
          }
      ]
  }
}`

const ExceptionMessageCreating = `{
  "version" : 3.3,
  "debug" : false,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "json",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_employeeDetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kaleigh",
        "statements" : [ {
          "id" : "560247453913225",
          "mandatory" : true,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "errors",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "errorfbuuas",
              "dataType" : "text"
            }
          },
          "name" : "Chloe"
        }, {
          "id" : "560852963952126",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "name"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "javed"
            }
          },
          "name" : "Aidan"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "560852564972565"
      },
      "id" : "560854242886072"
    } ]
  },
  "errors" : {
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Amy",
        "statements" : [ {
          "condition" : {
            "@type" : "logical",
            "type" : "and",
            "rules" : [ {
              "@type" : "relational",
              "lhs" : {
                "@type" : "keyword",
                "dataType" : "text",
                "dataValue" : "statementId"
              },
              "operator" : {
                "actualValue" : "=="
              },
              "rhs" : {
                "@type" : "keyword",
                "dataType" : "text",
                "dataValue" : "statementId"
              }
            } ]
          },
          "@type" : "ConditionalStatement",
          "success" : {
            "name" : "transformation",
            "statements" : [ {
              "@type" : "SectionalStatement",
              "section" : {
                "jsonIgnoreProperty" : false,
                "name" : "Mia",
                "statements" : [ {
                  "@type" : "ErrorStatement",
                  "id" : "validatePan",
                  "error" : {
                    "name" : "throwingException",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Myrtle",
                        "statements" : [ {
                          "id" : "563128829019203",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataType" : "text",
                              "dataValue" : "status"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataType" : "text",
                              "dataValue" : "FAILURE"
                            }
                          },
                          "name" : "Paula"
                        }, {
                          "id" : "563788020831328",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataType" : "text",
                              "dataValue" : "statusCode"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataType" : "text",
                              "dataValue" : "500"
                            }
                          },
                          "name" : "Phoebe"
                        }, {
                          "id" : "564986462856102",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataType" : "text",
                              "dataValue" : "erorMessage"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataType" : "text",
                              "dataValue" : "Server might be down, Please try after some time."
                            }
                          },
                          "name" : "Waldo"
                        }, {
                          "id" : "565736143310458",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataType" : "text",
                              "dataValue" : "detailedMessage"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "local",
                              "dataType" : "text",
                              "dataValue" : "currentError.detailedMessage"
                            }
                          },
                          "name" : "Osborne"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "565732315649635"
                      },
                      "id" : "565738278053605"
                    } ],
                    "id" : "validatePan"
                  }
                } ],
                "jsonIgnoreAliasValue" : null,
                "id" : "565736552998604"
              },
              "id" : "565731210390854"
            } ],
            "id" : "565733410554349"
          },
          "id" : "exception1"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "565731538119733"
      },
      "id" : "565739820027287"
    } ]
  }
}`

const TestMultiSelectStaticArrayAndTesting = `{"id":"transform_custodetails","version":3.3,"@type":"transform","contentInputType":"json","contentOutputType":"json","transform":{"id":"transform_custodetails","name":"Request payload Transformation","statements":[{"id":"13","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"status Code"},"operator":{"actualValue":"="},"rhs":{"@type":"literal","dataType":"text","dataValue":"200"}}},{"id":"1703587489795597","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"status"},"operator":{"actualValue":"="},"rhs":{"@type":"variable","dataType":"text","dataValue":"147ddf"}}}]},"errors":{"statements":[{"id":1,"@type":"ConditionalStatement","condition":{"@type":"logical","type":"and","rules":[{"@type":"relational","rhs":{"@type":"keyword","dataValue":"statementId","dataType":"text"},"operator":{"actualValue":"contains"},"lhs":{"@type":"keyword","dataType":"list","dataValue":"list","keywordArguments":{"init":{"values":["1703587489795597","1703587489795598"]},"format":"multiSelect"}}}]},"success":{"statements":[{"id":"1","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataType":"number","dataValue":"status"},"operator":{"actualValue":"="},"rhs":{"@type":"literal","dataType":"number","dataValue":"condition is success in generic statement"}}}]}},{"id":1,"@type":"ConditionalStatement","condition":{"@type":"logical","type":"and","rules":[{"@type":"relational","rhs":{"@type":"keyword","dataValue":"statementId","dataType":"text"},"operator":{"actualValue":"contains"},"lhs":{"@type":"keyword","dataType":"list","dataValue":"list","keywordArguments":{"init":{"values":["1703587489795597"]},"format":"multiSelect"}}}]},"success":{"statements":[{"id":"1","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataType":"number","dataValue":"status"},"operator":{"actualValue":"="},"rhs":{"@type":"literal","dataType":"number","dataValue":"condition is success in specific handling"}}}]}}]}}`

const ErrorParsing = `{
  "version" : 3.3,
  "debug" : true,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "xml",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_employeeDetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Camila",
        "statements" : [ {
          "id" : "566981220010078",
          "mandatory" : false,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "errors",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "errors",
              "dataType" : "list"
            }
          },
          "name" : "Lorenza"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "566981600046884"
      },
      "id" : "566986575366855"
    } ]
  }
}`

const ErrorStatement = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Wade",
        "statements" : [ {
          "id" : "568558579911421",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "normalAssignmentStatement"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "Executed"
            }
          },
          "name" : "Juliana"
        }, {
          "@type" : "ErrorStatement",
          "id" : "validatePan",
          "error" : {
            "name" : "throwingException",
            "statements" : [ {
              "@type" : "SectionalStatement",
              "section" : {
                "jsonIgnoreProperty" : false,
                "name" : "Christelle",
                "statements" : [ {
                  "id" : "568994401196681",
                  "@type" : "AssignmentStatement",
                  "assignment" : {
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "error.code"
                    },
                    "operator" : {
                      "actualValue" : "="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "1010"
                    }
                  },
                  "name" : "Mina"
                }, {
                  "id" : "569317914188224",
                  "@type" : "AssignmentStatement",
                  "assignment" : {
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "error.message"
                    },
                    "operator" : {
                      "actualValue" : "="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "errorOccured"
                    }
                  },
                  "name" : "Michel"
                } ],
                "jsonIgnoreAliasValue" : null,
                "id" : "569316145525925"
              },
              "id" : "569311822725814"
            } ],
            "id" : "validatePan"
          }
        }, {
          "id" : "569501729680827",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "name"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataType" : "text",
              "dataValue" : "javeed Mohammad ahbufcyjfvbV"
            }
          },
          "name" : "Rosalia"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "569509056975847"
      },
      "id" : "569509507493885"
    } ]
  }
}`

const ErrorStatementInsideTransForm = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Damaris",
        "statements" : [ {
          "id" : "572265317653209",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "AdditionalDetails",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "transform communication for Grid",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Casimir",
                        "statements" : [ {
                          "condition" : {
                            "@type" : "logical",
                            "type" : "and",
                            "rules" : [ {
                              "@type" : "relational",
                              "lhs" : {
                                "@type" : "variable",
                                "dataValue" : "netInflows",
                                "dataType" : "number"
                              },
                              "operator" : {
                                "actualValue" : ">="
                              },
                              "rhs" : {
                                "@type" : "literal",
                                "dataValue" : 30,
                                "dataType" : "number"
                              }
                            } ]
                          },
                          "@type" : "ConditionalStatement",
                          "success" : {
                            "name" : "transformation",
                            "statements" : [ {
                              "@type" : "SectionalStatement",
                              "section" : {
                                "jsonIgnoreProperty" : false,
                                "name" : "Kevin",
                                "statements" : [ {
                                  "@type" : "ErrorStatement",
                                  "id" : "validatePan",
                                  "error" : {
                                    "name" : "throwingException",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Alexandre",
                                        "statements" : [ {
                                          "id" : "571763828528981",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataType" : "text",
                                              "dataValue" : "error.code"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataType" : "text",
                                              "dataValue" : "1010"
                                            }
                                          },
                                          "name" : "Asia"
                                        }, {
                                          "id" : "572046558935212",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataType" : "text",
                                              "dataValue" : "error.message"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataType" : "text",
                                              "dataValue" : "errorOccured"
                                            }
                                          },
                                          "name" : "Brigitte"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "572041985687212"
                                      },
                                      "id" : "572045356078873"
                                    } ],
                                    "id" : "validatePan"
                                  }
                                }, {
                                  "id" : "572268310040502",
                                  "@type" : "AssignmentStatement",
                                  "assignment" : {
                                    "lhs" : {
                                      "@type" : "literal",
                                      "dataType" : "text",
                                      "dataValue" : "errorStatementNotExecuted"
                                    },
                                    "operator" : {
                                      "actualValue" : "="
                                    },
                                    "rhs" : {
                                      "@type" : "literal",
                                      "dataType" : "text",
                                      "dataValue" : "failed"
                                    }
                                  },
                                  "name" : "Cody"
                                } ],
                                "jsonIgnoreAliasValue" : null,
                                "id" : "572261940074489"
                              },
                              "id" : "572268250064200"
                            } ],
                            "id" : "572265171826261"
                          },
                          "id" : 1
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "572268956517040"
                      },
                      "id" : "572266460094978"
                    } ]
                  },
                  "value" : "AdditionalSalariedMonthlyDetails"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Kallie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "572269158391732"
      },
      "id" : "572264362083224"
    } ]
  }
}`

const TestMultiSelectStaticArray = `{"id":"transform_custodetails","version":3.3,"@type":"transform","contentInputType":"json","contentOutputType":"json","transform":{"id":"transform_custodetails","name":"Request payload Transformation","statements":[{"id":1703587489795597,"name":"SpeechSquare","@type":"AssignmentStatement","mandatory":true,"assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"abc"},"rhs":{"@type":"keyword","dataType":"text","dataValue":"list","keywordArguments":{"init":{"values":["1703587489795597","1000000000000000"]},"format":"multiSelect"}},"operator":{"actualValue":"="}}}]}}`

const ErrorsSectionTest = `{"id":"transform_custodetails","version":3.3,"@type":"transform","contentInputType":"json","contentOutputType":"json","transform":{"id":"transform_custodetails","name":"Request payload Transformation","statements":[{"id":"13","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"a"},"operator":{"actualValue":"="},"rhs":{"@type":"variable","dataType":"text","dataValue":"1"}}},{"id":"56","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"b"},"operator":{"actualValue":"="},"rhs":{"@type":"variable","dataType":"text","dataValue":"147"}}}]},"errors":{"statements":[{"id":1,"@type":"ConditionalStatement","condition":{"@type":"logical","type":"and","rules":[{"@type":"relational","lhs":{"@type":"keyword","dataValue":"statementId","dataType":"text"},"operator":{"actualValue":"=="},"rhs":{"@type":"literal","dataValue":"13","dataType":"text"}}]},"success":{"statements":[{"id":"1","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataType":"number","dataValue":"a"},"operator":{"actualValue":"="},"rhs":{"@type":"literal","dataType":"number","dataValue":500}}},{"id":"2","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataType":"number","dataValue":"b"},"operator":{"actualValue":"="},"rhs":{"@type":"literal","dataType":"number","dataValue":400}}}]}}]}}`

const DebugTrueOrFalseMandatoryTrue = `{
  "version" : 3.3,
  "debug" : false,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "json",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_employeeDetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Valentin",
        "statements" : [ {
          "id" : "573034747495315",
          "mandatory" : false,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customerName",
              "dataType" : "text"
            }
          },
          "name" : "Hazle"
        }, {
          "id" : "573359925497771",
          "mandatory" : false,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "age",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customerAge",
              "dataType" : "text"
            }
          },
          "name" : "Skye"
        }, {
          "id" : "573656559422851",
          "mandatory" : true,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "result",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "payloadResult",
              "dataType" : "text"
            }
          },
          "name" : "Ladarius"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "573658884608039"
      },
      "id" : "573657863312373"
    } ]
  }
}`

const AppendingMultipleErrorsDebugFalse = `{
  "version" : 3.3,
  "debug" : false,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "json",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_employeeDetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gavin",
        "statements" : [ {
          "id" : "574456447415718",
          "mandatory" : false,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customerName",
              "dataType" : "text"
            }
          },
          "name" : "Dejon"
        }, {
          "id" : "574651441031705",
          "mandatory" : false,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "age",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customerAge",
              "dataType" : "text"
            }
          },
          "name" : "Lonzo"
        }, {
          "id" : "574825041663172",
          "mandatory" : true,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "result",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "success",
              "dataType" : "text"
            }
          },
          "name" : "Kelsi"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "574826944202998"
      },
      "id" : "574838801379575"
    } ]
  }
}`

const AppendingMultipleErrorsDebugTrue = `{
  "version" : 3.3,
  "debug" : true,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "json",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_employeeDetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Marco",
        "statements" : [ {
          "id" : "575293117508974",
          "mandatory" : false,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customerName",
              "dataType" : "text"
            }
          },
          "name" : "Vicente"
        }, {
          "id" : "575562166572285",
          "mandatory" : false,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "age",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customerAge",
              "dataType" : "text"
            }
          },
          "name" : "Yasmine"
        }, {
          "id" : "575787797883490",
          "mandatory" : true,
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "result",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "success",
              "dataType" : "text"
            }
          },
          "name" : "Elmo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "575787740155798"
      },
      "id" : "575786271616225"
    } ]
  }
}`

const ErrorSectionTesting = `{
  "version" : 3.3,
  "debug" : true,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "json",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_employeeDetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Dayana",
        "statements" : [ {
          "@type" : "ErrorStatement",
          "id" : "validatePan",
          "error" : {
            "name" : "throwingException",
            "statements" : [ {
              "@type" : "SectionalStatement",
              "section" : {
                "jsonIgnoreProperty" : false,
                "name" : "Erika",
                "statements" : [ {
                  "id" : "576404216628983",
                  "@type" : "AssignmentStatement",
                  "assignment" : {
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "error.code"
                    },
                    "operator" : {
                      "actualValue" : "="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "1010"
                    }
                  },
                  "name" : "Roosevelt"
                }, {
                  "id" : "576664965192483",
                  "@type" : "AssignmentStatement",
                  "assignment" : {
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "error.message"
                    },
                    "operator" : {
                      "actualValue" : "="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "errorOccured"
                    }
                  },
                  "name" : "Noemy"
                } ],
                "jsonIgnoreAliasValue" : null,
                "id" : "576668839096250"
              },
              "id" : "576669079120804"
            } ],
            "id" : "validatePan"
          }
        }, {
          "id" : "576839178008069",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "customer.name"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "javeed"
            }
          },
          "name" : "Braeden"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "576837443441367"
      },
      "id" : "576833898163093"
    } ]
  }
}`

const UserExceptionError = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Vivian",
        "statements" : [ {
          "id" : "579436051689597",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "AdditionalDetails",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "transform communication for Grid",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Newton",
                        "statements" : [ {
                          "condition" : {
                            "@type" : "logical",
                            "type" : "and",
                            "rules" : [ {
                              "@type" : "relational",
                              "lhs" : {
                                "@type" : "literal",
                                "dataValue" : "javeed",
                                "dataType" : "text"
                              },
                              "operator" : {
                                "actualValue" : "=="
                              },
                              "rhs" : {
                                "@type" : "literal",
                                "dataValue" : "javeed",
                                "dataType" : "text"
                              }
                            } ]
                          },
                          "@type" : "ConditionalStatement",
                          "success" : {
                            "name" : "transformation",
                            "statements" : [ {
                              "@type" : "SectionalStatement",
                              "section" : {
                                "jsonIgnoreProperty" : false,
                                "name" : "Graciela",
                                "statements" : [ {
                                  "id" : "579435517678845",
                                  "@type" : "AssignmentStatement",
                                  "assignment" : {
                                    "lhs" : {
                                      "@type" : "literal",
                                      "dataValue" : "AdditionalDetails",
                                      "dataType" : "list"
                                    },
                                    "operator" : {
                                      "actualValue" : "="
                                    },
                                    "rhs" : {
                                      "@type" : "keyword",
                                      "dataType" : "list",
                                      "dataValue" : "list",
                                      "keywordArguments" : {
                                        "init" : {
                                          "transform" : {
                                            "id" : "transform_config_1",
                                            "name" : "transform communication for Grid",
                                            "statements" : [ {
                                              "@type" : "SectionalStatement",
                                              "section" : {
                                                "jsonIgnoreProperty" : false,
                                                "name" : "Enoch",
                                                "statements" : [ {
                                                  "condition" : {
                                                    "@type" : "logical",
                                                    "type" : "and",
                                                    "rules" : [ {
                                                      "@type" : "relational",
                                                      "lhs" : {
                                                        "@type" : "variable",
                                                        "dataValue" : "netInflows",
                                                        "dataType" : "number"
                                                      },
                                                      "operator" : {
                                                        "actualValue" : ">="
                                                      },
                                                      "rhs" : {
                                                        "@type" : "literal",
                                                        "dataValue" : 30,
                                                        "dataType" : "number"
                                                      }
                                                    } ]
                                                  },
                                                  "@type" : "ConditionalStatement",
                                                  "success" : {
                                                    "name" : "transformation",
                                                    "statements" : [ {
                                                      "@type" : "SectionalStatement",
                                                      "section" : {
                                                        "jsonIgnoreProperty" : false,
                                                        "name" : "Gennaro",
                                                        "statements" : [ {
                                                          "@type" : "ErrorStatement",
                                                          "id" : "validatePan",
                                                          "error" : {
                                                            "name" : "throwingException",
                                                            "statements" : [ {
                                                              "@type" : "SectionalStatement",
                                                              "section" : {
                                                                "jsonIgnoreProperty" : false,
                                                                "name" : "Roberta",
                                                                "statements" : [ {
                                                                  "id" : "578929235984322",
                                                                  "@type" : "AssignmentStatement",
                                                                  "assignment" : {
                                                                    "lhs" : {
                                                                      "@type" : "literal",
                                                                      "dataType" : "text",
                                                                      "dataValue" : "error.code"
                                                                    },
                                                                    "operator" : {
                                                                      "actualValue" : "="
                                                                    },
                                                                    "rhs" : {
                                                                      "@type" : "literal",
                                                                      "dataType" : "text",
                                                                      "dataValue" : "104"
                                                                    }
                                                                  },
                                                                  "name" : "Clarabelle"
                                                                }, {
                                                                  "id" : "579128527688400",
                                                                  "@type" : "AssignmentStatement",
                                                                  "assignment" : {
                                                                    "lhs" : {
                                                                      "@type" : "literal",
                                                                      "dataType" : "text",
                                                                      "dataValue" : "error.message"
                                                                    },
                                                                    "operator" : {
                                                                      "actualValue" : "="
                                                                    },
                                                                    "rhs" : {
                                                                      "@type" : "literal",
                                                                      "dataType" : "text",
                                                                      "dataValue" : "pageNotFound"
                                                                    }
                                                                  },
                                                                  "name" : "Jaylen"
                                                                } ],
                                                                "jsonIgnoreAliasValue" : null,
                                                                "id" : "579123964514308"
                                                              },
                                                              "id" : "579127870436340"
                                                            } ],
                                                            "id" : "validatePan"
                                                          }
                                                        }, {
                                                          "id" : "579428449991513",
                                                          "@type" : "AssignmentStatement",
                                                          "assignment" : {
                                                            "lhs" : {
                                                              "@type" : "literal",
                                                              "dataType" : "text",
                                                              "dataValue" : "errorStatementNotExecuted"
                                                            },
                                                            "operator" : {
                                                              "actualValue" : "="
                                                            },
                                                            "rhs" : {
                                                              "@type" : "literal",
                                                              "dataType" : "text",
                                                              "dataValue" : "failed"
                                                            }
                                                          },
                                                          "name" : "Anibal"
                                                        } ],
                                                        "jsonIgnoreAliasValue" : null,
                                                        "id" : "579428425052420"
                                                      },
                                                      "id" : "579421301979310"
                                                    } ],
                                                    "id" : "579421415372277"
                                                  },
                                                  "id" : 1
                                                } ],
                                                "jsonIgnoreAliasValue" : null,
                                                "id" : "579421577079866"
                                              },
                                              "id" : "579431523280332"
                                            } ]
                                          },
                                          "value" : "AdditionalSalariedMonthlyDetails"
                                        },
                                        "format" : "iterate"
                                      }
                                    }
                                  },
                                  "name" : "Berta"
                                } ],
                                "jsonIgnoreAliasValue" : null,
                                "id" : "579434577897896"
                              },
                              "id" : "579438012972298"
                            } ],
                            "id" : "579435955934729"
                          },
                          "id" : 1
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "579431443328419"
                      },
                      "id" : "579439274784939"
                    } ]
                  }
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Jaylan"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "579434570071709"
      },
      "id" : "579437535149788"
    } ]
  }
}`

const ErrorRecursiveConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": "965544288022753",
        "@type": "AssignmentStatement",
        "assignment": {
          "lhs": {
            "@type": "literal",
            "dataValue": "BirthDay_Month",
            "dataType": "text"
          },
          "operator": {
            "actualValue": "="
          },
          "rhs": {
            "@type": "variable",
            "dataValue": "BirthDay_Month",
            "dataType": "text"
          }
        },
        "name": "Davon"
      }
    ]
  },
  "errors": {
    "statements": [
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": false,
          "name": "Haven",
          "statements": [
            {
              "condition": {
                "@type": "logical",
                "type": "and",
                "rules": [
                  {
                    "@type": "relational",
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "text",
                      "dataValue": "statementId"
                    },
                    "operator": {
                      "actualValue": "=="
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "text",
                      "dataValue": "965544288022753"
                    }
                  }
                ]
              },
              "@type": "ConditionalStatement",
              "success": {
                "name": "transformation",
                "statements": [
                  {
                    "@type": "SectionalStatement",
                    "section": {
                      "jsonIgnoreProperty": false,
                      "name": "Robin",
                      "statements": [
                        {
                          "id": "966312195700505",
                          "@type": "AssignmentStatement",
                          "assignment": {
                            "@type": "SimpleAssignmentStatement",
                            "lhs": {
                              "@type": "literal",
                              "dataValue": "error.code",
                              "dataType": "text"
                            },
                            "operator": {
                              "actualValue": "="
                            },
                            "rhs": {
                              "@type": "variable",
                              "dataValue": "Davon_error.code@local",
                              "dataType": "text"
                            }
                          },
                          "name": "Brent"
                        },
                        {
                          "id": "966695641676496",
                          "@type": "AssignmentStatement",
                          "assignment": {
                            "@type": "SimpleAssignmentStatement",
                            "lhs": {
                              "@type": "literal",
                              "dataValue": "error.message",
                              "dataType": "text"
                            },
                            "operator": {
                              "actualValue": "="
                            },
                            "rhs": {
                              "@type": "variable",
                              "dataValue": "Davon_error.message@local",
                              "dataType": "text"
                            }
                          },
                          "name": "Nathan"
                        }
                      ],
                      "jsonIgnoreAliasValue": null,
                      "id": "966691280880370"
                    },
                    "id": "966697052642262"
                  }
                ],
                "id": "966698123518488"
              },
              "failure": null,
              "id": "exception1"
            }
          ],
          "jsonIgnoreAliasValue": null,
          "id": "966695543248164"
        },
        "id": "966697935954367"
      }
    ]
  }
}`

const IterateIsideThrowingError = `{
  "version": "1",
  "@type": "transform",
  "transform": {
    "id": "transform_config_1",
    "name": "customer Response",
    "statements": [
      {
        "id": "1",
        "@type": "AssignmentStatement",
        "assignment": {
          "lhs": {
            "@type": "literal",
            "dataType": "number",
            "dataValue": "status"
          },
          "operator": {
            "actualValue": "="
          },
          "rhs": {
            "@type": "literal",
            "dataType": "number",
            "dataValue": "condition is success in specific handling"
          }
        }
      },
      {
        "id": "579436051689597",
        "@type": "AssignmentStatement",
        "assignment": {
          "lhs": {
            "@type": "literal",
            "dataValue": "AdditionalDetails",
            "dataType": "list"
          },
          "operator": {
            "actualValue": "="
          },
          "rhs": {
            "@type": "keyword",
            "dataType": "list",
            "dataValue": "list",
            "keywordArguments": {
              "init": {
                "transform": {
                  "id": "transform_config_1",
                  "name": "transform communication for Grid",
                  "statements": [
                    {
                      "@type": "SectionalStatement",
                      "section": {
                        "jsonIgnoreProperty": false,
                        "name": "Newton",
                        "statements": [
                          {
                            "@type": "ErrorStatement",
                            "id": "validatePan",
                            "error": {
                              "name": "throwingException",
                              "statements": [
                                {
                                  "@type": "SectionalStatement",
                                  "section": {
                                    "jsonIgnoreProperty": false,
                                    "name": "Christelle",
                                    "statements": [
                                      {
                                        "id": "568994401196681",
                                        "@type": "AssignmentStatement",
                                        "assignment": {
                                          "lhs": {
                                            "@type": "literal",
                                            "dataType": "text",
                                            "dataValue": "error.code"
                                          },
                                          "operator": {
                                            "actualValue": "="
                                          },
                                          "rhs": {
                                            "@type": "literal",
                                            "dataType": "text",
                                            "dataValue": "1010"
                                          }
                                        },
                                        "name": "Mina"
                                      },
                                      {
                                        "id": "569317914188224",
                                        "@type": "AssignmentStatement",
                                        "assignment": {
                                          "lhs": {
                                            "@type": "literal",
                                            "dataType": "text",
                                            "dataValue": "error.message"
                                          },
                                          "operator": {
                                            "actualValue": "="
                                          },
                                          "rhs": {
                                            "@type": "literal",
                                            "dataType": "text",
                                            "dataValue": "errorOccured"
                                          }
                                        },
                                        "name": "Michel"
                                      }
                                    ],
                                    "jsonIgnoreAliasValue": null,
                                    "id": "569316145525925"
                                  },
                                  "id": "569311822725814"
                                }
                              ],
                              "id": "validatePan"
                            }
                          }
                        ],
                        "jsonIgnoreAliasValue": null,
                        "id": "579431443328419"
                      },
                      "id": "579439274784939"
                    }
                  ]
                }
              },
              "format": "iterate"
            }
          }
        },
        "name": "Jaylan"
      }
    ]
  },
  "errors": {
    "statements": [
      {
        "id": 1,
        "@type": "ConditionalStatement",
        "condition": {
          "@type": "logical",
          "type": "and",
          "rules": [
            {
              "@type": "relational",
              "rhs": {
                "@type": "keyword",
                "dataValue": "statementId",
                "dataType": "text"
              },
              "operator": {
                "actualValue": "=="
              },
              "lhs": {
                "@type": "keyword",
                "dataValue": "statementId",
                "dataType": "text"
              }
            }
          ]
        },
        "success": {
          "statements": [
            {
              "id": "1",
              "@type": "AssignmentStatement",
              "assignment": {
                "lhs": {
                  "@type": "literal",
                  "dataType": "number",
                  "dataValue": "status"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "literal",
                  "dataType": "number",
                  "dataValue": "condition is success in specific handling"
                }
              }
            }
          ]
        }
      }
    ]
  }
}`

const RecursiveErrorConfig = `{
  "version": "1",
  "@type": "transform",
  "transform": {
    "id": "transform_config_1",
    "name": "customer Response",
    "statements": [
      {
        "id": "1",
        "@type": "AssignmentStatement",
        "assignment": {
          "lhs": {
            "@type": "literal",
            "dataType": "number",
            "dataValue": "status"
          },
          "operator": {
            "actualValue": "="
          },
          "rhs": {
            "@type": "variable",
            "dataType": "number",
            "dataValue": "condition is success in specific handling ajdf lakdc"
          }
        }
      }
    ]
  },
  "errors": {
    "statements": [
      {
        "id": 1,
        "@type": "ConditionalStatement",
        "condition": {
          "@type": "logical",
          "type": "and",
          "rules": [
            {
              "@type": "relational",
              "rhs": {
                "@type": "keyword",
                "dataValue": "statementId",
                "dataType": "text"
              },
              "operator": {
                "actualValue": "=="
              },
              "lhs": {
                "@type": "keyword",
                "dataValue": "statementId",
                "dataType": "text"
              }
            }
          ]
        },
        "success": {
          "statements": [
            {
              "id": "1",
              "@type": "AssignmentStatement",
              "assignment": {
                "lhs": {
                  "@type": "literal",
                  "dataType": "number",
                  "dataValue": "status"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "varieble",
                  "dataType": "number",
                  "dataValue": "condition is success in specific handling"
                }
              }
            }
          ]
        }
      }
    ]
  }
}`
