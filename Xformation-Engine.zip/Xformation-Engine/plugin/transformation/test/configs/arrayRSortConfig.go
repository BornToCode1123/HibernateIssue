package configs

const ArrayMultipleObjectsSingleValueRSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Verna",
        "statements" : [ {
          "id" : "113622743568471",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "scores4",
                  "sortBy" : "message"
                }
              }
            }
          },
          "name" : "Chad"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "113636635890906"
      },
      "id" : "113633631009796"
    } ]
  }
}`

const ArrayStringRSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Keely",
        "statements" : [ {
          "id" : "115382673731458",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedStringArray",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "names"
                }
              }
            }
          },
          "name" : "Ramon"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "115388481925619"
      },
      "id" : "115407613581569"
    } ]
  }
}`

const RSortByObjectsLocal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Karlie",
        "statements" : [ {
          "id" : "116997929724131",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "profitability_ratios",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "profitability_ratios",
              "dataType" : "list"
            }
          },
          "name" : "Tre"
        }, {
          "id" : "117665580918047",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedArrayByProperty",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "profitability_ratios@local",
                  "sortBy" : "year"
                }
              }
            }
          },
          "name" : "Dedrick"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "117677932260871"
      },
      "id" : "117677130123833"
    } ]
  }
}`

const EmptyArrayRSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jerrod",
        "statements" : [ {
          "id" : "119531992397321",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedEmptyArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "scores1"
                }
              }
            }
          },
          "name" : "Matilde"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "119532097963071"
      },
      "id" : "119531425195426"
    } ]
  }
}`

const PrimitiveArrayRSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Moses",
        "statements" : [ {
          "id" : "120559469351800",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedPrimitiveArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "primitive"
                }
              }
            }
          },
          "name" : "Savanah"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "120556990863832"
      },
      "id" : "120558091286331"
    } ]
  }
}`

const ArrayObjectRSort = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Sammy",
        "statements" : [ {
          "id" : "121713738915832",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedArrayByObjects",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "profitability_ratios",
                  "sortBy" : "year"
                }
              }
            }
          },
          "name" : "Jonathan"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "121715969534236"
      },
      "id" : "121717230209353"
    } ]
  }
}`

const NullArrayRSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Brooklyn",
        "statements" : [ {
          "id" : "122668472300036",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedNullArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "scores2"
                }
              }
            }
          },
          "name" : "Rosella"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "122679096691789"
      },
      "id" : "122672903188691"
    } ]
  }
}`

const RSortStringsLocal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Eugene",
        "statements" : [ {
          "id" : "123071332139410",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "primitive",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "primitive",
              "dataType" : "list"
            }
          },
          "name" : "Santina"
        }, {
          "id" : "123249123030295",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "primitive@local"
                }
              }
            }
          },
          "name" : "Mayra"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "123245889479713"
      },
      "id" : "123245031213088"
    } ]
  }
}`

const ArrayObjectMissingRSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Rudy",
        "statements" : [ {
          "id" : "123776726836616",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "RSortedArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "rsort",
                "init" : {
                  "value" : "scores3",
                  "sortBy" : "message"
                }
              }
            }
          },
          "name" : "Maximo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "123775843072997"
      },
      "id" : "123778156045620"
    } ]
  }
}`
