package configs

const SortByObjectsLocal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Rene",
        "statements" : [ {
          "id" : "349328738853441",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "profitability_ratios",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "profitability_ratios",
              "dataType" : "list"
            }
          },
          "name" : "Hershel"
        }, {
          "id" : "349874537970381",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArrayByProperty",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "profitability_ratios@local",
                  "sortBy" : "year"
                }
              }
            }
          },
          "name" : "Deon"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "349875507312363"
      },
      "id" : "349876843804615"
    } ]
  }
}`

const ArrayMultipleObjectsSingleValueSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Rhoda",
        "statements" : [ {
          "id" : "351306665462208",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "scores4",
                  "sortBy" : "message"
                }
              }
            }
          },
          "name" : "Mallory"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "351308099292604"
      },
      "id" : "351306141495523"
    } ]
  }
}`

const EmptyArraySorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Sid",
        "statements" : [ {
          "id" : "352618065199570",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedEmptyArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "scores1"
                }
              }
            }
          },
          "name" : "Foster"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "352615018527849"
      },
      "id" : "352613085381879"
    } ]
  }
}`

const ArrayStringSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Makenna",
        "statements" : [ {
          "id" : "355172402278611",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedStringArray",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "names"
                }
              }
            }
          },
          "name" : "Rudy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "355179315463334"
      },
      "id" : "355175652561462"
    } ]
  }
}`

const ArrayObjectSort = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Hardy",
        "statements" : [ {
          "id" : "356142599468873",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArrayByObjects",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "profitability_ratios",
                  "sortBy" : "year"
                }
              }
            }
          },
          "name" : "Brody"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "356147182670820"
      },
      "id" : "356144942810336"
    } ]
  }
}`

const SortStringsLocal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Dane",
        "statements" : [ {
          "id" : "357891788255533",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "primitive",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "primitive",
              "dataType" : "list"
            }
          },
          "name" : "Bernadette"
        }, {
          "id" : "358904654620638",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "primitive@local"
                }
              }
            }
          },
          "name" : "Emely"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "358907469548008"
      },
      "id" : "358906761551525"
    } ]
  }
}`

const NullArraySorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Marc",
        "statements" : [ {
          "id" : "360252361183535",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedNullArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "scores2"
                }
              }
            }
          },
          "name" : "Andreanne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "360312583049871"
      },
      "id" : "360318818335108"
    } ]
  }
}`

const PrimitiveArraySorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Rosie",
        "statements" : [ {
          "id" : "362143045102047",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedPrimitiveArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "primitive",
                  "sortBy" : ""
                }
              }
            }
          },
          "name" : "Guy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "362142708361968"
      },
      "id" : "362142847902902"
    } ]
  }
}`

const ArrayObjectMissingSorting = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Earnestine",
        "statements" : [ {
          "id" : "363822781377198",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "SortedArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list",
              "keywordArguments" : {
                "format" : "sort",
                "init" : {
                  "value" : "scores3",
                  "sortBy" : "message"
                }
              }
            }
          },
          "name" : "Rico"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "363824023379380"
      },
      "id" : "363825830763530"
    } ]
  }
}`
