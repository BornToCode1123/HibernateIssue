package configs

const BooleanNumberToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jalen",
        "statements" : [ {
          "id" : "753624345163240",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "boolean",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "isBoolean3"
                }
              }
            }
          },
          "name" : "Leonardo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "753628194965587"
      },
      "id" : "753626960131506"
    } ]
  }
}`

const BooleanOtherTextToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Giovanna",
        "statements" : [ {
          "id" : "764895776327741",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "boolean",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "isBoolean2"
                }
              }
            }
          },
          "name" : "Eva"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "764892636199891"
      },
      "id" : "764891928383049"
    } ]
  }
}`

const Text_To_ToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Brady",
        "statements" : [ {
          "id" : "769325253475664",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "boolean",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "scoreVal"
                }
              }
            }
          },
          "name" : "Felipa"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "769323055198197"
      },
      "id" : "769324531246842"
    } ]
  }
}`

const BooleanTextToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Isidro",
        "statements" : [ {
          "id" : "773287554807506",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "boolean",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "isBoolean1"
                }
              }
            }
          },
          "name" : "Glenda"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "773288686713232"
      },
      "id" : "773288787967401"
    } ]
  }
}`

const BooleanToText = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Melvin",
        "statements" : [ {
          "id" : "776872280795939",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "boolean",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "isBoolean"
                }
              }
            }
          },
          "name" : "Berenice"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "776871140376680"
      },
      "id" : "776872908913300"
    } ]
  }
}`

const CheckBoolIsEmpty = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "boolean",
                      "keywordArguments": {
                        "init": {
                          "value": "krakend"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check Bool variable is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": true,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const CheckBoolIsEmptyForKeyNotPresent = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "boolean",
                      "keywordArguments": {
                        "init": {
                          "value": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check Bool variable is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const TestBoolValueKeyNotPresentInConfigForIsEmpty = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "boolean",
                      "keywordArguments": {
                        "init": {
                          "valuef": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check Bool variable is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`
