package configs 

const StringConcatWithCharactersConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tobin",
        "statements" : [ {
          "id" : "178908867561534",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "employeName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "firstName",
                  "values" : [ "character", "secondName", "character", "role" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Vivianne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "178907162725869"
      },
      "id" : "178901572589859"
    } ]
  }
}`

const LocalStringConcatConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Marilie",
        "statements" : [ {
          "id" : "180898267403774",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "employeName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "firstName",
                  "values" : [ "secondName" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Elissa"
        }, {
          "id" : "182008835603927",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "ConcatLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "employeName@local",
              "dataType" : "text"
            }
          },
          "name" : "Connor"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "182002042020740"
      },
      "id" : "182004654467719"
    } ]
  }
}`

const NumberConcatConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Samson",
        "statements" : [ {
          "id" : "183406832725998",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "age",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "first",
                  "values" : [ "second" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Ava"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "183402744381733"
      },
      "id" : "183404741005525"
    } ]
  }
}`

const StringConcatConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : true,
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Alex",
        "statements" : [ {
          "id" : "184895359742817",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "employeName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "firstName",
                  "values" : [ "secondName" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Abelardo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "184898868298656"
      },
      "id" : "184892969827141"
    } ]
  }
}`

const StringMultipleConcatConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Carol",
        "statements" : [ {
          "id" : "186231959220851",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "employeName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "firstName",
                  "values" : [ "secondName", "role", "gender" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Beryl"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "186237518708177"
      },
      "id" : "186232095494444"
    } ]
  }
}`

const EmptyConcatConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tressa",
        "statements" : [ {
          "id" : "187489379302789",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "age",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "first1",
                  "values" : [ "second2" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Curt"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "187488612318380"
      },
      "id" : "187485828222470"
    } ]
  }
}`

