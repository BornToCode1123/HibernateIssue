package configs

const IgnorePropertyKeywordDate = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : true,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Michel",
        "statements" : [ {
          "id" : "281543300400075",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataType" : "date",
              "dataValue" : "finalText"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "format" : "MMM yyyy",
                "init" : {
                  "value" : "dateDate",
                  "format" : "dd-MM-yyyy"
                }
              }
            }
          },
          "name" : "Jabari"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "281553658541026"
      },
      "id" : "281558353817680"
    } ]
  }
}`

const IgnorePropertyKeywordText = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : true,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Josianne",
        "statements" : [ {
          "id" : "283748489225654",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toLowerCase",
                "init" : {
                  "value" : "fName"
                }
              }
            }
          },
          "name" : "Payton"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "283749330529898"
      },
      "id" : "283742459955641"
    } ]
  }
}`

const IgnorePropertyKeywordNumber = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : true,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Camron",
        "statements" : [ {
          "id" : "285424004913467",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "ceil",
                "init" : {
                  "value" : "rates"
                }
              }
            }
          },
          "name" : "Zackery"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "285423089926813"
      },
      "id" : "285424226913842"
    } ]
  }
}`

const IgnorePropertyKeywordMap = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : true,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Amira",
        "statements" : [ {
          "id" : "286466994554121",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "length",
                "init" : {
                  "value" : "Data"
                }
              }
            }
          },
          "name" : "Kamren"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "286462441215445"
      },
      "id" : "286463445918752"
    } ]
  }
}`

const IgnorePropertyFunctionSumWithAliasAsNull = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : true,
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Sylvester",
        "statements" : [ {
          "id" : "287306661591143",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "val"
                },
                "format" : "sum"
              }
            }
          },
          "name" : "Jason"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "287306285961557"
      },
      "id" : "287302379243811"
    } ]
  }
}`

const IgnorePropertyFunctionAvg = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : true,
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Dorothea",
        "statements" : [ {
          "id" : "287896384842272",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "val"
                },
                "format" : "avg"
              }
            }
          },
          "name" : "Barbara"
        } ],
        "jsonIgnoreAliasValue" : "0",
        "id" : "287896308516995"
      },
      "id" : "287891531947953"
    } ]
  }
}`

const IgnorePropertyKeywordList = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "jsonIgnoreProperty" : true,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Cristopher",
        "statements" : [ {
          "id" : "288631075001407",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "length",
                "init" : {
                  "value" : "listData"
                }
              }
            }
          },
          "name" : "Lizeth"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "288637417833332"
      },
      "id" : "288638243539468"
    } ]
  }
}`

const IgnorePropertyFunctionConcatValue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : true,
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Chester",
        "statements" : [ {
          "id" : "289159128435653",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "fName",
                  "values" : [ "secondName" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Nels"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "289155072100203"
      },
      "id" : "289157033726262"
    } ]
  }
}`

const IgnorePropertyFunctionCount = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : true,
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Issac",
        "statements" : [ {
          "id" : "289669132898451",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "score"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Jamil"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "289661728834422"
      },
      "id" : "289668084147624"
    } ]
  }
}`

const IgnorePropertyFunctionConcatValuesList = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "jsonIgnoreProperty" : true,
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : true,
        "name" : "Mireille",
        "statements" : [ {
          "id" : "290382591089679",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "firstName",
                  "values" : [ "sName" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Sunny"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "290393089889733"
      },
      "id" : "290395658230405"
    } ]
  }
}`

const TestKeyNotPresentForFunctionMinConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "jsonIgnoreProperty": true,
    "statements": [
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": false,
          "name": "Kareem",
          "statements": [
            {
              "id": "290981152250573",
              "@type": "AssignmentStatement",
              "assignment": {
                "lhs": {
                  "@type": "literal",
                  "dataValue": "finalText",
                  "dataType": "number"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataType": "number",
                  "dataValue": "list",
                  "keywordArguments": {
                    "init": {
                      "value": "scores",
                      "aggregate": "val"
                    },
                    "format": "min"
                  }
                }
              },
              "name": "Gussie"
            }
          ],
          "jsonIgnoreAliasValue": null,
          "id": "290984090120405"
        },
        "id": "290988878945191"
      }
    ]
  }
}`

const TestIgnorePropertyForFunctionMinConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "jsonIgnoreProperty": true,
    "statements": [
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": true,
          "name": "Kareem",
          "statements": [
            {
              "id": "290981152250573",
              "@type": "AssignmentStatement",
              "assignment": {
                "lhs": {
                  "@type": "literal",
                  "dataValue": "finalText",
                  "dataType": "number"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataType": "number",
                  "dataValue": "list",
                  "keywordArguments": {
                    "init": {
                      "value": "scores",
                      "aggregate": "val"
                    },
                    "format": "min"
                  }
                }
              },
              "name": "Gussie"
            }
          ],
          "jsonIgnoreAliasValue": "0",
          "id": "290984090120405"
        },
        "id": "290988878945191"
      }
    ]
  }
}`
