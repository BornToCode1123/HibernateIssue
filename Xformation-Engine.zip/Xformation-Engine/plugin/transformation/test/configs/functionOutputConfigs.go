package configs

// Count TestCases

const TestArrayObjectCountTesting = `{"numberofratings":4}`
const TestPrimitiveArrayCountStringTesting = `{"totalnamescount":4}`
const TestPrimitiveArrayCountNumberTesting = `{"totalnumbercount":4}`
const TestFilterCountNumberTesting = `{"numberofratingwith10":3}`
const TestFilterCountNumber1Testing = `{"numberofratingwith10":0}`
const TestEmptyArrayCountTesting = `{"totalnamescount":0}`
const TestNullCountTesting = `{"totalcount":0}`

//----------------------------------------------------------------------------------------------------

//Sum TestCases

const TestArraySumTesting = `{"total":34}`
const TestPrimitiveArraySumTesting = `{"total1":10}`
const TestEmptyArraySumTesting = `{"total2":0}`
const TestValueMissingArraySumTesting = `{"total":16}`
const TestNullSumTesting = `{"totalcount":0}`
const TestStringSumTesting = `{"total":34}`
const TestFilterSumTesting = `{"numberofsumratingwith10":30}`
const TestFilterSum1Testing = `{"numberofsumratingwith1":0}`
const TestFilterPrimitiveArraySumTesting = `{"numberofsumratingwith1":10}`
const TestNestedConditionFiltersForSumCountMinMaxAvgTesting = `{"avgInList":3.5,"countOfList":2,"maxInList":4,"minInList":3,"numberofsumratingwith1":7}`

//------------------------------------------------------------------------------------------------------

//Avearage TestCases

const TestArrayObjectAvgTesting = `{"ratingsAvearage":8.5}`
const TestLocalArrayObjectAvgConfigTesting = `{"AvearageLocal":8.5}`
const TestPrimitiveArrayAvgTesting = `{"avearage":2.5}`
const TestNullAvgTesting = `{"totalcount":null}`
const TestFilterAvgNumberTesting = `{"numberofavgratingwith10":10}`
const TestFilterAvgDummyNumberTesting = `{"code":"1001","detailedMessage":"Please contact system admin.","message":"Technical Error","subCode":""}`

//-----------------------------------------------------------------------------------------------------

//Max TestCases

const TestArrayObjectMaxTesting = `{"ratingsMaximum":10}`
const TestLocalArrayObjectMaxConfigTesting = `{"MaximumLocal":10}`
const TestEmptyArrayMaxTesting = `{"ratingsMaximum1":0}`
const TestPrimitiveArrayMaxTesting = `{"totalnumbercount":4}`
const TestNullMaxTesting = `{"totalcount":0}`
const TestFilterMaxNumberTesting = `{"maxrating":4}`
const TestLocalFilterMaxNumberConfigTesting = `{"LocalFilterMaximum":10}`
const TestFilterPrimitiveArrayMaxTesting = `{"maxrating":4}`

//----------------------------------------------------------------------------------------------------

//Min TestCases

const TestArrayObjectMinTesting = `{"ratingsMinimum":4}`
const TestLocalArrayObjectMinConfigTesting = `{"MinimunLocal":4}`
const TestEmptyArrayMinTesting = `{"ratingsMinimum1":0}`
const TestPrimitiveArrayMinTesting = `{"totalnumbercount":1}`
const TestNullMinTesting = `{"totalcount":0}`
const TestFilterMinNumberTesting = `{"minrating":10}`
const TestLocalFilterMinNumberConfigTesting = `{"LocalFilterMinimum":10}`
const TestFilterPrimitiveArrayMinTesting = `{"minrating":1}`

//---------------------------------------------------------------------------------------------------

//Populate TestCases

const TestPopulateSampleTesting = `{"customer":{"customerAge":20,"designation":"Male"}}`
const TestPopulateLocalTesting = `{"customer":{"customerAge":22,"customerName":"Javed","designation":"developer"}}`
const TestPopulateLocalandDataTesting = `{"customer":{"customerAge":22,"customerName":"Javed","designation":"developer"}}`
const TestPopulateEmptyFieldsTesting = `{"populateEmpty":{}}`

//-------------------------------------------------------------------------------------------------------

//Split TestCases

const TestLocalDataSplitConfigTesting = `{"daysInPaymentHistory1":["xxx","yuo","123","456","789","098","765","432","123"]}`
const TestDataSplitConfigTesting = `{"splitpayment":["xxx","yuo","123","456","789","098","765","432","123"]}`
const TestCommaSplitTesting = `{"splitpayment,":["xxxyuo","123456789098765432123"]}`
const TestEmptySplitTesting = `{"splitpayment,":[""]}`
const TestOneSplitTesting = `{"splitpayment,":["a"]}`

//--------------------------------------------------------------------------------------------------------

//Concat TestCases

const TestStringConcatTesting = `{"employeName":"AKHILESHAKSHAY"}`
const TestEmptyConcatTesting = `{"age":""}`
const TestStringMultipleConcatConfigTesting = `{"employeName":"AKHILESHAKSHAYdeveloperMale"}`
const TestStringConcatWithCharactersConfigTesting = `{"employeName":"AKHILESH,AKSHAY,developer"}`
const TestLocalStringConcatConfigTesting = `{"ConcatLocal":"AKHILESHAKSHAY"}`

//----------------------------------------------------------------------------------------------------

//FormatDateAndTime TestCases

const TestFormatDateAndTimeTesting = `{"formatteddate":"12-07-2022"}`
const TestFormatDateAndTime1Testing = `{"formatddate":1657564200000}`
const TestFormatDateAndTime2Testing = `{"formatteddate1":1656613800000}`
const TestLocalFormatDateAndTimeConfigTesting = `{"local formatted date":"12-07-2022"}`

//---------------------------------------------------------------------------------------------------

//DateDifference TestCases

const TestDateDifferenceTesting = `{"difference_between_date":207}`
const TestLocalDateDifferenceYearsTesting = `{"difference_between_date":23}`
const TestLocalDateDifferenceWithDaysTesting = `{"difference_between_date":0}`

//------------------------------------------------------------------------------------------------

//Collect TestCases

// const TestCollectTesting = `{"collectedValues":["guarantor","pOAHolder","partner","authorisedSignatory","shareHolder","coBorrower"]}`

//-----------------------------------------------------------------------------------------------

//Iterate TestCases

const TestIterateFieldsChangeTesting = `{"customer":{"ratings":[{"comment":"Excellent"},{"comment":"poor"},{"comment":"good"},{"comment":"very good"}]}}`

// const TestIterateOtherFieldsChangeConfigTesting = `{"customer":{"ratings":[{"comment":"a"},{"comment":"b"},{"comment":"c"}]}}`
const TestIterateFieldsEmptyConfigTesting = `{"customer":{"ratings":[]}}`
const TestFilterIterateConfigTesting = `{"FilteredData":[{"dateClosed":"yes"},{"dateClosed":"yes"},{"dateClosed":"yes"}]}`
const TestFilterIterateFieldsTesting = `{"FilteredData":[{"dateClosed":"yes"},{"dateClosed":"yes"},{"dateClosed":"yes"}]}`
const TestLocalIterateFilterFieldsTesting = `{"FilteredData":[{"dateClosed":"yes"},{"dateClosed":"yes"},{"dateClosed":"yes"}]}`
const TestIterate1ConfigTesting = `{"ArrayDetails":[{"amountOverdue":10},{"amountOverdue":10},{"amountOverdue":100},{"amountOverdue":10}]}`
const TestTransformIterateLocalTesting = `{"FilteredData":[{"dateClosed":"yes"},{"dateClosed":"yes"},{"dateClosed":"yes"}]}`

// const TestBreakIteratebyvalueTesting = `{"iteratedListbybreakcondition":[{"name":"akhil"},{"name":"nikhil"},{"name":"sai"}]}`
const TestBreakIterateWithPayloadbynameTesting = `{"iteratedListbybreakcondition":[{"name":"akhil"},{"name":"nikhil"}]}`
const TestEmptyarrayBreakIterateTesting = `{"iteratedListbybreakcondition":[]}`
const TestNullarrayBreakIterateTesting = `{"iteratedListbybreakcondition":[]}`
const TestTransformEmptyStatementsIterateTesting = `{"ArrayDetails":[]}`

//---------------------------------------------------------------------------------------------

//Lower TestCases

const TestLowerConfigTesting = `{"Name":"akhilesh"}`
const TestLocalLowerConfigTesting = `{"LowerLocal":"akhilesh"}`

// const TestLowerNumberConfigTesting = ``

//------------------------------------------------------------------------------------------

//Upper TestCases

const TestUpperConfigTesting = `{"Name":"MALE"}`
const TestLocalUpperConfigTesting = `{"UpperLocal":"MALE"}`

// const TestUpperNumberConfigTesting = ``

//-----------------------------------------------------------------------------------------

//CamelCase TestCases

const TestCamelCaseConfigTesting = `{"Name":"narsimhaReddy"}`
const TestLocalCamelCaseConfigTesting = `{"CamelLocal":"narsimhaReddy"}`

// const TestCamelCaseIntegerConfigTesting = ``

//-----------------------------------------------------------------------------------------

//TextToNumber TestCases

const TestTextToNumberConfigTesting = `{"Number":940393739}`
const TestTextToNumberLocalConfigTesting = `{"Experience":60}`

// const TestTextToNumberIntegerConfigTesting = ``

//NumberToText TestCases

const TestNumberToTextConfigTesting = `{"finalText":"940393739"}`
const TestNumberToTextLocalConfigTesting = `{"finalText":"940393739"}`

// const TestNumberToTextStringConfigTesting = ``

//------------------------------------------------------------------------------------------

//Number TestCases

const TestNumberCeilConfigTesting = `{"finalText":124}`
const TestLocalNumberCeilConfigTesting = `{"NumberCeilLocal":124}`
const TestNumberFloorConfigTesting = `{"finalText":123}`
const TestLocalNumberFloorConfigTesting = `{"NumberFloorLocal":123}`
const TestNumberRoundConfigTesting = `{"finalText":123}`
const TestLocalNumberRoundConfigTesting = `{"NumberRoundLocal":123}`
const TestNumberRoundWithDecimalConfigTesting = `{"finalText":123.48}`
const TestLocalNumberRoundWithDecimalConfigTesting = `{"roundWithDecimalLocal":123.48}`
const TestNumberGetNonDecimalConfigTesting = `{"finalText":123}`
const TestLocalNumberGetNonDecimalConfigTesting = `{"getNonDecimalLocal":123}`
const TestNumberGetDecimalConfigTesting = `{"finalText":0.48269999999999413}`
const TestLocalNumberGetDecimalConfigTesting = `{"getNonDecimalLocal":0.48269999999999413}`

//-----------------------------------------------------------------------------------------------

//Currency TestCases

const TestCurrencyINRConfigTesting = `{"formattedAmount":"1,721.00"}`
const TestCurrencyINRTextConfigTesting = `{"formattedAmount":"10.00"}`
const TestCurrencyConfLOcalNUmberToUsd1Testing = `{"formattedAmount":"$456.00"}`
const TestCurrencyConfLOcalZeroNUmberToUsd1Testing = `{"formattedAmount":"$0.00"}`
const TestCurrencyConfLOcalWithNull1Testing = `{"formattedAmount":"$0.00"}`

//----------------------------------------------------------------------------------------------

//DateKeyword TestCases

const TestDateKeyword1ConfigTesting = `{"month":1656613800000}`
const TestDateKeyword2ConfigTesting = `{"convertedDate":"Jan 2006"}`
const TestDateKeyword3ConfigTesting = `{"sanctionDate":"01-07-2022"}`
const TestLocalDateKeywordConfigTesting = `{"date local":1656613800000}`

//----------------------------------------------------------------------------------------------

//ArraySorting TestCases

const TestPrimitiveArraySortingTesting = `{"SortedPrimitiveArray":[1,2,3,4]}`
const TestArrayStringSortingTesting = `{"SortedStringArray":["akhil","kiran","nikhil","sai"]}`
const TestArrayObjectSortTesting = `{"SortedArrayByObjects":[{"cash_profits_margin":"24.2","ebit_margin":"17.18","editda_margin":"37.97","gross_profit_margin":"38.09","net_profit_margin":"3.41","operating_profit_margin":"8.62","pbt_margin":"3.41","year":"2020"},{"cash_profits_margin":"41.77","ebit_margin":"16.87","editda_margin":"55.12","gross_profit_margin":"55.94","net_profit_margin":"3.53","operating_profit_margin":"-3.94","pbt_margin":"3.53","year":"2021"},{"cash_profits_margin":"23.73","ebit_margin":"26.7","editda_margin":"45.89","gross_profit_margin":"46.37","net_profit_margin":"4.54","operating_profit_margin":"17.03","pbt_margin":"4.54","year":"2022"}]}`
const TestSortStringsLocaltTesting = `{"SortedArray":[1,2,3,4]}`
const TestSortByObjectsLocaltTesting = `{"SortedArrayByProperty":[{"cash_profits_margin":"24.2","ebit_margin":"17.18","editda_margin":"37.97","gross_profit_margin":"38.09","net_profit_margin":"3.41","operating_profit_margin":"8.62","pbt_margin":"3.41","year":"2020"},{"cash_profits_margin":"41.77","ebit_margin":"16.87","editda_margin":"55.12","gross_profit_margin":"55.94","net_profit_margin":"3.53","operating_profit_margin":"-3.94","pbt_margin":"3.53","year":"2021"},{"cash_profits_margin":"23.73","ebit_margin":"26.7","editda_margin":"45.89","gross_profit_margin":"46.37","net_profit_margin":"4.54","operating_profit_margin":"17.03","pbt_margin":"4.54","year":"2022"}]}`
const TestArrayObjectMissingSortingTesting = `{"SortedArray":[{"message":"a","value":"10"},{"message":"b","value":10},{"message":"c","value":10},{"value":4}]}`
const TestEmptyArraySortingTesting = `{"SortedEmptyArray":null}`
const TestNullArraySortingTesting = `{"SortedNullArray":null}`
const TestArrayMultipleObjectsSingleValueSortingTesting = `{"SortedArray":[{"message":"Excellent"},{"message":"good"},{"message":"poor"},{"message":"very good"}]}`

//------------------------------------------------------------------------------------------------------

//TextKeywords TestCases

const TestTestKeyword_TrimTesting = `{"finalText":"NARSIMHA REDDY"}`
const TestLocalTestKeyword_TrimTesting = `{"trim local":"NARSIMHA REDDY"}`
const TestKeyword_tobooleanTesting = `{"finalText":true}`
const TestLocalTestKeyword_tobooleanTesting = `{"toBoolean local":true}`
const TestKeyword_isnumberFalseTesting = `{"finalText":false}`
const TestLocalTestKeyword_isnumberFalseTesting = `{"isnumberFalse local":false}`
const TestKeyword_isnumberTrueTesting = `{"finalText":true}`
const TestLocalTestKeyword_isnumberTrueTesting = `{"isnumberTrue local":true}`
const TestKeyword_isbooleanfalseTesting = `{"finalText":false}`
const TestLocalTestKeyword_isbooleanfalseTesting = `{"isbooleanfalse local":false}`
const TestKeyword_isbooleanTrueTesting = `{"finalText":true}`
const TestLocalTestKeyword_isbooleanTrueTesting = `{"isbooleanTrue local":true}`
const TestBooleantoTextTesting = `{"finalText":"false"}`

//-------------------------------------------------------------------------------------------------------

//MapKeyword TestCases

// const TestMapGetKeySetsTesting = `{"finalText":["avgNumberOfDaysOverdrawn","totalCredit","averageUtilization","totalExceptionalCredit","credits","debits","totalDebit","inwChqBouncePercent","cashWithdrawalToTotalDebitPercent","overdrawnAmountMax","exceptionalCredits","monthName","cashDepositToTotalCreditPercent","avgUtilizationAsPercentOfLimit","data","outwChqBouncePercent"]}`
// const TestMapGetValuesSetsTesting = `{"finalText":["Apr-21",10429174.64,3,[{"Score":10},{"Score":7},{"Score":1}],11436667.65,78,-1890258790.9,0,"NA",0,5242,22,11.54,0,0,3.6]}`
const TestMapLengthsTesting = `{"finalText":16}`

//----------------------------------------------------------------------------------------------------------------------

//ArrayRSorting TestCases

const TestPrimitiveArrayRSortingTesting = `{"RSortedPrimitiveArray":[4,3,2,1]}`
const TestArrayStringRSortingTesting = `{"RSortedStringArray":["sai","nikhil","kiran","akhil"]}`
const TestArrayObjectRSortTesting = `{"RSortedArrayByObjects":[{"cash_profits_margin":"23.73","ebit_margin":"26.7","editda_margin":"45.89","gross_profit_margin":"46.37","net_profit_margin":"4.54","operating_profit_margin":"17.03","pbt_margin":"4.54","year":"2022"},{"cash_profits_margin":"41.77","ebit_margin":"16.87","editda_margin":"55.12","gross_profit_margin":"55.94","net_profit_margin":"3.53","operating_profit_margin":"-3.94","pbt_margin":"3.53","year":"2021"},{"cash_profits_margin":"24.2","ebit_margin":"17.18","editda_margin":"37.97","gross_profit_margin":"38.09","net_profit_margin":"3.41","operating_profit_margin":"8.62","pbt_margin":"3.41","year":"2020"}]}`
const TestRSortStringsLocaltTesting = `{"RSortedArray":[4,3,2,1]}`
const TestRSortByObjectsLocaltTesting = `{"RSortedArrayByProperty":[{"cash_profits_margin":"23.73","ebit_margin":"26.7","editda_margin":"45.89","gross_profit_margin":"46.37","net_profit_margin":"4.54","operating_profit_margin":"17.03","pbt_margin":"4.54","year":"2022"},{"cash_profits_margin":"41.77","ebit_margin":"16.87","editda_margin":"55.12","gross_profit_margin":"55.94","net_profit_margin":"3.53","operating_profit_margin":"-3.94","pbt_margin":"3.53","year":"2021"},{"cash_profits_margin":"24.2","ebit_margin":"17.18","editda_margin":"37.97","gross_profit_margin":"38.09","net_profit_margin":"3.41","operating_profit_margin":"8.62","pbt_margin":"3.41","year":"2020"}]}`
const TestArrayObjectMissingRSortingTesting = `{"RSortedArray":[{"message":"c","value":10},{"message":"b","value":10},{"message":"a","value":"10"},{"value":4}]}`
const TestEmptyArrayRSortingTesting = `{"RSortedEmptyArray":null}`
const TestNullArrayRSortingTesting = `{"RSortedNullArray":null}`
const TestArrayMultipleObjectsSingleValueRSortingTesting = `{"RSortedArray":[{"message":"very good"},{"message":"poor"},{"message":"good"},{"message":"Excellent"}]}`

//----------------------------------------------------------------------------------------------------------------------

//Pagination TestCases

const TestPagination = `{"data":[{"appCode":46,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":47,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":48,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":49,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":50,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null}]}`
const TestPaginateNegativeSize = `{"code":"1001","detailedMessage":"Please contact system admin.","message":"Technical Error","subCode":""}`
const TestPaginateNegativePageNo = `{"code":"1001","detailedMessage":"Please contact system admin.","message":"Technical Error","subCode":""}`
const TestPaginateIncorrectArrayName = `{"code":"1010","detailedMessage":"Please contact system admin.","message":"Payload Property Error","subCode":""}`
const TestPaginateLastPage = `{"data":[{"appCode":37,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":38,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":39,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":40,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null}]}`
const TestPaginateIncorrectPageNo = `{"data":[]}`
const TestPaginateMissingPageNoAndSizeKeys = `{"data":[{"appCode":1,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":2,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":3,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":4,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":5,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":6,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":7,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":8,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":9,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":10,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":11,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":12,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":13,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":14,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":15,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":16,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":17,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":18,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":19,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":20,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":21,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":22,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":23,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":24,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":25,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":26,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":27,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":28,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":29,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null},{"appCode":30,"applicationId":3164,"applicationPackageId":null,"appliedamount":null,"assignedTo":"rmUser1","customerName":null,"driverId":7,"location":null,"stage":"RMJourney","stageId":267853,"status":"Application Initiated","statusId":5183,"taskGroup":"199521","taskRole":7,"taskType":0,"taskUser":87,"tenor":null}]}`
