package configs

const MapLength = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Darren",
        "statements" : [ {
          "id" : "850629120102392",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "length",
                "init" : {
                  "value" : "MonthlyData"
                }
              }
            }
          },
          "name" : "Madisyn"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "850625179379488"
      },
      "id" : "850622925933787"
    } ]
  }
}`

const MapValueSset = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Dean",
        "statements" : [ {
          "id" : "852513700390491",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getValueSet",
                "init" : {
                  "value" : "customer"
                }
              }
            }
          },
          "name" : "Tyshawn"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "852512135892191"
      },
      "id" : "852518949489357"
    } ]
  }
}`

const MapPushValueByKey = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Bradly",
        "statements" : [ {
          "id" : "854014361349340",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "key",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "name",
              "dataType" : "text"
            }
          },
          "name" : "Willy"
        }, {
          "id" : "854538750653098",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "value",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "javeed",
              "dataType" : "text"
            }
          },
          "name" : "Arno"
        }, {
          "id" : "855544977527101",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "employee",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "putValueByKey",
                "init" : {
                  "key" : "key@local",
                  "value" : "value@local"
                }
              }
            }
          },
          "name" : "Marquise"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "855625809714348"
      },
      "id" : "855625622082437"
    } ]
  }
}`

const MapDeleteFromMap = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ofelia",
        "statements" : [ {
          "id" : "857056190525520",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "key",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "name",
              "dataType" : "text"
            }
          },
          "name" : "Anika"
        }, {
          "id" : "858001200577565",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "value",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "javeed",
              "dataType" : "text"
            }
          },
          "name" : "Alphonso"
        }, {
          "id" : "858856826769123",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "employee",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "putValueByKey",
                "init" : {
                  "key" : "key@local",
                  "value" : "value@local"
                }
              }
            }
          },
          "name" : "Rosanna"
        }, {
          "id" : "859534118098563",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "key1",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "name2",
              "dataType" : "text"
            }
          },
          "name" : "Monique"
        }, {
          "id" : "860241531106559",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "value1",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "rohit",
              "dataType" : "text"
            }
          },
          "name" : "Carolyn"
        }, {
          "id" : "860765281769589",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "employee",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "putValueByKey",
                "init" : {
                  "key" : "key1@local",
                  "value" : "value1@local"
                }
              }
            }
          },
          "name" : "Brandt"
        }, {
          "id" : "861256697468142",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "employee",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "deleteFromMap",
                "init" : {
                  "key" : "name2",
                  "value" : "employee@local"
                }
              }
            }
          },
          "name" : "Desmond"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "861252106124224"
      },
      "id" : "861252512841500"
    } ]
  }
}`

const GetValueByKey = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Friedrich",
        "statements" : [ {
          "id" : "861989700060128",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "customer.name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "javeed",
              "dataType" : "text"
            }
          },
          "name" : "Tate"
        }, {
          "id" : "862289920588022",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "key",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "name",
              "dataType" : "text"
            }
          },
          "name" : "Cleo"
        }, {
          "id" : "862642329466240",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getValueByKey",
                "init" : {
                  "key" : "key@local",
                  "value" : "customer@local"
                }
              }
            }
          },
          "name" : "Janet"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "862653825649524"
      },
      "id" : "862651385514901"
    } ]
  }
}`

const MapGetKeySet = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Wyatt",
        "statements" : [ {
          "id" : "863275994709889",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getKeySet",
                "init" : {
                  "value" : "MonthlyData"
                }
              }
            }
          },
          "name" : "Domenick"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "863278286964364"
      },
      "id" : "863271709743060"
    } ]
  }
}`

const MapWithNullValue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Khalil",
        "statements" : [ {
          "id" : "863691905906139",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "length",
                "init" : {
                  "value" : "map1"
                }
              }
            }
          },
          "name" : "Percy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "863692251223526"
      },
      "id" : "863695615738634"
    } ]
  }
}`

const MapGetValuesSet = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tito",
        "statements" : [ {
          "id" : "864159016078027",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getValueSet",
                "init" : {
                  "value" : "MonthlyData"
                }
              }
            }
          },
          "name" : "Theresa"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "864156989816688"
      },
      "id" : "864154431683850"
    } ]
  }
}`

const JsonObjectMap = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "1729579905433740",
              "name": "LoadPhase",
              "@type": "AssignmentStatement",
              "mandatory": true,
              "toogleSwitchValue": false,
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataValue": "jsonObject",
                      "dataType": "text"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataValue": "map",
                      "functionLabelName": "Upload a json map",
                      "dataType": "map",
                      "keywordArguments": {
                          "format": "jsonObjectMap",
                          "init": {
                              "value": "{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":650,\"max_cibil_score\":699,\"amount\":150000}"
                          }
                      }
                  }
              }
          }
      ]
  }
}`

const MakeTheMapEmpty = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "1729579905433740",
              "name": "LoadPhase",
              "@type": "AssignmentStatement",
              "mandatory": true,
              "toogleSwitchValue": false,
              "assignment": {
                  "lhs": {
                      "@type": "declare",
                      "dataValue": "jsonObject",
                      "dataType": "text"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataValue": "map",
                      "functionLabelName": "Upload a json map",
                      "dataType": "map",
                      "keywordArguments": {
                          "format": "jsonObjectMap",
                          "init": {
                              "value": "{\"min_app_score\":346,\"max_app_score\":999,\"min_cibil_score\":650,\"max_cibil_score\":699,\"amount\":150000}"
                          }
                      }
                  }
              }
          },
          {
              "id": 1729669920415592,
              "name": "BidBall",
              "@type": "AssignmentStatement",
              "mandatory": true,
              "assignment": {
                  "lhs": {
                      "@type": "declare",
                      "dataType": "map",
                      "dataValue": "jsonObject"
                  },
                  "rhs": {
                    "@type": "keyword",
                    "dataType": "map",
                    "dataValue": "map",
                    "keywordArguments": {
                        "format": "clearTheMap"
                    }
                  },
                  "operator": {
                      "actualValue": "="
                  }
              }
          },
          {
              "id": "693563357661903",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataValue": "jsonObject",
                      "dataType": "map"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "local",
                      "dataValue": "jsonObject",
                      "dataType": "map"
                  }
              },
              "name": "Olga"
          }
      ]
  }
}`

const MapContainsKey = `{
  "version": 3.3,
  "debug": false,
  "@type": "transform",
  "contentInputType": "json",
  "contentOutputType": "json",
  "transform": {
      "jsonIgnoreProperty": false,
      "id": "transform_employeeDetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "condition": {
                  "@type": "logical",
                  "type": "and",
                  "rules": [
                      {
                          "@type": "relational",
                          "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "name"
                          },
                          "operator": {
                              "actualValue": "contains"
                          },
                          "lhs": {
                              "@type": "variable",
                              "dataType": "map",
                              "dataValue": "employees"
                          }
                      }
                  ]
              },
              "@type": "ConditionalStatement",
              "success": {
                  "name": "transformation",
                  "statements": [
                      {
                          "id": "433796587042862",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "literal",
                                  "dataType": "text",
                                  "dataValue": "status"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "text",
                                  "dataValue": "yes, key is present"
                              }
                          },
                          "name": "Nicholaus"
                      }
                  ],
                  "id": "433798354364253"
              },
              "failure": null,
              "id": "exception1"
          }
      ]
  }
}`

const CheckMapIsEmpty = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "map",
                      "keywordArguments": {
                        "init": {
                          "value": "emptyMap"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check map is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": true,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const TestMapIsEmptyForKeyNotPresent = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "map",
                      "keywordArguments": {
                        "init": {
                          "value": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check map is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const TestMapIsEmptyForValueKeyNotPresentInConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "map",
                      "keywordArguments": {
                        "init": {
                          "valuef": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check map is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`
