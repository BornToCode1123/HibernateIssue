package configs

const LogStatementInfoLevelConfig = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "598163340749418",
                "@type": "LogStatement",
                "name": "logginPanInformation",
                "log": {
                    "level": "INFO",
                    "messages": [
                        {
                            "@type": "literal",
                            "datavalue": "pan is invalid",
                            "dataType" : "text"
                        },
                        {
                            "@type": "variable",
                            "datavalue": "panObject",
                            "dataType" : "text"
                        },
                        {
                            "@type": "keyword",
                            "dataValue": "text",
                            "dataType": "text",
                            "keywordArguments": {
                                "format": "isNumber",
                                "init": {
                                    "value": "mobile"
                                }
                            }
                        },
                        {
                            "@type": "keyword",
                            "dataType": "number",
                            "dataValue": "number",
                            "keywordArguments": {
                                "init": {
                                    "value": "input"
                                },
                                "format": "toASCII"
                            }
                        },
                        {
                            "@type": "function",
                            "functionName": "encrypt",
                            "functionArguments": {
                                "value": "encrypt",
                                "encType": "AES"
                            },
                            "dataType" : "text"
                        }
                    ]
                }
            }
        ]
    }
}`

const LogStatementDebugLevelConfig = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "598163340749418",
                "@type": "LogStatement",
                "name": "AadharInformation",
                "log": {
                    "level": "DEBUG",
                    "messages": [
                        {
                            "@type": "literal",
                            "datavalue": "MobileNumber is invalid",
                            "dataType" : "text"

                        },
                        {
                            "@type": "variable",
                            "datavalue": "aadharObject",
                            "dataType" : "text"
                        },
                        {
                            "@type": "keyword",
                            "dataType": "number",
                            "dataValue": "text",
                            "keywordArguments": {
                                "init": {
                                    "value": "value"
                                },
                                "format": "toBoolean"
                            }
                        },
                        {
                            "@type": "keyword",
                            "dataType": "number",
                            "dataValue": "number",
                            "keywordArguments": {
                                "init": {
                                    "value": "inputValue"
                                },
                                "format": "ceil"
                            }
                        }
                    ]
                }
            }
        ]
    }
}`

const LogStatementTraceLevelConfig = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "598163340749418",
                "@type": "LogStatement",
                "name": "Registered AddressInformation",
                "log": {
                    "level": "TRACE",
                    "messages": [
                        {
                            "@type": "literal",
                            "datavalue": "Registered Address is Valid",
                            "dataType" : "text"
                        },
                        {
                            "@type": "variable",
                            "datavalue": "ResidentialObject",
                            "dataType" : "text"
                        },
                        {
                              "@type": "keyword",
                              "dataType": "text",
                              "dataValue": "text",
                              "keywordArguments": {
                                "format": "getNullValue"
                              }
                            },
                        {
                              "@type": "keyword",
                              "dataType": "number",
                              "dataValue": "number",
                              "keywordArguments": {
                                "init": {
                                  "value": "inputValue"
                                },
                                "format": "round"
                              }
                            }
                    ]
                }
            }
        ]
    }
}`

const LogStatementErrorLevelConfig = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "598163340749418",
                "@type": "LogStatement",
                "name": "ITRInformation",
                "log": {
                    "level": "ERROR",
                    "messages": [
                        {
                            "@type": "literal",
                            "datavalue": "Response can be transformed only for ITRType:1",
                            "dataType" : "text"
                        },
                        {
                            "@type": "variable",
                            "datavalue": "ITRObject",
                            "dataType" : "text"
                        },
                        {
                              "@type": "keyword",
                              "dataType": "number",
                              "dataValue": "boolean",
                              "keywordArguments": {
                                "init": {
                                  "value": "value"
                                },
                                "format": "toText"
                              }
                            },
                            {
                              "@type": "keyword",
                              "dataType": "number",
                              "dataValue": "list",
                              "keywordArguments": {
                                "init": {
                                  "value": "Key Value Array"
                                },
                                "format": "length"
                              }
                            }
                    ]
                }
            }
        ]
    }
}`

const LogStatementForOtherLevelConfig = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": "598163340749418",
                "@type": "LogStatement",
                "name": "productDetailsInformation",
                "log": {
                    "level": "WARNING",
                    "messages": [
                        {
                            "@type": "literal",
                            "datavalue": "productDetails saved successfully",
                            "dataType" : "text"
                        },
                        {
                            "@type": "variable",
                            "datavalue": "productDetails",
                            "dataType" : "text"
                        },
                        {
                            "@type": "keyword",
                            "dataType": "text",
                            "dataValue": "list",
                            "keywordArguments": {
                                "init": {
                                    "value": "productDetails"
                                },
                                "format": "pop"
                            }
                        },
                        {
                            "@type": "keyword",
                            "dataType": "number",
                            "dataValue": "number",
                            "keywordArguments": {
                                "init": {
                                    "value": "input1"
                                },
                                "format": "getDecimal"
                            }
                        }
                    ]
                }
            }
        ]
    }
}`

const LogStatementWithInvalidDataConfig = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
       {
    "id": "1727331876204202",
    "name": "CoatJoy",
    "@type": "LogStatement",
    "mandatory": true,
    "toogleSwitchValue": false,
    "log": {
        "level": "ERROR",
        "messages": [
            {
                "@type": "literal",
                "dataValue": "application Id is null, cannot check condition",
                "dataType": "text"
            },
            {
                "@type": "literal",
                "dataValue": "",
                "dataType": "text"
            },
            {
                "@type": "literal",
                "dataValue": "",
                "dataType": "text"
            },
            {
                "@type": "literal",
                "dataValue": "so we are not proceeding forward",
                "dataType": "text"
            }
        ]
    }
}]}}`
