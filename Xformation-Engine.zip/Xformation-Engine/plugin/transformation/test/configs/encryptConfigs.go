package configs 

const EncryptEncTypeIncorrect = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Angelo",
        "statements" : [ {
          "id" : "402735532358950",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "ABC",
                "encMode" : "CBC",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Giovani"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "402734422181016"
      },
      "id" : "402733121278340"
    } ]
  }
}`

const EncryptConfigDESCFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jazmin",
        "statements" : [ {
          "id" : "404948848824670",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "DES",
                "encMode" : "CFB",
                "iv" : "12345678",
                "encKey" : "1a2sd35f",
                "encodeType" : "Base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Ryley"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "404948325376867"
      },
      "id" : "404941453239644"
    } ]
  }
}`

const Encrypt3DESCFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gennaro",
        "statements" : [ {
          "id" : "407116644131043",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "3DES",
                "encodeType" : "Base64",
                "encKey" : "mysecretPasswordkeySiz24",
                "encMode" : "CFB",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Kaylie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "407112504055061"
      },
      "id" : "407117858705305"
    } ]
  }
}`

const Encrypt3DESCTR = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lucy",
        "statements" : [ {
          "id" : "408316200143704",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "3DES",
                "encodeType" : "Base64",
                "encKey" : "mysecretPasswordkeySiz24",
                "encMode" : "CTR",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Ed"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "408311304608605"
      },
      "id" : "408316368893637"
    } ]
  }
}`

const EncryptConfigDESCTR = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Marilou",
        "statements" : [ {
          "id" : "411258172234291",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "DES",
                "encMode" : "CTR",
                "iv" : "12345678",
                "encKey" : "1a2sd35f",
                "encodeType" : "Base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Nikita"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "411259213316592"
      },
      "id" : "411259777606053"
    } ]
  }
}`

const Encrypt3DESECB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jermaine",
        "statements" : [ {
          "id" : "413054633276069",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "3DES",
                "encodeType" : "Base64",
                "encKey" : "mysecretPasswordkeySiz24",
                "encMode" : "ECB",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Nicholas"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "413072283582103"
      },
      "id" : "413072707436347"
    } ]
  }
}`

const EncryptConfigDESECB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lenny",
        "statements" : [ {
          "id" : "414239259731366",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "DES",
                "encMode" : "ECB",
                "iv" : "12345678",
                "encKey" : "1a2sd35f",
                "encodeType" : "Base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Matteo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "414239427137606"
      },
      "id" : "414233512271186"
    } ]
  }
}`

const EncryptIVNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Thurman",
        "statements" : [ {
          "id" : "414969770206448",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "CTR",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Damion"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "414965312016888"
      },
      "id" : "414968872439675"
    } ]
  }
}`

const EncryptConfigAESGCM = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Queen",
        "statements" : [ {
          "id" : "415868590510787",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "GCM",
                "iv" : "123456789012",
                "encKey" : "AES256Key-32Characters1234567890",
                "encodeType" : "hex"
              },
              "dataType" : "text"
            }
          },
          "name" : "Roxanne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "415867485137734"
      },
      "id" : "415865734610433"
    } ]
  }
}`

const EncryptEncKeyIncorrect = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Eliza",
        "statements" : [ {
          "id" : "417259792239711",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "CTR",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b3426",
                "encodeType" : "Base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Easter"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "417254864495744"
      },
      "id" : "417255404000214"
    } ]
  }
}`

const EncryptEncModeNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jordy",
        "statements" : [ {
          "id" : "417835681063425",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Patsy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "417838198945450"
      },
      "id" : "417838299675563"
    } ]
  }
}`

const EncryptEncodeTypeNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Trystan",
        "statements" : [ {
          "id" : "418392287766778",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "OFB",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Mohamed"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "418397424890366"
      },
      "id" : "418396779103148"
    } ]
  }
}`

const TojsonConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transoformingToJson",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Berniece",
        "statements" : [ {
          "id" : "419204480111104",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptCFB",
                "decType" : "AES",
                "decMode" : "CFB",
                "iv" : "1234567890123456",
                "decKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Josianne"
        }, {
          "id" : "419595618869578",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toJson",
                "init" : {
                  "value" : "decryptValue@local"
                }
              }
            }
          },
          "name" : "Carter"
        }, {
          "id" : "420455251407913",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "decryptValue.appID@local",
              "dataType" : "text"
            }
          },
          "name" : "Brady"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "420453686886454"
      },
      "id" : "420468977024946"
    } ]
  }
}`

const EncryptConfigDESOFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lennie",
        "statements" : [ {
          "id" : "421732508063503",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "DES",
                "encMode" : "OFB",
                "iv" : "12345678",
                "encKey" : "1a2sd35f",
                "encodeType" : "Base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Billy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "421733401201674"
      },
      "id" : "421738061005317"
    } ]
  }
}`

const EncryptConfigAESCFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Don",
        "statements" : [ {
          "id" : "422776639838110",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "CFB",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Ulises"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "422774545388752"
      },
      "id" : "422776262500684"
    } ]
  }
}`

const EncryptConfigAESECB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Larissa",
        "statements" : [ {
          "id" : "423382194293116",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "ECB",
                "iv" : "1234567890123456",
                "encKey" : "AES256Key-32Characters1234567890"
              },
              "dataType" : "text"
            }
          },
          "name" : "Isaac"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "423381008664435"
      },
      "id" : "423381738033186"
    } ]
  }
}`

const EncryptConfigAESCTR = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Paige",
        "statements" : [ {
          "id" : "424159108731880",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "CTR",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Brooklyn"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "424155613179350"
      },
      "id" : "424155462156581"
    } ]
  }
}`

const EncryptConfigAESOFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Adeline",
        "statements" : [ {
          "id" : "424724321867242",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "OFB",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Bailee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "424725911494783"
      },
      "id" : "424728463516684"
    } ]
  }
}`

const EncryptAESGCMIncorrectIV = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lukas",
        "statements" : [ {
          "id" : "425042373802773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "GCM",
                "iv" : "1234567890123456",
                "encKey" : "AES256Key-32Characters1234567890",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Karl"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "425048123957016"
      },
      "id" : "425043208660505"
    } ]
  }
}`

const EncryptEncodeTypeIncorrect = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Alessandra",
        "statements" : [ {
          "id" : "425358468152818",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "CTR",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "encodeType" : "base"
              },
              "dataType" : "text"
            }
          },
          "name" : "Korey"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "425354996981987"
      },
      "id" : "425353952120986"
    } ]
  }
}`

const Encrypt3DESCBC = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Leanne",
        "statements" : [ {
          "id" : "425877079414591",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "3DES",
                "encodeType" : "Base64",
                "encKey" : "mysecretPasswordkeySiz24",
                "encMode" : "CBC",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Van"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "425874184304622"
      },
      "id" : "425872724090836"
    } ]
  }
}`

const EncryptConfigDESCBC = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Harry",
        "statements" : [ {
          "id" : "426198512225096",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "DES",
                "encMode" : "CBC",
                "iv" : "12345678",
                "encKey" : "1a2sd35f",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Fatima"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "426197267160320"
      },
      "id" : "426191658161905"
    } ]
  }
}`

const EncryptEncKeyNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Adelbert",
        "statements" : [ {
          "id" : "426536767375651",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "DES",
                "encMode" : "CTR",
                "iv" : "12345678",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Keeley"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "426537480744875"
      },
      "id" : "426536531907687"
    } ]
  }
}`

const EncryptEncModeIncorrect = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Devan",
        "statements" : [ {
          "id" : "426984359784449",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "ABC",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Amya"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "426987594196184"
      },
      "id" : "426983870550265"
    } ]
  }
}`

const EncryptIVIncorrect = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Wilton",
        "statements" : [ {
          "id" : "427439140723906",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "CTR",
                "iv" : "123456789012345678",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "encodeType" : "Base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Nettie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "427433421142262"
      },
      "id" : "427437771538625"
    } ]
  }
}`

const Encrypt3DESOFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Elmore",
        "statements" : [ {
          "id" : "427955843384680",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "3DES",
                "encodeType" : "Base64",
                "encKey" : "mysecretPasswordkeySiz24",
                "encMode" : "OFB",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Merritt"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "427954378970036"
      },
      "id" : "427958923991858"
    } ]
  }
}`

const EncryptEncTypeNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jennifer",
        "statements" : [ {
          "id" : "428473473145396",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encMode" : "CBC",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Maximus"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "428472218091354"
      },
      "id" : "428477000569857"
    } ]
  }
}`

const EncryptConfigAESCBC = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Faustino",
        "statements" : [ {
          "id" : "429297976087237",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "AES",
                "encMode" : "CBC",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Demetris"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "429295745547765"
      },
      "id" : "429292395324747"
    } ]
  }
}`

const EncryptDESGCM = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Pansy",
        "statements" : [ {
          "id" : "429914206419133",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "encrypt",
                "encType" : "DES",
                "encMode" : "GCM",
                "iv" : "12345678",
                "encKey" : "12345678",
                "encodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Mckayla"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "429916926369818"
      },
      "id" : "429915485038658"
    } ]
  }
}`

const TojsonConfigGetdata = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transoformingToJson",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Daniela",
        "statements" : [ {
          "id" : "430505059864417",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptCFB",
                "decType" : "AES",
                "decMode" : "CFB",
                "iv" : "1234567890123456",
                "decKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Brando"
        }, {
          "id" : "430758425843450",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "1stDecriptVlueFromPayload",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "decryptValue@local",
              "dataType" : "text"
            }
          },
          "name" : "Krystal"
        }, {
          "id" : "430948304620219",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decryptValueJson",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toJson",
                "init" : {
                  "value" : "decryptValue@local"
                }
              }
            }
          },
          "name" : "Claude"
        }, {
          "id" : "431145309286465",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValueJson",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "decryptValueJson@local",
              "dataType" : "text"
            }
          },
          "name" : "Armand"
        }, {
          "id" : "431304240294990",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encryptingThe1stDecryptedValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "encrypt",
              "functionArguments" : {
                "value" : "decryptValue@local",
                "encType" : "AES",
                "encMode" : "CFB",
                "iv" : "1234567890123456",
                "encKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Odessa"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "431309231056222"
      },
      "id" : "431306428262656"
    } ]
  }
}`

