package configs

const GetURLUrlWithurlPattern = ` {
        "version": 3.3,
        "@type": "transform",
        "transform": {
            "id": "transform_custodetails",
            "name": "Request payload Transformation",
            "statements": [
                {
                    "id": "1",
                    "@type": "AssignmentStatement",
                    "assignment": {
                        "@type": "SimpleAssignmentStatement",
                        "lhs": {
                            "@type": "declare",
                            "dataValue": "url",
                            "dataType": "text"
                        },
                        "operator": {
                            "actualValue": "="
                        },
                        "rhs": {
                            "@type": "literal",
                            "dataValue": "/posts/1",
                            "dataType": "text"
                        }
                    }
                },
                {
                    "id": "4",
                    "@type": "AssignmentStatement",
                    "assignment": {
                        "@type": "SimpleAssignmentStatement",
                        "lhs": {
                            "@type": "declare",
                            "dataValue": "headers.Accept",
                            "dataType": "text"
                        },
                        "operator": {
                            "actualValue": "="
                        },
                        "rhs": {
                            "@type": "literal",
                            "dataValue": "*/*",
                            "dataType": "text"
                        }
                    }
                },
                {
                    "id": "5",
                    "@type": "AssignmentStatement",
                    "assignment": {
                        "@type": "SimpleAssignmentStatement",
                        "lhs": {
                            "@type": "declare",
                            "dataValue": "response",
                            "dataType": "map"
                        },
                        "operator": {
                            "actualValue": "="
                        },
                        "rhs": {
                            "@type": "function",
                            "functionName": "apiRestCall",
                            "functionArguments": {
                                "host": "https://jsonplaceholder.typicode.com",
                                "urlPattern": "url@local",
                                "retriggerCount": "10",
                                "contentInputType": "json",
                                "contentOutputType": "json",
                                "headers": "headers@local",
                                "methodType": "GET",
                                "connectionTimeout": 60,
                                "readTimeout": 60,
                                "allowInsecureConnection": false
                            },
                            "dataType": "map"
                        }
                    }
                },
                {
                  "id": "4",
                  "@type": "AssignmentStatement",
                  "assignment": {
                      "@type": "SimpleAssignmentStatement",
                      "lhs": {
                          "@type": "keyword",
                          "dataValue": "none",
                          "dataType": "map"
                      },
                      "operator": {
                          "actualValue": "="
                      },
                      "rhs": {
                          "@type": "local",
                          "dataValue": "response.body",
                          "dataType": "map"
                      }
                  }
              }
            ]
        }
    }`

const GetURLWithoutUrlPattern = `{
        "version": 3.3,
        "@type": "transform",
        "transform": {
            "id": "transform_custodetails",
            "name": "Request payload Transformation",
            "statements": [
                
                {
                    "id": "4",
                    "@type": "AssignmentStatement",
                    "assignment": {
                        "@type": "SimpleAssignmentStatement",
                        "lhs": {
                            "@type": "declare",
                            "dataValue": "headers.Accept",
                            "dataType": "text"
                        },
                        "operator": {
                            "actualValue": "="
                        },
                        "rhs": {
                            "@type": "literal",
                            "dataValue": "*/*",
                            "dataType": "text"
                        }
                    }
                },
                {
                    "id": "5",
                    "@type": "AssignmentStatement",
                    "assignment": {
                        "@type": "SimpleAssignmentStatement",
                        "lhs": {
                            "@type": "declare",
                            "dataValue": "response",
                            "dataType": "map"
                        },
                        "operator": {
                            "actualValue": "="
                        },
                        "rhs": {
                            "@type": "function",
                            "functionName": "apiRestCall",
                            "functionArguments": {
                                "host": "https://jsonplaceholder.typicode.com/posts/1",
                                "contentInputType": "json",
                                "contentOutputType": "json",
                                "headers": "headers@local",
                                "methodType": "GET",
                                "connectionTimeout": 60,
                                "readTimeout": 60,
                                "allowInsecureConnection": false
                            },
                            "dataType": "map"
                        }
                    }
                },
                {
                  "id": "4",
                  "@type": "AssignmentStatement",
                  "assignment": {
                      "@type": "SimpleAssignmentStatement",
                      "lhs": {
                          "@type": "keyword",
                          "dataValue": "none",
                          "dataType": "map"
                      },
                      "operator": {
                          "actualValue": "="
                      },
                      "rhs": {
                          "@type": "local",
                          "dataValue": "response.body",
                          "dataType": "map"
                      }
                  }
              }
            ]
        }
    }
`

const GetURLWithError = ` {
        "version": 3.3,
        "@type": "transform",
        "transform": {
            "id": "transform_custodetails",
            "name": "Request payload Transformation",
            "statements": [
               
                {
                    "id": "1",
                    "@type": "AssignmentStatement",
                    "assignment": {
                        "@type": "SimpleAssignmentStatement",
                        "lhs": {
                            "@type": "declare",
                            "dataValue": "url",
                            "dataType": "text"
                        },
                        "operator": {
                            "actualValue": "="
                        },
                        "rhs": {
                            "@type": "literal",
                            "dataValue": "/get/1",
                            "dataType": "text"
                        }
                    }
                },
                {
                    "id": "4",
                    "@type": "AssignmentStatement",
                    "assignment": {
                        "@type": "SimpleAssignmentStatement",
                        "lhs": {
                            "@type": "declare",
                            "dataValue": "headers.Accept",
                            "dataType": "text"
                        },
                        "operator": {
                            "actualValue": "="
                        },
                        "rhs": {
                            "@type": "literal",
                            "dataValue": "*/*",
                            "dataType": "text"
                        }
                    }
                },
                {
                    "id": "5",
                    "@type": "AssignmentStatement",
                    "assignment": {
                        "@type": "SimpleAssignmentStatement",
                        "lhs": {
                            "@type": "declare",
                            "dataValue": "response",
                            "dataType": "map"
                        },
                        "operator": {
                            "actualValue": "="
                        },
                        "rhs": {
                            "@type": "function",
                            "functionName": "apiRestCall",
                            "functionArguments": {
                                "host": "https://jsonplaceholder.typicode.com",
                                "urlPattern": "url@local",
                                "retriggerCount": 0,
                                "contentInputType": "json",
                                "contentOutputType": "json",
                                "headers": "headers@local",
                                "methodType": "GET",
                                "connectionTimeout": 60,
                                "readTimeout": 60,
                                "allowInsecureConnection": false
                            },
                            "dataType": "map"
                        }
                    }
                },
                {
                  "id": "4",
                  "@type": "AssignmentStatement",
                  "assignment": {
                      "@type": "SimpleAssignmentStatement",
                      "lhs": {
                          "@type": "literal",
                          "dataValue": "response.error",
                          "dataType": "text"
                      },
                      "operator": {
                          "actualValue": "="
                      },
                      "rhs": {
                          "@type": "local",
                          "dataValue": "response.body",
                          "dataType": "text"
                      }
                  }
              }
            ]
        }
    }
`
const PostURL1 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "ONiwe",
        "statements" : [ {
          "id" : "597796947219737",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "value",
              "dataType" : "map"
            }
          },
          "name" : "cWFVO"
        }, {
          "@type" : "SectionalStatement",
          "section" : {
            "jsonIgnoreProperty" : false,
            "name" : "JdzLM",
            "statements" : [ {
              "assignment" : {
                "lhs" : {
                  "@type" : "declare",
                  "dataType" : "text",
                  "dataValue" : "postUrl"
                },
                "rhs" : {
                  "@type" : "literal",
                  "dataType" : "text",
                  "dataValue" : "https://dummyjson.com/products"
                },
                "operator" : {
                  "actualValue" : "="
                }
              },
              "@type" : "AssignmentStatement",
              "name" : "AxxIy",
              "id" : "597794556610393"
            }, {
              "id" : "597795105062221",
              "@type" : "AssignmentStatement",
              "assignment" : {
                "@type" : "SimpleAssignmentStatement",
                "lhs" : {
                  "@type" : "declare",
                  "dataValue" : "response",
                  "dataType" : "map"
                },
                "operator" : {
                  "actualValue" : "="
                },
                "rhs" : {
                  "functionName" : "apiRestCall",
                  "@type" : "function",
                  "dataType" : "map",
                  "functionArguments" : {
                    "contentInputType" : "json",
                    "contentOutputType" : "json",
                    "headers" : "headers@local",
                    "methodType" : "POST",
                    "body" : "body@local",
                    "connectionTimeout" : 60,
                    "readTimeout" : 60,
                    "allowInsecureConnection" : true,
                     "urlPattern" : "postUrl@local",
                    "host" : "https://dummyjson.com/products",
                    "retries" : 0
                  }
                }
              },
              "name" : "fFgCn"
            },
            {
              "id": "4",
              "@type": "AssignmentStatement",
              "assignment": {
                  "@type": "SimpleAssignmentStatement",
                  "lhs": {
                      "@type": "literal",
                      "dataValue": "response.errror",
                      "dataType": "text"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "local",
                      "dataValue": "response.body",
                      "dataType": "text"
                  }
              }
          } ],
            "jsonIgnoreAliasValue" : "",
            "id" : "597797614250163"
          },
          "id" : "597794168848594"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "597792717379980"
      },
      "id" : "597793052323295"
    } ]
  }
}`

const GetWithBodyUrl = `{
                          "version" : 3.3,
                          "@type" : "transform",
                          "transform" : {
                            "id" : "transform_custodetails",
                            "name" : "Request payload Transformation",
                            "statements" : [ {
                              "@type" : "SectionalStatement",
                              "section" : {
                                "jsonIgnoreProperty" : false,
                                "name" : "JIlcL",
                                "statements" : [ {
                                  "id" : "598151754895671",
                                  "@type" : "AssignmentStatement",
                                  "assignment" : {
                                    "@type" : "SimpleAssignmentStatement",
                                    "lhs" : {
                                      "@type" : "declare",
                                      "dataValue" : "body.q",
                                      "dataType" : "text"
                                    },
                                    "operator" : {
                                      "actualValue" : "="
                                    },
                                    "rhs" : {
                                      "@type" : "literal",
                                      "dataValue" : "Laptop",
                                      "dataType" : "text"
                                    }
                                  },
                                  "name" : "AWLkR"
                                }, {
                                  "id" : "598161382234241",
                                  "@type" : "AssignmentStatement",
                                  "assignment" : {
                                    "@type" : "SimpleAssignmentStatement",
                                    "lhs" : {
                                      "@type" : "declare",
                                      "dataValue" : "getUrl",
                                      "dataType" : "text"
                                    },
                                    "operator" : {
                                      "actualValue" : "="
                                    },
                                    "rhs" : {
                                      "@type" : "literal",
                                      "dataValue" : "https://dummyjson.com/products/search",
                                      "dataType" : "text"
                                    }
                                  },
                                  "name" : "hvLlV"
                                }, {
                                  "@type" : "SectionalStatement",
                                  "section" : {
                                    "jsonIgnoreProperty" : false,
                                    "name" : "xgKJE",
                                    "statements" : [ {
                                      "assignment" : {
                                        "lhs" : {
                                          "@type" : "declare",
                                          "dataType" : "text",
                                          "dataValue" : "getUrl"
                                        },
                                        "rhs" : {
                                          "@type" : "literal",
                                          "dataType" : "text",
                                          "dataValue" : "https://dummyjson.com/products/search"
                                        },
                                        "operator" : {
                                          "actualValue" : "="
                                        }
                                      },
                                      "@type" : "AssignmentStatement",
                                      "name" : "NTQMs",
                                      "id" : "598166943926820"
                                    }, {
                                      "id" : "598163340749418",
                                      "@type" : "AssignmentStatement",
                                      "assignment" : {
                                        "@type" : "SimpleAssignmentStatement",
                                        "lhs" : {
                                          "@type" : "declare",
                                          "dataValue" : "response",
                                          "dataType" : "map"
                                        },
                                        "operator" : {
                                          "actualValue" : "="
                                        },
                                        "rhs" : {
                                          "functionName" : "apiRestCall",
                                          "@type" : "function",
                                          "dataType" : "map",
                                          "functionArguments" : {
                                            "host" : "https://dummyjson.com/products/search",
                                            "contentInputType" : "json",
                                            "contentOutputType" : "json",
                                            "headers" : "headers@local",
                                            "methodType" : "GET",
                                            "body" : "body@local",
                                            "connectionTimeout" : 60,
                                            "readTimeout" : 60,
                                            "allowInsecureConnection" : true,
                                            "retries" : 0
                                          }
                                        }
                                      },
                                      "name" : "cDZVZ"
                                    } ,
                                    {
                                      "id": "4",
                                      "@type": "AssignmentStatement",
                                      "assignment": {
                                          "@type": "SimpleAssignmentStatement",
                                          "lhs": {
                                              "@type": "literal",
                                              "dataValue": "statusCode",
                                              "dataType": "text"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          },
                                          "rhs": {
                                              "@type": "local",
                                              "dataValue": "response.statusCode",
                                              "dataType": "text"
                                          }
                                      }
                                  }],
                                    "jsonIgnoreAliasValue" : "",
                                    "id" : "598167369408744"
                                  },
                                  "id" : "598167671624410"
                                } ],
                                "jsonIgnoreAliasValue" : null,
                                "id" : "598167842524391"
                              },
                              "id" : "598165480122834"
                            } ]
                          }
                        }`

const CustomHeaders = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "JIlcL",
                  "statements": [
                      {
                          "id": "598151754895671",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "declare",
                                  "dataValue": "body.q",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataValue": "Laptop",
                                  "dataType": "text"
                              }
                          },
                          "name": "AWLkR"
                      },
                      {
                          "id": "598161382234241",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "declare",
                                  "dataValue": "getUrl",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataValue": "https://dummyjson.com/products/search",
                                  "dataType": "text"
                              }
                          },
                          "name": "hvLlV"
                      },
                      {
                          "@type": "SectionalStatement",
                          "section": {
                              "jsonIgnoreProperty": false,
                              "name": "xgKJE",
                              "statements": [
                                  {
                                      "assignment": {
                                          "lhs": {
                                              "@type": "declare",
                                              "dataType": "text",
                                              "dataValue": "getUrl"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "https://dummyjson.com/products/search"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      },
                                      "@type": "AssignmentStatement",
                                      "name": "NTQMs",
                                      "id": "598166943926820"
                                  },
                                  {
                                      "id": "598163340749418",
                                      "@type": "AssignmentStatement",
                                      "assignment": {
                                          "@type": "SimpleAssignmentStatement",
                                          "lhs": {
                                              "@type": "declare",
                                              "dataValue": "response",
                                              "dataType": "map"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          },
                                          "rhs": {
                                              "functionName": "apiRestCall",
                                              "@type": "function",
                                              "dataType": "map",
                                              "functionArguments": {
                                                  "host": "https://dummyjson.com/products/search",
                                                  "contentInputType": "json",
                                                  "contentOutputType": "json",
                                                  "headers": "headers@local",
                                                  "customHeaders": {
                                                    "content-type": "application/json"
                                                 },
                                                  "methodType": "GET",
                                                  "body": "body@local",
                                                  "connectionTimeout": 60,
                                                  "readTimeout": 60,
                                                  "allowInsecureConnection": true,
                                                  "retries": 0
                                              }
                                          }
                                      },
                                      "name": "cDZVZ"
                                  },
                                  {
                                    "id": "4",
                                    "@type": "AssignmentStatement",
                                    "assignment": {
                                        "@type": "SimpleAssignmentStatement",
                                        "lhs": {
                                            "@type": "literal",
                                            "dataValue": "statusCode",
                                            "dataType": "text"
                                        },
                                        "operator": {
                                            "actualValue": "="
                                        },
                                        "rhs": {
                                            "@type": "local",
                                            "dataValue": "response.statusCode",
                                            "dataType": "text"
                                        }
                                    }
                                }
                              ],
                              "jsonIgnoreAliasValue": "",
                              "id": "598167369408744"
                          },
                          "id": "598167671624410"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "598167842524391"
              },
              "id": "598165480122834"
          }
      ]
  }
}`

const ConsumingResponseHeaders = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "JIlcL",
                  "statements": [
                      {
                          "id": "598151754895671",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "declare",
                                  "dataValue": "body.q",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataValue": "Laptop",
                                  "dataType": "text"
                              }
                          },
                          "name": "AWLkR"
                      },
                     
                      {
                          "@type": "SectionalStatement",
                          "section": {
                              "jsonIgnoreProperty": false,
                              "name": "xgKJE",
                              "statements": [
                                 
                                  {
                                      "id": "598163340749418",
                                      "@type": "AssignmentStatement",
                                      "assignment": {
                                          "@type": "SimpleAssignmentStatement",
                                          "lhs": {
                                              "@type": "declare",
                                              "dataValue": "response",
                                              "dataType": "map"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          },
                                          "rhs": {
                                              "functionName": "apiRestCall",
                                              "@type": "function",
                                              "dataType": "map",
                                              "functionArguments": {
                                                  "host": "https://dummyjson.com/products/search",
                                                  "contentInputType": "json",
                                                  "contentOutputType": "json",
                                                  "headers": "headers@local",
                                                  "customHeaders": {
                                                    "content-type": "application/json"
                                                 },
                                                  "methodType": "GET",
                                                  "body": "body@local",
                                                  "connectionTimeout": 60,
                                                  "readTimeout": 60,
                                                  "allowInsecureConnection": true,
                                                  "retries": 0
                                              }
                                          }
                                      },
                                      "name": "cDZVZ"
                                  },
                                {
                                  "assignment": {
                                      "lhs": {
                                          "@type": "literal",
                                          "dataType": "text",
                                          "dataValue": "Vary"
                                      },
                                      "rhs": {
                                          "@type": "local",
                                          "dataType": "text",
                                          "dataValue": "response.headers.Vary"
                                      },
                                      "operator": {
                                          "actualValue": "="
                                      }
                                  },
                                  "@type": "AssignmentStatement",
                                  "name": "NTQMs",
                                  "id": "598166943926820"
                              },
                              {
                                "assignment": {
                                    "lhs": {
                                        "@type": "literal",
                                        "dataType": "text",
                                        "dataValue": "statusCode"
                                    },
                                    "rhs": {
                                        "@type": "local",
                                        "dataType": "text",
                                        "dataValue": "response.statusCode"
                                    },
                                    "operator": {
                                        "actualValue": "="
                                    }
                                },
                                "@type": "AssignmentStatement",
                                "name": "NTQMs",
                                "id": "598166943926820"
                            },
                            {
                              "assignment": {
                                  "lhs": {
                                      "@type": "literal",
                                      "dataType": "text",
                                      "dataValue": "error"
                                  },
                                  "rhs": {
                                      "@type": "local",
                                      "dataType": "text",
                                      "dataValue": "response.error"
                                  },
                                  "operator": {
                                      "actualValue": "="
                                  }
                              },
                              "@type": "AssignmentStatement",
                              "name": "NTQMs",
                              "id": "598166943926820"
                          } 
                                 
                              ],
                              "jsonIgnoreAliasValue": "",
                              "id": "598167369408744"
                          },
                          "id": "598167671624410"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "598167842524391"
              },
              "id": "598165480122834"
          }
      ]
  }
}`

const AddingAPICallRespHeadersIntoMainHostHeaders = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "@type": "SectionalStatement",
                "section": {
                    "jsonIgnoreProperty": false,
                    "name": "JIlcL",
                    "statements": [
                        {
                            "id": "598151754895671",
                            "@type": "AssignmentStatement",
                            "assignment": {
                                "@type": "SimpleAssignmentStatement",
                                "lhs": {
                                    "@type": "declare",
                                    "dataValue": "body.q",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "="
                                },
                                "rhs": {
                                    "@type": "literal",
                                    "dataValue": "Laptop",
                                    "dataType": "text"
                                }
                            },
                            "name": "AWLkR"
                        },
                        {
                            "@type": "SectionalStatement",
                            "section": {
                                "jsonIgnoreProperty": false,
                                "name": "xgKJE",
                                "statements": [
                                    {
                                        "id": "598163340749418",
                                        "@type": "AssignmentStatement",
                                        "assignment": {
                                            "@type": "SimpleAssignmentStatement",
                                            "lhs": {
                                                "@type": "declare",
                                                "dataValue": "response",
                                                "dataType": "map"
                                            },
                                            "operator": {
                                                "actualValue": "="
                                            },
                                            "rhs": {
                                                "functionName": "apiRestCall",
                                                "@type": "function",
                                                "dataType": "map",
                                                "functionArguments": {
                                                    "host": "https://dummyjson.com/products/search",
                                                    "contentInputType": "json",
                                                    "contentOutputType": "json",
                                                    "headers": "headers@local",
                                                    "customHeaders": {
                                                        "content-type": "application/json"
                                                    },
                                                    "methodType": "GET",
                                                    "body": "body@local",
                                                    "connectionTimeout": 60,
                                                    "readTimeout": 60,
                                                    "allowInsecureConnection": true,
                                                    "retries": 0
                                                }
                                            }
                                        },
                                        "name": "cDZVZ"
                                    },
                                    {
                                        "assignment": {
                                            "lhs": {
                                                "@type": "declare",
                                                "dataType": "text",
                                                "dataValue": "respHeaders"
                                            },
                                            "rhs": {
                                                "@type": "local",
                                                "dataType": "text",
                                                "dataValue": "response.headers"
                                            },
                                            "operator": {
                                                "actualValue": "="
                                            }
                                        },
                                        "@type": "AssignmentStatement",
                                        "name": "NTQMs",
                                        "id": "598166943926820"
                                    },
                                    {
                                        "assignment": {
                                            "lhs": {
                                                "@type": "declare",
                                                "dataType": "text",
                                                "dataValue": "respHeaders.person"
                                            },
                                            "rhs": {
                                                "@type": "literal",
                                                "dataType": "text",
                                                "dataValue": "javeed"
                                            },
                                            "operator": {
                                                "actualValue": "="
                                            }
                                        },
                                        "@type": "AssignmentStatement",
                                        "name": "NTQMs",
                                        "id": "598166943926820"
                                    },
                                    {
                                        "assignment": {
                                            "lhs": {
                                                "@type": "literal",
                                                "dataType": "text",
                                                "dataValue": "respHeaders.person"
                                            },
                                            "rhs": {
                                                "@type": "local",
                                                "dataType": "text",
                                                "dataValue": "respHeaders.person"
                                            },
                                            "operator": {
                                                "actualValue": "="
                                            }
                                        },
                                        "@type": "AssignmentStatement",
                                        "name": "NTQMs",
                                        "id": "598166943926820"
                                    }
                                ],
                                "jsonIgnoreAliasValue": "",
                                "id": "598167369408744"
                            },
                            "id": "598167671624410"
                        }
                    ],
                    "jsonIgnoreAliasValue": null,
                    "id": "598167842524391"
                },
                "id": "598165480122834"
            }
        ]
    }
}`

const ConnectionSSL = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "@type": "SectionalStatement",
                "section": {
                    "jsonIgnoreProperty": false,
                    "name": "JIlcL",
                    "statements": [
                        {
                            "id": "598151754895671",
                            "@type": "AssignmentStatement",
                            "assignment": {
                                "@type": "SimpleAssignmentStatement",
                                "lhs": {
                                    "@type": "declare",
                                    "dataValue": "body.name",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "="
                                },
                                "rhs": {
                                    "@type": "literal",
                                    "dataValue": "javeed",
                                    "dataType": "text"
                                }
                            },
                            "name": "AWLkR"
                        },
                        {
                            "@type": "SectionalStatement",
                            "section": {
                                "jsonIgnoreProperty": false,
                                "name": "xgKJE",
                                "statements": [
                                    {
                                        "id": "598163340749418",
                                        "@type": "AssignmentStatement",
                                        "assignment": {
                                            "@type": "SimpleAssignmentStatement",
                                            "lhs": {
                                                "@type": "keyword",
                                                "dataValue": "none",
                                                "dataType": "map"
                                            },
                                            "operator": {
                                                "actualValue": "="
                                            },
                                            "rhs": {
                                                "functionName": "apiRestCall",
                                                "@type": "function",
                                                "dataType": "map",
                                                "functionArguments": {
                                                    "host": "https://192.168.7.48:8080/simple/getDetails",
                                                    "contentInputType": "json",
                                                    "contentOutputType": "json",
                                                    "headers": "headers@local",
                                                    "customHeaders": {
                                                        "content-type": "application/json"
                                                    },
                                                    "methodType": "POST",
                                                    "body": "body@local",
                                                    "connectionTimeout": 60,
                                                    "readTimeout": 60,
                                                    "allowInsecureConnection": false,
                                                    "retries": 0
                                                }
                                            }
                                        },
                                        "name": "cDZVZ"
                                    }
                                ]
                            }
                        }
                    ],
                    "jsonIgnoreAliasValue": null,
                    "id": "598167842524391"
                },
                "id": "598165480122834"
            }
        ]
    }
}`

const TestUrlEncodedRequestForSimpleJsonCallConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": "140094318218249",
        "name": "FzeXv",
        "@type": "AssignmentStatement",
        "mandatory": true,
        "assignment": {
          "lhs": {
            "@type": "declare",
            "dataType": "text",
            "dataValue": "body.title"
          },
          "rhs": {
            "@type": "literal",
            "dataType": "text",
            "dataValue": "Akash Singla"
          },
          "operator": {
            "actualValue": "="
          }
        }
      },
      {
        "id": "140094318218249",
        "name": "FzeXv",
        "@type": "AssignmentStatement",
        "mandatory": true,
        "assignment": {
          "lhs": {
            "@type": "declare",
            "dataType": "text",
            "dataValue": "body.email"
          },
          "rhs": {
            "@type": "literal",
            "dataType": "text",
            "dataValue": "john.doe@example.com"
          },
          "operator": {
            "actualValue": "="
          }
        }
      },
      {
        "id": "140092537612759",
        "@type": "AssignmentStatement",
        "assignment": {
          "lhs": {
            "@type": "declare",
            "dataType": "text",
            "dataValue": "bodyUrl"
          },
          "operator": {
            "actualValue": "="
          },
          "rhs": {
            "@type": "literal",
            "dataType": "text",
            "dataValue": "/posts"
          }
        },
        "name": "PmGVm"
      },
                        {
                          "id": "140094318218249",
                          "name": "FzeXv",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "headers.Content-Type"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "application/json"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": false,
          "name": "pFgYQ",
          "statements": [
            {
              "id": "140152471712151",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "declare",
                  "dataType": "map",
                  "dataValue": "ResponseTotal"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "functionName": "apiRestCall",
                  "@type": "function",
                  "dataType": "map",
                  "functionArguments": {
                    "host": "https://jsonplaceholder.typicode.com",
                    "contentInputType": "form-urlencoded",
                    "contentOutputType": "json",
                    "headers": "headers@local",
                    "methodType": "POST",
                    "body": "body@local",
                    "connectionTimeout": 60,
                    "readTimeout": 60,
                    "allowInsecureConnection": true,
                    "urlPattern": "bodyUrl@local",
                    "retries": 0
                  }
                }
              },
              "name": "sWVyw"
            },
            {
              "id": "140092537612759",
              "@type": "AssignmentStatement",
              "assignment": {
                "lhs": {
                  "@type": "literal",
                  "dataType": "text",
                  "dataValue": "response"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "local",
                  "dataType": "text",
                  "dataValue": "ResponseTotal.body"
                }
              },
              "name": "PmGVm"
            }
          ],
          "jsonIgnoreAliasValue": "",
          "id": "140153156905413"
        },
        "id": "140158842146635"
      }
    ]
  }
}`
