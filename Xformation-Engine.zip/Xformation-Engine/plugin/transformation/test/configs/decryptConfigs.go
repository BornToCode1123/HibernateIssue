package configs

const DecryptConfigAESCBC = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Orlo",
        "statements" : [ {
          "id" : "530478251176079",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptCBC",
                "decType" : "AES",
                "decMode" : "CBC",
                "iv" : "1234567890123456",
                "decKey" : "abc&1*~#^2^#s0^=)^^7%b34",
                "decodeType" : "base64"
              },
              "dataType" : "text"
            }
          },
          "name" : "Abraham"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "530481940425754"
      },
      "id" : "530485444536037"
    } ]
  }
}`

const DecryptDecTypeNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jadon",
        "statements" : [ {
          "id" : "532518822567480",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCTR",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "CTR",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Edyth"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "532516200882620"
      },
      "id" : "532514761339917"
    } ]
  }
}`

const DecryptAESGCMIncorrectIV = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Nasir",
        "statements" : [ {
          "id" : "535021791749421",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptAESGCM",
                "decType" : "AES",
                "decMode" : "GCM",
                "decodeType" : "hex",
                "iv" : "123456789000",
                "decKey" : "AES256Key-32Characters1234567890"
              },
              "dataType" : "text"
            }
          },
          "name" : "Hilma"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "535022834536445"
      },
      "id" : "535021253674318"
    } ]
  }
}`

const DecryptConfigDESCFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Leopold",
        "statements" : [ {
          "id" : "536236298516460",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptDESCFB",
                "decType" : "DES",
                "decMode" : "CFB",
                "iv" : "12345678",
                "decKey" : "1a2sd35f"
              },
              "dataType" : "text"
            }
          },
          "name" : "Amelie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "536236903124437"
      },
      "id" : "536233714796025"
    } ]
  }
}`

const DecryptConfigDESCTR = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Deanna",
        "statements" : [ {
          "id" : "537204892238582",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptDESCTR",
                "decType" : "DES",
                "decMode" : "CTR",
                "iv" : "12345678",
                "decKey" : "1a2sd35f"
              },
              "dataType" : "text"
            }
          },
          "name" : "Earl"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "537202799253908"
      },
      "id" : "537209952689195"
    } ]
  }
}`

const DecryptConfig3DESCBC = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lysanne",
        "statements" : [ {
          "id" : "538089317164280",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCBC",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "CBC",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Mayra"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "538087272640027"
      },
      "id" : "538087584366900"
    } ]
  }
}`

const DecryptConfigDESCBC = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Josiane",
        "statements" : [ {
          "id" : "538922463908155",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptDESCBC",
                "decType" : "DES",
                "decMode" : "CBC",
                "iv" : "12345678",
                "decKey" : "1a2sd35f"
              },
              "dataType" : "text"
            }
          },
          "name" : "Jalyn"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "538929707858824"
      },
      "id" : "538928719387022"
    } ]
  }
}`

const DecryptConfigAESGCM = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Alvena",
        "statements" : [ {
          "id" : "539626402846322",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptAESGCM",
                "decType" : "AES",
                "decMode" : "GCM",
                "decodeType" : "hex",
                "iv" : "123456789012",
                "decKey" : "AES256Key-32Characters1234567890"
              },
              "dataType" : "text"
            }
          },
          "name" : "Idell"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "539623090585481"
      },
      "id" : "539623818002490"
    } ]
  }
}`

const abc = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Bridie",
        "statements" : [ {
          "id" : "540292068996473",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCTR",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "CTR",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Elmira"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "540296980662783"
      },
      "id" : "540292533046107"
    } ]
  }
}`

const DecryptDecKeyNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Zackary",
        "statements" : [ {
          "id" : "540976013249715",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCTR",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decMode" : "CTR",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Vivianne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "540973151710034"
      },
      "id" : "540973052215126"
    } ]
  }
}`

const DecryptConfigAESOFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gracie",
        "statements" : [ {
          "id" : "541458460670985",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptOFB",
                "decType" : "AES",
                "decMode" : "OFB",
                "iv" : "1234567890123456",
                "decKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Sadie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "541451970035209"
      },
      "id" : "541454920313782"
    } ]
  }
}`

const DecryptIVIncorrect = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gene",
        "statements" : [ {
          "id" : "541869065583407",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptECB",
                "decType" : "AES",
                "decMode" : "ECB",
                "iv" : "12345",
                "decKey" : "AES256Key-32Characters1234567890"
              },
              "dataType" : "text"
            }
          },
          "name" : "Glenda"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "541869526271650"
      },
      "id" : "541861781087639"
    } ]
  }
}`

const DecryptDESGCM = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Maud",
        "statements" : [ {
          "id" : "542441166371682",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptAESGCM",
                "decType" : "DES",
                "decMode" : "GCM",
                "decodeType" : "hex",
                "iv" : "123456789012",
                "decKey" : "AES256Key-32Characters1234567890"
              },
              "dataType" : "text"
            }
          },
          "name" : "Willard"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "542441866018235"
      },
      "id" : "542444768681940"
    } ]
  }
}`

const DecryptConfigAESCFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Zetta",
        "statements" : [ {
          "id" : "543159538330391",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptCFB",
                "decType" : "AES",
                "decMode" : "CFB",
                "iv" : "1234567890123456",
                "decKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Else"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "543153024030944"
      },
      "id" : "543156686422053"
    } ]
  }
}`

const DecryptIVNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Trever",
        "statements" : [ {
          "id" : "543839899121371",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCTR",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "CTR"
              },
              "dataType" : "text"
            }
          },
          "name" : "Richmond"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "543832686050031"
      },
      "id" : "543831762348824"
    } ]
  }
}`

const DecryptConfigAESECB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Daisy",
        "statements" : [ {
          "id" : "544353552835555",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptECB",
                "decType" : "AES",
                "decMode" : "ECB",
                "iv" : "1234567890123456",
                "decKey" : "AES256Key-32Characters1234567890"
              },
              "dataType" : "text"
            }
          },
          "name" : "Moses"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "544352613767694"
      },
      "id" : "544352380686894"
    } ]
  }
}`

const DecryptConfigAESCTR = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Percival",
        "statements" : [ {
          "id" : "544743028087871",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptCTR",
                "decType" : "AES",
                "decMode" : "CTR",
                "iv" : "1234567890123456",
                "decKey" : "abc&1*~#^2^#s0^=)^^7%b34"
              },
              "dataType" : "text"
            }
          },
          "name" : "Arno"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "544746410929887"
      },
      "id" : "544745726704171"
    } ]
  }
}`

const DecryptConfig3DESECB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kurt",
        "statements" : [ {
          "id" : "545126709230776",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESECB",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "ECB",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Elena"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "545123107555288"
      },
      "id" : "545129448130840"
    } ]
  }
}`

const DecryptConfig3DESCFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Monica",
        "statements" : [ {
          "id" : "545471275441458",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCFB",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "CFB",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Ariel"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "545474188175970"
      },
      "id" : "545473456821774"
    } ]
  }
}`

const DecryptConfig3DESCTR = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Dallas",
        "statements" : [ {
          "id" : "545734156085653",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCTR",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "CTR",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Sylvester"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "545739241678929"
      },
      "id" : "545838766776497"
    } ]
  }
}`

const DecryptConfigDESOFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Rocky",
        "statements" : [ {
          "id" : "546264077134964",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptDESOFB",
                "decType" : "DES",
                "decMode" : "OFB",
                "iv" : "12345678",
                "decKey" : "1a2sd35f"
              },
              "dataType" : "text"
            }
          },
          "name" : "Paris"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "546264398692045"
      },
      "id" : "546269531392686"
    } ]
  }
}`

const DecryptConfig3DESOFB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lonzo",
        "statements" : [ {
          "id" : "546776186351137",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESOFB",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "OFB",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Bobbie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "546772242488013"
      },
      "id" : "546775976557827"
    } ]
  }
}`

const DecryptConfigDESECB = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Astrid",
        "statements" : [ {
          "id" : "547084340264916",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptDESECB",
                "decType" : "DES",
                "decMode" : "ECB",
                "iv" : "12345678",
                "decKey" : "1a2sd35f"
              },
              "dataType" : "text"
            }
          },
          "name" : "Jeromy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "547086695908733"
      },
      "id" : "547083301158062"
    } ]
  }
}`

const DecryptIncorrectEncKey = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Eldora",
        "statements" : [ {
          "id" : "547568595533034",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decryptDESCTR",
                "decType" : "DES",
                "decMode" : "CTR",
                "iv" : "12345600",
                "decKey" : "1a2sd358"
              },
              "dataType" : "text"
            }
          },
          "name" : "Brody"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "547565490913521"
      },
      "id" : "547569363986251"
    } ]
  }
}`

const DecryptDecodeTypeNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Michelle",
        "statements" : [ {
          "id" : "547882400702967",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCTR",
                "decType" : "3DES",
                "decKey" : "mysecretPasswordkeySiz24",
                "decMode" : "CTR",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Richmond"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "547888312706417"
      },
      "id" : "547883283447660"
    } ]
  }
}`

const DecryptDecModeNotGiven = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Antone",
        "statements" : [ {
          "id" : "548348618617849",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "decrypt",
              "functionArguments" : {
                "value" : "decrypt3DESCBC",
                "decType" : "3DES",
                "decodeType" : "Base64",
                "decKey" : "mysecretPasswordkeySiz24",
                "iv" : "12345678"
              },
              "dataType" : "text"
            }
          },
          "name" : "Jose"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "548348594191826"
      },
      "id" : "548342177419074"
    } ]
  }
}`
