package configs 

const LowerConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Remington",
        "statements" : [ {
          "id" : "623611346633795",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toLowerCase",
                "init" : {
                  "value" : "firstName"
                }
              }
            }
          },
          "name" : "Danial"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "623614092545244"
      },
      "id" : "623611121043507"
    } ]
  }
}`

const LowerNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Rahul",
        "statements" : [ {
          "id" : "625541207982364",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Name",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "toLowerCase",
                "init" : {
                  "value" : "experience"
                }
              }
            }
          },
          "name" : "Fritz"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "625547681282317"
      },
      "id" : "625548532481438"
    } ]
  }
}`

const LocalLowerConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Justus",
        "statements" : [ {
          "id" : "626542562222620",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "firstName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toLowerCase",
                "init" : {
                  "value" : "firstName"
                }
              }
            }
          },
          "name" : "Myles"
        }, {
          "id" : "627008191168365",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "LowerLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "firstName@local",
              "dataType" : "text"
            }
          },
          "name" : "Keenan"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "627008836588856"
      },
      "id" : "627008507876180"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

