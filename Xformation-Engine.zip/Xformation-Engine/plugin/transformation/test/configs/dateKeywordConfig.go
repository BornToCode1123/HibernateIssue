package configs

const DateKeyword3Config = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ozzie",
        "statements" : [ {
          "id" : "284003704930113",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "sanctionDate",
              "dataType" : "date"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "format" : "dd-MM-yyyy",
                "init" : {
                  "value" : "monthName",
                  "format" : "unixTime"
                }
              }
            }
          },
          "name" : "Kasandra"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "284008217515759"
      },
      "id" : "284001964947608"
    } ]
  }
}`

const DateKeyword2Config = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Alayna",
        "statements" : [ {
          "id" : "285954929088451",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataType" : "date",
              "dataValue" : "convertedDate"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "format" : "MMM yyyy",
                "init" : {
                  "value" : "startDate",
                  "format" : "dd-MM-yyyy"
                }
              }
            }
          },
          "name" : "Jayde"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "285958636999492"
      },
      "id" : "285956476380040"
    } ]
  }
}`

const LocalDateKeywordConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Immanuel",
        "statements" : [ {
          "id" : "287224645061835",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "month",
              "dataType" : "date"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "format" : "unixTime",
                "init" : {
                  "value" : "month1",
                  "format" : "MMM-yy"
                }
              }
            }
          },
          "name" : "Raymond"
        }, {
          "id" : "288124962408877",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "date local",
              "dataType" : "date"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "month@local",
              "dataType" : "date"
            }
          },
          "name" : "Kody"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "288125189041012"
      },
      "id" : "288121780816945"
    } ]
  }
}`

const DateWithNullValue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [
      {
        "id": "106355439029029",
        "@type": "AssignmentStatement",
        "assignment": {
            "@type": "SimpleAssignmentStatement",
            "lhs": {
                "@type": "declare",
                "dataValue": "previous3Months",
                "dataType": "number"
            },
            "operator": {
                "actualValue": "="
            },
            "rhs": {
                "@type": "literal",
                "dataValue": "-3",
                "dataType": "number"
            }
        },
        "name": "Gregg"
    }, {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Aileen",
        "statements" : [ {
          "id" : "290076996213223",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataType" : "date",
              "dataValue" : "convertedDate"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "format" : "MMM yyyy",
                "value" : "previous3Months@local",
                "type" : "month",
                "init" : {
                  "value" : "krakend",
                  "format" : "dd-MM-yyyy"
                }
              }
            }
          },
          "name" : "Eugene"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "290077076995250"
      },
      "id" : "290075785662588"
    } ]
  }
}`

const TestCurrentDate = `{
  "version" : "1",
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lauren",
        "statements" : [ {
          "id" : "291175901744285",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "date"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date"
            }
          },
          "name" : "Rigoberto"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "291171991801065"
      },
      "id" : "291179932250088"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const DateFromatForMonth = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Abbigail",
        "statements" : [ {
          "id" : "292163122820526",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataType" : "date",
              "dataValue" : "formattedMonth"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "format" : "MMMM",
                "init" : {
                  "value" : "startDate",
                  "format" : "dd-MM-yyyy"
                }
              }
            }
          },
          "name" : "Maude"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "292169117656891"
      },
      "id" : "292163415918098"
    } ]
  }
}`

const DateKeywordConfig = `{
  "version" : 1,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "transform cibilresponse for Grid",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Orpha",
        "statements" : [ {
          "id" : "293354512093394",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "AdditionalDetails",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "transform communication for Grid",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Rachel",
                        "statements" : [ {
                          "id" : "293317699569963",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "detailedDate",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataValue" : "date",
                              "dataType" : "date",
                              "keywordArguments" : {
                                "format" : "dd-MM-yyyy",
                                "init" : {
                                  "value" : "monthName",
                                  "format" : "MMM-yy"
                                }
                              }
                            }
                          },
                          "name" : "Garry"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "293356102361653"
                      },
                      "id" : "293354144793827"
                    } ]
                  },
                  "value" : "AdditionalSalariedMonthlyDetails"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Keeley"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "293354346544944"
      },
      "id" : "293355555446653"
    } ]
  }
}`

const DateKeyword1Config = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ethel",
        "statements" : [ {
          "id" : "293979634426513",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "month",
              "dataType" : "date"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "format" : "unixTime",
                "init" : {
                  "value" : "month1",
                  "format" : "MMM-yy"
                }
              }
            }
          },
          "name" : "Michale"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "293979507056190"
      },
      "id" : "293974920738049"
    } ]
  }
}`

const UnixDateFormatter = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Cornell",
                  "statements": [
                      {
                          "id": "294571530298959",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataType": "date",
                                  "dataValue": "tenure"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "date",
                                  "dataValue": "1"
                              }
                          },
                          "name": "Edd"
                      },
                     
                      {
                          "id": "294788128634351",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "lhs": {
                                  "@type": "literal",
                                  "dataType": "date",
                                  "dataValue": "monthYear"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataValue": "date",
                                  "dataType": "date",
                                  "keywordArguments": {
                                      "type": "month",
                                      "format": "dd-MM-yyyy",
                                      "init": {
                                          "value": "unixTime",
                                          "format": "unixTime"
                                      },
                                      "value": "tenure@local"
                                  }
                              }
                          },
                          "name": "Stan"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "294786024263009"
              },
              "id": "294784266216375"
          }
      ]
  }
}`

const IncreasingAllDatesFormats = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "294571530298959",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "declare",
                      "dataType": "date",
                      "dataValue": "tenure"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "2"
                  }
              },
              "name": "Edd"
          },
          {
              "id": "294788128634351",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "increasedmonthDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataValue": "date",
                      "dataType": "date",
                      "keywordArguments": {
                          "type": "month",
                          "format": "dd-MM-yyyy",
                          "init": {
                              "value": "FYDate",
                              "format": "dd-MM-yyyy"
                          },
                          "value": "tenure@local",
                          "includeDifference": true
                      }
                  }
              },
              "name": "Stan"
          },
          {
              "id": "294788128634351",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "increasedYearDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataValue": "date",
                      "dataType": "date",
                      "keywordArguments": {
                          "type": "year",
                          "format": "dd-MM-yyyy",
                          "init": {
                              "value": "FYDate",
                              "format": "dd-MM-yyyy"
                          },
                          "value": "tenure@local",
                          "includeDifference": true
                      }
                  }
              },
              "name": "Stan"
          },
          {
              "id": "294788128634351",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "increasedDayDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataValue": "date",
                      "dataType": "date",
                      "keywordArguments": {
                          "type": "day",
                          "format": "dd-MM-yyyy",
                          "init": {
                              "value": "FYDate",
                              "format": "dd-MM-yyyy"
                          },
                          "value": "tenure@local",
                          "includeDifference": true
                      }
                  }
              },
              "name": "Stan"
          },
          {
              "id": "294571530298959",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "actualDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "variable",
                      "dataType": "date",
                      "dataValue": "FYDate"
                  }
              },
              "name": "Edd"
          }
      ]
  }
}`

const IncreasingDay = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "294571530298959",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "declare",
                      "dataType": "date",
                      "dataValue": "tenure"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "0"
                  }
              },
              "name": "Edd"
          },
          {
              "id": "294788128634351",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "increasedDayDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataValue": "date",
                      "dataType": "date",
                      "keywordArguments": {
                          "format": "dd-MM-yyyy",
                          "init": {
                              "value": "FYDate",
                              "format": "dd-MM-yyyy"
                          }
                      }
                  }
              },
              "name": "Stan"
          },
          {
              "id": "294571530298959",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "actualDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "variable",
                      "dataType": "date",
                      "dataValue": "FYDate"
                  }
              },
              "name": "Edd"
          }
      ]
  }
}`

const GetLastDate = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "294788128634351",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "lastDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataValue": "date",
                      "dataType": "date",
                      "keywordArguments": {
                          "format": "getLastDate",
                          "type": "day",
                          "init": {
                              "value": "FYDate",
                              "format": "dd-MM-yyyy"
                          }
                      }
                  }
              },
              "name": "Stan"
          }
      ]
  }
}`

const IncreasingHoursConfig = `{
  "id": 616155157541644,
  "name": "first",
  "@type": "transform",
  "debug": false,
  "errors": {
      "id": 616155157541644,
      "name": "ErrorStatement",
      "statements": [
          {
              "id": 616546648887650,
              "name": "STATEMENT 616331973634827",
              "@type": "SectionalStatement",
              "section": {
                  "id": 616337300338837,
                  "name": "SECTION Statement 616337300338837",
                  "statements": [],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
          }
      ],
      "jsonIgnoreProperty": false
  },
  "headers": {},
  "version": 6,
  "transform": {
      "id": 616155157541644,
      "name": "first",
      "statements": [
          {
              "id": 1718015436566553,
              "name": "SchoolWake",
              "@type": "SectionalStatement",
              "section": {
                  "id": 658352497766325,
                  "name": "SECTION Statement 85038",
                  "statements": [
                      {
                          "id": 1727355598385683,
                          "name": "TeamBrake",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataType": "date",
                                  "dataValue": "plusValue"
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "date",
                                  "dataValue": "2"
                              },
                              "operator": {
                                  "actualValue": "="
                              }
                          }
                      },
                      {
                          "id": 1727694313890636,
                          "name": "StaffBulk",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataType": "text",
                                  "dataValue": "hour"
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "text",
                                  "dataValue": "12:58 AM"
                              },
                              "operator": {
                                  "actualValue": "="
                              }
                          }
                      },
                      {
                          "id": 1727694453394639,
                          "name": "BombLoss",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                              "lhs": {
                                  "@type": "literal",
                                  "dataType": "text",
                                  "dataValue": "hourIncrease"
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataType": "text",
                                  "dataValue": "date",
                                  "keywordArguments": {
                                      "init": {
                                          "value": "hour@local",
                                          "format": "K:mm a"
                                      },
                                      "type": "hour",
                                      "value": "plusValue@local",
                                      "format": "K:mm a"
                                  }
                              },
                              "operator": {
                                  "actualValue": "="
                              }
                          }
                      }
                  ]
              }
          }
      ]
  }
}`

const IncreasingHoursConfig1 = `{
  "id": 616155157541644,
  "name": "first",
  "@type": "transform",
  "debug": false,
  "errors": {
    "id": 616155157541644,
    "name": "ErrorStatement",
    "statements": [
      {
        "id": 616546648887650,
        "name": "STATEMENT 616331973634827",
        "@type": "SectionalStatement",
        "section": {
          "id": 616337300338837,
          "name": "SECTION Statement 616337300338837",
          "statements": [],
          "jsonIgnoreProperty": false
        },
        "mandatory": true
      }
    ],
    "jsonIgnoreProperty": false
  },
  "headers": {},
  "version": 6,
  "transform": {
    "id": 616155157541644,
    "name": "first",
    "statements": [
      {
        "id": 1718015436566553,
        "name": "SchoolWake",
        "@type": "SectionalStatement",
        "section": {
          "id": 658352497766325,
          "name": "SECTION Statement 85038",
          "statements": [
            {
              "id": 1727961245554613,
              "name": "SmoothPen",
              "@type": "SectionalStatement",
              "section": {
                "id": 725498551192415,
                "name": "SECTION Statement 960740",
                "statements": [
                  {
                    "id": 1727961347859707,
                    "name": "SmoothDrop",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "declare",
                        "dataType": "text",
                        "dataValue": "plusValue"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "12"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  },
                  {
                    "id": 1727979917377019,
                    "name": "ChinCold",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "declare",
                        "dataType": "text",
                        "dataValue": "hourValue2"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "23:58:59"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  },
                  {
                    "id": 1727979839747464,
                    "name": "ShelfTruth",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "hourIncrease4"
                      },
                      "rhs": {
                        "@type": "keyword",
                        "dataType": "text",
                        "dataValue": "date",
                        "keywordArguments": {
                          "init": {
                            "value": "hourValue2@local",
                            "format": "HH:mm:ss"
                          },
                          "type": "hour",
                          "value": "plusValue@local",
                          "format": "HH:mm:ss"
                        }
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false
        },
        "mandatory": true
      }
    ],
    "jsonIgnoreProperty": false
  },
  "contentInputType": "json",
  "ignoreNullFields": false,
  "contentOutputType": "json"
}`

const IncreasingHoursConfig2 = `{
   "id": 616155157541644,
  "name": "first",
  "@type": "transform",
  "debug": false,
  "errors": {
      "id": 616155157541644,
     "name": "ErrorStatement",
      "statements": [
          {
              "id": 616546648887650,
              "name": "STATEMENT 616331973634827",
              "@type": "SectionalStatement",
              "section": {
                   "id": 616337300338837,
                   "name": "SECTION Statement 616337300338837",
                  "statements": [],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
           }
       ],
     "jsonIgnoreProperty": false
   },
  "headers": {},
  "version": 6,
   "transform": {
      "id": 616155157541644,
      "name": "first",
      "statements": [
          {
              "id": 1718015436566553,
              "name": "SchoolWake",
              "@type": "SectionalStatement",
              "section": {
                  "id": 658352497766325,
                  "name": "SECTION Statement 85038",
                  "statements": [
                      {
                          "id": 1727961245554613,
                          "name": "SmoothPen",
                          "@type": "SectionalStatement",
                          "section": {
                              "id": 725498551192415,
                              "name": "SECTION Statement 960740",
                              "statements": [
                                  {
                                      "id": 1727961347859707,
                                      "name": "SmoothDrop",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "declare",
                                              "dataType": "text",
                                              "dataValue": "plusValue"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "24"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                         }
                                     }
                                 },
                                 {
                                     "id": 1727977724256751,
                                     "name": "LaunchButt",
                                     "@type": "AssignmentStatement",
                                     "mandatory": true,
                                     "assignment": {
                                           "lhs": {
                                               "@type": "declare",
                                               "dataType": "text",
                                              "dataValue": "hourValue"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                               "dataValue": "12:58:59 PM"
                                           },
                                           "operator": {
                                               "actualValue": "="
                                           }
                                       }
                                   },
                                   {
                                       "id": 1727977672891090,
                                       "name": "HarshJob",
                                       "@type": "AssignmentStatement",
                                       "mandatory": true,
                                       "assignment": {
                                           "lhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "hourIncrease3"
                                         },
                                         "rhs": {
                                              "@type": "keyword",
                                              "dataType": "text",
                                               "dataValue": "date",
                                              "keywordArguments": {
                                                  "init": {
                                                       "value": "hourValue@local",
                                                       "format": "KK:mm:ss a"
                                                   },
                                                   "type": "hour",
                                                   "value": "plusValue@local",
                                                   "format": "KK:mm:ss a"
                                               }
                                           },
                                           "operator": {
                                               "actualValue": "="
                                           }
                                       }
                                   }
                               ],
                               "jsonIgnoreProperty": false
                           },
                           "mandatory": true
                       }
                   ],
                   "jsonIgnoreProperty": false
               },
               "mandatory": true
           }
       ],
       "jsonIgnoreProperty": false
  },
  "contentInputType": "json",
  "ignoreNullFields": false,
  "contentOutputType": "json"
}`

const IncreasingHoursConfig3 = `{
  "id": 616155157541644,
  "name": "first",
  "@type": "transform",
  "debug": false,
  "errors": {
      "id": 616155157541644,
      "name": "ErrorStatement",
      "statements": [
          {
              "id": 616546648887650,
              "name": "STATEMENT 616331973634827",
              "@type": "SectionalStatement",
              "section": {
                  "id": 616337300338837,
                  "name": "SECTION Statement 616337300338837",
                  "statements": [],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
          }
      ],
      "jsonIgnoreProperty": false
  },
  "headers": {},
  "version": 6,
  "transform": {
      "id": 616155157541644,
      "name": "first",
      "statements": [
          {
              "id": 1718015436566553,
              "name": "SchoolWake",
              "@type": "SectionalStatement",
              "section": {
                  "id": 658352497766325,
                  "name": "SECTION Statement 85038",
                  "statements": [
                      {
                          "id": 1727961245554613,
                          "name": "SmoothPen",
                          "@type": "SectionalStatement",
                          "section": {
                              "id": 725498551192415,
                              "name": "SECTION Statement 960740",
                              "statements": [
                                  {
                                      "id": 1727961347859707,
                                      "name": "SmoothDrop",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "declare",
                                              "dataType": "text",
                                              "dataValue": "plusValue"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "-10"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  },
                                  {
                                      "id": 1727961294447648,
                                      "name": "GuardFool",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "declare",
                                              "dataType": "text",
                                              "dataValue": "hour"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "23:58"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  },
                                  {
                                      "id": 1727977606039286,
                                      "name": "LensPool",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "hourIncrease2"
                                          },
                                          "rhs": {
                                              "@type": "keyword",
                                              "dataType": "text",
                                              "dataValue": "date",
                                              "keywordArguments": {
                                                  "init": {
                                                      "value": "hour@local",
                                                      "format": "HH:mm"
                                                  },
                                                  "type": "hour",
                                                  "value": "plusValue@local",
                                                  "format": "HH:mm"
                                              }
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  }
                              ],
                              "jsonIgnoreProperty": false
                          },
                          "mandatory": true
                      }
                  ],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
          }
      ],
      "jsonIgnoreProperty": false
  },
  "contentInputType": "json",
  "ignoreNullFields": false,
  "contentOutputType": "json"
}`

const IncreasingHoursConfig4 = `{
  "id": 616155157541644,
  "name": "first",
  "@type": "transform",
  "debug": false,
  "errors": {
      "id": 616155157541644,
      "name": "ErrorStatement",
      "statements": [
          {
              "id": 616546648887650,
              "name": "STATEMENT 616331973634827",
              "@type": "SectionalStatement",
              "section": {
                  "id": 616337300338837,
                  "name": "SECTION Statement 616337300338837",
                  "statements": [],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
          }
      ],
      "jsonIgnoreProperty": false
  },
  "headers": {},
  "version": 6,
  "transform": {
      "id": 616155157541644,
      "name": "first",
      "statements": [
          {
              "id": 1718015436566553,
              "name": "SchoolWake",
              "@type": "SectionalStatement",
              "section": {
                  "id": 658352497766325,
                  "name": "SECTION Statement 85038",
                  "statements": [
                      {
                          "id": 1727355598385683,
                          "name": "TeamBrake",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataType": "date",
                                  "dataValue": "plusValue"
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "date",
                                  "dataValue": "0"
                              },
                              "operator": {
                                  "actualValue": "="
                              }
                          }
                      },
                      {
                          "id": 1727694313890636,
                          "name": "StaffBulk",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataType": "text",
                                  "dataValue": "hour"
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "text",
                                  "dataValue": "12:58 AM"
                              },
                              "operator": {
                                  "actualValue": "="
                              }
                          }
                      },
                      {
                          "id": 1727694453394639,
                          "name": "BombLoss",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                              "lhs": {
                                  "@type": "literal",
                                  "dataType": "text",
                                  "dataValue": "hourIncrease"
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataType": "text",
                                  "dataValue": "date",
                                  "keywordArguments": {
                                      "init": {
                                          "value": "hour@local",
                                          "format": "K:mm a"
                                      },
                                      "type": "hour",
                                      "value": "plusValue@local",
                                      "format": "K:mm a"
                                  }
                              },
                              "operator": {
                                  "actualValue": "="
                              }
                          }
                      }
                  ]
              }
          }
      ]
  }
}`

const IncreasingHoursConfig5 = `{
  "id": 616155157541644,
  "name": "first",
  "@type": "transform",
  "debug": false,
  "errors": {
      "id": 616155157541644,
      "name": "ErrorStatement",
      "statements": [
          {
              "id": 616546648887650,
              "name": "STATEMENT 616331973634827",
              "@type": "SectionalStatement",
              "section": {
                  "id": 616337300338837,
                  "name": "SECTION Statement 616337300338837",
                  "statements": [],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
          }
      ],
      "jsonIgnoreProperty": false
  },
  "headers": {},
  "version": 6,
  "transform": {
      "id": 616155157541644,
      "name": "first",
      "statements": [
          {
              "id": 1718015436566553,
              "name": "SchoolWake",
              "@type": "SectionalStatement",
              "section": {
                  "id": 658352497766325,
                  "name": "SECTION Statement 85038",
                  "statements": [
                      {
                          "id": 1727961245554613,
                          "name": "SmoothPen",
                          "@type": "SectionalStatement",
                          "section": {
                              "id": 725498551192415,
                              "name": "SECTION Statement 960740",
                              "statements": [
                                  {
                                      "id": 1727961347859707,
                                      "name": "SmoothDrop",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "declare",
                                              "dataType": "text",
                                              "dataValue": "plusValue"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "720"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  },
                                  {
                                      "id": 1727961294447648,
                                      "name": "GuardFool",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "declare",
                                              "dataType": "text",
                                              "dataValue": "hour"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "31 Dec 1998 23:58:59"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  },
                                  {
                                      "id": 1727961231545672,
                                      "name": "ChipClerk",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "hourIncrease"
                                          },
                                          "rhs": {
                                              "@type": "keyword",
                                              "dataType": "text",
                                              "dataValue": "date",
                                              "keywordArguments": {
                                                  "init": {
                                                      "value": "hour@local",
                                                      "format": "d MMM yyyy HH:mm:ss"
                                                  },
                                                  "type": "minute",
                                                  "value": "plusValue@local",
                                                  "format": "d MMM yyyy HH:mm:ss"
                                              }
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  }
                              ],
                              "jsonIgnoreProperty": false
                          },
                          "mandatory": true
                      }
                  ],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
          }
      ],
      "jsonIgnoreProperty": false
  },
  "contentInputType": "json",
  "ignoreNullFields": false,
  "contentOutputType": "json"
}`

const IncreasingMinute = `{
              "id": 205711074769176,
              "name": "req",
              "@type": "transform",
              "debug": false,
              "errors": {
                "id": 205711074769176,
                "name": "ErrorStatement",
                "statements": [
                  {
                    "id": 206303809198894,
                    "name": "STATEMENT 205933314794781",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 205942408117277,
                      "name": "SECTION Statement 205942408117277",
                      "statements": [],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "headers": {},
              "version": 3,
              "transform": {
                "id": 205711074769176,
                "name": "req",
                "statements": [
                  {
                    "id": 1728278073602530,
                    "name": "RodTrend",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 252876937894003,
                      "name": "SECTION Statement 429952",
                      "statements": [
                        {
                          "id": 1728278085291157,
                          "name": "ToughFlour",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "minuteInput"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "31 Dec 1998 23:58:59"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1728278191260150,
                          "name": "SkillBall",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "minuteValueIncrease"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "720"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1728278183502727,
                          "name": "DraftLake",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "minuteIncrease"
                            },
                            "rhs": {
                              "@type": "keyword",
                              "dataType": "text",
                              "dataValue": "date",
                              "keywordArguments": {
                                "init": {
                                  "value": "minuteInput@local",
                                  "format": "d MMM yyyy HH:mm:ss"
                                },
                                "type": "minute",
                                "value": "minuteValueIncrease@local",
                                "format": "d MMM yyyy HH:mm:ss"
                              }
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        }
                      ],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "contentInputType": "json",
              "ignoreNullFields": false,
              "contentOutputType": "json"
            }`

const IncreasingMinuteConfig = `{
              "id": 616155157541644,
              "name": "first",
              "@type": "transform",
              "debug": false,
              "errors": {
                "id": 616155157541644,
                "name": "ErrorStatement",
                "statements": [
                  {
                    "id": 616546648887650,
                    "name": "STATEMENT 616331973634827",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 616337300338837,
                      "name": "SECTION Statement 616337300338837",
                      "statements": [],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "headers": {},
              "version": 6,
              "transform": {
                "id": 616155157541644,
                "name": "first",
                "statements": [
                  {
                    "id": 1718015436566553,
                    "name": "SchoolWake",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 658352497766325,
                      "name": "SECTION Statement 85038",
                      "statements": [
                        {
                                      "id": 1727949897328504,
                                      "name": "TrustSake",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                        "lhs": {
                                          "@type": "declare",
                                          "dataType": "text",
                                          "dataValue": "minute"
                                        },
                                        "rhs": {
                                          "@type": "literal",
                                          "dataType": "text",
                                          "dataValue": "50"
                                        },
                                        "operator": {
                                          "actualValue": "="
                                        }
                                      }
                                    },
                                    {
                                      "id": 1727950163571635,
                                      "name": "DraftBank",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                        "lhs": {
                                          "@type": "declare",
                                          "dataType": "text",
                                          "dataValue": "minuteInput"
                                        },
                                        "rhs": {
                                          "@type": "literal",
                                          "dataType": "text",
                                          "dataValue": "12:10"
                                        },
                                        "operator": {
                                          "actualValue": "="
                                        }
                                      }
                                    },
                                    {
                                      "id": 1727950048184971,
                                      "name": "LeftCream",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                        "lhs": {
                                          "@type": "literal",
                                          "dataType": "text",
                                          "dataValue": "minuteIncrease"
                                        },
                                        "rhs": {
                                          "@type": "keyword",
                                          "dataType": "text",
                                          "dataValue": "date",
                                          "keywordArguments": {
                                            "init": {
                                              "value": "minuteInput@local",
                                              "format": "HH:mm"
                                            },
                                            "type": "minute",
                                            "value": "minute@local",
                                            "format": "HH:mm"
                                          }
                                        },
                                        "operator": {
                                          "actualValue": "="
                                        }
                                      }
                                    }
                                  ],
                                  "jsonIgnoreProperty": false
                                },
                                "mandatory": true
                              }
                            ],
                            "jsonIgnoreProperty": false
                          },
                          "contentInputType": "json",
                          "ignoreNullFields": false,
                          "contentOutputType": "json"
                        }`

const IncreasingMinuteConfig1 = `{
                          "id": 616155157541644,
                          "name": "first",
                          "@type": "transform",
                          "debug": false,
                          "errors": {
                            "id": 616155157541644,
                            "name": "ErrorStatement",
                            "statements": [
                              {
                                "id": 616546648887650,
                                "name": "STATEMENT 616331973634827",
                                "@type": "SectionalStatement",
                                "section": {
                                  "id": 616337300338837,
                                  "name": "SECTION Statement 616337300338837",
                                  "statements": [],
                                  "jsonIgnoreProperty": false
                                },
                                "mandatory": true
                              }
                            ],
                            "jsonIgnoreProperty": false
                          },
                          "headers": {},
                          "version": 6,
                          "transform": {
                            "id": 616155157541644,
                            "name": "first",
                            "statements": [
                              {
                                "id": 1718015436566553,
                                "name": "SchoolWake",
                                "@type": "SectionalStatement",
                                "section": {
                                  "id": 658352497766325,
                                  "name": "SECTION Statement 85038",
                                  "statements": [
                                    {
                                      "id": 1728014832720452,
                                      "name": "StairAd",
                                      "@type": "SectionalStatement",
                                      "section": {
                                        "id": 114838672046371,
                                        "name": "SECTION Statement 56547",
                                        "statements": [
                                          {
                                            "id": 1728014908016626,
                                            "name": "ClayLoop",
                                            "@type": "AssignmentStatement",
                                            "mandatory": true,
                                            "assignment": {
                                              "lhs": {
                                                "@type": "declare",
                                                "dataType": "text",
                                                "dataValue": "plusValue"
                                              },
                                              "rhs": {
                                                "@type": "literal",
                                                "dataType": "text",
                                                "dataValue": "20"
                                              },
                                              "operator": {
                                                "actualValue": "="
                                              }
                                            }
                                          },
                                          {
                                            "id": 1728014921612828,
                                            "name": "PoorStrain",
                                            "@type": "AssignmentStatement",
                                            "mandatory": true,
                                            "assignment": {
                                              "lhs": {
                                                "@type": "declare",
                                                "dataType": "text",
                                                "dataValue": "minuteInput1"
                                              },
                                              "rhs": {
                                                "@type": "literal",
                                                "dataType": "text",
                                                "dataValue": "12:58 PM"
                                              },
                                              "operator": {
                                                "actualValue": "="
                                              }
                                            }
                                          },
                                          {
                                            "id": 1728014927267443,
                                            "name": "BigFat",
                                            "@type": "AssignmentStatement",
                                            "mandatory": true,
                                            "assignment": {
                                              "lhs": {
                                                "@type": "literal",
                                                "dataType": "text",
                                                "dataValue": "minuteIncrease1"
                                              },
                                              "rhs": {
                                                "@type": "keyword",
                                                "dataType": "text",
                                                "dataValue": "date",
                                                "keywordArguments": {
                                                  "init": {
                                                    "value": "minuteInput1@local",
                                                    "format": "K:mm a"
                                                  },
                                                  "type": "minute",
                                                  "value": "plusValue@local",
                                                  "format": "K:mm a"
                                                }
                                              },
                                              "operator": {
                                                "actualValue": "="
                                              }
                                            }
                                          }]}}]}}]}}`
const IncreasingMinuteConfig2 = `{
                                            "id": 616155157541644,
                                            "name": "first",
                                            "@type": "transform",
                                            "debug": false,
                                            "errors": {
                                              "id": 616155157541644,
                                              "name": "ErrorStatement",
                                              "statements": [
                                                {
                                                  "id": 616546648887650,
                                                  "name": "STATEMENT 616331973634827",
                                                  "@type": "SectionalStatement",
                                                  "section": {
                                                    "id": 616337300338837,
                                                    "name": "SECTION Statement 616337300338837",
                                                    "statements": [],
                                                    "jsonIgnoreProperty": false
                                                  },
                                                  "mandatory": true
                                                }
                                              ],
                                              "jsonIgnoreProperty": false
                                            },
                                            "headers": {},
                                            "version": 6,
                                            "transform": {
                                              "id": 616155157541644,
                                              "name": "first",
                                              "statements": [
                                                {
                                                  "id": 1718015436566553,
                                                  "name": "SchoolWake",
                                                  "@type": "SectionalStatement",
                                                  "section": {
                                                    "id": 658352497766325,
                                                    "name": "SECTION Statement 85038",
                                                    "statements": [
                                                      {
                                                        "id": 1728014832720452,
                                                        "name": "StairAd",
                                                        "@type": "SectionalStatement",
                                                        "section": {
                                                          "id": 114838672046371,
                                                          "name": "SECTION Statement 56547",
                                                          "statements": [
                                                            {
                                                              "id": 1728014908016626,
                                                              "name": "ClayLoop",
                                                              "@type": "AssignmentStatement",
                                                              "mandatory": true,
                                                              "assignment": {
                                                                "lhs": {
                                                                  "@type": "declare",
                                                                  "dataType": "text",
                                                                  "dataValue": "plusValue"
                                                                },
                                                                "rhs": {
                                                                  "@type": "literal",
                                                                  "dataType": "text",
                                                                  "dataValue": "20"
                                                                },
                                                                "operator": {
                                                                  "actualValue": "="
                                                                }
                                                              }
                                                            },
                                                            {
                                                              "id": 1728015012217383,
                                                              "name": "AdRun",
                                                              "@type": "AssignmentStatement",
                                                              "mandatory": true,
                                                              "assignment": {
                                                                "lhs": {
                                                                  "@type": "declare",
                                                                  "dataType": "text",
                                                                  "dataValue": "minuteInput2"
                                                                },
                                                                "rhs": {
                                                                  "@type": "literal",
                                                                  "dataType": "text",
                                                                  "dataValue": "12:58:59 PM"
                                                                },
                                                                "operator": {
                                                                  "actualValue": "="
                                                                }
                                                              }
                                                            },
                                                            {
                                                              "id": 1728015025709763,
                                                              "name": "BidCode",
                                                              "@type": "AssignmentStatement",
                                                              "mandatory": true,
                                                              "assignment": {
                                                                "lhs": {
                                                                  "@type": "literal",
                                                                  "dataType": "text",
                                                                  "dataValue": "minuteIncrease2"
                                                                },
                                                                "rhs": {
                                                                  "@type": "keyword",
                                                                  "dataType": "text",
                                                                  "dataValue": "date",
                                                                  "keywordArguments": {
                                                                    "init": {
                                                                      "value": "minuteInput2@local",
                                                                      "format": "KK:mm:ss a"
                                                                    },
                                                                    "type": "minute",
                                                                    "value": "plusValue@local",
                                                                    "format": "KK:mm:ss a"
                                                                  }
                                                                },
                                                                "operator": {
                                                                  "actualValue": "="
                                                                }
                                                              }
                                                            }
                                                          ],
                                                          "jsonIgnoreProperty": false
                                                        },
                                                        "mandatory": true
                                                      }]}}]}}`

const IncreasingMinuteConfig3 = `{
  "id": 616155157541644,
  "name": "first",
  "@type": "transform",
  "debug": false,
  "errors": {
    "id": 616155157541644,
    "name": "ErrorStatement",
    "statements": [
      {
        "id": 616546648887650,
        "name": "STATEMENT 616331973634827",
        "@type": "SectionalStatement",
        "section": {
          "id": 616337300338837,
          "name": "SECTION Statement 616337300338837",
          "statements": [],
          "jsonIgnoreProperty": false
        },
        "mandatory": true
      }
    ],
    "jsonIgnoreProperty": false
  },
  "headers": {},
  "version": 6,
  "transform": {
    "id": 616155157541644,
    "name": "first",
    "statements": [
      {
        "id": 1718015436566553,
        "name": "SchoolWake",
        "@type": "SectionalStatement",
        "section": {
          "id": 658352497766325,
          "name": "SECTION Statement 85038",
          "statements": [
            {
              "id": 1728014832720452,
              "name": "StairAd",
              "@type": "SectionalStatement",
              "section": {
                "id": 114838672046371,
                "name": "SECTION Statement 56547",
                "statements": [
                  {
                    "id": 1728014908016626,
                    "name": "ClayLoop",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "declare",
                        "dataType": "text",
                        "dataValue": "plusValue"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "20"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  },
                  {
                    "id": 1728015066719461,
                    "name": "NoonGlobe",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "declare",
                        "dataType": "text",
                        "dataValue": "minuteInput3"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "23:58:59"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  },
                  {
                    "id": 1728015182174101,
                    "name": "ToeMoon",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "minuteIncrease3"
                      },
                      "rhs": {
                        "@type": "keyword",
                        "dataType": "text",
                        "dataValue": "date",
                        "keywordArguments": {
                          "init": {
                            "value": "minuteInput3@local",
                            "format": "HH:mm:ss"
                          },
                          "type": "minute",
                          "value": "plusValue@local",
                          "format": "HH:mm:ss"
                        }
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "mandatory": true
            }
          ]
        }
      }
    ]
  }
}`

const IncreaseDaysWithHours = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
          {
              "id": "294571530298959",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "declare",
                      "dataType": "date",
                      "dataValue": "tenure"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "2"
                  }
              },
              "name": "Edd"
          },
          {
              "id": "294788128634351",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "increasedDayDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "keyword",
                      "dataValue": "date",
                      "dataType": "date",
                      "keywordArguments": {
                          "type": "day",
                          "format": "yyyy-MM-dd HH:mm:ss",
                          "init": {
                              "value": "dateOfJoining",
                              "format": "yyyy-MM-dd HH:mm:ss"
                          },
                          "value": "tenure@local",
                          "includeDifference": true
                      }
                  }
              },
              "name": "Stan"
          },
          {
              "id": "294571530298959",
              "@type": "AssignmentStatement",
              "assignment": {
                  "lhs": {
                      "@type": "literal",
                      "dataType": "date",
                      "dataValue": "actualDate"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "variable",
                      "dataType": "date",
                      "dataValue": "dateOfJoining"
                  }
              },
              "name": "Edd"
          }
      ]
  }
}`

const IncreasingDayAndHour = `{
              "id": 205711074769176,
              "name": "req",
              "@type": "transform",
              "debug": false,
              "errors": {
                "id": 205711074769176,
                "name": "ErrorStatement",
                "statements": [
                  {
                    "id": 206303809198894,
                    "name": "STATEMENT 205933314794781",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 205942408117277,
                      "name": "SECTION Statement 205942408117277",
                      "statements": [],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "headers": {},
              "version": 3,
              "transform": {
                "id": 205711074769176,
                "name": "req",
                "statements": [
                  {
                    "id": 1728278073602530,
                    "name": "RodTrend",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 252876937894003,
                      "name": "SECTION Statement 429952",
                      "statements": [
                        {
                          "id": 1729572958746774,
                          "name": "CalmBlow",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "dayInput"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "31 Dec 1998 23:58:59"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1729573203974067,
                          "name": "LotRest",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "dayIncreaseValue"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "2"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1729573303143652,
                          "name": "FloodPhone",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "IncreasedDay"
                            },
                            "rhs": {
                              "@type": "keyword",
                              "dataType": "text",
                              "dataValue": "date",
                              "keywordArguments": {
                                "init": {
                                  "value": "dayInput@local",
                                  "format": "d MMM yyyy HH:mm:ss"
                                },
                                "type": "day",
                                "value": "dayIncreaseValue@local",
                                "format": "d MMM yyyy HH:mm:ss"
                              }
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        }
                      ],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "contentInputType": "json",
              "ignoreNullFields": false,
              "contentOutputType": "json"
            }`
const IncreasingMonth = `{
              "id": 205711074769176,
              "name": "req",
              "@type": "transform",
              "debug": false,
              "errors": {
                "id": 205711074769176,
                "name": "ErrorStatement",
                "statements": [
                  {
                    "id": 206303809198894,
                    "name": "STATEMENT 205933314794781",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 205942408117277,
                      "name": "SECTION Statement 205942408117277",
                      "statements": [],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "headers": {},
              "version": 3,
              "transform": {
                "id": 205711074769176,
                "name": "req",
                "statements": [
                  {
                    "id": 1728278073602530,
                    "name": "RodTrend",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 252876937894003,
                      "name": "SECTION Statement 429952",
                      "statements": [
                        {
                          "id": 1729572958746774,
                          "name": "CalmBlow",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "monthInput"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "31 Dec 1998 23:58:59"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1729573203974067,
                          "name": "LotRest",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "monthIncreaseValue"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "2"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1729573303143652,
                          "name": "FloodPhone",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "Increasedmonth"
                            },
                            "rhs": {
                              "@type": "keyword",
                              "dataType": "text",
                              "dataValue": "date",
                              "keywordArguments": {
                                "init": {
                                  "value": "monthInput@local",
                                  "format": "d MMM yyyy HH:mm:ss"
                                },
                                "type": "month",
                                "value": "monthIncreaseValue@local",
                                "format": "d MMM yyyy HH:mm:ss"
                              }
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        }
                      ],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "contentInputType": "json",
              "ignoreNullFields": false,
              "contentOutputType": "json"
            }`
const IncreasingYear = `{
              "id": 205711074769176,
              "name": "req",
              "@type": "transform",
              "debug": false,
              "errors": {
                "id": 205711074769176,
                "name": "ErrorStatement",
                "statements": [
                  {
                    "id": 206303809198894,
                    "name": "STATEMENT 205933314794781",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 205942408117277,
                      "name": "SECTION Statement 205942408117277",
                      "statements": [],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "headers": {},
              "version": 3,
              "transform": {
                "id": 205711074769176,
                "name": "req",
                "statements": [
                  {
                    "id": 1728278073602530,
                    "name": "RodTrend",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 252876937894003,
                      "name": "SECTION Statement 429952",
                      "statements": [
                        {
                          "id": 1729572958746774,
                          "name": "CalmBlow",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "yearInput"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "31 Dec 1998 23:58:59"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1729573203974067,
                          "name": "LotRest",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "yearIncreaseValue"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "2"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1729573303143652,
                          "name": "FloodPhone",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "Increasedyear"
                            },
                            "rhs": {
                              "@type": "keyword",
                              "dataType": "text",
                              "dataValue": "date",
                              "keywordArguments": {
                                "init": {
                                  "value": "yearInput@local",
                                  "format": "d MMM yyyy HH:mm:ss"
                                },
                                "type": "year",
                                "value": "yearIncreaseValue@local",
                                "format": "d MMM yyyy HH:mm:ss"
                              }
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        }
                      ],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "contentInputType": "json",
              "ignoreNullFields": false,
              "contentOutputType": "json"
            }`

const CheckDateFormatConfig = `{
  "id": 542072376338973,
  "name": "req",
  "@type": "transform",
  "debug": false,
  "headers": {},
  "version": 3,
  "transform": {
      "id": 542072376338973,
      "name": "req",
      "statements": [
          {
              "id": 1728995654362073,
              "name": "FaintCare",
              "@type": "SectionalStatement",
              "section": {
                  "id": 608751083699108,
                  "name": "SECTION Statement 648368",
                  "statements": [
                      {
                          "id": 1728995693129450,
                          "name": "BanBolt",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataType": "date",
                                  "dataValue": "input"
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "date",
                                  "dataValue": "1998-07-15"
                              },
                              "operator": {
                                  "actualValue": "="
                              }
                          }
                      },
                      {
                          "id": 1728995578723294,
                          "name": "CastDisk",
                          "@type": "ConditionalStatement",
                          "failure": {
                              "id": 240274201167560,
                              "name": "ELSE Statement 1728995653413345",
                              "statements": [
                                  {
                                      "id": 1728995768134158,
                                      "name": "SkinJuice",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "msg "
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "false"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  }
                              ],
                              "jsonIgnoreProperty": false
                          },
                          "success": {
                              "id": 127961812594366,
                              "name": "THEN Statement 1728995660741661",
                              "statements": [
                                  {
                                      "id": 1728995801287594,
                                      "name": "CleanBooth",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "msg"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "true"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  }
                              ],
                              "jsonIgnoreProperty": false
                          },
                          "condition": {
                              "type": "and",
                              "@type": "logical",
                              "rules": [
                                  {
                                      "lhs": {
                                          "@type": "variable",
                                          "dataType": "date",
                                          "dataValue": "input@local"
                                      },
                                      "rhs": {
                                          "@type": "literal",
                                          "dataType": "date",
                                          "dataValue": "yyyy-MM-dd"
                                      },
                                      "@type": "relational",
                                      "operator": {
                                          "actualValue": "checkDateFormat"
                                      }
                                  }
                              ]
                          },
                          "mandatory": true
                      }
                  ],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
          }
      ],
      "jsonIgnoreProperty": false
  },
  "contentInputType": "json",
  "ignoreNullFields": false,
  "contentOutputType": "json"
}`

const CheckDateFormatConfigNotEqualsConfig = `{
  "id": 542072376338973,
  "name": "req",
  "@type": "transform",
  "debug": false,
  "headers": {},
  "version": 3,
  "transform": {
      "id": 542072376338973,
      "name": "req",
      "statements": [
          {
              "id": 1728995654362073,
              "name": "FaintCare",
              "@type": "SectionalStatement",
              "section": {
                  "id": 608751083699108,
                  "name": "SECTION Statement 648368",
                  "statements": [
                      {
                          "id": 1728995693129450,
                          "name": "BanBolt",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                              "lhs": {
                                  "@type": "declare",
                                  "dataType": "date",
                                  "dataValue": "input"
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataType": "date",
                                  "dataValue": "1998-07-15"
                              },
                              "operator": {
                                  "actualValue": "="
                              }
                          }
                      },
                      {
                          "id": 1728995578723294,
                          "name": "CastDisk",
                          "@type": "ConditionalStatement",
                          "failure": {
                              "id": 240274201167560,
                              "name": "ELSE Statement 1728995653413345",
                              "statements": [
                                  {
                                      "id": 1728995768134158,
                                      "name": "SkinJuice",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "msg"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "false"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  }
                              ],
                              "jsonIgnoreProperty": false
                          },
                          "success": {
                              "id": 127961812594366,
                              "name": "THEN Statement 1728995660741661",
                              "statements": [
                                  {
                                      "id": 1728995801287594,
                                      "name": "CleanBooth",
                                      "@type": "AssignmentStatement",
                                      "mandatory": true,
                                      "assignment": {
                                          "lhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "msg"
                                          },
                                          "rhs": {
                                              "@type": "literal",
                                              "dataType": "text",
                                              "dataValue": "true"
                                          },
                                          "operator": {
                                              "actualValue": "="
                                          }
                                      }
                                  }
                              ],
                              "jsonIgnoreProperty": false
                          },
                          "condition": {
                              "type": "and",
                              "@type": "logical",
                              "rules": [
                                  {
                                      "lhs": {
                                          "@type": "variable",
                                          "dataType": "date",
                                          "dataValue": "input@local"
                                      },
                                      "rhs": {
                                          "@type": "literal",
                                          "dataType": "date",
                                          "dataValue": "yyyy-MM-dd"
                                      },
                                      "@type": "relational",
                                      "operator": {
                                          "actualValue": "notEqualDateFormat"
                                      }
                                  }
                              ]
                          },
                          "mandatory": true
                      }
                  ],
                  "jsonIgnoreProperty": false
              },
              "mandatory": true
          }
      ],
      "jsonIgnoreProperty": false
  },
  "contentInputType": "json",
  "ignoreNullFields": false,
  "contentOutputType": "json"
}`

const CalculateDifferenceWithCurrentDate = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
        {
          "id": "1729579905433740",
          "name": "LoadPhase",
          "@type": "AssignmentStatement",
          "mandatory": true,
          "toogleSwitchValue": false,
          "assignment": {
              "lhs": {
                  "@type": "literal",
                  "dataValue": "duration",
                  "dataType": "text"
              },
              "operator": {
                  "actualValue": "="
              },
              "rhs": {
                  "@type": "keyword",
                  "dataType": "text",
                  "dataValue": "date",
                  "keywordArguments": {
                      "init": {
                          "value": "dateValue",
                          "format": "dd-MM-yyyy"
                      },
                      "format": "dateDiffFromToday",
                      "type": "years"
                  }
              }
          }
      }
      ]
  }
}`
const CalculateDifferenceWithCurrentDateInMonths = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
        {
          "id": "1729579905433740",
          "name": "LoadPhase",
          "@type": "AssignmentStatement",
          "mandatory": true,
          "toogleSwitchValue": false,
          "assignment": {
              "lhs": {
                  "@type": "literal",
                  "dataValue": "duration",
                  "dataType": "text"
              },
              "operator": {
                  "actualValue": "="
              },
              "rhs": {
                  "@type": "keyword",
                  "dataType": "text",
                  "dataValue": "date",
                  "keywordArguments": {
                      "init": {
                          "value": "dateValue",
                          "format": "dd-MM-yyyy"
                      },
                      "format": "dateDiffFromToday",
                      "type": "years"
                  }
              }
          }
      }
      ]
  }
}`

const DateNewFormatddMMyyz = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
        {
          "id": "1729579905433740",
          "name": "LoadPhase",
          "@type": "AssignmentStatement",
          "mandatory": true,
          "toogleSwitchValue": false,
          "assignment": {
              "lhs": {
                  "@type": "literal",
                  "dataValue": "newConvertedDate",
                  "dataType": "text"
              },
              "operator": {
                  "actualValue": "="
              },
              "rhs": {
                  "@type": "keyword",
                  "dataType": "text",
                  "dataValue": "date",
                  "keywordArguments": {
                      "init": {
                          "value": "dateValue",
                          "format": "dd-MM-yyyy"
                      },
                      "format": "yyyy-MM-ddZ"
                  }
              }
          }
      }
      ]
  }
}`

const CreatingDateWithIndividualParameters = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "id": 1726478510503255,
                "name": "VastClothes",
                "@type": "AssignmentStatement",
                "mandatory": true,
                "assignment": {
                    "lhs": {
                        "@type": "declare",
                        "dataType": "text",
                        "dataValue": "month"
                    },
                    "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "07"
                    },
                    "operator": {
                        "actualValue": "="
                    }
                }
            },
            {
                "id": "293979634426513",
                "@type": "AssignmentStatement",
                "assignment": {
                    "lhs": {
                        "@type": "literal",
                        "dataValue": "month",
                        "dataType": "date"
                    },
                    "operator": {
                        "actualValue": "="
                    },
                    "rhs": {
                        "@type": "keyword",
                        "dataValue": "date",
                        "dataType": "date",
                        "keywordArguments": {
                            "format": "createDate",
                            "init": {
                                "values": {
                                    "day": "day",
                                    "month": "month@local",
                                    "year": "year"
                                },
                                "format": "dd MMMM yyyy"
                            }
                        }
                    }
                },
                "name": "Michale"
            }
        ]
    }
}`

const DateDifferenceFromTodayInYears = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
        {
          "id": "1729579905433740",
          "name": "LoadPhase",
          "@type": "AssignmentStatement",
          "mandatory": true,
          "toogleSwitchValue": false,
          "assignment": {
              "lhs": {
                  "@type": "literal",
                  "dataValue": "duration",
                  "dataType": "text"
              },
              "operator": {
                  "actualValue": "="
              },
              "rhs": {
                  "@type": "keyword",
                  "dataType": "text",
                  "dataValue": "date",
                  "keywordArguments": {
                      "init": {
                          "value": "datOfBirth",
                          "format": "yyyy-MM-dd"
                      },
                      "format": "dateDiffFromToday",
                      "type": "years"
                  }
              }
          }
      }
      ]
  }
}`

const TestConfigDifferenceWithYears = `{
  "version": 3.3,
  "@type": "transform",
  "contentInputType": "json",
  "transform": {
      "id": "transform_custodetails",
      "jsonIgnoreProperty": "false",
      "name": "Request payload Transformation",
      "statements": [
        {
          "id": "1729579905433740",
          "name": "LoadPhase",
          "@type": "AssignmentStatement",
          "mandatory": true,
          "toogleSwitchValue": false,
          "assignment": {
              "lhs": {
                  "@type": "literal",
                  "dataValue": "duration",
                  "dataType": "text"
              },
              "operator": {
                  "actualValue": "="
              },
              "rhs": {
                  "@type": "keyword",
                  "dataType": "text",
                  "dataValue": "date",
                  "keywordArguments": {
                      "init": {
                          "value": "dob",
                          "format": "yyyy-MM-dd"
                      },
                      "format": "dateDiffFromToday",
                      "type": "years"
                  }
              }
          }
      }
      ]
  }
}`

const CheckDateIsEmptyConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "date",
                      "keywordArguments": {
                        "init": {
                          "value": "krakend"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check date is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": true,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const TestDateIsEmptyForKeyNotPresent = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "date",
                      "keywordArguments": {
                        "init": {
                          "value": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check date is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const TestDateIsEmptyForValueKeyNotPresentInConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "pass"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "date",
                      "keywordArguments": {
                        "init": {
                          "valuef": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "check date is empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`
