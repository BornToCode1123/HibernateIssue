package configs

const LocalTestKeyword_isbooleanfalse = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Althea",
        "statements" : [ {
          "id" : "429707161927685",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "name1",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isBoolean",
                "init" : {
                  "value" : "name1"
                }
              }
            }
          },
          "name" : "Brandon"
        }, {
          "id" : "430773733203641",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "isbooleanfalse local",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "name1@local",
              "dataType" : "text"
            }
          },
          "name" : "Vaughn"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "430791181004225"
      },
      "id" : "430793333017808"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeyword_toboolean = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Garett",
        "statements" : [ {
          "id" : "433706896253688",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toBoolean",
                "init" : {
                  "value" : "isAlive"
                }
              }
            }
          },
          "name" : "Brannon"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "433704400265006"
      },
      "id" : "433704560162295"
    } ]
  }
}`

const BooleantoText = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ambrose",
        "statements" : [ {
          "id" : "437159997539447",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "boolean",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "isBoolean"
                }
              }
            }
          },
          "name" : "Kameron"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "437158505643966"
      },
      "id" : "437157880797284"
    } ]
  }
}`

const LocalTestKeyword_isnumberTrue = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lilla",
        "statements" : [ {
          "id" : "438593392137557",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "mobile",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isNumber",
                "init" : {
                  "value" : "mobile"
                }
              }
            }
          },
          "name" : "Cleve"
        }, {
          "id" : "439165131690421",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "isnumberTrue local",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "mobile@local",
              "dataType" : "text"
            }
          },
          "name" : "Brain"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "439162441350782"
      },
      "id" : "439161929508211"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const LocalTestKeyword_isbooleanTrue = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Chance",
        "statements" : [ {
          "id" : "440253613844662",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "isAlive",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isBoolean",
                "init" : {
                  "value" : "isAlive"
                }
              }
            }
          },
          "name" : "Leola"
        }, {
          "id" : "440846436916685",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "isbooleanTrue local",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "isAlive@local",
              "dataType" : "text"
            }
          },
          "name" : "Ettie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "440841341763275"
      },
      "id" : "440844938683925"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeyword_isnumberTrue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Danika",
        "statements" : [ {
          "id" : "441916166637495",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isNumber",
                "init" : {
                  "value" : "mobile"
                }
              }
            }
          },
          "name" : "Domenico"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "441912832581309"
      },
      "id" : "441915108113113"
    } ]
  }
}`

const LocalTestKeyword_isnumberFalse = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Cole",
        "statements" : [ {
          "id" : "442821363529124",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "name1",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isNumber",
                "init" : {
                  "value" : "name1"
                }
              }
            }
          },
          "name" : "Jaylin"
        }, {
          "id" : "443252251990789",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "isnumberFalse local",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "name1@local",
              "dataType" : "text"
            }
          },
          "name" : "Salvador"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "443255137685043"
      },
      "id" : "443251464916899"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeyword_Trim = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Sigurd",
        "statements" : [ {
          "id" : "444243217230700",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "trim",
                "init" : {
                  "value" : "fathersName"
                }
              }
            }
          },
          "name" : "Mariah"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "444243474034941"
      },
      "id" : "444245381346186"
    } ]
  }
}`

const TestKeyword_isnumberFalse = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Dayna",
        "statements" : [ {
          "id" : "445263445794261",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isNumber",
                "init" : {
                  "value" : "name1"
                }
              }
            }
          },
          "name" : "Zella"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "445269914286692"
      },
      "id" : "445267737666926"
    } ]
  }
}`

const LocalTestKeyword_toboolean = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Hertha",
        "statements" : [ {
          "id" : "446203393309844",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "isAlive",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toBoolean",
                "init" : {
                  "value" : "isAlive"
                }
              }
            }
          },
          "name" : "Maxine"
        }, {
          "id" : "446506033263229",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "toBoolean local",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "isAlive@local",
              "dataType" : "text"
            }
          },
          "name" : "Kirk"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "446502002949780"
      },
      "id" : "446507153121901"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const LocalTestKeyword_Trim = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Oda",
        "statements" : [ {
          "id" : "447482022157424",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "fathersName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "trim",
                "init" : {
                  "value" : "fathersName"
                }
              }
            }
          },
          "name" : "Macey"
        }, {
          "id" : "448041418247329",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "trim local",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "fathersName@local",
              "dataType" : "text"
            }
          },
          "name" : "Myah"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "448048703166121"
      },
      "id" : "448049813328006"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeyword_isbooleanfalse = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Teagan",
        "statements" : [ {
          "id" : "449152639448428",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isBoolean",
                "init" : {
                  "value" : "name1"
                }
              }
            }
          },
          "name" : "Ike"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "449151348611431"
      },
      "id" : "449155965286626"
    } ]
  }
}`

const TestKeyword_isbooleanTrue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gerard",
        "statements" : [ {
          "id" : "450251326366160",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isBoolean",
                "init" : {
                  "value" : "isAlive"
                }
              }
            }
          },
          "name" : "Jordy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "450254752532708"
      },
      "id" : "450252757288303"
    } ]
  }
}`

