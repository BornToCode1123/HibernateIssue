package configs

const TransConfig6 = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jacey",
        "statements" : [ {
          "id" : "982092988529459",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.coApplicantList",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_related_parties",
                    "name" : "Request payload Transformation",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Granville",
                        "statements" : [ {
                          "id" : "979917980913268",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "customerPrincipalAddressList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "address" : "addressLine1",
                                    "stateProvinceRegion" : "state",
                                    "address2" : "addressLine2",
                                    "city" : "CityOrDistrict",
                                    "addressType" : "typeofAddress",
                                    "postalCode" : "pincode",
                                    "isOwnedRented" : "ownershipType"
                                  },
                                  "value" : "addressinfo"
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Doug"
                        }, {
                          "id" : "982097717517509",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "customerPrincipalAddressList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_related_parties",
                                    "name" : "Request payload Transformation",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Zula",
                                        "statements" : [ {
                                          "id" : "981631051016595",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "residentialStatus",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "residentType",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Jadyn"
                                        }, {
                                          "id" : "982097872490764",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "residentialStatus1",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "addressinfo.[0].pincode",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Corine"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "982097383433301"
                                      },
                                      "id" : "982099904022956"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Brennan"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "982096824492973"
                      },
                      "id" : "982093080413290"
                    } ]
                  },
                  "value" : "relatedParties"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Sigurd"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "982095314710626"
      },
      "id" : "982093393834334"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TransConfig4 = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Bradley",
        "statements" : [ {
          "id" : "987589888386462",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "A",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Lucile",
                        "statements" : [ {
                          "id" : "986951207250923",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "keyword",
                              "dataValue" : "none",
                              "dataType" : "map"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "B.mapC" : "city"
                                  }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Lamont"
                        }, {
                          "id" : "987589559406480",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "keyword",
                              "dataValue" : "none",
                              "dataType" : "map"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "B.mapC1" : "city"
                                  }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Kennedi"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "987581981312463"
                      },
                      "id" : "987585555468577"
                    } ]
                  },
                  "value" : "address"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Ernesto"
        }, {
          "id" : "988739271685706",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "P",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Major",
                        "statements" : [ {
                          "id" : "988444747201714",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "Q",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "R.textR" : "city"
                                  }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Robin"
                        }, {
                          "id" : "988667315371756",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "Q",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "R.textR1" : "city"
                                  }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Alfonzo"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "988662894501137"
                      },
                      "id" : "988661302692714"
                    } ]
                  },
                  "value" : "address"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Cooper"
        }, {
          "id" : "990246716506007",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "X",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Jeffry",
                        "statements" : [ {
                          "id" : "989854720592287",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "Y.Z",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "city",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Elody"
                        }, {
                          "id" : "990244856429862",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "Y.Z1",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "city",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Roma"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "990246379748599"
                      },
                      "id" : "990247163720992"
                    } ]
                  },
                  "value" : "address"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Javier"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "990244032398324"
      },
      "id" : "990248920910217"
    } ]
  }
}`

const TestKeywordWithMonthAndIncludeFalseWithInit = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Alessia",
        "statements" : [ 
          {
            "id" : "705967289525232",
            "@type" : "AssignmentStatement",
            "assignment" : {
              "lhs" : {
                "@type" : "declare",
                "dataValue" : "previous8Months",
                "dataType" : "number"
              },
              "operator" : {
                "actualValue" : "="
              },
              "rhs" : {
                "@type" : "literal",
                "dataValue" : "-8",
                "dataType" : "number"
              }
            },
            "name" : "Rosalind"
          },{
          "id" : "990958828503199",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "month",
                "init" : {
                  "value" : "startDate",
                  "format" : "dd/MM/yyyy"
                },
                "value" : "previous8Months@local",
                "includeDifference" : false
              }
            },
            "dataType" : "text"
          },
          "name" : "Marion"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "990959452941333"
      },
      "id" : "990959752772160"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeywordWithMonthAndIncludeTrueWithOutInit = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ 
      {
        "id" : "705967289525232",
        "@type" : "AssignmentStatement",
        "assignment" : {
          "lhs" : {
            "@type" : "declare",
            "dataValue" : "previous8Months",
            "dataType" : "number"
          },
          "operator" : {
            "actualValue" : "="
          },
          "rhs" : {
            "@type" : "literal",
            "dataValue" : "-8",
            "dataType" : "number"
          }
        },
        "name" : "Rosalind"
      },{
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Adolf",
        "statements" : [ {
          "id" : "991894938411253",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "month",
                "value" : "previous8Months@local",
                "includeDifference" : true
              }
            },
            "dataType" : "text"
          },
          "name" : "Mathew"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "991899496927404"
      },
      "id" : "991899654439512"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TransConfig8 = `{
  "version" : 1,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "transform",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Elouise",
        "statements" : [ {
          "id" : "995797559196522",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "accountAnalysis",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "transform",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Nicholaus",
                        "statements" : [ {
                          "id" : "994183328852437",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "summaryInfo",
                              "dataType" : "map"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "fullMonthCount" : "summaryInfo.fullMonthCount"
                                  }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Leland"
                        }, {
                          "id" : "995235803978125",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Hildegard",
                                        "statements" : [ {
                                          "id" : "995047931957620",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalBalanceOn5",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal5"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Shanel"
                                        }, {
                                          "id" : "995231234819973",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalBalanceOn6666665",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal5"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Orlando"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "995237747979087"
                                      },
                                      "id" : "995234209779523"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Vallie"
                        }, {
                          "id" : "995797378970994",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Bessie",
                                        "statements" : [ {
                                          "id" : "995791070344819",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalBalanceOn5333",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal5"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Sylvia"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "995792599060568"
                                      },
                                      "id" : "995799486014542"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Luella"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "995792329048173"
                      },
                      "id" : "995798988783179"
                    } ]
                  },
                  "value" : "accountAnalysis"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Madie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "995792817993815"
      },
      "id" : "995793283164417"
    } ]
  }
}`

const ConfigConcatWithOneValue = `{
  "version" : "1",
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Cecilia",
        "statements" : [ {
          "id" : "996302368601034",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "toBeConcatedValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "response.enquiryMemberUserId",
                  "values" : [ "response.tuefsegmentTag" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Kareem"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "996305009517531"
      },
      "id" : "996308253226701"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TransConfig2 = `{
  "version" : 1,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "transform Consumer Details",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Heloise",
        "statements" : [ {
          "id" : "999246377298138",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "consumerDetails",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "=",
              "expressionType" : "SimpleAssignment",
              "dataType" : "text"
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "transform Consumer Communication Address Details",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Kieran",
                        "statements" : [ {
                          "id" : "997074893793822",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "address1",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "communicationAddress.city",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Brooks"
                        }, {
                          "id" : "997309148300834",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "address2",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "communicationAddress.addressLine1",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Kristian"
                        }, {
                          "id" : "997739973732005",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "address3",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "communicationAddress.addressLine2",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Cristina"
                        }, {
                          "id" : "998208802119617",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "address4",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "communicationAddress.addressLine3",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Issac"
                        }, {
                          "id" : "998908305671390",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "postalCode",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "communicationAddress.pincode",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Katelin"
                        }, {
                          "id" : "999246718084549",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "addressType",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "communicationAddress",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Janessa"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "999248908037239"
                      },
                      "id" : "999249088551604"
                    } ]
                  }
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Elwin"
        }, {
          "id" : "101218791997804",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "consumerDetails",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "=",
              "expressionType" : "SimpleAssignment",
              "dataType" : "text"
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_2",
                    "name" : "transform Consumer Perminent Address Details",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Alanis",
                        "statements" : [ {
                          "id" : "999947997858542",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "address1",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "permanentAddress.city",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Danika"
                        }, {
                          "id" : "100105391577569",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "address2",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "permanentAddress.addressLine1",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Adaline"
                        }, {
                          "id" : "100298270123022",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "address3",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "permanentAddress.addressLine2",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Nels"
                        }, {
                          "id" : "100515511841579",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "address4",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "permanentAddress.addressLine3",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Christa"
                        }, {
                          "id" : "100804840109963",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "postalCode",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "permanentAddress.pincode",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Theresia"
                        }, {
                          "id" : "101219391492159",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "addressType",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "=",
                              "expressionType" : "SimpleAssignment",
                              "dataType" : "text"
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "perminentAddress",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Moshe"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "101219279274144"
                      },
                      "id" : "101215635402026"
                    } ]
                  }
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Jayson"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "101219968709730"
      },
      "id" : "101215991545939"
    } ]
  }
}`

const DateFilter = `{
  "version": 1,
  "@type": "transform",
  "transform": {
    "id": "transform_config_1",
    "name": "transform cibilresponse for Grid",
    "statements": [
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": false,
          "name": "Bridie",
          "statements": [
            {
              "id": "106361531019045",
              "@type": "AssignmentStatement",
              "assignment": {
                "lhs": {
                  "@type": "declare",
                  "dataValue": "dummyArray",
                  "dataType": "list"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataType": "list",
                  "dataValue": "list",
                  "keywordArguments": {
                    "init": {
                      "transform": {
                        "id": "transform_config_2",
                        "name": "transform Consumer Communication Address Details",
                        "statements": [
                          {
                            "@type": "SectionalStatement",
                            "section": {
                              "jsonIgnoreProperty": false,
                              "name": "Carmella",
                              "statements": [
                                {
                                  "id": "105317889598362",
                                  "@type": "AssignmentStatement",
                                  "assignment": {
                                    "@type": "SimpleAssignmentStatement",
                                    "lhs": {
                                      "@type": "literal",
                                      "dataValue": "monthName",
                                      "dataType": "number"
                                    },
                                    "operator": {
                                      "actualValue": "=",
                                      "expressionType": "SimpleAssignment",
                                      "dataType": "text"
                                    },
                                    "rhs": {
                                      "@type": "keyword",
                                      "dataValue": "date",
                                      "dataType": "date",
                                      "keywordArguments": {
                                        "format": "unixTime",
                                        "init": {
                                          "value": "monthName",
                                          "format": "MMM-yy"
                                        }
                                      }
                                    }
                                  },
                                  "name": "Chaya"
                                },
                                {
                                  "id": "105651758768201",
                                  "@type": "AssignmentStatement",
                                  "assignment": {
                                    "@type": "SimpleAssignmentStatement",
                                    "lhs": {
                                      "@type": "literal",
                                      "dataValue": "credits",
                                      "dataType": "number"
                                    },
                                    "operator": {
                                      "actualValue": "="
                                    },
                                    "rhs": {
                                      "@type": "variable",
                                      "dataValue": "credits",
                                      "dataType": "number"
                                    }
                                  },
                                  "name": "Myron"
                                },
                                {
                                  "id": "105926085523444",
                                  "@type": "AssignmentStatement",
                                  "assignment": {
                                    "@type": "SimpleAssignmentStatement",
                                    "lhs": {
                                      "@type": "literal",
                                      "dataValue": "totalCredit",
                                      "dataType": "number"
                                    },
                                    "operator": {
                                      "actualValue": "="
                                    },
                                    "rhs": {
                                      "@type": "variable",
                                      "dataValue": "totalCredit",
                                      "dataType": "number"
                                    }
                                  },
                                  "name": "Valerie"
                                },
                                {
                                  "id": "106175468050447",
                                  "@type": "AssignmentStatement",
                                  "assignment": {
                                    "@type": "SimpleAssignmentStatement",
                                    "lhs": {
                                      "@type": "literal",
                                      "dataValue": "debits",
                                      "dataType": "number"
                                    },
                                    "operator": {
                                      "actualValue": "="
                                    },
                                    "rhs": {
                                      "@type": "variable",
                                      "dataValue": "debits",
                                      "dataType": "number"
                                    }
                                  },
                                  "name": "Cory"
                                },
                                {
                                  "id": "106355439029029",
                                  "@type": "AssignmentStatement",
                                  "assignment": {
                                    "@type": "SimpleAssignmentStatement",
                                    "lhs": {
                                      "@type": "literal",
                                      "dataValue": "totalDebit",
                                      "dataType": "number"
                                    },
                                    "operator": {
                                      "actualValue": "="
                                    },
                                    "rhs": {
                                      "@type": "variable",
                                      "dataValue": "totalDebit",
                                      "dataType": "number"
                                    }
                                  },
                                  "name": "Gregg"
                                }
                              ],
                              "jsonIgnoreAliasValue": null,
                              "id": "106367547583561"
                            },
                            "id": "106366559865021"
                          }
                        ]
                      },
                      "value": "AdditionalMonthlyDetails.MonthlyData1"
                    },
                    "format": "iterate"
                  }
                }
              },
              "name": "Wilhelm"
            },
            {
              "id": "106526249185797",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "declare",
                  "dataValue": "maxDate",
                  "dataType": "text"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataType": "number",
                  "dataValue": "list",
                  "keywordArguments": {
                    "init": {
                      "value": "dummyArray@local",
                      "aggregate": "monthName"
                    },
                    "format": "max"
                  }
                }
              },
              "name": "Alfreda"
            },
            {
              "id": "106355439029029",
              "@type": "AssignmentStatement",
              "assignment": {
                  "@type": "SimpleAssignmentStatement",
                  "lhs": {
                      "@type": "declare",
                      "dataValue": "previousMonths",
                      "dataType": "number"
                  },
                  "operator": {
                      "actualValue": "="
                  },
                  "rhs": {
                      "@type": "literal",
                      "dataValue": "-6",
                      "dataType": "number"
                  }
              },
              "name": "Gregg"
          },
            {
              "id": "106726531337293",
              "@type": "AssignmentStatement",
              "assignment": {
                "lhs": {
                  "@type": "literal",
                  "dataValue": "Last_6_Months_Credits",
                  "dataType": "number"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "filter": {
                    "id": "106725439056307",
                    "name": "filteraccountsbyDate",
                    "condition": {
                      "@type": "logical",
                      "type": "and",
                      "rules": [
                        {
                          "@type": "relational",
                          "lhs": {
                            "@type": "literal",
                            "dataType": "number",
                            "dataValue": "monthName"
                          },
                          "operator": {
                            "actualValue": ">="
                          },
                          "rhs": {
                            "@type": "keyword",
                            "dataValue": "date",
                            "dataType": "number",
                            "keywordArguments": {
                              "type": "month",
                              "format": "unixTime",
                              "init": {
                                "value": "maxDate@local",
                                "format": "unixTime"
                              },
                              "value": "previousMonths@local"
                            }
                          }
                        }
                      ]
                    }
                  },
                  "@type": "keyword",
                  "dataType": "number",
                  "dataValue": "list",
                  "keywordArguments": {
                    "init": {
                      "value": "dummyArray@local",
                      "aggregate": "credits"
                    },
                    "format": "sum"
                  }
                }
              },
              "name": "Jonatan"
            }
          ],
          "jsonIgnoreAliasValue": null,
          "id": "106723043123981"
        },
        "id": "106728919401092"
      }
    ]
  }
}`

const ConcatWithCharacter = `{
  "version" : "1",
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Vernie",
        "statements" : [ {
          "id" : "107092220821928",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "toBeConcatedValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "concatWith" : ",",
                  "value" : "name",
                  "values" : [ "name2", "name3" ]
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Vincenzo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "107097230983686"
      },
      "id" : "107092183146173"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeywordWithMonthAndIncludeFalseWithOutInit = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ 
      {
        "id" : "705967289525232",
        "@type" : "AssignmentStatement",
        "assignment" : {
          "lhs" : {
            "@type" : "declare",
            "dataValue" : "previous8Months",
            "dataType" : "number"
          },
          "operator" : {
            "actualValue" : "="
          },
          "rhs" : {
            "@type" : "literal",
            "dataValue" : "-8",
            "dataType" : "number"
          }
        },
        "name" : "Rosalind"
      },{
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Griffin",
        "statements" : [ {
          "id" : "107608631676954",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "month",
                "value" : "previous8Months@local",
                "includeDifference" : false
              }
            },
            "dataType" : "text"
          },
          "name" : "Providenci"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "107611717315593"
      },
      "id" : "107618580075663"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeywordWithMonthAndWithOutValue = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Eva",
        "statements" : [ {
          "id" : "108053651873729",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "month"
              }
            },
            "dataType" : "text"
          },
          "name" : "Barney"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "108053453849144"
      },
      "id" : "108052344681558"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const DefaultValues = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Damon",
        "statements" : [ {
          "id" : "108557955695165",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "defaul_tArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list"
            }
          },
          "name" : "Pearline"
        }, {
          "id" : "108864938591114",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "default_map",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "map"
            }
          },
          "name" : "Rickey"
        }, {
          "id" : "109122494153832",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "default_text",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text"
            }
          },
          "name" : "Alfred"
        }, {
          "id" : "109439313336933",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "default_number",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "number"
            }
          },
          "name" : "Osborne"
        }, {
          "id" : "109678759164065",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "default_boolean",
              "dataType" : "boolean"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "boolean",
              "dataType" : "boolean"
            }
          },
          "name" : "Cortney"
        }, {
          "condition" : {
            "@type" : "logical",
            "type" : "and",
            "rules" : [ {
              "@type" : "relational",
              "lhs" : {
                "@type" : "variable",
                "dataValue" : "customerDetails",
                "dataType" : "list"
              },
              "operator" : {
                "actualValue" : "==="
              },
              "rhs" : {
                "@type" : "keyword",
                "dataValue" : "list",
                "dataType" : "list"
              }
            } ]
          },
          "@type" : "ConditionalStatement",
          "success" : {
            "name" : "transformation",
            "statements" : [ {
              "@type" : "SectionalStatement",
              "section" : {
                "jsonIgnoreProperty" : false,
                "name" : "Josephine",
                "statements" : [ {
                  "id" : "110098983114855",
                  "@type" : "AssignmentStatement",
                  "assignment" : {
                    "lhs" : {
                      "@type" : "literal",
                      "dataValue" : "condition",
                      "dataType" : "text"
                    },
                    "operator" : {
                      "actualValue" : "="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "true",
                      "dataType" : "text"
                    }
                  },
                  "name" : "Libbie"
                } ],
                "jsonIgnoreAliasValue" : null,
                "id" : "110091816458743"
              },
              "id" : "110092006205910"
            } ],
            "id" : "110096032196992"
          },
          "id" : 1
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "110094804493261"
      },
      "id" : "110097860626705"
    } ]
  }
}`

const TestKeywordWithMonthAndIncludeTrueWithInit = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Lowell",
        "statements" : [
          {
            "id" : "705967289525232",
            "@type" : "AssignmentStatement",
            "assignment" : {
              "lhs" : {
                "@type" : "declare",
                "dataValue" : "previous9Months",
                "dataType" : "number"
              },
              "operator" : {
                "actualValue" : "="
              },
              "rhs" : {
                "@type" : "literal",
                "dataValue" : "-9",
                "dataType" : "number"
              }
            },
            "name" : "Rosalind"
          }, {
          "id" : "110508610647610",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "month",
                "init" : {
                  "value" : "startDate",
                  "format" : "dd/MM/yyyy"
                },
                "value" : "previous9Months@local",
                "includeDifference" : true
              }
            },
            "dataType" : "text"
          },
          "name" : "Kaley"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "110501061652086"
      },
      "id" : "110503417607910"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeywordWithMonthAndWithOutInclude = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Dean",
        "statements" : [
          {
            "id" : "705967289525232",
            "@type" : "AssignmentStatement",
            "assignment" : {
              "lhs" : {
                "@type" : "declare",
                "dataValue" : "previous6Months",
                "dataType" : "number"
              },
              "operator" : {
                "actualValue" : "="
              },
              "rhs" : {
                "@type" : "literal",
                "dataValue" : "-8",
                "dataType" : "number"
              }
            },
            "name" : "Rosalind"
          }, {
          "id" : "110854092516545",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "month",
                "value" : "previous6Months@local"
              }
            },
            "dataType" : "text"
          },
          "name" : "Garnet"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "110851237406138"
      },
      "id" : "110858348369042"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TransConfig5 = `{
  "version" : 1,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "transform",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Anastacio",
        "statements" : [ {
          "id" : "112354306210557",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "statementDetail",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "transform",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Russ",
                        "statements" : [ {
                          "id" : "112353752275714",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "statementAccount",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Alta",
                                        "statements" : [ {
                                          "id" : "112355134372463",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "keyword",
                                              "dataValue" : "none",
                                              "dataType" : "map"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "map",
                                              "dataValue" : "map",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "fields" : {
                                                    "accountNo" : "accountNo",
                                                    "accountType" : "accountType"
                                                  }
                                                },
                                                "format" : "populate"
                                              }
                                            }
                                          },
                                          "name" : "Vernice"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "112355926663854"
                                      },
                                      "id" : "112358069258931"
                                    } ]
                                  },
                                  "value" : "statementAccounts"
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Kari"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "112356269474162"
                      },
                      "id" : "112351472432350"
                    } ]
                  },
                  "value" : "statementdetails"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Toney"
        }, {
          "id" : "199128710259790",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "accountAnalysis",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "transform",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Dwight",
                        "statements" : [ {
                          "id" : "115425446972467",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "summaryInfo",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "fullMonthCount" : "summaryInfo.fullMonthCount"
                                  }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Dedrick"
                        }, {
                          "id" : "117147267749857",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Creola",
                                        "statements" : [ {
                                          "id" : "117142097651533",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.averageBalanceOn5",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal5"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Marquise"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "117143551751765"
                                      },
                                      "id" : "117145650142376"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Mathias"
                        }, {
                          "id" : "119858206974488",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Kirstin",
                                        "statements" : [ {
                                          "id" : "119688820823912",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.averageBalanceOn10",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal10"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Tatum"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "119828552671748"
                                      },
                                      "id" : "119859724186059"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Cora"
                        }, {
                          "id" : "124608057037584",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Stone",
                                        "statements" : [ {
                                          "id" : "124591519910537",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.averageBalanceOn15",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal15"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Amanda"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "124608632734617"
                                      },
                                      "id" : "124607134404268"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Marlene"
                        }, {
                          "id" : "131412879720281",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Theo",
                                        "statements" : [ {
                                          "id" : "131383382778516",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.averageBalanceOn20",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal20"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Lorine"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "131416210458485"
                                      },
                                      "id" : "131413044703290"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Cristobal"
                        }, {
                          "id" : "134243218069590",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Hertha",
                                        "statements" : [ {
                                          "id" : "134236357192327",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.averageBalanceOn25",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal25"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Kaitlyn"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "134242247106320"
                                      },
                                      "id" : "134243436144380"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Malcolm"
                        }, {
                          "id" : "135426335188111",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Rosamond",
                                        "statements" : [ {
                                          "id" : "135424075604607",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.averageBalanceMonthEnd",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal30"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Mireya"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "135427657980591"
                                      },
                                      "id" : "135428123830603"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Kellen"
                        }, {
                          "id" : "138171961424421",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Corine",
                                        "statements" : [ {
                                          "id" : "138173805858624",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalCashDeposits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "cashDeposits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Hoyt"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "138175375246747"
                                      },
                                      "id" : "138176073696153"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Jamil"
                        }, {
                          "id" : "139616269989570",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Lessie",
                                        "statements" : [ {
                                          "id" : "139612954477886",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalCashWithdrawals",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "cashWithdrawals"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Jazlyn"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "139617229603280"
                                      },
                                      "id" : "139614892323596"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Alessandra"
                        }, {
                          "id" : "141128562337680",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Lance",
                                        "statements" : [ {
                                          "id" : "141124664490747",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalNoofOutwardReturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "chqDeposits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Wilson"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "141123190726133"
                                      },
                                      "id" : "141129865768123"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Cordelia"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "141123761405398"
                      },
                      "id" : "141125439640530"
                    }, {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Isabel",
                        "statements" : [ {
                          "id" : "142261585565790",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Francesca",
                                        "statements" : [ {
                                          "id" : "142255457677275",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalNoofInwardReturn",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "chqIssues"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Destany"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "142256294035678"
                                      },
                                      "id" : "142265765161712"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Joana"
                        }, {
                          "id" : "143314104736106",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Gail",
                                        "statements" : [ {
                                          "id" : "143313127089391",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalNoofCredits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "credits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Vinnie"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "143319959270014"
                                      },
                                      "id" : "143312211870116"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Garett"
                        }, {
                          "id" : "143934805762704",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Austyn",
                                        "statements" : [ {
                                          "id" : "143938130967193",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalNumberofDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "debits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Felton"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "143935473041305"
                                      },
                                      "id" : "143932152321562"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Miguel"
                        }, {
                          "id" : "145554665412993",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Jermey",
                                        "statements" : [ {
                                          "id" : "145555549272946",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalNoofExceptionalDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "exceptionalDebits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Loren"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "145552024432617"
                                      },
                                      "id" : "145556205710765"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Deborah"
                        }, {
                          "id" : "147305141997648",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Rolando",
                                        "statements" : [ {
                                          "id" : "147305285268267",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalNoofEMIreturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "inwEMIBounces"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Tod"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "147306773490863"
                                      },
                                      "id" : "147308957557726"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Tracy"
                        }, {
                          "id" : "154305185105402",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Tyler",
                                        "statements" : [ {
                                          "id" : "154307235158923",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalValueofCredits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCredit"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Jed"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "154309762232325"
                                      },
                                      "id" : "154302689652923"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Buster"
                        }, {
                          "id" : "156339154939781",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Pearlie",
                                        "statements" : [ {
                                          "id" : "156334730864147",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.fromGroupaccounts",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCreditSC"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Ambrose"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "156333658852498"
                                      },
                                      "id" : "156337393196634"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Chaz"
                        }, {
                          "id" : "157111639733544",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Judah",
                                        "statements" : [ {
                                          "id" : "157115231419203",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalValueofInwardTrans",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCreditSelf"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Blake"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "157112755233157"
                                      },
                                      "id" : "157113114024674"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Katelynn"
                        }, {
                          "id" : "158098007087315",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Dorcas",
                                        "statements" : [ {
                                          "id" : "158095716625217",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalValueofDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebit"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Andreanne"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "158096510930031"
                                      },
                                      "id" : "158091311464340"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Kattie"
                        }, {
                          "id" : "158799132227946",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Zachary",
                                        "statements" : [ {
                                          "id" : "158789379772006",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totalValueofoutwardTrans",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebitSC"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "D'angelo"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "158785560397817"
                                      },
                                      "id" : "158795197582508"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Easter"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "158795639907735"
                      },
                      "id" : "158796818925069"
                    }, {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Reggie",
                        "statements" : [ {
                          "id" : "159201840336099",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Marcus",
                                        "statements" : [ {
                                          "id" : "159203551600066",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.outwardTransfertogroupAccounts",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebitSelf"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Elliott"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "159201781011264"
                                      },
                                      "id" : "159202475293588"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Janelle"
                        }, {
                          "id" : "159766152168761",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Evan",
                                        "statements" : [ {
                                          "id" : "159768059811702",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "3Month.totaloutwardReturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalOutwBounce"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Odell"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "159766288488819"
                                      },
                                      "id" : "159761405541902"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Tomas"
                        }, {
                          "id" : "160459264886995",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Johnathan",
                                        "statements" : [ {
                                          "id" : "160453040277317",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.averageBalanceOn5",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal5"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Rickey"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "160456136872431"
                                      },
                                      "id" : "160459899086254"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Sister"
                        }, {
                          "id" : "165399620033079",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Myra",
                                        "statements" : [ {
                                          "id" : "165391219420802",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.averageBalanceOn10",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal10"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Lucinda"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "165396639989728"
                                      },
                                      "id" : "165391752231315"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Emmanuel"
                        }, {
                          "id" : "166531727336851",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Nikki",
                                        "statements" : [ {
                                          "id" : "166534700301238",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.averageBalanceOn15",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal15"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Amari"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "166533948065273"
                                      },
                                      "id" : "166533524352307"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Maximus"
                        }, {
                          "id" : "167247958571146",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Angus",
                                        "statements" : [ {
                                          "id" : "167248333595994",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.averageBalanceOn20",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal20"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Kristoffer"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "167242031112019"
                                      },
                                      "id" : "167243169892624"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Greyson"
                        }, {
                          "id" : "167961032826145",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Bernadette",
                                        "statements" : [ {
                                          "id" : "167967963974155",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.averageBalanceOn25",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal25"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Jaunita"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "167962735193301"
                                      },
                                      "id" : "167961217128350"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Nestor"
                        }, {
                          "id" : "168647373587806",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Trace",
                                        "statements" : [ {
                                          "id" : "168649396394126",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.averageBalanceMonthEnd",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal30"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Charles"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "168641179158157"
                                      },
                                      "id" : "168646536980715"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Nicole"
                        }, {
                          "id" : "169287031632927",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Kobe",
                                        "statements" : [ {
                                          "id" : "169289287439257",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalCashDeposits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "cashDeposits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Silas"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "169289499472634"
                                      },
                                      "id" : "169284372313294"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Keegan"
                        }, {
                          "id" : "169814405458621",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Gordon",
                                        "statements" : [ {
                                          "id" : "169814100163819",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalCashWithdrawals",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "cashWithdrawals"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Vella"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "169811858476348"
                                      },
                                      "id" : "169812531641515"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Arch"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "169815633834383"
                      },
                      "id" : "169815717871778"
                    }, {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Stefan",
                        "statements" : [ {
                          "id" : "170418859284588",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Eunice",
                                        "statements" : [ {
                                          "id" : "170417552870777",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalNoofOutwardReturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "chqDeposits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Coby"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "170413420105186"
                                      },
                                      "id" : "170415583502416"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Asha"
                        }, {
                          "id" : "170924938651494",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Lowell",
                                        "statements" : [ {
                                          "id" : "170924015707568",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalNoofInwardReturn",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "chqIssues"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Rebeka"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "170922760750260"
                                      },
                                      "id" : "170928769675884"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Davon"
                        }, {
                          "id" : "171842834806977",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Jaydon",
                                        "statements" : [ {
                                          "id" : "171849989776311",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalNoofCredits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "credits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Briana"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "171841660142006"
                                      },
                                      "id" : "171845638175069"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Edwina"
                        }, {
                          "id" : "172551352614958",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Tomasa",
                                        "statements" : [ {
                                          "id" : "172558182527454",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalNumberofDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "debits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Dario"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "172556099067945"
                                      },
                                      "id" : "172556438966192"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Linwood"
                        }, {
                          "id" : "173063318062984",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Jeanne",
                                        "statements" : [ {
                                          "id" : "173063089353671",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalNoofExceptionalDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "exceptionalDebits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Dallas"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "173065350005907"
                                      },
                                      "id" : "173065742328670"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Camille"
                        }, {
                          "id" : "173576703710182",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Felicita",
                                        "statements" : [ {
                                          "id" : "173575094962225",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalNoofEMIreturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "inwEMIBounces"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Laverne"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "173576804704264"
                                      },
                                      "id" : "173575446496711"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Santos"
                        }, {
                          "id" : "174195992233884",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Magali",
                                        "statements" : [ {
                                          "id" : "174192952058600",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalValueofCredits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCredit"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Astrid"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "174195140242435"
                                      },
                                      "id" : "174199271422580"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Roy"
                        }, {
                          "id" : "174674294950258",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Preston",
                                        "statements" : [ {
                                          "id" : "174673861640993",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.fromGroupaccounts",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCreditSC"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Ulices"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "174679542253176"
                                      },
                                      "id" : "174675720749582"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Abraham"
                        }, {
                          "id" : "175214299505867",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Mariah",
                                        "statements" : [ {
                                          "id" : "175212475754132",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalValueofInwardTrans",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCreditSelf"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Gerald"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "175211899769718"
                                      },
                                      "id" : "175212205459332"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Chauncey"
                        }, {
                          "id" : "175709676934372",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Brendan",
                                        "statements" : [ {
                                          "id" : "175706882700180",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalValueofDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebit"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Dessie"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "175709009176730"
                                      },
                                      "id" : "175702367667948"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Mayra"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "175706738732042"
                      },
                      "id" : "175703222677879"
                    }, {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Edd",
                        "statements" : [ {
                          "id" : "176135349398618",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Quincy",
                                        "statements" : [ {
                                          "id" : "176138445205369",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totalValueofoutwardTrans",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebitSC"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Mikel"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "176136033249444"
                                      },
                                      "id" : "176139014318357"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Max"
                        }, {
                          "id" : "176752936611955",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Theodora",
                                        "statements" : [ {
                                          "id" : "176759663285752",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.outwardTransfertogroupAccounts",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebitSelf"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Elias"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "176753366033317"
                                      },
                                      "id" : "176756938756029"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Drew"
                        }, {
                          "id" : "177289605982374",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Brook",
                                        "statements" : [ {
                                          "id" : "177281704971466",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "6Month.totaloutwardReturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalOutwBounce"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Shania"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "177289490174898"
                                      },
                                      "id" : "177285098539151"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Alene"
                        }, {
                          "id" : "177771603458674",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Madie",
                                        "statements" : [ {
                                          "id" : "177777839180717",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.averageBalanceOn5",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal5"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Alyce"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "177778562140621"
                                      },
                                      "id" : "177775629339492"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Cathryn"
                        }, {
                          "id" : "178284818545233",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Nelda",
                                        "statements" : [ {
                                          "id" : "178288961248037",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.averageBalanceOn10",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal10"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Cristina"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "178287894090917"
                                      },
                                      "id" : "178287052576632"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Garfield"
                        }, {
                          "id" : "178785926376364",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Gianni",
                                        "statements" : [ {
                                          "id" : "178781372534184",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.averageBalanceOn15",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal15"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Matteo"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "178785524563230"
                                      },
                                      "id" : "178789079631763"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Derrick"
                        }, {
                          "id" : "179297791305112",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Blanche",
                                        "statements" : [ {
                                          "id" : "179293898664096",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.averageBalanceOn20",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal20"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Nellie"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "179298271486437"
                                      },
                                      "id" : "179292744419525"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Krystel"
                        }, {
                          "id" : "179804766324916",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Micaela",
                                        "statements" : [ {
                                          "id" : "179802548242876",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.averageBalanceOn25",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal25"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Rubye"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "179805054281811"
                                      },
                                      "id" : "179806741325980"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Emery"
                        }, {
                          "id" : "180443581523073",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Henry",
                                        "statements" : [ {
                                          "id" : "180445431788604",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.averageBalanceMonthEnd",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal30"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Millie"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "180449659072153"
                                      },
                                      "id" : "180448970905031"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Emilia"
                        }, {
                          "id" : "180993674363348",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Erling",
                                        "statements" : [ {
                                          "id" : "180994834512014",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalCashDeposits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "cashDeposits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Arlo"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "180995014402660"
                                      },
                                      "id" : "180997264136569"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Ottis"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "180992785147934"
                      },
                      "id" : "181008720264141"
                    }, {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Karli",
                        "statements" : [ {
                          "id" : "181462508980160",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Juliet",
                                        "statements" : [ {
                                          "id" : "181468699095912",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalCashWithdrawals",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "cashWithdrawals"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Liliane"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "181467489414190"
                                      },
                                      "id" : "181465719333126"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Lilla"
                        }, {
                          "id" : "181899688777802",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Buck",
                                        "statements" : [ {
                                          "id" : "181896942961232",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalNoofOutwardReturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "chqDeposits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Abraham"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "181891258364328"
                                      },
                                      "id" : "181899615007950"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Estella"
                        }, {
                          "id" : "182395848479585",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Willie",
                                        "statements" : [ {
                                          "id" : "182399455751591",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalNoofInwardReturn",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "chqIssues"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Hilbert"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "182391555793796"
                                      },
                                      "id" : "182399512115500"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Alice"
                        }, {
                          "id" : "182923939872676",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Gonzalo",
                                        "statements" : [ {
                                          "id" : "182921714115351",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalNoofCredits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "credits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Ivah"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "182924803486273"
                                      },
                                      "id" : "182921084682985"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Gina"
                        }, {
                          "id" : "183484672954353",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Keven",
                                        "statements" : [ {
                                          "id" : "183488946776637",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalNumberofDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "debits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Vena"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "183485539706169"
                                      },
                                      "id" : "183485994820894"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Ashton"
                        }, {
                          "id" : "183931902152973",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Nick",
                                        "statements" : [ {
                                          "id" : "183937500493865",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalNoofExceptionalDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "exceptionalDebits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Clarissa"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "183931720511885"
                                      },
                                      "id" : "183933284590841"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Malvina"
                        }, {
                          "id" : "184467284892308",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Ulises",
                                        "statements" : [ {
                                          "id" : "184462925088358",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalNoofEMIreturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "inwEMIBounces"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Gregorio"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "184465143142986"
                                      },
                                      "id" : "184462865956166"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Maryse"
                        }, {
                          "id" : "185072178934588",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Chance",
                                        "statements" : [ {
                                          "id" : "185077560738520",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalValueofCredits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCredit"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Maegan"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "185077569967792"
                                      },
                                      "id" : "185074197540363"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Rhett"
                        }, {
                          "id" : "185489477137809",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Joy",
                                        "statements" : [ {
                                          "id" : "185487056809492",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.fromGroupaccounts",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCreditSC"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Enid"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "185487107926099"
                                      },
                                      "id" : "185484396083521"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Jennings"
                        }, {
                          "id" : "186007110709144",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Daniela",
                                        "statements" : [ {
                                          "id" : "186009501266670",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalValueofInwardTrans",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCreditSelf"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Norma"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "186009438740135"
                                      },
                                      "id" : "186001340070114"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Earnestine"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "186002785974503"
                      },
                      "id" : "186006026284181"
                    }, {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Casandra",
                        "statements" : [ {
                          "id" : "186517140980253",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Harrison",
                                        "statements" : [ {
                                          "id" : "186513106788210",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalValueofDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebit"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Elizabeth"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "186513710608111"
                                      },
                                      "id" : "186514988927160"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Eugene"
                        }, {
                          "id" : "186913372587619",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Savion",
                                        "statements" : [ {
                                          "id" : "186915445725802",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totalValueofoutwardTrans",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebitSC"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Janiya"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "186912268745529"
                                      },
                                      "id" : "186914479569619"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Yasmin"
                        }, {
                          "id" : "187349202693529",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Alayna",
                                        "statements" : [ {
                                          "id" : "187348033959792",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.outwardTransfertogroupAccounts",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebitSelf"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Ronny"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "187346240751306"
                                      },
                                      "id" : "187349628786537"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Kimberly"
                        }, {
                          "id" : "187909140173391",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Lindsey",
                                        "statements" : [ {
                                          "id" : "187901953767417",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "9Month.totaloutwardReturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalOutwBounce"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Izabella"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "187906196196316"
                                      },
                                      "id" : "187908161703426"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Estel"
                        }, {
                          "id" : "188411558205591",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Derek",
                                        "statements" : [ {
                                          "id" : "188413302147603",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.averageBalanceOn5",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal5"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Georgianna"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "188414988427364"
                                      },
                                      "id" : "188411448035086"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Dixie"
                        }, {
                          "id" : "188972433685586",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Orpha",
                                        "statements" : [ {
                                          "id" : "188964854227817",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.averageBalanceOn10",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal10"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Ezekiel"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "188977143597559"
                                      },
                                      "id" : "188973240295397"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Demond"
                        }, {
                          "id" : "189363787332553",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Jakob",
                                        "statements" : [ {
                                          "id" : "189363738809387",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.averageBalanceOn15",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal15"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Erick"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "189363775316601"
                                      },
                                      "id" : "189367951342772"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Ray"
                        }, {
                          "id" : "189874772315069",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Tianna",
                                        "statements" : [ {
                                          "id" : "189873096899415",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.averageBalanceOn20",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal20"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Emma"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "189871723318551"
                                      },
                                      "id" : "189873421075646"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Al"
                        }, {
                          "id" : "190295313790517",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Claire",
                                        "statements" : [ {
                                          "id" : "190291498916751",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.averageBalanceOn25",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal25"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Vida"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "190292913972282"
                                      },
                                      "id" : "190299329960743"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Caroline"
                        }, {
                          "id" : "190912462734557",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Fannie",
                                        "statements" : [ {
                                          "id" : "190919573635280",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.averageBalanceMonthEnd",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "bal30"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Alysha"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "190914709995043"
                                      },
                                      "id" : "190912126732789"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Lincoln"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "190914612897048"
                      },
                      "id" : "190916337734456"
                    }, {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Isai",
                        "statements" : [ {
                          "id" : "191389806962847",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Janice",
                                        "statements" : [ {
                                          "id" : "191386559027035",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalCashDeposits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "cashDeposits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Jackeline"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "191386057259097"
                                      },
                                      "id" : "191388396901807"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Billy"
                        }, {
                          "id" : "191986391068232",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Gracie",
                                        "statements" : [ {
                                          "id" : "191988634058627",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalCashWithdrawals",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "cashWithdrawals"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Benedict"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "191987686363238"
                                      },
                                      "id" : "191983175632484"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Shayna"
                        }, {
                          "id" : "192841176661910",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Elinore",
                                        "statements" : [ {
                                          "id" : "192843085991064",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalNoofOutwardReturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "chqDeposits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Yvonne"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "192845343941975"
                                      },
                                      "id" : "192843440213612"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Nina"
                        }, {
                          "id" : "193301446059614",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Dewitt",
                                        "statements" : [ {
                                          "id" : "193302102528797",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalNoofInwardReturn",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "chqIssues"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Arely"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "193303756570848"
                                      },
                                      "id" : "193305873195851"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Jalen"
                        }, {
                          "id" : "193925983733433",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Antone",
                                        "statements" : [ {
                                          "id" : "193921637233835",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalNoofCredits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "credits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Molly"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "193921721159223"
                                      },
                                      "id" : "193928079314348"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Javon"
                        }, {
                          "id" : "194436323661792",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Odell",
                                        "statements" : [ {
                                          "id" : "194439874484755",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalNumberofDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "debits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Theron"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "194431171002186"
                                      },
                                      "id" : "194439780094434"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Janick"
                        }, {
                          "id" : "194843486790416",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Lizeth",
                                        "statements" : [ {
                                          "id" : "194849975970944",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalNoofExceptionalDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "exceptionalDebits"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Mona"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "194849934459048"
                                      },
                                      "id" : "194848927207816"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Lysanne"
                        }, {
                          "id" : "195552142609204",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Sunny",
                                        "statements" : [ {
                                          "id" : "195552840678525",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalNoofEMIreturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "inwEMIBounces"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Jose"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "195555788583142"
                                      },
                                      "id" : "195556460492542"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Ivah"
                        }, {
                          "id" : "196121472266805",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Brandt",
                                        "statements" : [ {
                                          "id" : "196126996068726",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalValueofCredits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCredit"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Lula"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "196121716355295"
                                      },
                                      "id" : "196121306488216"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Antonietta"
                        }, {
                          "id" : "196691585897853",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Roberto",
                                        "statements" : [ {
                                          "id" : "196691849164846",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.fromGroupaccounts",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCreditSC"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Cale"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "196694616628982"
                                      },
                                      "id" : "196696483809538"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Jayson"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "196697008887033"
                      },
                      "id" : "196693110792981"
                    }, {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Quentin",
                        "statements" : [ {
                          "id" : "197284991965029",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Zoe",
                                        "statements" : [ {
                                          "id" : "197285308378561",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalValueofInwardTrans",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalCreditSelf"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Jamaal"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "197288802628209"
                                      },
                                      "id" : "197287569894410"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Edythe"
                        }, {
                          "id" : "197684194042101",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Gerson",
                                        "statements" : [ {
                                          "id" : "197683643453532",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalValueofDebits",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebit"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Rosalyn"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "197685425164387"
                                      },
                                      "id" : "197688531478600"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Shannon"
                        }, {
                          "id" : "198191164370423",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Lionel",
                                        "statements" : [ {
                                          "id" : "198199123392759",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totalValueofoutwardTrans",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebitSC"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Alexandrine"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "198198649805240"
                                      },
                                      "id" : "198191689514946"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Winfield"
                        }, {
                          "id" : "198621107918456",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Merritt",
                                        "statements" : [ {
                                          "id" : "198626882756007",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.outwardTransfertogroupAccounts",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalDebitSelf"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Mikayla"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "198626366987175"
                                      },
                                      "id" : "198623532961391"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Kali"
                        }, {
                          "id" : "199122053592810",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "monthlyDetails",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Laura",
                                        "statements" : [ {
                                          "id" : "199129509396728",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "12Month.totaloutwardReturns",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "number",
                                              "dataValue" : "list",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "value" : "monthlyDetails",
                                                  "aggregate" : "totalOutwBounce"
                                                },
                                                "format" : "sum"
                                              }
                                            }
                                          },
                                          "name" : "Alexie"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "199124905195876"
                                      },
                                      "id" : "199127885129563"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Clare"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "199125927676028"
                      },
                      "id" : "199127814135915"
                    } ]
                  },
                  "value" : "accountAnalysis"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Carmine"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "199127702063038"
      },
      "id" : "199122788790255"
    } ]
  }
}`

const SplitConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Bennie",
        "statements" : [ {
          "id" : "199842790914531",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "splittedValues",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Katarina",
                        "statements" : [ {
                          "id" : "199844804607509",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "paymentHistory1",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "text",
                              "keywordArguments" : {
                                "init" : {
                                  "value" : "paymentHistory1",
                                  "splitby" : "4"
                                },
                                "format" : "split"
                              }
                            }
                          },
                          "name" : "Magdalena"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "199844479490548"
                      },
                      "id" : "199841466010788"
                    } ]
                  },
                  "value" : "relatedParties"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Tad"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "199841696724667"
      },
      "id" : "199842072701616"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TransConfig3 = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ena",
        "statements" : [ {
          "id" : "100273065562057",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "cuss.mobi.leNu.mber" : "customer.mob",
                    "cuss.customerType" : "customer.type",
                    "cuss.custome.rName" : "customer.name"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Clair"
        }, {
          "id" : "100362600382321",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.cuss.totalratings",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "=",
              "expressionType" : "SimpleAssignment",
              "dataType" : "text"
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "customer.ratings"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Shanie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "100365877010988"
      },
      "id" : "100368328776134"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeywordWithDayAndIncludeFalseWithInit = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Roscoe",
        "statements" : [
          {
            "id" : "705967289525232",
            "@type" : "AssignmentStatement",
            "assignment" : {
              "lhs" : {
                "@type" : "declare",
                "dataValue" : "previous20Months",
                "dataType" : "number"
              },
              "operator" : {
                "actualValue" : "="
              },
              "rhs" : {
                "@type" : "literal",
                "dataValue" : "-20",
                "dataType" : "number"
              }
            },
            "name" : "Rosalind"
          }, {
          "id" : "100706360946091",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "day",
                "init" : {
                  "value" : "startDate",
                  "format" : "dd/MM/yyyy"
                },
                "value" : "previous20Months@local",
                "includeDifference" : false
              }
            },
            "dataType" : "text"
          },
          "name" : "Kaya"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "100708198140539"
      },
      "id" : "100701923695323"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const DateConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jamie",
        "statements" : [ {
          "id" : "101711285100022",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "startDate",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "startDate",
              "dataType" : "number"
            }
          },
          "name" : "Elenora"
        }, {
          "id" : "101976093389550",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "myDate",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date"
            }
          },
          "name" : "Sherman"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "101978467423638"
      },
      "id" : "101979270913747"
    } ]
  }
}`

const TestKeywordWithYearAndIncludeTrueWithInit = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ 
      {
        "id" : "705967289525232",
        "@type" : "AssignmentStatement",
        "assignment" : {
          "lhs" : {
            "@type" : "declare",
            "dataValue" : "previous1Months",
            "dataType" : "number"
          },
          "operator" : {
            "actualValue" : "="
          },
          "rhs" : {
            "@type" : "literal",
            "dataValue" : "1",
            "dataType" : "number"
          }
        },
        "name" : "Rosalind"
      },{
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Hailie",
        "statements" : [ {
          "id" : "102713239461897",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "year",
                "init" : {
                  "value" : "startDate",
                  "format" : "dd/MM/yyyy"
                },
                "value" : "previous1Months@local",
                "includeDifference" : true
              }
            },
            "dataType" : "text"
          },
          "name" : "Christop"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "102714698006294"
      },
      "id" : "102718901660066"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TransConfig7 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_related_parties",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Celia",
        "statements" : [ {
          "id" : "103243164926837",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.application.applicationId",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "appPackageId",
              "dataType" : "text"
            }
          },
          "name" : "Kenny"
        }, {
          "id" : "108254664804531",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.coApplicantList",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_related_parties",
                    "name" : "Request payload Transformation",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Torrance",
                        "statements" : [ {
                          "id" : "103866029110558",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "keyword",
                              "dataValue" : "none",
                              "dataType" : "map"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "firstName" : "nameofRelatedParty",
                                    "gender" : "gender",
                                    "motherMaidenName" : "mothersName",
                                    "prefix" : "salutation",
                                    "fatherOrSpouse" : "fathersName",
                                    "cpId" : "cpId",
                                    "fiPrincipalId" : "cIFID",
                                    "dateOfBirth" : "dateofBirth"
                                  }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Loy"
                        }, {
                          "id" : "104584880528634",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "customerPrincipalAddressList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform Address Information",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Arch",
                                        "statements" : [ {
                                          "id" : "104324513013356",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "keyword",
                                              "dataValue" : "none",
                                              "dataType" : "map"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "map",
                                              "dataValue" : "map",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "fields" : {
                                                    "address" : "addressinfo.[0].addressLine1",
                                                    "stateProvinceRegion" : "addressinfo.[0].state",
                                                    "cpAddId" : "addressid",
                                                    "address2" : "addressinfo.[0].addressLine2",
                                                    "city" : "addressinfo.[0].CityOrDistrict",
                                                    "addressType" : "addressinfo.[0].typeofAddress",
                                                    "residentialStatus" : "residentType",
                                                    "postalCode" : "addressinfo.[0].pincode",
                                                    "isOwnedRented" : "addressinfo.[0].ownershipType"
                                                  }
                                                },
                                                "format" : "populate"
                                              }
                                            }
                                          },
                                          "name" : "Stefanie"
                                        }, {
                                          "id" : "104583979554022",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "addrAddlInfo",
                                              "dataType" : "list"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "map",
                                              "dataValue" : "map",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "fields" : { }
                                                },
                                                "format" : "populate"
                                              }
                                            }
                                          },
                                          "name" : "Leann"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "104589683159775"
                                      },
                                      "id" : "104584803579506"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Elmer"
                        }, {
                          "id" : "105515036996391",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "cpIdentityList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_related_parties",
                                    "name" : "Request payload Transformation",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Juwan",
                                        "statements" : [ {
                                          "id" : "105183308105195",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idNo",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "panNumber",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Bridget"
                                        }, {
                                          "id" : "105352423753525",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "cpIdentityId",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "cpIdentityIdPan",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Kaylin"
                                        }, {
                                          "id" : "105516829862229",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idType",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "PAN",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Nelle"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "105511138528672"
                                      },
                                      "id" : "105517558302637"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Durward"
                        }, {
                          "id" : "106531792326083",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "cpIdentityList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_related_parties",
                                    "name" : "Request payload Transformation",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Kristoffer",
                                        "statements" : [ {
                                          "id" : "106046626151196",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idNo",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "aadharNo",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Eduardo"
                                        }, {
                                          "id" : "106324237041753",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "cpIdentityId",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "cpIdentityIdAadhar",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Katharina"
                                        }, {
                                          "id" : "106534600723193",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idType",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "aadhaar",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Prince"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "106531282630366"
                                      },
                                      "id" : "106536891160923"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Lucy"
                        }, {
                          "id" : "107588118407526",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "cpIdentityList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_related_parties",
                                    "name" : "Request payload Transformation",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Lilyan",
                                        "statements" : [ {
                                          "id" : "107119877660260",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idNo",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "dINNo",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Milton"
                                        }, {
                                          "id" : "107277180352746",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "cpIdentityId",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "cpIdentityDIN",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Donavon"
                                        }, {
                                          "id" : "107299373891278",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idType",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "DIN",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Werner"
                                        }, {
                                          "id" : "107588151426931",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "expireDate",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "dINExpiry",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Arne"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "107585567437350"
                                      },
                                      "id" : "107587085325129"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Paris"
                        }, {
                          "id" : "108256949758408",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "cpIdentityList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_related_parties",
                                    "name" : "Request payload Transformation",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Irwin",
                                        "statements" : [ {
                                          "id" : "108049477090522",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idNo",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "passportNo",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Karolann"
                                        }, {
                                          "id" : "108208763543155",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "cpIdentityId",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "cpIdentityIdPassport",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Tracy"
                                        }, {
                                          "id" : "108252622695707",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idType",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "PASSPORT",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Lulu"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "108253773060258"
                                      },
                                      "id" : "108251438247623"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Abel"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "108252659119981"
                      },
                      "id" : "108252331685082"
                    } ]
                  },
                  "value" : "relatedParties"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Aisha"
        }, {
          "id" : "112248751848897",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.coApplicantList",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_related_parties",
                    "name" : "Request payload Transformation",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Ozzie",
                        "statements" : [ {
                          "id" : "108875412088911",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "keyword",
                              "dataValue" : "none",
                              "dataType" : "map"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : {
                                    "dateOfIncorporation" : "dateofIncorporationOrRegistrationDate",
                                    "fiPrincipalId" : "cIFID",
                                    "fullName" : "keyContactPerson",
                                    "natureOfBiz" : "natureofBusiness",
                                    "customerCategory" : "constitutionType",
                                    "email" : "emailID",
                                    "contactNo" : "contactNumber",
                                    "industryGroup" : "industryType"
                                  }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Cristian"
                        }, {
                          "id" : "109044631051029",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "cpAdditionalInfo",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "map",
                              "dataValue" : "map",
                              "keywordArguments" : {
                                "init" : {
                                  "fields" : { }
                                },
                                "format" : "populate"
                              }
                            }
                          },
                          "name" : "Landen"
                        }, {
                          "id" : "109772628690193",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "customerPrincipalAddressList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "transform Address Information",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Thurman",
                                        "statements" : [ {
                                          "id" : "109407277530438",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "keyword",
                                              "dataValue" : "none",
                                              "dataType" : "map"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "map",
                                              "dataValue" : "map",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "fields" : {
                                                    "address" : "addressLine1",
                                                    "stateProvinceRegion" : "state",
                                                    "address2" : "addressLine2",
                                                    "city" : "CityOrDistrict",
                                                    "cpAddId" : "addressid",
                                                    "addressType" : "typeofAddress",
                                                    "postalCode" : "pincode",
                                                    "isOwnedRented" : "ownershipType"
                                                  }
                                                },
                                                "format" : "populate"
                                              }
                                            }
                                          },
                                          "name" : "Frankie"
                                        }, {
                                          "id" : "109772729446780",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "addrAddlInfo",
                                              "dataType" : "list"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "keyword",
                                              "dataType" : "map",
                                              "dataValue" : "map",
                                              "keywordArguments" : {
                                                "init" : {
                                                  "fields" : { }
                                                },
                                                "format" : "populate"
                                              }
                                            }
                                          },
                                          "name" : "Ellen"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "109777099619461"
                                      },
                                      "id" : "109777051239768"
                                    } ]
                                  },
                                  "value" : "entityaddressDetailsNI"
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Grant"
                        }, {
                          "id" : "110712314982261",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "cpIdentityList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_related_parties",
                                    "name" : "Request payload Transformation",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Megane",
                                        "statements" : [ {
                                          "id" : "110506262088210",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idNo",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "panEntity",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Dan"
                                        }, {
                                          "id" : "110712812192172",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idType",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "PAN",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Patsy"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "110717781613716"
                                      },
                                      "id" : "110711162653430"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Julianne"
                        }, {
                          "id" : "111568828664512",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "cpIdentityList",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_related_parties",
                                    "name" : "Request payload Transformation",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Jessie",
                                        "statements" : [ {
                                          "id" : "111356260499794",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idNo",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "variable",
                                              "dataValue" : "primaryGSTIN",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Gilda"
                                        }, {
                                          "id" : "111568101633974",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "idType",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "GSTIN",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Elenora"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "111563538057687"
                                      },
                                      "id" : "111561878484948"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Hildegard"
                        }, {
                          "id" : "112121558841958",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "declare",
                              "dataValue" : "CollecteD_Keys",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "Collect",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Reese",
                                        "statements" : [ {
                                          "id" : "112127818940777",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "@type" : "SimpleAssignmentStatement",
                                            "lhs" : {
                                              "@type" : "declare",
                                              "dataValue" : "primitives",
                                              "dataType" : "list"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "function",
                                              "functionName" : "collect",
                                              "functionArguments" : {
                                                "pick" : "key",
                                                "condition" : {
                                                  "@type" : "logical",
                                                  "type" : "and",
                                                  "rules" : [ {
                                                    "@type" : "relational",
                                                    "lhs" : {
                                                      "@type" : "keyword",
                                                      "dataValue" : "mapvalue",
                                                      "dataType" : "boolean"
                                                    },
                                                    "operator" : {
                                                      "actualValue" : "=="
                                                    },
                                                    "rhs" : {
                                                      "@type" : "literal",
                                                      "dataValue" : true,
                                                      "dataType" : "boolean"
                                                    }
                                                  } ]
                                                }
                                              },
                                              "dataType" : "list"
                                            }
                                          },
                                          "name" : "Cyril"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "112127487087871"
                                      },
                                      "id" : "112127611854795"
                                    } ]
                                  },
                                  "value" : "relatedParties"
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Antonia"
                        }, {
                          "id" : "112245257317131",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "P",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "local",
                              "dataValue" : "primitives",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Pauline"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "112245703663032"
                      },
                      "id" : "112245610378866"
                    } ]
                  },
                  "value" : "relatedPartiesNI"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Phyllis"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "112247838154108"
      },
      "id" : "112247335928261"
    } ]
  }
}`

const TransConfig1 = `{
  "version" : 1,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "transform cibilresponse for Grid",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Arlie",
        "statements" : [ {
          "id" : "112702067717887",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "jg_perfios.jpf_customer.name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customerInfo.name",
              "dataType" : "text"
            }
          },
          "name" : "Raquel"
        }, {
          "id" : "112946815727988",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "jg_perfios.jpf_customer.accountstatements",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "statementdetails"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Florian"
        }, {
          "condition" : {
            "@type" : "logical",
            "type" : "and",
            "rules" : [ {
              "@type" : "relational",
              "lhs" : {
                "@type" : "variable",
                "dataType" : "text",
                "dataValue" : "accountAnalysis.[0].accountNo"
              },
              "operator" : {
                "actualValue" : "!="
              },
              "rhs" : {
                "@type" : "literal",
                "dataValue" : "nil",
                "dataType" : "text"
              }
            }, {
              "@type" : "relational",
              "lhs" : {
                "@type" : "variable",
                "dataType" : "text",
                "dataValue" : "accountAnalysis.[0].accountType"
              },
              "operator" : {
                "actualValue" : "=="
              },
              "rhs" : {
                "@type" : "literal",
                "dataType" : "text",
                "dataValue" : "SAVINGS"
              }
            } ]
          },
          "@type" : "ConditionalStatement",
          "success" : {
            "name" : "transformation",
            "statements" : [ {
              "@type" : "SectionalStatement",
              "section" : {
                "jsonIgnoreProperty" : false,
                "name" : "Nicholas",
                "statements" : [ {
                  "id" : "113518985876091",
                  "@type" : "AssignmentStatement",
                  "assignment" : {
                    "lhs" : {
                      "@type" : "literal",
                      "dataValue" : "jg_perfios.jpf_customer.status",
                      "dataType" : "text"
                    },
                    "operator" : {
                      "actualValue" : "="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "0",
                      "dataType" : "number"
                    }
                  },
                  "name" : "Magdalen"
                } ],
                "jsonIgnoreAliasValue" : null,
                "id" : "113515945911659"
              },
              "id" : "113517499832025"
            } ],
            "id" : "113518611262066"
          },
          "id" : 3
        }, {
          "id" : "113863355464060",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "jg_perfios.jpf_customer.bankname",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "customerInfo.bank",
              "dataType" : "text"
            }
          },
          "name" : "Ezequiel"
        }, {
          "id" : "114197064694532",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "jg_perfios.jpf_customer.totalCredits",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "AdditionalMonthlyDetails.MonthlyData2",
                  "aggregate" : "credits"
                },
                "format" : "sum"
              }
            }
          },
          "name" : "Harmon"
        }, {
          "id" : "114432881684641",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "jg_perfios.jpf_customer.verifiedAccounts",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "114439486099913",
                "name" : "filter accounts by type",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "statementStatus"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "VERIFIED",
                      "dataType" : "text"
                    }
                  }, {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "fileName"
                    },
                    "operator" : {
                      "actualValue" : "!="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "nil",
                      "dataType" : "text"
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "statementdetails"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Eudora"
        }, {
          "id" : "114603318579199",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "jg_perfios.jpf_customer.unVerifiedAccounts",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "114608686189987",
                "name" : "filter accounts by type",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "text",
                      "dataValue" : "statementStatus"
                    },
                    "operator" : {
                      "actualValue" : "=="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataValue" : "UNVERIFIED",
                      "dataType" : "text"
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "statementdetails"
                },
                "format" : "count"
              }
            }
          },
          "name" : "Alisa"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "114606815605565"
      },
      "id" : "114603506974347"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const SplitAndUseLocal = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customer Response",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kieran",
        "statements" : [ {
          "id" : "115017087586463",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "CustomerName",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "JaveedLocalName",
              "dataType" : "number"
            }
          },
          "name" : "Rebecca"
        }, {
          "id" : "115497498343358",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "splittedValues",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Mateo",
                        "statements" : [ {
                          "id" : "115496230682882",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "paymentHistory1",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "text",
                              "keywordArguments" : {
                                "init" : {
                                  "value" : "paymentHistory1",
                                  "splitby" : "3"
                                },
                                "format" : "split"
                              }
                            }
                          },
                          "name" : "Adrianna"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "115496049040776"
                      },
                      "id" : "115497114776405"
                    } ]
                  },
                  "value" : "relatedParties"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Kariane"
        }, {
          "id" : "116224953358134",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "fromlocalArray",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "Fat API Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Hilbert",
                        "statements" : [ {
                          "id" : "116014279587914",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "localArrayinside",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "variable",
                              "dataValue" : "paymentHistory1",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Alta"
                        }, {
                          "id" : "116226701299458",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "TotalVariablesInCount",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "number",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "value" : "paymentHistory1"
                                },
                                "format" : "count"
                              }
                            }
                          },
                          "name" : "Lonzo"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "116227716814541"
                      },
                      "id" : "116229144867730"
                    } ]
                  },
                  "value" : "splittedValues@local"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Betty"
        }, {
          "id" : "116399736742715",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Resp_Name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "ResponseName",
              "dataType" : "text"
            }
          },
          "name" : "Madge"
        }, {
          "id" : "116618412041322",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "LocalDataName",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "CustomerName@local",
              "dataType" : "number"
            }
          },
          "name" : "Herta"
        }, {
          "id" : "116803028354955",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "FromWithouAggregation",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "array.[0].primitives"
                },
                "format" : "sum"
              }
            }
          },
          "name" : "Rosamond"
        }, {
          "id" : "116977424064059",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "defaultArray",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "list",
              "dataType" : "list"
            }
          },
          "name" : "Davion"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "116973263825585"
      },
      "id" : "116971655069029"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeywordWithDayAndIncludeTrueWithInit = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Joaquin",
        "statements" : [ 
          {
            "id" : "705967289525232",
            "@type" : "AssignmentStatement",
            "assignment" : {
              "lhs" : {
                "@type" : "declare",
                "dataValue" : "previous15Months",
                "dataType" : "number"
              },
              "operator" : {
                "actualValue" : "="
              },
              "rhs" : {
                "@type" : "literal",
                "dataValue" : "-15",
                "dataType" : "number"
              }
            },
            "name" : "Rosalind"
          },{
          "id" : "117261979586439",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "day",
                "format" : "unixTime",
                "init" : {
                  "value" : 1608076800000,
                  "format" : "unixTime"
                },
                "value" : "previous15Months@local"
              }
            },
            "dataType" : "text"
          },
          "name" : "Ernie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "117266218332191"
      },
      "id" : "117262467936318"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const KeywordConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "FiltertheDateRepsonse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tamara",
        "statements" : [ {
          "id" : "117699610468507",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "3_Months_Credits",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "117697024025233",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "date",
                      "etype" : "MMM-yy",
                      "dataValue" : "monthName"
                    },
                    "operator" : {
                      "actualValue" : ">="
                    },
                    "rhs" : {
                      "@type" : "keyword",
                      "dataValue" : "date",
                      "dataType" : "date",
                      "keywordArguments" : {
                        "type" : "day",
                        "init" : {
                          "value" : "01/07/2021",
                          "format" : "dd/MM/yyyy"
                        }
                      }
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "AdditionalMonthlyDetails.MonthlyData1",
                  "aggregate" : "credits"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Trinity"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "117692796572461"
      },
      "id" : "117695566403266"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TestKeywordWithYearAndIncludeFalseWithInit = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [
      {
        "id" : "705967289525232",
        "@type" : "AssignmentStatement",
        "assignment" : {
          "lhs" : {
            "@type" : "declare",
            "dataValue" : "previous1Months",
            "dataType" : "number"
          },
          "operator" : {
            "actualValue" : "="
          },
          "rhs" : {
            "@type" : "literal",
            "dataValue" : "-1",
            "dataType" : "number"
          }
        },
        "name" : "Rosalind"
      }, {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Myrtis",
        "statements" : [ {
          "id" : "118186565775437",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "date",
              "dataType" : "date",
              "keywordArguments" : {
                "type" : "year",
                "init" : {
                  "value" : "startDate",
                  "format" : "dd/MM/yyyy"
                },
                "value" : "previous1Months@local",
                "includeDifference" : false
              }
            },
            "dataType" : "text"
          },
          "name" : "Tamia"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "118184314444520"
      },
      "id" : "118185926078733"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const TransConfig11 = `{
  "version": "1",
  "@type": "transform",
  "transform": {
      "id": "transform_config_1",
      "name": "Collect",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "jzimu",
                  "statements": [
                      {
                          "@type": "SectionalStatement",
                          "name": "BpcNo",
                          "section": {
                              "name": null,
                              "statements": [
                                  {
                                      "@type": "SectionalStatement",
                                      "section": {
                                          "jsonIgnoreProperty": false,
                                          "name": "nKZpz",
                                          "statements": [
                                              {
                                                  "id": "709392889714278",
                                                  "@type": "AssignmentStatement",
                                                  "assignment": {
                                                      "lhs": {
                                                          "@type": "literal",
                                                          "dataValue": "CollecteD_Keys",
                                                          "dataType": "list"
                                                      },
                                                      "operator": {
                                                          "actualValue": "="
                                                      },
                                                      "rhs": {
                                                          "@type": "keyword",
                                                          "dataType": "list",
                                                          "dataValue": "list",
                                                          "keywordArguments": {
                                                              "init": {
                                                                  "transform": {
                                                                      "id": "transform_config_1",
                                                                      "name": "Collect",
                                                                      "statements": [
                                                                          {
                                                                              "@type": "SectionalStatement",
                                                                              "section": {
                                                                                  "jsonIgnoreProperty": false,
                                                                                  "name": "VvrpX",
                                                                                  "statements": [
                                                                                      {
                                                                                          "@type": "SectionalStatement",
                                                                                          "name": "H9dnt",
                                                                                          "section": {
                                                                                              "name": null,
                                                                                              "statements": [
                                                                                                  {
                                                                                                      "@type": "SectionalStatement",
                                                                                                      "section": {
                                                                                                          "jsonIgnoreProperty": false,
                                                                                                          "name": "HHqHx",
                                                                                                          "statements": [
                                                                                                              {
                                                                                                                  "id": "709361607990607",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "arrayObject"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "value"
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "nApPq"
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709399365722351",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "arrayObjectKeySet"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "map",
                                                                                                                          "keywordArguments": {
                                                                                                                              "format": "getKeySet",
                                                                                                                              "init": {
                                                                                                                                  "value": "arrayObject@local"
                                                                                                                              }
                                                                                                                          }
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "mDIOu"
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709393477367027",
                                                                                                                  "name": "Statement 1697201799113696",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "mandatory": true,
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "list",
                                                                                                                          "dataValue": "arrayObjectList"
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "list",
                                                                                                                          "dataValue": "list",
                                                                                                                          "keywordArguments": {
                                                                                                                              "init": {
                                                                                                                                  "transform": {
                                                                                                                                      "id": "6744641075848",
                                                                                                                                      "name": "Iterate 724645",
                                                                                                                                      "statements": [
                                                                                                                                          {
                                                                                                                                              "@type": "SectionalStatement",
                                                                                                                                              "section": {
                                                                                                                                                  "jsonIgnoreProperty": false,
                                                                                                                                                  "name": "XdRPl",
                                                                                                                                                  "statements": [
                                                                                                                                                      {
                                                                                                                                                          "id": "709394631669177",
                                                                                                                                                          "@type": "AssignmentStatement",
                                                                                                                                                          "assignment": {
                                                                                                                                                              "lhs": {
                                                                                                                                                                  "@type": "declare",
                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                  "dataValue": "arrayObjectKey"
                                                                                                                                                              },
                                                                                                                                                              "operator": {
                                                                                                                                                                  "actualValue": "="
                                                                                                                                                              },
                                                                                                                                                              "rhs": {
                                                                                                                                                                  "@type": "keyword",
                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                  "dataValue": "value"
                                                                                                                                                              }
                                                                                                                                                          },
                                                                                                                                                          "name": "mOCFK"
                                                                                                                                                      },
                                                                                                                                                      {
                                                                                                                                                          "condition": {
                                                                                                                                                              "@type": "logical",
                                                                                                                                                              "type": "and",
                                                                                                                                                              "rules": [
                                                                                                                                                                  {
                                                                                                                                                                      "@type": "relational",
                                                                                                                                                                      "lhs": {
                                                                                                                                                                          "@type": "literal",
                                                                                                                                                                          "dataValue": "director",
                                                                                                                                                                          "dataType": "text"
                                                                                                                                                                      },
                                                                                                                                                                      "operator": {
                                                                                                                                                                          "actualValue": "=="
                                                                                                                                                                      },
                                                                                                                                                                      "rhs": {
                                                                                                                                                                          "@type": "variable",
                                                                                                                                                                          "dataValue": "arrayObjectKey@local",
                                                                                                                                                                          "dataType": "text"
                                                                                                                                                                      }
                                                                                                                                                                  }
                                                                                                                                                              ]
                                                                                                                                                          },
                                                                                                                                                          "@type": "ConditionalStatement",
                                                                                                                                                          "success": {
                                                                                                                                                              "name": "transformation",
                                                                                                                                                              "statements": [
                                                                                                                                                                  {
                                                                                                                                                                      "@type": "SectionalStatement",
                                                                                                                                                                      "section": {
                                                                                                                                                                          "jsonIgnoreProperty": false,
                                                                                                                                                                          "name": "nEAuG",
                                                                                                                                                                          "statements": [
                                                                                                                                                                              {
                                                                                                                                                                                  "@type": "SectionalStatement",
                                                                                                                                                                                  "name": "4F0im",
                                                                                                                                                                                  "section": {
                                                                                                                                                                                      "name": null,
                                                                                                                                                                                      "statements": [
                                                                                                                                                                                          {
                                                                                                                                                                                              "@type": "SectionalStatement",
                                                                                                                                                                                              "section": {
                                                                                                                                                                                                  "jsonIgnoreProperty": false,
                                                                                                                                                                                                  "name": "nOwkA",
                                                                                                                                                                                                  "statements": [
                                                                                                                                                                                                      {
                                                                                                                                                                                                          "id": "709393573753694",
                                                                                                                                                                                                          "@type": "AssignmentStatement",
                                                                                                                                                                                                          "assignment": {
                                                                                                                                                                                                              "lhs": {
                                                                                                                                                                                                                  "@type": "declare",
                                                                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                                                                  "dataValue": "arrayObjectValueByKey"
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "operator": {
                                                                                                                                                                                                                  "actualValue": "="
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "rhs": {
                                                                                                                                                                                                                  "@type": "keyword",
                                                                                                                                                                                                                  "dataValue": "map",
                                                                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                                                                  "keywordArguments": {
                                                                                                                                                                                                                      "format": "getValueByKey",
                                                                                                                                                                                                                      "init": {
                                                                                                                                                                                                                          "key": "arrayObjectKey@local",
                                                                                                                                                                                                                          "value": "arrayObject@local"
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }
                                                                                                                                                                                                          },
                                                                                                                                                                                                          "name": "nSmdf"
                                                                                                                                                                                                      },
                                                                                                                                                                                                      {
                                                                                                                                                                                                          "id": "709392971574523",
                                                                                                                                                                                                          "name": "Statement 1697536215578009",
                                                                                                                                                                                                          "@type": "AssignmentStatement",
                                                                                                                                                                                                          "mandatory": true,
                                                                                                                                                                                                          "assignment": {
                                                                                                                                                                                                              "lhs": {
                                                                                                                                                                                                                  "@type": "declare",
                                                                                                                                                                                                                  "dataType": "list",
                                                                                                                                                                                                                  "dataValue": "primitives"
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "rhs": {
                                                                                                                                                                                                                  "@type": "keyword",
                                                                                                                                                                                                                  "dataType": "list",
                                                                                                                                                                                                                  "dataValue": "list",
                                                                                                                                                                                                                  "keywordArguments": {
                                                                                                                                                                                                                      "init": {
                                                                                                                                                                                                                          "values": [
                                                                                                                                                                                                                              "arrayObjectValueByKey@local"
                                                                                                                                                                                                                          ]
                                                                                                                                                                                                                      },
                                                                                                                                                                                                                      "format": "push"
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "operator": {
                                                                                                                                                                                                                  "actualValue": "="
                                                                                                                                                                                                              }
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }
                                                                                                                                                                                                  ],
                                                                                                                                                                                                  "jsonIgnoreAliasValue": null,
                                                                                                                                                                                                  "id": "709395210906087"
                                                                                                                                                                                              },
                                                                                                                                                                                              "id": "709395477120557"
                                                                                                                                                                                          }
                                                                                                                                                                                      ],
                                                                                                                                                                                      "id": "709396701563849"
                                                                                                                                                                                  },
                                                                                                                                                                                  "id": "709392169520205"
                                                                                                                                                                              }
                                                                                                                                                                          ],
                                                                                                                                                                          "jsonIgnoreAliasValue": null,
                                                                                                                                                                          "id": "709393170899783"
                                                                                                                                                                      },
                                                                                                                                                                      "id": "709392226720816"
                                                                                                                                                                  }
                                                                                                                                                              ],
                                                                                                                                                              "id": "709399495102344"
                                                                                                                                                          },
                                                                                                                                                          "failure": {},
                                                                                                                                                          "id": "709394392740716"
                                                                                                                                                      }
                                                                                                                                                  ],
                                                                                                                                                  "jsonIgnoreAliasValue": null,
                                                                                                                                                  "id": "709398214261251"
                                                                                                                                              },
                                                                                                                                              "id": "709393624788085"
                                                                                                                                          }
                                                                                                                                      ]
                                                                                                                                  },
                                                                                                                                  "value": "arrayObjectKeySet@local"
                                                                                                                              },
                                                                                                                              "format": "iterate"
                                                                                                                          }
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      }
                                                                                                                  }
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709391746308747",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "literal",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "primitives"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "variable",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "primitives@local"
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "ZBKmv"
                                                                                                              }
                                                                                                          ],
                                                                                                          "jsonIgnoreAliasValue": null,
                                                                                                          "id": "709397728672201"
                                                                                                      },
                                                                                                      "id": "709396741112171"
                                                                                                  }
                                                                                              ],
                                                                                              "id": "709394387127814"
                                                                                          },
                                                                                          "id": "709344598005253"
                                                                                      }
                                                                                  ],
                                                                                  "jsonIgnoreAliasValue": null,
                                                                                  "id": "709398998158885"
                                                                              },
                                                                              "id": "709392278200669"
                                                                          }
                                                                      ]
                                                                  },
                                                                  "value": "arrayName"
                                                              },
                                                              "format": "iterate"
                                                          }
                                                      }
                                                  },
                                                  "name": "Shirley"
                                              },
                                              {
                                                  "id": "709396837552800",
                                                  "@type": "AssignmentStatement",
                                                  "assignment": {
                                                      "lhs": {
                                                          "@type": "declare",
                                                          "dataType": "text",
                                                          "dataValue": "primitives"
                                                      },
                                                      "operator": {
                                                          "actualValue": "="
                                                      },
                                                      "rhs": {
                                                          "@type": "keyword",
                                                          "dataType": "text",
                                                          "dataValue": "text",
                                                          "keywordArguments": {
                                                              "format": "getNullValue"
                                                          }
                                                      }
                                                  },
                                                  "name": "IFeFX"
                                              },
                                              {
                                                  "id": "709402796500430",
                                                  "@type": "AssignmentStatement",
                                                  "assignment": {
                                                      "lhs": {
                                                          "@type": "literal",
                                                          "dataValue": "CollecteD_Keys",
                                                          "dataType": "list"
                                                      },
                                                      "operator": {
                                                          "actualValue": "="
                                                      },
                                                      "rhs": {
                                                          "@type": "keyword",
                                                          "dataType": "list",
                                                          "dataValue": "list",
                                                          "keywordArguments": {
                                                              "init": {
                                                                  "transform": {
                                                                      "id": "transform_config_1",
                                                                      "name": "Collect",
                                                                      "statements": [
                                                                          {
                                                                              "@type": "SectionalStatement",
                                                                              "section": {
                                                                                  "jsonIgnoreProperty": false,
                                                                                  "name": "hYdlo",
                                                                                  "statements": [
                                                                                      {
                                                                                          "@type": "SectionalStatement",
                                                                                          "name": "AkPyx",
                                                                                          "section": {
                                                                                              "name": null,
                                                                                              "statements": [
                                                                                                  {
                                                                                                      "@type": "SectionalStatement",
                                                                                                      "section": {
                                                                                                          "jsonIgnoreProperty": false,
                                                                                                          "name": "nMxWi",
                                                                                                          "statements": [
                                                                                                              {
                                                                                                                  "id": "709399685739822",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "relatedPartiesObject"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "value"
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "Jxdhp"
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709391063280719",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "relatedPartiesObjectKeySet"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "map",
                                                                                                                          "keywordArguments": {
                                                                                                                              "format": "getKeySet",
                                                                                                                              "init": {
                                                                                                                                  "value": "relatedPartiesObject@local"
                                                                                                                              }
                                                                                                                          }
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "AJURw"
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709399277745979",
                                                                                                                  "name": "Statement 1697201799113696",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "mandatory": true,
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "list",
                                                                                                                          "dataValue": "relatedPartieslist"
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "list",
                                                                                                                          "dataValue": "list",
                                                                                                                          "keywordArguments": {
                                                                                                                              "init": {
                                                                                                                                  "transform": {
                                                                                                                                      "id": "6744641075848",
                                                                                                                                      "name": "Iterate 724645",
                                                                                                                                      "statements": [
                                                                                                                                          {
                                                                                                                                              "@type": "SectionalStatement",
                                                                                                                                              "section": {
                                                                                                                                                  "jsonIgnoreProperty": false,
                                                                                                                                                  "name": "lDcXi",
                                                                                                                                                  "statements": [
                                                                                                                                                      {
                                                                                                                                                          "id": "709392259160691",
                                                                                                                                                          "@type": "AssignmentStatement",
                                                                                                                                                          "assignment": {
                                                                                                                                                              "lhs": {
                                                                                                                                                                  "@type": "declare",
                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                  "dataValue": "relatedPartiesKey"
                                                                                                                                                              },
                                                                                                                                                              "operator": {
                                                                                                                                                                  "actualValue": "="
                                                                                                                                                              },
                                                                                                                                                              "rhs": {
                                                                                                                                                                  "@type": "keyword",
                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                  "dataValue": "value"
                                                                                                                                                              }
                                                                                                                                                          },
                                                                                                                                                          "name": "JMJoT"
                                                                                                                                                      },
                                                                                                                                                      {
                                                                                                                                                          "condition": {
                                                                                                                                                              "@type": "logical",
                                                                                                                                                              "type": "and",
                                                                                                                                                              "rules": [
                                                                                                                                                                  {
                                                                                                                                                                      "@type": "relational",
                                                                                                                                                                      "lhs": {
                                                                                                                                                                          "@type": "literal",
                                                                                                                                                                          "dataValue": true,
                                                                                                                                                                          "dataType": "text"
                                                                                                                                                                      },
                                                                                                                                                                      "operator": {
                                                                                                                                                                          "actualValue": "=="
                                                                                                                                                                      },
                                                                                                                                                                      "rhs": {
                                                                                                                                                                          "@type": "keyword",
                                                                                                                                                                          "dataValue": "map",
                                                                                                                                                                          "dataType": "text",
                                                                                                                                                                          "keywordArguments": {
                                                                                                                                                                              "format": "getValueByKey",
                                                                                                                                                                              "init": {
                                                                                                                                                                                  "key": "relatedPartiesKey@local",
                                                                                                                                                                                  "value": "relatedPartiesObject@local"
                                                                                                                                                                              }
                                                                                                                                                                          }
                                                                                                                                                                      }
                                                                                                                                                                  }
                                                                                                                                                              ]
                                                                                                                                                          },
                                                                                                                                                          "@type": "ConditionalStatement",
                                                                                                                                                          "success": {
                                                                                                                                                              "name": "transformation",
                                                                                                                                                              "statements": [
                                                                                                                                                                  {
                                                                                                                                                                      "@type": "SectionalStatement",
                                                                                                                                                                      "section": {
                                                                                                                                                                          "jsonIgnoreProperty": false,
                                                                                                                                                                          "name": "XPCLT",
                                                                                                                                                                          "statements": [
                                                                                                                                                                              {
                                                                                                                                                                                  "@type": "SectionalStatement",
                                                                                                                                                                                  "name": "jbQnd",
                                                                                                                                                                                  "section": {
                                                                                                                                                                                      "name": null,
                                                                                                                                                                                      "statements": [
                                                                                                                                                                                          {
                                                                                                                                                                                              "@type": "SectionalStatement",
                                                                                                                                                                                              "section": {
                                                                                                                                                                                                  "jsonIgnoreProperty": false,
                                                                                                                                                                                                  "name": "YVzFF",
                                                                                                                                                                                                  "statements": [
                                                                                                                                                                                                      {
                                                                                                                                                                                                          "id": "709399596505487",
                                                                                                                                                                                                          "name": "Statement 1697536215578009",
                                                                                                                                                                                                          "@type": "AssignmentStatement",
                                                                                                                                                                                                          "mandatory": true,
                                                                                                                                                                                                          "assignment": {
                                                                                                                                                                                                              "lhs": {
                                                                                                                                                                                                                  "@type": "declare",
                                                                                                                                                                                                                  "dataType": "list",
                                                                                                                                                                                                                  "dataValue": "primitives"
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "rhs": {
                                                                                                                                                                                                                  "@type": "keyword",
                                                                                                                                                                                                                  "dataType": "list",
                                                                                                                                                                                                                  "dataValue": "list",
                                                                                                                                                                                                                  "keywordArguments": {
                                                                                                                                                                                                                      "init": {
                                                                                                                                                                                                                          "values": [
                                                                                                                                                                                                                              "relatedPartiesKey@local"
                                                                                                                                                                                                                          ]
                                                                                                                                                                                                                      },
                                                                                                                                                                                                                      "format": "push"
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "operator": {
                                                                                                                                                                                                                  "actualValue": "="
                                                                                                                                                                                                              }
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }
                                                                                                                                                                                                  ],
                                                                                                                                                                                                  "jsonIgnoreAliasValue": null,
                                                                                                                                                                                                  "id": "709392475532876"
                                                                                                                                                                                              },
                                                                                                                                                                                              "id": "709393360632085"
                                                                                                                                                                                          }
                                                                                                                                                                                      ],
                                                                                                                                                                                      "id": "709397279549622"
                                                                                                                                                                                  },
                                                                                                                                                                                  "id": "709394948924546"
                                                                                                                                                                              }
                                                                                                                                                                          ],
                                                                                                                                                                          "jsonIgnoreAliasValue": null,
                                                                                                                                                                          "id": "709397312804770"
                                                                                                                                                                      },
                                                                                                                                                                      "id": "709397583333007"
                                                                                                                                                                  }
                                                                                                                                                              ],
                                                                                                                                                              "id": "709394589500573"
                                                                                                                                                          },
                                                                                                                                                          "failure": {},
                                                                                                                                                          "id": "709396287269720"
                                                                                                                                                      }
                                                                                                                                                  ],
                                                                                                                                                  "jsonIgnoreAliasValue": null,
                                                                                                                                                  "id": "709397389365423"
                                                                                                                                              },
                                                                                                                                              "id": "709391816932372"
                                                                                                                                          }
                                                                                                                                      ]
                                                                                                                                  },
                                                                                                                                  "value": "relatedPartiesObjectKeySet@local"
                                                                                                                              },
                                                                                                                              "format": "iterate"
                                                                                                                          }
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      }
                                                                                                                  }
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709397228153453",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "literal",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "primitives"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "variable",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "primitives@local"
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "dmuco"
                                                                                                              }
                                                                                                          ],
                                                                                                          "jsonIgnoreAliasValue": null,
                                                                                                          "id": "709397167873286"
                                                                                                      },
                                                                                                      "id": "709398266877793"
                                                                                                  }
                                                                                              ],
                                                                                              "id": "709396368186963"
                                                                                          },
                                                                                          "id": "709392677359725"
                                                                                      }
                                                                                  ],
                                                                                  "jsonIgnoreAliasValue": null,
                                                                                  "id": "709408340561040"
                                                                              },
                                                                              "id": "709407742375314"
                                                                          }
                                                                      ]
                                                                  },
                                                                  "value": "relatedParties"
                                                              },
                                                              "format": "iterate"
                                                          }
                                                      }
                                                  },
                                                  "name": "Bradly"
                                              },
                                              {
                                                  "id": "709409245783707",
                                                  "@type": "AssignmentStatement",
                                                  "assignment": {
                                                      "lhs": {
                                                          "@type": "declare",
                                                          "dataType": "text",
                                                          "dataValue": "primitives"
                                                      },
                                                      "operator": {
                                                          "actualValue": "="
                                                      },
                                                      "rhs": {
                                                          "@type": "keyword",
                                                          "dataType": "text",
                                                          "dataValue": "text",
                                                          "keywordArguments": {
                                                              "format": "getNullValue"
                                                          }
                                                      }
                                                  },
                                                  "name": "XXoBh"
                                              },
                                              {
                                                  "id": "709405567150652",
                                                  "@type": "AssignmentStatement",
                                                  "assignment": {
                                                      "lhs": {
                                                          "@type": "literal",
                                                          "dataValue": "CollecteD_Keys",
                                                          "dataType": "list"
                                                      },
                                                      "operator": {
                                                          "actualValue": "="
                                                      },
                                                      "rhs": {
                                                          "@type": "keyword",
                                                          "dataType": "list",
                                                          "dataValue": "list",
                                                          "keywordArguments": {
                                                              "init": {
                                                                  "transform": {
                                                                      "id": "transform_config_1",
                                                                      "name": "Collect",
                                                                      "statements": [
                                                                          {
                                                                              "@type": "SectionalStatement",
                                                                              "section": {
                                                                                  "jsonIgnoreProperty": false,
                                                                                  "name": "DLqrP",
                                                                                  "statements": [
                                                                                      {
                                                                                          "@type": "SectionalStatement",
                                                                                          "name": "A9KpI",
                                                                                          "section": {
                                                                                              "name": null,
                                                                                              "statements": [
                                                                                                  {
                                                                                                      "@type": "SectionalStatement",
                                                                                                      "section": {
                                                                                                          "jsonIgnoreProperty": false,
                                                                                                          "name": "Zuxma",
                                                                                                          "statements": [
                                                                                                              {
                                                                                                                  "id": "709404022497679",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "relatedPartiesNIObject"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "value"
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "LSjNj"
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709405132121805",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "relatedPartiesNIObjectKeySet"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "map",
                                                                                                                          "keywordArguments": {
                                                                                                                              "format": "getKeySet",
                                                                                                                              "init": {
                                                                                                                                  "value": "relatedPartiesNIObject@local"
                                                                                                                              }
                                                                                                                          }
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "xVWxG"
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709408593122402",
                                                                                                                  "name": "Statement 1697201799113696",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "mandatory": true,
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "declare",
                                                                                                                          "dataType": "list",
                                                                                                                          "dataValue": "relatedPartiesNIlist"
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "keyword",
                                                                                                                          "dataType": "list",
                                                                                                                          "dataValue": "list",
                                                                                                                          "keywordArguments": {
                                                                                                                              "init": {
                                                                                                                                  "transform": {
                                                                                                                                      "id": "6744641075848",
                                                                                                                                      "name": "Iterate 724645",
                                                                                                                                      "statements": [
                                                                                                                                          {
                                                                                                                                              "@type": "SectionalStatement",
                                                                                                                                              "section": {
                                                                                                                                                  "jsonIgnoreProperty": false,
                                                                                                                                                  "name": "hcofw",
                                                                                                                                                  "statements": [
                                                                                                                                                      {
                                                                                                                                                          "id": "709404671318714",
                                                                                                                                                          "@type": "AssignmentStatement",
                                                                                                                                                          "assignment": {
                                                                                                                                                              "lhs": {
                                                                                                                                                                  "@type": "declare",
                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                  "dataValue": "relatedPartiesNIKey"
                                                                                                                                                              },
                                                                                                                                                              "operator": {
                                                                                                                                                                  "actualValue": "="
                                                                                                                                                              },
                                                                                                                                                              "rhs": {
                                                                                                                                                                  "@type": "keyword",
                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                  "dataValue": "value"
                                                                                                                                                              }
                                                                                                                                                          },
                                                                                                                                                          "name": "gbIaF"
                                                                                                                                                      },
                                                                                                                                                      {
                                                                                                                                                          "condition": {
                                                                                                                                                              "@type": "logical",
                                                                                                                                                              "type": "and",
                                                                                                                                                              "rules": [
                                                                                                                                                                  {
                                                                                                                                                                      "@type": "relational",
                                                                                                                                                                      "lhs": {
                                                                                                                                                                          "@type": "literal",
                                                                                                                                                                          "dataValue": true,
                                                                                                                                                                          "dataType": "text"
                                                                                                                                                                      },
                                                                                                                                                                      "operator": {
                                                                                                                                                                          "actualValue": "=="
                                                                                                                                                                      },
                                                                                                                                                                      "rhs": {
                                                                                                                                                                          "@type": "keyword",
                                                                                                                                                                          "dataValue": "map",
                                                                                                                                                                          "dataType": "text",
                                                                                                                                                                          "keywordArguments": {
                                                                                                                                                                              "format": "getValueByKey",
                                                                                                                                                                              "init": {
                                                                                                                                                                                  "key": "relatedPartiesNIKey@local",
                                                                                                                                                                                  "value": "relatedPartiesNIObject@local"
                                                                                                                                                                              }
                                                                                                                                                                          }
                                                                                                                                                                      }
                                                                                                                                                                  }
                                                                                                                                                              ]
                                                                                                                                                          },
                                                                                                                                                          "@type": "ConditionalStatement",
                                                                                                                                                          "success": {
                                                                                                                                                              "name": "transformation",
                                                                                                                                                              "statements": [
                                                                                                                                                                  {
                                                                                                                                                                      "@type": "SectionalStatement",
                                                                                                                                                                      "section": {
                                                                                                                                                                          "jsonIgnoreProperty": false,
                                                                                                                                                                          "name": "vReQD",
                                                                                                                                                                          "statements": [
                                                                                                                                                                              {
                                                                                                                                                                                  "@type": "SectionalStatement",
                                                                                                                                                                                  "name": "XM4zx",
                                                                                                                                                                                  "section": {
                                                                                                                                                                                      "name": null,
                                                                                                                                                                                      "statements": [
                                                                                                                                                                                          {
                                                                                                                                                                                              "@type": "SectionalStatement",
                                                                                                                                                                                              "section": {
                                                                                                                                                                                                  "jsonIgnoreProperty": false,
                                                                                                                                                                                                  "name": "XneaM",
                                                                                                                                                                                                  "statements": [
                                                                                                                                                                                                      {
                                                                                                                                                                                                          "id": "709407824074030",
                                                                                                                                                                                                          "@type": "AssignmentStatement",
                                                                                                                                                                                                          "assignment": {
                                                                                                                                                                                                              "lhs": {
                                                                                                                                                                                                                  "@type": "declare",
                                                                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                                                                  "dataValue": "relatedPartiesNiValueByKey"
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "operator": {
                                                                                                                                                                                                                  "actualValue": "="
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "rhs": {
                                                                                                                                                                                                                  "@type": "keyword",
                                                                                                                                                                                                                  "dataValue": "map",
                                                                                                                                                                                                                  "dataType": "text",
                                                                                                                                                                                                                  "keywordArguments": {
                                                                                                                                                                                                                      "format": "getValueByKey",
                                                                                                                                                                                                                      "init": {
                                                                                                                                                                                                                          "key": "relatedPartiesNIKey@local",
                                                                                                                                                                                                                          "value": "relatedPartiesNIObject@local"
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }
                                                                                                                                                                                                          },
                                                                                                                                                                                                          "name": "SfFNd"
                                                                                                                                                                                                      },
                                                                                                                                                                                                      {
                                                                                                                                                                                                          "id": "709404793979343",
                                                                                                                                                                                                          "name": "Statement 1697536215578009",
                                                                                                                                                                                                          "@type": "AssignmentStatement",
                                                                                                                                                                                                          "mandatory": true,
                                                                                                                                                                                                          "assignment": {
                                                                                                                                                                                                              "lhs": {
                                                                                                                                                                                                                  "@type": "declare",
                                                                                                                                                                                                                  "dataType": "list",
                                                                                                                                                                                                                  "dataValue": "primitives"
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "rhs": {
                                                                                                                                                                                                                  "@type": "keyword",
                                                                                                                                                                                                                  "dataType": "list",
                                                                                                                                                                                                                  "dataValue": "list",
                                                                                                                                                                                                                  "keywordArguments": {
                                                                                                                                                                                                                      "init": {
                                                                                                                                                                                                                          "values": [
                                                                                                                                                                                                                              "relatedPartiesNiValueByKey@local"
                                                                                                                                                                                                                          ]
                                                                                                                                                                                                                      },
                                                                                                                                                                                                                      "format": "push"
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              },
                                                                                                                                                                                                              "operator": {
                                                                                                                                                                                                                  "actualValue": "="
                                                                                                                                                                                                              }
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }
                                                                                                                                                                                                  ],
                                                                                                                                                                                                  "jsonIgnoreAliasValue": null,
                                                                                                                                                                                                  "id": "709406528494449"
                                                                                                                                                                                              },
                                                                                                                                                                                              "id": "709402943563150"
                                                                                                                                                                                          }
                                                                                                                                                                                      ],
                                                                                                                                                                                      "id": "709403812001463"
                                                                                                                                                                                  },
                                                                                                                                                                                  "id": "709403414134982"
                                                                                                                                                                              }
                                                                                                                                                                          ],
                                                                                                                                                                          "jsonIgnoreAliasValue": null,
                                                                                                                                                                          "id": "709403710533517"
                                                                                                                                                                      },
                                                                                                                                                                      "id": "709405479788629"
                                                                                                                                                                  }
                                                                                                                                                              ],
                                                                                                                                                              "id": "709408359705702"
                                                                                                                                                          },
                                                                                                                                                          "failure": {},
                                                                                                                                                          "id": "709408648845554"
                                                                                                                                                      }
                                                                                                                                                  ],
                                                                                                                                                  "jsonIgnoreAliasValue": null,
                                                                                                                                                  "id": "709401816219363"
                                                                                                                                              },
                                                                                                                                              "id": "709404397164549"
                                                                                                                                          }
                                                                                                                                      ]
                                                                                                                                  },
                                                                                                                                  "value": "relatedPartiesNIObjectKeySet@local"
                                                                                                                              },
                                                                                                                              "format": "iterate"
                                                                                                                          }
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      }
                                                                                                                  }
                                                                                                              },
                                                                                                              {
                                                                                                                  "id": "709404905754525",
                                                                                                                  "@type": "AssignmentStatement",
                                                                                                                  "assignment": {
                                                                                                                      "lhs": {
                                                                                                                          "@type": "literal",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "primitives"
                                                                                                                      },
                                                                                                                      "operator": {
                                                                                                                          "actualValue": "="
                                                                                                                      },
                                                                                                                      "rhs": {
                                                                                                                          "@type": "variable",
                                                                                                                          "dataType": "text",
                                                                                                                          "dataValue": "primitives@local"
                                                                                                                      }
                                                                                                                  },
                                                                                                                  "name": "MomzR"
                                                                                                              }
                                                                                                          ],
                                                                                                          "jsonIgnoreAliasValue": null,
                                                                                                          "id": "709404690584961"
                                                                                                      },
                                                                                                      "id": "709406882541010"
                                                                                                  }
                                                                                              ],
                                                                                              "id": "709401507577682"
                                                                                          },
                                                                                          "id": "709405694477507"
                                                                                      }
                                                                                  ],
                                                                                  "jsonIgnoreAliasValue": null,
                                                                                  "id": "709403522176569"
                                                                              },
                                                                              "id": "709402927969186"
                                                                          }
                                                                      ]
                                                                  },
                                                                  "value": "relatedPartiesNI"
                                                              },
                                                              "format": "iterate"
                                                          }
                                                      }
                                                  },
                                                  "name": "Arlo"
                                              }
                                          ],
                                          "jsonIgnoreAliasValue": null,
                                          "id": "709409272192273"
                                      },
                                      "id": "709406714719437"
                                  }
                              ],
                              "id": "709402297370214"
                          },
                          "id": "709337645258956"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "709402820600524"
              },
              "id": "709409468351388"
          }
      ]
  },
  "delete": {},
  "extract": {},
  "id": "709401796501483"
}`

const ConfigConcatWithMultipleValue = `{
  "version" : "1",
  "@type" : "transform",
  "contentInputType" : "json",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Telly",
        "statements" : [ {
          "id" : "121263986724241",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "toBeConcatedValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "response.enquiryMemberUserId",
                  "values" : [ "response.tuefsegmentTag", "response.enquiryControlNumber", "response.processedDateTime" ],
                  "concatWith" : ""
                },
                "format" : "concat"
              }
            }
          },
          "name" : "Raleigh"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "121261629087278"
      },
      "id" : "121262047845045"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`
