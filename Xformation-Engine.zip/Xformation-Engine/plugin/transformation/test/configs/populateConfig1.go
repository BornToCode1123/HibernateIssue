package configs

const PopulateLocalandData1 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Laurence",
        "statements" : [ {
          "id" : "742863303505597",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "text",
              "dataValue" : "name"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "Javed"
            }
          },
          "name" : "Joelle"
        }, {
          "id" : "743946077317960",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "number",
              "dataValue" : "age"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "number",
              "dataValue" : 22
            }
          },
          "name" : "Ralph"
        }, {
          "id" : "745287500172323",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "text",
              "dataValue" : "role"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "developer"
            }
          },
          "name" : "Gabe"
        }, {
          "id" : "746225805915429",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "customerAge" : "age@local",
                    "designation" : "role",
                    "customerName" : "name@local"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Jeanie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "746227966474299"
      },
      "id" : "746227507470245"
    } ]
  }
}`

const PopulateEmptyFields1 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Orrin",
        "statements" : [ {
          "id" : "752719212133695",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "populateEmpty",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : { }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Bailey"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "752712460623349"
      },
      "id" : "752715923859381"
    } ]
  }
}`

const PopulateLocal1 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jose",
        "statements" : [ {
          "id" : "753855780996928",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "text",
              "dataValue" : "name"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "Javed"
            }
          },
          "name" : "Shana"
        }, {
          "id" : "754424321871194",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "number",
              "dataValue" : "age"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "number",
              "dataValue" : 22
            }
          },
          "name" : "Ollie"
        }, {
          "id" : "754869403795567",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataType" : "text",
              "dataValue" : "role"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataType" : "text",
              "dataValue" : "developer"
            }
          },
          "name" : "Lyla"
        }, {
          "id" : "755332890280567",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "customerAge" : "age@local",
                    "designation" : "role@local",
                    "customerName" : "name@local"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Yessenia"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "755335410458478"
      },
      "id" : "755331874626759"
    } ]
  }
}`

const PopulateSample1 = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Estefania",
        "statements" : [ {
          "id" : "756758957247731",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "map",
              "dataValue" : "map",
              "keywordArguments" : {
                "init" : {
                  "fields" : {
                    "customerAge" : "age",
                    "designation" : "gender"
                  }
                },
                "format" : "populate"
              }
            }
          },
          "name" : "Tianna"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "756751088428672"
      },
      "id" : "756759608477370"
    } ]
  }
}`
