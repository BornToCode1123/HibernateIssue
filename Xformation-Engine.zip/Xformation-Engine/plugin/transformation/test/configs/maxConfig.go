package configs 

const LocalArrayObjectMaxConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Antonietta",
        "statements" : [ {
          "id" : "293594476672008",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "ratingsMaximum",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Merritt"
        }, {
          "id" : "294199084407598",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "MaximumLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "ratingsMaximum@local",
              "dataType" : "text"
            }
          },
          "name" : "Dorris"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "294193692740771"
      },
      "id" : "294194893812362"
    } ]
  }
}`

const ArrayObjectMaxConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "King",
        "statements" : [ {
          "id" : "296111308698428",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "ratingsMaximum",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Erin"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "296114270455521"
      },
      "id" : "296118377419663"
    } ]
  }
}`

const NilMaxConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tre",
        "statements" : [ {
          "id" : "297495883333906",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalcount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores2"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Constantin"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "297508775091072"
      },
      "id" : "297508776428108"
    } ]
  }
}`

const FilterMaxNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Darrell",
        "statements" : [ {
          "id" : "300921842073907",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "maxrating",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "300922162359999",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "!="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 10
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Lauriane"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "300935334864091"
      },
      "id" : "300933180164344"
    } ]
  }
}`

const EmptyArrayMaxConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Annette",
        "statements" : [ {
          "id" : "302174274036676",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "ratingsMaximum1",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores1"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Toney"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "302175950778284"
      },
      "id" : "302175769326359"
    } ]
  }
}`

const FilterPrimitiveArrayMaxConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Nestor",
        "statements" : [ {
          "id" : "303393697161051",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "maxrating",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "303391791345050",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "!="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 4
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "name"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Ubaldo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "303392120504041"
      },
      "id" : "303398179169886"
    } ]
  }
}`

const PrimitiveArrayMaxConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ned",
        "statements" : [ {
          "id" : "304114276954542",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "totalnumbercount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "name"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Marlee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "304172664468041"
      },
      "id" : "304176538351452"
    } ]
  }
}`

const LocalFilterMaxNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Emely",
        "statements" : [ {
          "id" : "304728304153988",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "maxrating",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "filter" : {
                "id" : "304725167154707",
                "name" : "filteraccountsbytype",
                "condition" : {
                  "@type" : "logical",
                  "type" : "and",
                  "rules" : [ {
                    "@type" : "relational",
                    "lhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : "value"
                    },
                    "operator" : {
                      "actualValue" : "!="
                    },
                    "rhs" : {
                      "@type" : "literal",
                      "dataType" : "number",
                      "dataValue" : 4
                    }
                  } ]
                }
              },
              "@type" : "keyword",
              "dataType" : "number",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "value" : "scores",
                  "aggregate" : "value"
                },
                "format" : "max"
              }
            }
          },
          "name" : "Mario"
        }, {
          "id" : "305011124483380",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "LocalFilterMaximum",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "maxrating@local",
              "dataType" : "text"
            }
          },
          "name" : "Abel"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "305016293144645"
      },
      "id" : "305018097001099"
    } ]
  }
}`

