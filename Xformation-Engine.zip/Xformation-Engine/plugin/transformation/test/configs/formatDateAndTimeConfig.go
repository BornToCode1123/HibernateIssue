package configs

const FormatWrongConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jacklyn",
        "statements" : [ {
          "id" : "815977276455089",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "formatteddate1",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "formatDateAndTime",
              "functionArguments" : {
                "toBeFormattedValue" : {
                  "value" : "month1",
                  "valueType" : "date"
                },
                "inputFormat" : "dd/MM/yyyy",
                "outputFormat" : "unixTime"
              },
              "dataType" : "text"
            }
          },
          "name" : "Annie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "815979174907569"
      },
      "id" : "815979507970159"
    } ]
  }
}`

const FormatDateAndTimeConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "jsonIgnoreProperty": true,
    "statements": [
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": true,
          "name": "Addie",
          "statements": [
            {
              "id": "820429051457675",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "literal",
                  "dataValue": "formatteddate",
                  "dataType": "number"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataValue": "date",
                  "dataType": "date",
                  "keywordArguments": {
                    "format": "dd-MM-yyyy",
                    "init": {
                      "value": "month",
                      "format": "dd/MM/yyyy"
                    }
                  }
                }
              },
              "name": "Bell"
            }
          ],
          "jsonIgnoreAliasValue": null,
          "id": "820421298654994"
        },
        "id": "820421149181288"
      }
    ]
  }
}`

const FormatDateAndTime2Config = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": false,
          "name": "Mitchel",
          "statements": [
            {
              "id": "822217939719368",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "literal",
                  "dataValue": "formatteddate1",
                  "dataType": "number"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataValue": "date",
                  "dataType": "date",
                  "keywordArguments": {
                    "format": "unixTime",
                    "init": {
                      "value": "month1",
                      "format": "MMM-yy"
                    }
                  }
                }
              },
              "name": "Kaitlin"
            }
          ],
          "jsonIgnoreAliasValue": null,
          "id": "822212658165229"
        },
        "id": "822211872019194"
      }
    ]
  }
}`

const FormatDateAndTime1Config = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": false,
          "name": "Anne",
          "statements": [
            {
              "id": "824479594196719",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "literal",
                  "dataValue": "formatddate",
                  "dataType": "number"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataValue": "date",
                  "dataType": "date",
                  "keywordArguments": {
                    "format": "unixTime",
                    "init": {
                      "value": "month",
                      "format": "dd/MM/yyyy"
                    }
                  }
                }
              },
              "name": "Caterina"
            }
          ],
          "jsonIgnoreAliasValue": null,
          "id": "824477284292355"
        },
        "id": "824474370710357"
      }
    ]
  }
}`

const LocalFormatDateAndTimeConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "@type": "SectionalStatement",
        "section": {
          "jsonIgnoreProperty": false,
          "name": "Jerald",
          "statements": [
            {
              "id": "826134196392357",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "declare",
                  "dataValue": "formatteddate",
                  "dataType": "number"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "keyword",
                  "dataValue": "date",
                  "dataType": "date",
                  "keywordArguments": {
                    "format": "dd-MM-yyyy",
                    "init": {
                      "value": "month",
                      "format": "dd/MM/yyyy"
                    }
                  }
                }
              },
              "name": "Blaise"
            },
            {
              "id": "826631944076360",
              "@type": "AssignmentStatement",
              "assignment": {
                "@type": "SimpleAssignmentStatement",
                "lhs": {
                  "@type": "literal",
                  "dataValue": "local formatted date",
                  "dataType": "text"
                },
                "operator": {
                  "actualValue": "="
                },
                "rhs": {
                  "@type": "variable",
                  "dataValue": "formatteddate@local",
                  "dataType": "text"
                }
              },
              "name": "Raymundo"
            }
          ],
          "jsonIgnoreAliasValue": null,
          "id": "826639716472566"
        },
        "id": "826635690676288"
      }
    ]
  }
}`
