package configs

const YBLConf = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Braulio",
        "statements" : [ {
          "id" : "809888496205061",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.application.productType",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "3487",
              "dataType" : "text"
            }
          },
          "name" : "Marilie"
        }, {
          "id" : "810421975992656",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.application.isDeleted",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 0,
              "dataType" : "text"
            }
          },
          "name" : "Randi"
        }, {
          "id" : "810903687626314",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.customerPrincipal.fullName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "Anirudh",
              "dataType" : "text"
            }
          },
          "name" : "Zola"
        }, {
          "id" : "811395640712978",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.customerPrincipal.email",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "anirudhsharma0505@gmail.com",
              "dataType" : "text"
            }
          },
          "name" : "Alexys"
        }, {
          "id" : "811985780769956",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.customerPrincipal.fiPrincipalId",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "",
              "dataType" : "text"
            }
          },
          "name" : "Jonathon"
        }, {
          "id" : "812413001227870",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.customerPrincipal.customerType",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "5208",
              "dataType" : "text"
            }
          },
          "name" : "Kathlyn"
        }, {
          "id" : "812853861011198",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "genericDetails.customerPrincipal.segment",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 123,
              "dataType" : "text"
            }
          },
          "name" : "Uriel"
        }, {
          "id" : "817274525005254",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customerPrincipalAddressList",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Celia",
                        "statements" : [ {
                          "id" : "815322212013480",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "addressType",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "142",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Eusebio"
                        }, {
                          "id" : "815768675539823",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "addressType",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "142",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Mark"
                        }, {
                          "id" : "816388596669939",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "city",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "276208",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Barry"
                        }, {
                          "id" : "816887244504283",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "stateProvinceRegion",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "276208",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Boyd"
                        }, {
                          "id" : "817114811633182",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "country",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "276208",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Haylie"
                        }, {
                          "id" : "817275808430807",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "postalCode",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "276208",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Abbie"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "817278908230441"
                      },
                      "id" : "817276320188952"
                    } ]
                  }
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Elijah"
        }, {
          "id" : "817512579149597",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "FilteredData",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "size" : 10,
                  "type" : "numeric"
                },
                "format" : "generateUUID"
              }
            }
          },
          "name" : "Rhiannon"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "817518731903405"
      },
      "id" : "817516227100175"
    } ]
  }
}`

const SimpleXmlCData = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jessie",
        "statements" : [ {
          "id" : "818365087379511",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "root",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "root.successful.root.[0].hango2.#attr",
              "dataType" : "text"
            }
          },
          "name" : "Kim"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "818364273519449"
      },
      "id" : "818362486652842"
    } ]
  }
}`

const YBLConf2 = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Yazmin",
        "statements" : [ {
          "id" : "818792144716274",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "disbursementAmount",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toNumber",
                "init" : {
                  "value" : "ns2:Envelope.ns2:Body.ns3:executeService.arg_0_0.FIXML.Body.executeFinacleScriptRequest.executeFinacleScript_CustomData.disbursement_amount.#text"
                }
              }
            }
          },
          "name" : "Julia"
        }, {
          "id" : "818992714002348",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "appFeeAmt",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toNumber",
                "init" : {
                  "value" : "ns2:Envelope.ns2:Body.ns3:executeService.arg_0_0.FIXML.Body.executeFinacleScriptRequest.executeFinacleScript_CustomData.charge_type1_amt.#text"
                }
              }
            }
          },
          "name" : "Kobe"
        }, {
          "id" : "819315523086819",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "body.disbursementDetails.disbursementAmount",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "expression",
              "structure" : {
                "@type" : "arithmetic",
                "dataType" : "-",
                "variables" : [ {
                  "@type" : "variable",
                  "dataType" : "number",
                  "dataValue" : "disbursementAmount@local"
                }, {
                  "@type" : "expression",
                  "structure" : {
                    "@type" : "arithmetic",
                    "dataType" : "+",
                    "variables" : [ {
                      "@type" : "variable",
                      "dataType" : "number",
                      "dataValue" : "appFeeAmt@local"
                    }, {
                      "@type" : "expression",
                      "structure" : {
                        "@type" : "arithmetic",
                        "dataType" : "*",
                        "variables" : [ {
                          "@type" : "variable",
                          "dataType" : "number",
                          "dataValue" : "appFeeAmt@local"
                        }, {
                          "@type" : "expression",
                          "structure" : {
                            "@type" : "arithmetic",
                            "dataType" : "/",
                            "variables" : [ {
                              "@type" : "literal",
                              "dataType" : "number",
                              "dataValue" : 18
                            }, {
                              "@type" : "literal",
                              "dataType" : "number",
                              "dataValue" : 100
                            } ]
                          },
                          "dataType" : "number"
                        } ]
                      },
                      "dataType" : "number"
                    } ]
                  },
                  "dataType" : "number"
                } ]
              },
              "dataType" : "number"
            }
          },
          "name" : "Bernhard"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "819315428484725"
      },
      "id" : "819311996116372"
    } ]
  }
}`

const XMlAttr = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Amanda",
        "statements" : [ {
          "id" : "819789077408997",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "details.finalText.#attr.x.#text",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "root.name.#attr.b.#text",
              "dataType" : "text"
            }
          },
          "name" : "Leonie"
        }, {
          "id" : "820009358124732",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "details.finalText.#seq",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 1,
              "dataType" : "number"
            }
          },
          "name" : "Wellington"
        }, {
          "id" : "820261569324594",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "details.finalText.#text",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "root.name.#text",
              "dataType" : "text"
            }
          },
          "name" : "Carmela"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "820269102764648"
      },
      "id" : "820269503712254"
    } ]
  }
}`

const JsonToXml = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Alayna",
        "statements" : [ {
          "id" : "820875144952034",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "keyword",
              "dataValue" : "none",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "value",
              "dataType" : "map"
            }
          },
          "name" : "Marielle"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "820871980859680"
      },
      "id" : "820873639047158"
    } ]
  }
}`

const YBL_Project_Config = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jamison",
        "statements" : [ {
          "id" : "821532322253138",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "xml",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "PHNvYXBlbnY6RW52ZWxvcGUKCXhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiCgl4bWxuczp4c2Q9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIgoJeG1sbnM6c29hcGVuYz0iaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvc29hcC9lbmNvZGluZy8iCgl4bWxuczpzb2FwZW52PSJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy9zb2FwL2VudmVsb3BlLyI+Cgk8c29hcGVudjpIZWFkZXIvPgoJPHNvYXBlbnY6Qm9keT4KCQk8cDU5NDpleGVjdXRlU2VydmljZVJlc3BvbnNlCgkJCXhtbG5zOnA1OTQ9Imh0dHA6Ly93ZWJzZXJ2aWNlLmZpdXNiLmNpLmluZm9zeXMuY29tIj4KCQkJPGV4ZWN1dGVTZXJ2aWNlUmV0dXJuPgoJCQkJPEZJWE1MIHhzaTpzY2hlbWFMb2NhdGlvbj0iaHR0cDovL3d3dy5maW5hY2xlLmNvbS9maXhtbCBleGVjdXRlRmluYWNsZVNjcmlwdC54c2QiCgkJCQkJeG1sbnM9Imh0dHA6Ly93d3cuZmluYWNsZS5jb20vZml4bWwiCgkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJPEhlYWRlcj4KCQkJCQkJPFJlc3BvbnNlSGVhZGVyPgoJCQkJCQkJPFJlcXVlc3RNZXNzYWdlS2V5PgoJCQkJCQkJCTxSZXF1ZXN0VVVJRD5KUDEzNDA5MTc5XzY1NDM8L1JlcXVlc3RVVUlEPgoJCQkJCQkJCTxTZXJ2aWNlUmVxdWVzdElkPmV4ZWN1dGVGaW5hY2xlU2NyaXB0PC9TZXJ2aWNlUmVxdWVzdElkPgoJCQkJCQkJCTxTZXJ2aWNlUmVxdWVzdFZlcnNpb24+MTAuMjwvU2VydmljZVJlcXVlc3RWZXJzaW9uPgoJCQkJCQkJCTxDaGFubmVsSWQ+Sk9DPC9DaGFubmVsSWQ+CgkJCQkJCQk8L1JlcXVlc3RNZXNzYWdlS2V5PgoJCQkJCQkJPFJlc3BvbnNlTWVzc2FnZUluZm8+CgkJCQkJCQkJPEJhbmtJZD4wMTwvQmFua0lkPgoJCQkJCQkJCTxUaW1lWm9uZT48L1RpbWVab25lPgoJCQkJCQkJCTxNZXNzYWdlRGF0ZVRpbWU+MjAyMy0wNy0yNVQxMjoyOToxOC4zNjg8L01lc3NhZ2VEYXRlVGltZT4KCQkJCQkJCTwvUmVzcG9uc2VNZXNzYWdlSW5mbz4KCQkJCQkJCTxVQlVTVHJhbnNhY3Rpb24+CgkJCQkJCQkJPElkLz4KCQkJCQkJCQk8U3RhdHVzLz4KCQkJCQkJCTwvVUJVU1RyYW5zYWN0aW9uPgoJCQkJCQkJPEhvc3RUcmFuc2FjdGlvbj4KCQkJCQkJCQk8SWQvPgoJCQkJCQkJCTxTdGF0dXM+U1VDQ0VTUzwvU3RhdHVzPgoJCQkJCQkJPC9Ib3N0VHJhbnNhY3Rpb24+CgkJCQkJCQk8SG9zdFBhcmVudFRyYW5zYWN0aW9uPgoJCQkJCQkJCTxJZC8+CgkJCQkJCQkJPFN0YXR1cy8+CgkJCQkJCQk8L0hvc3RQYXJlbnRUcmFuc2FjdGlvbj4KCQkJCQkJCTxDdXN0b21JbmZvLz4KCQkJCQkJPC9SZXNwb25zZUhlYWRlcj4KCQkJCQk8L0hlYWRlcj4KCQkJCQk8Qm9keT4KCQkJCQkJPGV4ZWN1dGVGaW5hY2xlU2NyaXB0UmVzcG9uc2U+CgkJCQkJCQk8RXhlY3V0ZUZpbmFjbGVTY3JpcHRPdXRwdXRWTz48L0V4ZWN1dGVGaW5hY2xlU2NyaXB0T3V0cHV0Vk8+CgkJCQkJCQk8ZXhlY3V0ZUZpbmFjbGVTY3JpcHRfQ3VzdG9tRGF0YT4KCQkJCQkJCQk8U3VjY0ZhaUZsZz5TPC9TdWNjRmFpRmxnPgoJCQkJCQkJCTxNZXNzYWdlPlNVQ0NFU1M8L01lc3NhZ2U+CgkJCQkJCQkJPFRyYW5JZD5NMTUxNTMxMTwvVHJhbklkPgoJCQkJCQkJPC9leGVjdXRlRmluYWNsZVNjcmlwdF9DdXN0b21EYXRhPgoJCQkJCQk8L2V4ZWN1dGVGaW5hY2xlU2NyaXB0UmVzcG9uc2U+CgkJCQkJPC9Cb2R5PgoJCQkJPC9GSVhNTD4KCQkJPC9leGVjdXRlU2VydmljZVJldHVybj4KCQk8L3A1OTQ6ZXhlY3V0ZVNlcnZpY2VSZXNwb25zZT4KCTwvc29hcGVudjpCb2R5Pgo8L3NvYXBlbnY6RW52ZWxvcGU+",
              "dataType" : "text"
            }
          },
          "name" : "Carmelo"
        }, {
          "id" : "821769394457925",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decodedXML",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "decode",
                "init" : {
                  "value" : "xml@local",
                  "format" : "base64"
                }
              }
            }
          },
          "name" : "Ron"
        }, {
          "id" : "821975268838359",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "keyword",
              "dataValue" : "none",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "map",
              "keywordArguments" : {
                "format" : "toXml",
                "init" : {
                  "value" : "decodedXML@local"
                }
              }
            }
          },
          "name" : "Cydney"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "821979050055898"
      },
      "id" : "821975770657783"
    } ]
  }
}`

const XMLToXml = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "General",
        "statements" : [ {
          "id" : "822394198160679",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "XML_LocalData",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "value",
              "dataType" : "map"
            }
          },
          "name" : "Ken"
        }, {
          "id" : "822607437989656",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "XML_LocalData.root.name.#attr.b.#text",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "Iam attr value",
              "dataType" : "text"
            }
          },
          "name" : "Beverly"
        }, {
          "id" : "822774875038576",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "XML_LocalData",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "XML_LocalData@local",
              "dataType" : "map"
            }
          },
          "name" : "Jaunita"
        }, {
          "id" : "822945703508911",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "XML_LocalData.root.name.#text",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "DLP Software as Service",
              "dataType" : "text"
            }
          },
          "name" : "Domenic"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "822944234756783"
      },
      "id" : "822945179077322"
    } ]
  }
}`

const JsonInpuXmlOutput = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Raoul",
        "statements" : [ {
          "id" : "823327179765583",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "root.name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "name",
              "dataType" : "text"
            }
          },
          "name" : "Abby"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "823328675520118"
      },
      "id" : "823325040520260"
    } ]
  }
}`

const XML_to_XMl = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Christa",
        "statements" : [ {
          "id" : "823548737647963",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "details",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "value",
              "dataType" : "text"
            }
          },
          "name" : "Della"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "823623971379399"
      },
      "id" : "823628960388697"
    } ]
  }
}`

const YBL3 = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Thomas",
        "statements" : [ {
          "id" : "823962639991934",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "xml",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "PHNvYXBlbnY6RW52ZWxvcGUKCXhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiCgl4bWxuczp4c2Q9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIgoJeG1sbnM6c29hcGVuYz0iaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvc29hcC9lbmNvZGluZy8iCgl4bWxuczpzb2FwZW52PSJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy9zb2FwL2VudmVsb3BlLyI+Cgk8c29hcGVudjpIZWFkZXIvPgoJPHNvYXBlbnY6Qm9keT4KCQk8cDU5NDpleGVjdXRlU2VydmljZVJlc3BvbnNlCgkJCXhtbG5zOnA1OTQ9Imh0dHA6Ly93ZWJzZXJ2aWNlLmZpdXNiLmNpLmluZm9zeXMuY29tIj4KCQkJPGV4ZWN1dGVTZXJ2aWNlUmV0dXJuPgoJCQkJPEZJWE1MIHhzaTpzY2hlbWFMb2NhdGlvbj0iaHR0cDovL3d3dy5maW5hY2xlLmNvbS9maXhtbCBleGVjdXRlRmluYWNsZVNjcmlwdC54c2QiCgkJCQkJeG1sbnM9Imh0dHA6Ly93d3cuZmluYWNsZS5jb20vZml4bWwiCgkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJPEhlYWRlcj4KCQkJCQkJPFJlc3BvbnNlSGVhZGVyPgoJCQkJCQkJPFJlcXVlc3RNZXNzYWdlS2V5PgoJCQkJCQkJCTxSZXF1ZXN0VVVJRD5KUDEzNDA5MTc5XzY1NDM8L1JlcXVlc3RVVUlEPgoJCQkJCQkJCTxTZXJ2aWNlUmVxdWVzdElkPmV4ZWN1dGVGaW5hY2xlU2NyaXB0PC9TZXJ2aWNlUmVxdWVzdElkPgoJCQkJCQkJCTxTZXJ2aWNlUmVxdWVzdFZlcnNpb24+MTAuMjwvU2VydmljZVJlcXVlc3RWZXJzaW9uPgoJCQkJCQkJCTxDaGFubmVsSWQ+Sk9DPC9DaGFubmVsSWQ+CgkJCQkJCQk8L1JlcXVlc3RNZXNzYWdlS2V5PgoJCQkJCQkJPFJlc3BvbnNlTWVzc2FnZUluZm8+CgkJCQkJCQkJPEJhbmtJZD4wMTwvQmFua0lkPgoJCQkJCQkJCTxUaW1lWm9uZT48L1RpbWVab25lPgoJCQkJCQkJCTxNZXNzYWdlRGF0ZVRpbWU+MjAyMy0wNy0yNVQxMjoyOToxOC4zNjg8L01lc3NhZ2VEYXRlVGltZT4KCQkJCQkJCTwvUmVzcG9uc2VNZXNzYWdlSW5mbz4KCQkJCQkJCTxVQlVTVHJhbnNhY3Rpb24+CgkJCQkJCQkJPElkLz4KCQkJCQkJCQk8U3RhdHVzLz4KCQkJCQkJCTwvVUJVU1RyYW5zYWN0aW9uPgoJCQkJCQkJPEhvc3RUcmFuc2FjdGlvbj4KCQkJCQkJCQk8SWQvPgoJCQkJCQkJCTxTdGF0dXM+U1VDQ0VTUzwvU3RhdHVzPgoJCQkJCQkJPC9Ib3N0VHJhbnNhY3Rpb24+CgkJCQkJCQk8SG9zdFBhcmVudFRyYW5zYWN0aW9uPgoJCQkJCQkJCTxJZC8+CgkJCQkJCQkJPFN0YXR1cy8+CgkJCQkJCQk8L0hvc3RQYXJlbnRUcmFuc2FjdGlvbj4KCQkJCQkJCTxDdXN0b21JbmZvLz4KCQkJCQkJPC9SZXNwb25zZUhlYWRlcj4KCQkJCQk8L0hlYWRlcj4KCQkJCQk8Qm9keT4KCQkJCQkJPGV4ZWN1dGVGaW5hY2xlU2NyaXB0UmVzcG9uc2U+CgkJCQkJCQk8RXhlY3V0ZUZpbmFjbGVTY3JpcHRPdXRwdXRWTz48L0V4ZWN1dGVGaW5hY2xlU2NyaXB0T3V0cHV0Vk8+CgkJCQkJCQk8ZXhlY3V0ZUZpbmFjbGVTY3JpcHRfQ3VzdG9tRGF0YT4KCQkJCQkJCQk8U3VjY0ZhaUZsZz5TPC9TdWNjRmFpRmxnPgoJCQkJCQkJCTxNZXNzYWdlPlNVQ0NFU1M8L01lc3NhZ2U+CgkJCQkJCQkJPFRyYW5JZD5NMTUxNTMxMTwvVHJhbklkPgoJCQkJCQkJPC9leGVjdXRlRmluYWNsZVNjcmlwdF9DdXN0b21EYXRhPgoJCQkJCQk8L2V4ZWN1dGVGaW5hY2xlU2NyaXB0UmVzcG9uc2U+CgkJCQkJPC9Cb2R5PgoJCQkJPC9GSVhNTD4KCQkJPC9leGVjdXRlU2VydmljZVJldHVybj4KCQk8L3A1OTQ6ZXhlY3V0ZVNlcnZpY2VSZXNwb25zZT4KCTwvc29hcGVudjpCb2R5Pgo8L3NvYXBlbnY6RW52ZWxvcGU+",
              "dataType" : "text"
            }
          },
          "name" : "Caitlyn"
        }, {
          "id" : "824157870620229",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decodedXML",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "decode",
                "init" : {
                  "value" : "xml@local",
                  "format" : "base64"
                }
              }
            }
          },
          "name" : "Florence"
        }, {
          "id" : "824299495062037",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "response",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "map",
              "keywordArguments" : {
                "format" : "toXml",
                "init" : {
                  "value" : "decodedXML@local"
                }
              }
            }
          },
          "name" : "Colin"
        }, {
          "id" : "824439892072323",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "custIdSplit",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "ns2:Envelope.ns2:Body.ns3:executeService.arg_0_0.FIXML.Body.LoanAcctAddRequest.LoanAcctAddRq.CustId.CustId.#text",
                  "splitby" : "_"
                },
                "format" : "split"
              }
            }
          },
          "name" : "Jacklyn"
        }, {
          "id" : "824588837997490",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.applicationId",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "custIdSplit.[0]@local",
              "dataType" : "text"
            }
          },
          "name" : "Daija"
        }, {
          "id" : "824681735886036",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.clientAccNo",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "custIdSplit.[0]@local",
              "dataType" : "text"
            }
          },
          "name" : "Branson"
        }, {
          "id" : "824856357343778",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.productName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "ns2:Envelope.ns2:Body.ns3:executeService.arg_0_0.FIXML.Body.LoanAcctAddRequest.LoanAcctAdd_CustomData.INT_TABLE_CODE.#text",
              "dataType" : "text"
            }
          },
          "name" : "Edna"
        }, {
          "id" : "824988176373300",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.loanAmt",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 100000,
              "dataType" : "text"
            }
          },
          "name" : "Janae"
        }, {
          "id" : "825068279850676",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.clientAccNo",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "3014",
              "dataType" : "text"
            }
          },
          "name" : "Alejandra"
        }, {
          "id" : "825279996086348",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.rateOfInterestValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "10",
              "dataType" : "text"
            }
          },
          "name" : "Rodrigo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "825273163017445"
      },
      "id" : "825273266762443"
    }, {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Baron",
        "statements" : [ {
          "id" : "825429682775794",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.repaymentFrequency",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "EMI",
              "dataType" : "text"
            }
          },
          "name" : "Kiana"
        }, {
          "id" : "825649319107248",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.loanTenureValue",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 12,
              "dataType" : "text"
            }
          },
          "name" : "Garrick"
        }, {
          "id" : "825881948583147",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.loanTenureType",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "DAYS",
              "dataType" : "text"
            }
          },
          "name" : "Christiana"
        }, {
          "id" : "826113574990284",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.daysBasis",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "Actual DAYS",
              "dataType" : "text"
            }
          },
          "name" : "Jaylin"
        }, {
          "id" : "828151915790233",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.gracePeriodForLateInst",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "Actual DAYS",
              "dataType" : "text"
            }
          },
          "name" : "Katrine"
        }, {
          "id" : "828372092317245",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.isTDSApplicable",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : false,
              "dataType" : "text"
            }
          },
          "name" : "Bennie"
        }, {
          "id" : "828588486882748",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.loanStatus",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : false,
              "dataType" : "text"
            }
          },
          "name" : "Eva"
        }, {
          "id" : "828823221115874",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.loanActionStatus",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "READY FOR DISBURSEMENT",
              "dataType" : "text"
            }
          },
          "name" : "Joshua"
        }, {
          "id" : "828974751948421",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.loanApplicationSentDate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "2021-06-18T06:00:00.000Z",
              "dataType" : "text"
            }
          },
          "name" : "Russel"
        }, {
          "id" : "829127676814589",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.sentById",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 1,
              "dataType" : "text"
            }
          },
          "name" : "Reyes"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "829125827571329"
      },
      "id" : "829123866476014"
    }, {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gabriella",
        "statements" : [ {
          "id" : "829276460535510",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.sentById",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 1,
              "dataType" : "text"
            }
          },
          "name" : "May"
        }, {
          "id" : "829393893081682",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.disbursementAmount",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "100000",
              "dataType" : "text"
            }
          },
          "name" : "Ervin"
        }, {
          "id" : "829569210279968",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.paymentClearanceDate",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "2025-10-25",
              "dataType" : "text"
            }
          },
          "name" : "Virgil"
        }, {
          "id" : "829709738637655",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.instrRefNo",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "62143123413478",
              "dataType" : "text"
            }
          },
          "name" : "Roger"
        }, {
          "id" : "829758519396275",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.disbursedTo",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "APPLICANT",
              "dataType" : "text"
            }
          },
          "name" : "Alberta"
        }, {
          "id" : "829921734686790",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.srcBankAccNo",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "68952326894563",
              "dataType" : "text"
            }
          },
          "name" : "Taryn"
        }, {
          "id" : "830122510838688",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.destBankAccNo",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "format" : "getNullValue"
              }
            }
          },
          "name" : "Arnulfo"
        }, {
          "id" : "830256024344857",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.srcBankAccName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "HDFC",
              "dataType" : "text"
            }
          },
          "name" : "Ian"
        }, {
          "id" : "830409267251898",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.destBankAccName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "text",
              "dataValue" : "text",
              "keywordArguments" : {
                "format" : "getNullValue"
              }
            }
          },
          "name" : "Yasmine"
        }, {
          "id" : "830549889674536",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.disbursementDetails.modeOfDisbursement",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "CHEQUE",
              "dataType" : "text"
            }
          },
          "name" : "Ignacio"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "830545798260940"
      },
      "id" : "830542027882217"
    }, {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Maya",
        "statements" : [ {
          "id" : "831826658200942",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "body.loanFeeDetailsList",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "transform_config_1",
                    "name" : "customer Response",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Francesco",
                        "statements" : [ {
                          "id" : "830969610201965",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "feeName",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : "Disbursal Fee",
                              "dataType" : "text"
                            }
                          },
                          "name" : "Boris"
                        }, {
                          "id" : "831081851096633",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "appFeeAmt",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : 500,
                              "dataType" : "text"
                            }
                          },
                          "name" : "Elsie"
                        }, {
                          "id" : "831218825856409",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "appFeePercentage",
                              "dataType" : "text"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "literal",
                              "dataValue" : 1,
                              "dataType" : "text"
                            }
                          },
                          "name" : "Heber"
                        }, {
                          "id" : "831826998398389",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "@type" : "SimpleAssignmentStatement",
                            "lhs" : {
                              "@type" : "literal",
                              "dataValue" : "listOfTaxOnLoan",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "keyword",
                              "dataType" : "list",
                              "dataValue" : "list",
                              "keywordArguments" : {
                                "init" : {
                                  "transform" : {
                                    "id" : "transform_config_1",
                                    "name" : "customer Response",
                                    "statements" : [ {
                                      "@type" : "SectionalStatement",
                                      "section" : {
                                        "jsonIgnoreProperty" : false,
                                        "name" : "Israel",
                                        "statements" : [ {
                                          "id" : "831615156609041",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "taxName",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "gstTax",
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Everette"
                                        }, {
                                          "id" : "831829661844924",
                                          "@type" : "AssignmentStatement",
                                          "assignment" : {
                                            "lhs" : {
                                              "@type" : "literal",
                                              "dataValue" : "taxPercentage",
                                              "dataType" : "text"
                                            },
                                            "operator" : {
                                              "actualValue" : "="
                                            },
                                            "rhs" : {
                                              "@type" : "literal",
                                              "dataValue" : 18,
                                              "dataType" : "text"
                                            }
                                          },
                                          "name" : "Hillary"
                                        } ],
                                        "jsonIgnoreAliasValue" : null,
                                        "id" : "831823820419381"
                                      },
                                      "id" : "831829303459927"
                                    } ]
                                  }
                                },
                                "format" : "iterate"
                              }
                            }
                          },
                          "name" : "Eden"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "831823458103965"
                      },
                      "id" : "831824560162432"
                    } ]
                  }
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Vicenta"
        }, {
          "id" : "832021352241429",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "response",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "local",
              "dataValue" : "body",
              "dataType" : "text"
            }
          },
          "name" : "Kennedy"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "832024903545486"
      },
      "id" : "832029051349744"
    } ]
  }
}`

const SimpleXMLConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Chadrick",
        "statements" : [ {
          "id" : "832321461971488",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "root.name.#text",
              "dataType" : "text"
            }
          },
          "name" : "Camylle"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "832322502835201"
      },
      "id" : "832328916649238"
    } ]
  }
}`

const XmlInputJsonOutput = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Peyton",
        "statements" : [ {
          "id" : "832615008377128",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "root.name.#text",
              "dataType" : "text"
            }
          },
          "name" : "Lavonne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "832618577772733"
      },
      "id" : "832619063702117"
    } ]
  }
}`

const YBLDisburs = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Sandy",
        "statements" : [ {
          "id" : "832836890238570",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "keyword",
              "dataValue" : "none",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "value",
              "dataType" : "map"
            }
          },
          "name" : "Kenny"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "832832383046731"
      },
      "id" : "832834741880149"
    } ]
  }
}`

const XmlToJson = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Enola",
        "statements" : [ {
          "id" : "833248155933188",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "keyword",
              "dataValue" : "none",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "value",
              "dataType" : "map"
            }
          },
          "name" : "Abel"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "833246300692884"
      },
      "id" : "833244557482834"
    } ]
  }
}`

const XML_NameSpaces = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Vanessa",
        "statements" : [ {
          "id" : "833559744683302",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "details",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "value",
              "dataType" : "text"
            }
          },
          "name" : "Mariah"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "833553986319832"
      },
      "id" : "833553289817541"
    } ]
  }
}`

const JsonToXmlError = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Karina",
        "statements" : [ {
          "id" : "833858371535865",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "keyword",
              "dataValue" : "none",
              "dataType" : "map"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "values",
              "dataType" : "map"
            }
          },
          "name" : "Marcella"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "833857880743223"
      },
      "id" : "833855753947303"
    } ]
  }
}`
