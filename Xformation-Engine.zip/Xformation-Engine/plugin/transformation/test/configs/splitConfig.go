package configs 

const DataSplitConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Aleen",
        "statements" : [ {
          "id" : "985525403601979",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "splitpayment",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "chunkby" : 3,
                  "value" : "paymentHistory1"
                },
                "format" : "chunk"
              }
            }
          },
          "name" : "Mabel"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "985526931299766"
      },
      "id" : "985528247875018"
    } ]
  }
}`

const CommaSplitConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Foster",
        "statements" : [ {
          "id" : "988253987098401",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "splitpayment,",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "paymentHistory",
                  "splitby" : ","
                },
                "format" : "split"
              }
            }
          },
          "name" : "Christa"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "988267234063612"
      },
      "id" : "988267403961644"
    } ]
  }
}`

const OneSplitConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Keeley",
        "statements" : [ {
          "id" : "990627854742921",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "splitpayment,",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "paymentHistory4",
                  "splitby" : "2"
                },
                "format" : "split"
              }
            }
          },
          "name" : "Catharine"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "990622322533605"
      },
      "id" : "990623694105042"
    } ]
  }
}`

const EmptySplitConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Nathen",
        "statements" : [ {
          "id" : "992739218172628",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "splitpayment,",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "value" : "paymentHistory3",
                  "splitby" : "1"
                },
                "format" : "split"
              }
            }
          },
          "name" : "Abdul"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "992734912174603"
      },
      "id" : "992734532835682"
    } ]
  }
}`

const LocalDataSplitConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Nyasia",
        "statements" : [ {
          "id" : "995454598846369",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "splitpayment3",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "text",
              "keywordArguments" : {
                "init" : {
                  "chunkby" : 3,
                  "value" : "paymentHistory1"
                },
                "format" : "chunk"
              }
            }
          },
          "name" : "Lonnie"
        }, {
          "id" : "996227536858956",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "daysInPaymentHistory1",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "splitpayment3@local",
              "dataType" : "list"
            }
          },
          "name" : "Austin"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "996229899632128"
      },
      "id" : "996235056799815"
    } ]
  }
}`

