package configs

const CollectConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Salvador",
        "statements" : [ {
          "id" : "131219946577877",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "relatedP",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataType" : "list",
              "dataValue" : "list",
              "keywordArguments" : {
                "init" : {
                  "transform" : {
                    "id" : "1",
                    "name" : "transform",
                    "statements" : [ {
                      "@type" : "SectionalStatement",
                      "section" : {
                        "jsonIgnoreProperty" : false,
                        "name" : "Isaias",
                        "statements" : [ {
                          "id" : "131212721966495",
                          "@type" : "AssignmentStatement",
                          "assignment" : {
                            "lhs" : {
                              "@type" : "declare",
                              "dataValue" : "relatedPtrue",
                              "dataType" : "list"
                            },
                            "operator" : {
                              "actualValue" : "="
                            },
                            "rhs" : {
                              "@type" : "function",
                              "functionName" : "collect",
                              "functionArguments" : {
                                "condition" : {
                                  "@type" : "logical",
                                  "type" : "and",
                                  "rules" : [ {
                                    "@type" : "relational",
                                    "lhs" : {
                                      "@type" : "keyword",
                                      "dataValue" : "mapvalue",
                                      "dataType" : "boolean"
                                    },
                                    "operator" : {
                                      "actualValue" : "=="
                                    },
                                    "rhs" : {
                                      "@type" : "literal",
                                      "dataValue" : true,
                                      "dataType" : "boolean"
                                    }
                                  } ]
                                },
                                "pick" : "key"
                              },
                              "dataType" : "list"
                            }
                          },
                          "name" : "Summer"
                        } ],
                        "jsonIgnoreAliasValue" : null,
                        "id" : "131212934283015"
                      },
                      "id" : "131213013489028"
                    } ]
                  },
                  "value" : "relatedParties"
                },
                "format" : "iterate"
              }
            }
          },
          "name" : "Jeramy"
        }, {
          "id" : "132009192234539",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "collectedValues",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "relatedPtrue@local",
              "dataType" : "list"
            }
          },
          "name" : "Eve"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "132004993888453"
      },
      "id" : "132001094142830"
    } ]
  }
}`
