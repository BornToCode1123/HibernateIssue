package configs

const CamelCaseIntegerConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Justyn",
        "statements" : [ {
          "id" : "496773092374879",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Name",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "number",
              "keywordArguments" : {
                "format" : "camel",
                "init" : {
                  "value" : "fathersName"
                }
              }
            }
          },
          "name" : "Savion"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "496776069918758"
      },
      "id" : "496775450874355"
    } ]
  }
}`

const CamelCaseConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Demario",
        "statements" : [ {
          "id" : "500606063674046",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toCamelCase",
                "init" : {
                  "value" : "fathersName"
                }
              }
            }
          },
          "name" : "Shane"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "500608121140036"
      },
      "id" : "500608034659079"
    } ]
  }
}`

const LocalCamelCaseConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Kobe",
        "statements" : [ {
          "id" : "503944547143629",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "fathersName",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toCamelCase",
                "init" : {
                  "value" : "fathersName"
                }
              }
            }
          },
          "name" : "Otho"
        }, {
          "id" : "505183062536575",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "CamelLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "fathersName@local",
              "dataType" : "text"
            }
          },
          "name" : "Mona"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "505181257756604"
      },
      "id" : "505189569360666"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`
