package configs 

const PaginateIncorrectArrayName = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jimmy",
        "statements" : [ {
          "id" : "166224559125057",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "data",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "paginate",
              "functionArguments" : {
                "arrayName" : "record.abc.tata"
              },
              "dataType" : "list"
            }
          },
          "name" : "Monroe"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "166226592487072"
      },
      "id" : "166229423497733"
    } ]
  }
}`

const PaginationConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Edyth",
        "statements" : [ {
          "id" : "169371413304358",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "data",
              "dataType" : "list"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "function",
              "functionName" : "paginate",
              "functionArguments" : {
                "arrayName" : "record.abc.data"
              },
              "dataType" : "list"
            }
          },
          "name" : "Wilfredo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "169374516176222"
      },
      "id" : "169376942622041"
    } ]
  }
}`

