package configs

const TextFromXml = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Myrl",
        "statements" : [ {
          "id" : "661962836476222",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "xmlBytes",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "fromXml",
                "init" : {
                  "value" : "customerDetails"
                }
              }
            }
          },
          "name" : "Orville"
        }, {
          "id" : "662992349656942",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encodedXml",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "encode",
                "init" : {
                  "value" : "xmlBytes@local",
                  "format" : "base64"
                }
              }
            }
          },
          "name" : "Angelina"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "662991254180584"
      },
      "id" : "663007295390364"
    } ]
  }
}`

const TestKeyword_toBoolean = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Magdalen",
        "statements" : [ {
          "id" : "665881283751030",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toBoolean",
                "init" : {
                  "value" : "isAlive"
                }
              }
            }
          },
          "name" : "Arnaldo"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "665886088984357"
      },
      "id" : "665883338651470"
    } ]
  }
}`

const TestKeyword_isNumberFalse = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Rahsaan",
        "statements" : [ {
          "id" : "670214641720842",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isNumber",
                "init" : {
                  "value" : "name"
                }
              }
            }
          },
          "name" : "Amie"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "670212713328502"
      },
      "id" : "670215152053915"
    } ]
  }
}`

const TestTextConvertingXml = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "text",
  "contentOutputType" : "json",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Marcelo",
        "statements" : [ {
          "id" : "671946279552139",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "startTag",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "<",
              "dataType" : "text"
            }
          },
          "name" : "Leila"
        }, {
          "id" : "672848552136355",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "closeTag",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : ">",
              "dataType" : "text"
            }
          },
          "name" : "Kennith"
        }, {
          "id" : "674008022126975",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "replacedString",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "replace",
                "init" : {
                  "value" : "encryptedPayload",
                  "fields" : {
                    "&lt;" : "startTag@local",
                    "&gt;" : "closeTag@local"
                  }
                }
              }
            }
          },
          "name" : "Sydni"
        }, {
          "id" : "675615251689841",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "xmlData",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toXml",
                "init" : {
                  "value" : "replacedString@local"
                }
              }
            }
          },
          "name" : "Oda"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "675671426631550"
      },
      "id" : "675674291951820"
    } ]
  }
}`

const TextFromJson = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Moses",
        "statements" : [ {
          "id" : "677154325001994",
          "@type" : "AssignmentStatement",
          "mandatory" : true,
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "JsonBytes",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "fromJson",
                "init" : {
                  "value" : "customerDetails"
                }
              }
            }
          },
          "name" : "Fannie"
        }, {
          "id" : "677591884408045",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "encodedJson",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "encode",
                "init" : {
                  "value" : "JsonBytes@local",
                  "format" : "base64"
                }
              }
            }
          },
          "name" : "Riley"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "677603632135043"
      },
      "id" : "677601936877200"
    } ]
  }
}`

const TestKeyword_contains = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Maribel",
        "statements" : [ {
          "id" : "678349609575877",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "subStr",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "LIEN_AS_ON",
              "dataType" : "number"
            }
          },
          "name" : "Maria"
        }, {
          "id" : "678765814795003",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "hasSubString",
                "init" : {
                  "value" : "field",
                  "subString" : "subStr@local"
                }
              }
            }
          },
          "name" : "Jenifer"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "678763476768521"
      },
      "id" : "678764297929270"
    } ]
  }
}`

const XmlNumericConversion = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Heidi",
        "statements" : [ {
          "id" : "679647392122148",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.name",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "javeed",
              "dataType" : "number"
            }
          },
          "name" : "Xander"
        }, {
          "id" : "680124022892297",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.age",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : 5,
              "dataType" : "number"
            }
          },
          "name" : "Breanna"
        }, {
          "id" : "680569094445711",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.isWorking",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : true,
              "dataType" : "number"
            }
          },
          "name" : "Marian"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "680562558659181"
      },
      "id" : "680568591989529"
    } ]
  }
}`

const TestKeyword_camel = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jaden",
        "statements" : [ {
          "id" : "681499445958317",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toCamelCase",
                "init" : {
                  "value" : "dataValue"
                }
              }
            }
          },
          "name" : "Lauretta"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "681496904118956"
      },
      "id" : "681498565530937"
    } ]
  }
}`

const TestKeyword_Pascal = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jaden",
        "statements" : [ {
          "id" : "681499445958317",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toPascalCase",
                "init" : {
                  "value" : "dataValue"
                }
              }
            }
          },
          "name" : "Lauretta"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "681496904118956"
      },
      "id" : "681498565530937"
    } ]
  }
}`

const TestKeyword_KebabCase = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jaden",
        "statements" : [ {
          "id" : "681499445958317",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toKebabCase",
                "init" : {
                  "value" : "valueData"
                }
              }
            }
          },
          "name" : "Lauretta"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "681496904118956"
      },
      "id" : "681498565530937"
    } ]
  }
}`

const TestKeyword_SnakeCase = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jaden",
        "statements" : [ {
          "id" : "681499445958317",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toSnakeCase",
                "init" : {
                  "value" : "valueData"
                }
              }
            }
          },
          "name" : "Lauretta"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "681496904118956"
      },
      "id" : "681498565530937"
    } ]
  }
}`

const TestKeyword_decode = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Madalyn",
        "statements" : [ {
          "id" : "682427408194355",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decodedValue2",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "CiAgICA8bnMyOkVudmVsb3BlCgl4bWxuczpuczI9Imh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3NvYXAvZW52ZWxvcGUvIgoJeG1sbnM6bnMzPSJodHRwOi8vd2Vic2VydmljZS5maXVzYi5jaS5pbmZvc3lzLmNvbSI+Cgk8bnMyOkJvZHk+CgkJPG5zMzpleGVjdXRlU2VydmljZT4KCQkJPGFyZ18wXzA+CgkJCQk8RklYTUwKCQkJCQl4bWxucz0iaHR0cDovL3d3dy5maW5hY2xlLmNvbS9maXhtbCI+CgkJCQkJPEhlYWRlcj4KCQkJCQkJPFJlcXVlc3RIZWFkZXI+CgkJCQkJCQk8TWVzc2FnZUtleT4KCQkJCQkJCQk8UmVxdWVzdFVVSUQ+JHtsb2FuQXBwbGljYXRpb25JZH08L1JlcXVlc3RVVUlEPgoJCQkJCQkJCTxTZXJ2aWNlUmVxdWVzdElkPlJldEN1c3RBZGQ8L1NlcnZpY2VSZXF1ZXN0SWQ+CgkJCQkJCQkJPFNlcnZpY2VSZXF1ZXN0VmVyc2lvbj4xMC4yPC9TZXJ2aWNlUmVxdWVzdFZlcnNpb24+CgkJCQkJCQkJPENoYW5uZWxJZD5KT0M8L0NoYW5uZWxJZD4KCQkJCQkJCQk8TGFuZ3VhZ2VJZCB4c2k6dHlwZT0ieHM6c3RyaW5nIgoJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCXhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiPgoJCQkJCQkJCTwvTGFuZ3VhZ2VJZD4KCQkJCQkJCTwvTWVzc2FnZUtleT4KCQkJCQkJCTxSZXF1ZXN0TWVzc2FnZUluZm8+CgkJCQkJCQkJPEJhbmtJZCB4c2k6dHlwZT0ieHM6c3RyaW5nIgoJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCXhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiPgoJCQkJCQkJCTwvQmFua0lkPgoJCQkJCQkJCTxUaW1lWm9uZSB4c2k6dHlwZT0ieHM6c3RyaW5nIgoJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCXhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiPgoJCQkJCQkJCTwvVGltZVpvbmU+CgkJCQkJCQkJPEVudGl0eUlkPjwvRW50aXR5SWQ+CgkJCQkJCQkJPEVudGl0eVR5cGUgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJeG1sbnM6eHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIgoJCQkJCQkJCQl4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KCQkJCQkJCQk8L0VudGl0eVR5cGU+CgkJCQkJCQkJPEFybUNvcnJlbGF0aW9uSWQgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJeG1sbnM6eHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIgoJCQkJCQkJCQl4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KCQkJCQkJCQk8L0FybUNvcnJlbGF0aW9uSWQ+CgkJCQkJCQkJPE1lc3NhZ2VEYXRlVGltZT4yMDIyLTEyLTE4VDIwOjQ0OjUwLjExNzwvTWVzc2FnZURhdGVUaW1lPgoJCQkJCQkJPC9SZXF1ZXN0TWVzc2FnZUluZm8+CgkJCQkJCQk8U2VjdXJpdHk+CgkJCQkJCQkJPFRva2VuPgoJCQkJCQkJCQk8UGFzc3dvcmRUb2tlbj4KCQkJCQkJCQkJCTxVc2VySWQgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJCQk8L1VzZXJJZD4KCQkJCQkJCQkJCTxQYXNzd29yZCB4c2k6dHlwZT0ieHM6c3RyaW5nIgoJCQkJCQkJCQkJCXhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIKCQkJCQkJCQkJCQl4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KCQkJCQkJCQkJCTwvUGFzc3dvcmQ+CgkJCQkJCQkJCTwvUGFzc3dvcmRUb2tlbj4KCQkJCQkJCQk8L1Rva2VuPgoJCQkJCQkJCTxGSUNlcnRUb2tlbiB4c2k6dHlwZT0ieHM6c3RyaW5nIgoJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCXhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiPgoJCQkJCQkJCTwvRklDZXJ0VG9rZW4+CgkJCQkJCQkJPFJlYWxVc2VyTG9naW5TZXNzaW9uSWQgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJeG1sbnM6eHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIgoJCQkJCQkJCQl4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KCQkJCQkJCQk8L1JlYWxVc2VyTG9naW5TZXNzaW9uSWQ+CgkJCQkJCQkJPFJlYWxVc2VyIHhzaTp0eXBlPSJ4czpzdHJpbmciCgkJCQkJCQkJCXhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIKCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJPC9SZWFsVXNlcj4KCQkJCQkJCQk8UmVhbFVzZXJQd2QgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJeG1sbnM6eHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIgoJCQkJCQkJCQl4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KCQkJCQkJCQk8L1JlYWxVc2VyUHdkPgoJCQkJCQkJCTxTU09UcmFuc2ZlclRva2VuIHhzaTp0eXBlPSJ4czpzdHJpbmciCgkJCQkJCQkJCXhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIKCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJPC9TU09UcmFuc2ZlclRva2VuPgoJCQkJCQkJPC9TZWN1cml0eT4KCQkJCQkJPC9SZXF1ZXN0SGVhZGVyPgoJCQkJCTwvSGVhZGVyPgoJCQkJCTxCb2R5PgoJCQkJCQk8UmV0Q3VzdEFkZFJlcXVlc3Q+CgkJCQkJCQk8UmV0Q3VzdEFkZFJxPgoJCQkJCQkJCTxDdXN0RHRscz4KCQkJCQkJCQkJPEN1c3REYXRhPgoJCQkJCQkJCQkJPEFkZHJEdGxzPgoJCQkJCQkJCQkJCTxBZGRyTGluZTE+JHthZGRyTGluZTF9PC9BZGRyTGluZTE+CgkJCQkJCQkJCQkJPEFkZHJMaW5lMj4ke2FkZHJMaW5lMn08L0FkZHJMaW5lMj4KCQkJCQkJCQkJCQk8QWRkckNhdGVnb3J5PiR7YWRkckNhdGVnb3J5fTwvQWRkckNhdGVnb3J5PgoJCQkJCQkJCQkJCTxDaXR5PiR7Y2l0eX08L0NpdHk+CgkJCQkJCQkJCQkJPENvdW50cnk+JHtjb3VudHJ5fTwvQ291bnRyeT4KCQkJCQkJCQkJCQk8RnJlZVRleHRBZGRyIHhzaTp0eXBlPSJ4czpzdHJpbmciCgkJCQkJCQkJCQkJCXhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIKCQkJCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+LgoJCQkJCQkJCQkJCTwvRnJlZVRleHRBZGRyPgoJCQkJCQkJCQkJCTxGcmVlVGV4dExhYmVsPi48L0ZyZWVUZXh0TGFiZWw+CgkJCQkJCQkJCQkJPFByZWZBZGRyPlk8L1ByZWZBZGRyPgoJCQkJCQkJCQkJCTxQcmVmRm9ybWF0PkZSRUVfVEVYVF9GT1JNQVQ8L1ByZWZGb3JtYXQ+CgkJCQkJCQkJCQkJPFN0YXJ0RHQ+MjAyMi0xMi0xOFQxNToxNDo0OS43MTZaPC9TdGFydER0PgoJCQkJCQkJCQkJCTxTdGF0ZT4ke3N0YXRlfTwvU3RhdGU+CgkJCQkJCQkJCQkJPFBvc3RhbENvZGU+JHtwb3N0YWxDb2RlfTwvUG9zdGFsQ29kZT4KCQkJCQkJCQkJCQk8SXNBZGRyZXNzUHJvb2ZSZWNlaXZlZD5ZPC9Jc0FkZHJlc3NQcm9vZlJlY2VpdmVkPgoJCQkJCQkJCQkJPC9BZGRyRHRscz4KCQkJCQkJCQkJCTxBdXRvQXBwcm92YWw+WTwvQXV0b0FwcHJvdmFsPgoJCQkJCQkJCQkJPEJpcnRoRHQ+JHtiaXJ0aER0fTwvQmlydGhEdD4KCQkJCQkJCQkJCTxCaXJ0aE1vbnRoPiR7YmlydGhNb250aH08L0JpcnRoTW9udGg+CgkJCQkJCQkJCQk8QmlydGhZZWFyPiR7YmlydGhZZWFyfTwvQmlydGhZZWFyPgoJCQkJCQkJCQkJPENyZWF0ZWRCeVN5c3RlbUlkPkZJVlVTUjwvQ3JlYXRlZEJ5U3lzdGVtSWQ+CgkJCQkJCQkJCQk8RGF0ZU9mQmlydGg+JHtkYXRlT2ZCaXJ0aH08L0RhdGVPZkJpcnRoPgoJCQkJCQkJCQkJPExhbmd1YWdlPiR7bGFuZ3VhZ2V9IChFbmdsaXNoKTwvTGFuZ3VhZ2U+CgkJCQkJCQkJCQk8TGFzdE5hbWU+JHtsYXN0TmFtZX08L0xhc3ROYW1lPgoJCQkJCQkJCQkJPElzTWlub3I+JHtpc01pbm9yfTwvSXNNaW5vcj4KCQkJCQkJCQkJCTxJc0N1c3ROUkU+JHtpc0N1c3ROUkV9PC9Jc0N1c3ROUkU+CgkJCQkJCQkJCQk8RmF0aGVyT3JIdXNiYW5kTmFtZT4ke2ZhdGhlck9ySHVzYmFuZE5hbWV9PC9GYXRoZXJPckh1c2JhbmROYW1lPgoJCQkJCQkJCQkJPERlZmF1bHRBZGRyVHlwZT4ke2RlZmF1bHRBZGRyVHlwZX08L0RlZmF1bHRBZGRyVHlwZT4KCQkJCQkJCQkJCTxHZW5kZXI+JHtnZW5kZXJ9PC9HZW5kZXI+CgkJCQkJCQkJCQk8TWFuYWdlcj5CUEQyPC9NYW5hZ2VyPgoJCQkJCQkJCQkJPE5hdGl2ZUxhbmd1YWdlQ29kZT4ke25hdGl2ZUxhbmd1YWdlQ29kZX08L05hdGl2ZUxhbmd1YWdlQ29kZT4KCQkJCQkJCQkJCTxPY2N1cGF0aW9uPiR7b2NjdXBhdGlvbn08L09jY3VwYXRpb24+CgkJCQkJCQkJCQk8U01TQmFua2luZ01vYmlsZU51bWJlcj4ke3NNU0JhbmtpbmdNb2JpbGVOdW1iZXJ9PC9TTVNCYW5raW5nTW9iaWxlTnVtYmVyPgoJCQkJCQkJCQkJPElzU01TQmFua2luZ0VuYWJsZWQ+JHtpc1NNU0JhbmtpbmdFbmFibGVkfTwvSXNTTVNCYW5raW5nRW5hYmxlZD4KCQkJCQkJCQkJCTxDdXN0X1R5cGU+RUM8L0N1c3RfVHlwZT4KCQkJCQkJCQkJCTxTdHJVc2VyRmllbGQyPk48L1N0clVzZXJGaWVsZDI+CgkJCQkJCQkJCQk8UGhvbmVFbWFpbER0bHM+CgkJCQkJCQkJCQkJPFBob25lRW1haWxUeXBlPkNFTExQSDwvUGhvbmVFbWFpbFR5cGU+CgkJCQkJCQkJCQkJPFBob25lTnVtPiR7cGhvbmVOdW19PC9QaG9uZU51bT4KCQkJCQkJCQkJCQk8UGhvbmVOdW1DaXR5Q29kZT4ke3Bob25lTnVtQ2l0eUNvZGV9PC9QaG9uZU51bUNpdHlDb2RlPgoJCQkJCQkJCQkJCTxQaG9uZU51bUNvdW50cnlDb2RlPiR7cGhvbmVOdW1Db3VudHJ5Q29kZX08L1Bob25lTnVtQ291bnRyeUNvZGU+CgkJCQkJCQkJCQkJPFBob25lTnVtTG9jYWxDb2RlPiR7cGhvbmVOdW1Mb2NhbENvZGV9PC9QaG9uZU51bUxvY2FsQ29kZT4KCQkJCQkJCQkJCQk8UHJlZkZsYWc+WTwvUHJlZkZsYWc+CgkJCQkJCQkJCQkJPFBob25lT3JFbWFpbD5QSE9ORTwvUGhvbmVPckVtYWlsPgoJCQkJCQkJCQkJPC9QaG9uZUVtYWlsRHRscz4KCQkJCQkJCQkJCTxOYW1lPiR7bmFtZX08L05hbWU+CgkJCQkJCQkJCQk8UmVsYXRpb25zaGlwT3BlbmluZ0R0PiR7cmVsYXRpb25zaGlwT3BlbmluZ0R0fTwvUmVsYXRpb25zaGlwT3BlbmluZ0R0PgoJCQkJCQkJCQkJPFNhbHV0YXRpb24+JHtzYWx1dGF0aW9ufTwvU2FsdXRhdGlvbj4KCQkJCQkJCQkJCTxTZWNvbmRhcnlSTUlkPkJQRDI8L1NlY29uZGFyeVJNSWQ+CgkJCQkJCQkJCQk8U2VnbWVudGF0aW9uQ2xhc3M+UkVUPC9TZWdtZW50YXRpb25DbGFzcz4KCQkJCQkJCQkJCTxDdXN0VHlwZT5BY2NvdW50PC9DdXN0VHlwZT4KCQkJCQkJCQkJCTxQcmltYXJ5U29sSWQ+MDAxODwvUHJpbWFyeVNvbElkPgoJCQkJCQkJCQkJPFNob3J0TmFtZT4ke3Nob3J0TmFtZX08L1Nob3J0TmFtZT4KCQkJCQkJCQkJCTxTdGFmZkZsYWc+TjwvU3RhZmZGbGFnPgoJCQkJCQkJCQkJPFN1YlNlZ21lbnQ+JHtzdWJTZWdtZW50fTwvU3ViU2VnbWVudD4KCQkJCQkJCQkJCTxSZWdpb24+JHtyZWdpb259PC9SZWdpb24+CgkJCQkJCQkJCQk8SXNJc2xhbWljQmFua2luZ0N1c3Q+JHtpc0lzbGFtaWNCYW5raW5nQ3VzdH08L0lzSXNsYW1pY0JhbmtpbmdDdXN0PgoJCQkJCQkJCQkJPE1haWRlbk5hbWVPZk1vdGhlcj4ke21haWRlbk5hbWVPZk1vdGhlcn08L01haWRlbk5hbWVPZk1vdGhlcj4KCQkJCQkJCQkJPC9DdXN0RGF0YT4KCQkJCQkJCQk8L0N1c3REdGxzPgoJCQkJCQkJCTxSZWxhdGVkRHRscz4KCQkJCQkJCQkJPERlbW9ncmFwaGljRGF0YT4KCQkJCQkJCQkJCTxNYXJpdGFsU3RhdHVzPiR7bWFyaXRhbFN0YXR1c308L01hcml0YWxTdGF0dXM+CgkJCQkJCQkJCQk8TmF0aW9uYWxpdHk+bmF0aW9uYWxpdHk8L05hdGlvbmFsaXR5PgoJCQkJCQkJCQkJPEVtcGxveW1lbnRTdGF0dXMgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJCQk8L0VtcGxveW1lbnRTdGF0dXM+CgkJCQkJCQkJCQk8RGVtb2dyYXBoaWNNaXNjRGF0YT4KCQkJCQkJCQkJCQk8VHlwZT5DVVJSRU5UX0VNUExPWU1FTlQ8L1R5cGU+CgkJCQkJCQkJCQk8L0RlbW9ncmFwaGljTWlzY0RhdGE+CgkJCQkJCQkJCTwvRGVtb2dyYXBoaWNEYXRhPgoJCQkJCQkJCQk8RW50aXR5RG9jdERhdGE+CgkJCQkJCQkJCQk8Q291bnRyeU9mSXNzdWU+JHtjb3VudHJ5T2ZJc3N1ZX08L0NvdW50cnlPZklzc3VlPgoJCQkJCQkJCQkJPERvY0NvZGU+JHtkb2NDb2RlfTwvRG9jQ29kZT4KCQkJCQkJCQkJCTxEZXNjPlVJRDwvRGVzYz4KCQkJCQkJCQkJCTxJc3N1ZUR0PiR7aXNzdWVEdH08L0lzc3VlRHQ+CgkJCQkJCQkJCQk8UmVjZWl2ZWREdD4ke3JlY2VpdmVkRHR9PC9SZWNlaXZlZER0PgoJCQkJCQkJCQkJPFR5cGVDb2RlPiR7dHlwZUNvZGV9PC9UeXBlQ29kZT4KCQkJCQkJCQkJCTxUeXBlRGVzYz4ke3R5cGVEZXNjfTwvVHlwZURlc2M+CgkJCQkJCQkJCQk8U09VUkNFX0NPREUgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJCQk8L1NPVVJDRV9DT0RFPgoJCQkJCQkJCQkJPFJldEVudFR5cGU+CgkJCQkJCQkJCQkJPEN1c3RBdHRyaWJ1dGVJZD5BREQ8L0N1c3RBdHRyaWJ1dGVJZD4KCQkJCQkJCQkJCQk8SGlkZGVuQ3VzdElkPkNJRlJldEN1c3Q8L0hpZGRlbkN1c3RJZD4KCQkJCQkJCQkJCTwvUmV0RW50VHlwZT4KCQkJCQkJCQkJCTxSZXRJZGVudGlmaWNhdGlvbnR5cGU+CgkJCQkJCQkJCQkJPEN1c3RBdHRyaWJ1dGVJZD5BREQ8L0N1c3RBdHRyaWJ1dGVJZD4KCQkJCQkJCQkJCQk8SGlkZGVuQ3VzdElkPjE1PC9IaWRkZW5DdXN0SWQ+CgkJCQkJCQkJCQk8L1JldElkZW50aWZpY2F0aW9udHlwZT4KCQkJCQkJCQkJCTxQbGFjZU9mSXNzdWU+JHtwbGFjZU9mSXNzdWV9PC9QbGFjZU9mSXNzdWU+CgkJCQkJCQkJCQk8UmVmZXJlbmNlTnVtPiR7cmVmZXJlbmNlTnVtfTwvUmVmZXJlbmNlTnVtPgoJCQkJCQkJCQk8L0VudGl0eURvY3REYXRhPgoJCQkJCQkJCQk8UHN5Y2hvZ3JhcGhpY0RhdGE+CgkJCQkJCQkJCQk8Q3VzdEN1cnJDb2RlPklOUjwvQ3VzdEN1cnJDb2RlPgoJCQkJCQkJCQkJPFBzeWNob2dyYXBoTWlzY0RhdGE+CgkJCQkJCQkJCQkJPERURHQxPiR7ZFREdDF9PC9EVER0MT4KCQkJCQkJCQkJCQk8U3RyVGV4dDEwPklOUjwvU3RyVGV4dDEwPgoJCQkJCQkJCQkJCTxUeXBlPiR7dHlwZX08L1R5cGU+CgkJCQkJCQkJCQk8L1BzeWNob2dyYXBoTWlzY0RhdGE+CgkJCQkJCQkJCTwvUHN5Y2hvZ3JhcGhpY0RhdGE+CgkJCQkJCQkJCTxSZWxhdGlvbnNoaXBEdGxzPgoJCQkJCQkJCQkJPENoaWxkQ3VzdElkIHhzaTp0eXBlPSJ4czpzdHJpbmciCgkJCQkJCQkJCQkJeG1sbnM6eHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIgoJCQkJCQkJCQkJCXhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiPgoJCQkJCQkJCQkJPC9DaGlsZEN1c3RJZD4KCQkJCQkJCQkJCTxSZWxhdGlvbnNoaXAgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJCQk8L1JlbGF0aW9uc2hpcD4KCQkJCQkJCQkJCTxSZWxhdGlvbnNoaXBDYXRlZ29yeSB4c2k6dHlwZT0ieHM6c3RyaW5nIgoJCQkJCQkJCQkJCXhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIKCQkJCQkJCQkJCQl4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KCQkJCQkJCQkJCTwvUmVsYXRpb25zaGlwQ2F0ZWdvcnk+CgkJCQkJCQkJCQk8Q2hpbGRFbnRpdHkgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJCQk8L0NoaWxkRW50aXR5PgoJCQkJCQkJCQkJPENoaWxkRW50aXR5VHlwZSB4c2k6dHlwZT0ieHM6c3RyaW5nIgoJCQkJCQkJCQkJCXhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIKCQkJCQkJCQkJCQl4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KCQkJCQkJCQkJCTwvQ2hpbGRFbnRpdHlUeXBlPgoJCQkJCQkJCQkJPFJlbGF0aW9uc2hpcE1pc2NJbmZvPgoJCQkJCQkJCQkJCTxUeXBlIHhzaTp0eXBlPSJ4czpzdHJpbmciCgkJCQkJCQkJCQkJCXhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIKCQkJCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJCQkJPC9UeXBlPgoJCQkJCQkJCQkJPC9SZWxhdGlvbnNoaXBNaXNjSW5mbz4KCQkJCQkJCQkJCTxHdWFyZENvZGUgeHNpOnR5cGU9InhzOnN0cmluZyIKCQkJCQkJCQkJCQl4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiCgkJCQkJCQkJCQkJeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CgkJCQkJCQkJCQk8L0d1YXJkQ29kZT4KCQkJCQkJCQkJPC9SZWxhdGlvbnNoaXBEdGxzPgoJCQkJCQkJCTwvUmVsYXRlZER0bHM+CgkJCQkJCQk8L1JldEN1c3RBZGRScT4KCQkJCQkJCTxSZXRDdXN0QWRkX0N1c3RvbURhdGE+CgkJCQkJCQkJPFNUUlVTRVJGSUVMRDIzPlBBTjwvU1RSVVNFUkZJRUxEMjM+CgkJCQkJCQkJPFNUUlVTRVJGSUVMRDI0PkRTSVBLNDg4OEs8L1NUUlVTRVJGSUVMRDI0PgoJCQkJCQkJCTxDT05TVElUVVRJT05fQ09ERT4wMDI8L0NPTlNUSVRVVElPTl9DT0RFPgoJCQkJCQkJCTxDVVNUX1RZUEU+RUM8L0NVU1RfVFlQRT4KCQkJCQkJCQk8TkFUVVJFX09GX0FDVElWSVRZPk9UPC9OQVRVUkVfT0ZfQUNUSVZJVFk+CgkJCQkJCQkJPEFTU0VUX0NMQVNTSUZJQ0FUSU9OPlU8L0FTU0VUX0NMQVNTSUZJQ0FUSU9OPgoJCQkJCQkJCTxTVFJURVhUMjI+SlAwMDAzMzQyMTwvU1RSVEVYVDIyPgoJCQkJCQkJCTxJU0VCQU5LSU5HRU5BQkxFRD5ZPC9JU0VCQU5LSU5HRU5BQkxFRD4KCQkJCQkJCQk8UFVSR0VGTEFHPk48L1BVUkdFRkxBRz4KCQkJCQkJCQk8U1RSVVNFUkZJRUxEMjU+SlAwMDAzMzQyMTwvU1RSVVNFUkZJRUxEMjU+CgkJCQkJCQk8L1JldEN1c3RBZGRfQ3VzdG9tRGF0YT4KCQkJCQkJPC9SZXRDdXN0QWRkUmVxdWVzdD4KCQkJCQk8L0JvZHk+CgkJCQk8L0ZJWE1MPgoJCQk8L2FyZ18wXzA+CgkJPC9uczM6ZXhlY3V0ZVNlcnZpY2U+Cgk8L25zMjpCb2R5Pgo8L25zMjpFbnZlbG9wZT4K",
              "dataType" : "text"
            }
          },
          "name" : "Kris"
        }, {
          "id" : "682944175245541",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "dummy",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "Dumbo..",
              "dataType" : "text"
            }
          },
          "name" : "Gladyce"
        }, {
          "id" : "683401953849045",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decryptValue2",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "decode",
                "init" : {
                  "value" : "decodedValue2@local",
                  "format" : "base64"
                }
              }
            }
          },
          "name" : "Coy"
        }, {
          "id" : "683842280905592",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "decryptValue3",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "replace",
                "init" : {
                  "value" : "decryptValue2@local",
                  "fields" : {
                    "${addrLine1}" : "abc",
                    "${addrLine2}" : "dummy@local"
                  }
                }
              }
            }
          },
          "name" : "Vesta"
        }, {
          "id" : "684436331279969",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "decryptValue4",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toXml",
                "init" : {
                  "value" : "decryptValue3@local"
                }
              }
            }
          },
          "name" : "Georgette"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "684432261147337"
      },
      "id" : "684439754148127"
    } ]
  }
}`

const Test_xml = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Birdie",
        "statements" : [ {
          "id" : "685241484866081",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "customer.name",
              "dataType" : "number"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "javeed",
              "dataType" : "number"
            }
          },
          "name" : "Gregory"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "685243489120790"
      },
      "id" : "685249736474822"
    } ]
  }
}`

const TestKeyword_isBooleanTrueWithXMLInput = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "xml",
  "contentOutputType" : "xml",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jackeline",
        "statements" : [ {
          "id" : "686003905555549",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isBoolean",
                "init" : {
                  "value" : "root.isAlive.#text"
                }
              }
            }
          },
          "name" : "Ebony"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "686002592455121"
      },
      "id" : "686005216328346"
    } ]
  }
}`

const TextWithNullValue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Armani",
        "statements" : [ {
          "id" : "686665474703829",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toUpperCase",
                "init" : {
                  "value" : "krakend"
                }
              }
            }
          },
          "name" : "Jennings"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "686669893785096"
      },
      "id" : "686661197621184"
    } ]
  }
}`

const TestKeyword_isBooleanTrue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Noemie",
        "statements" : [ {
          "id" : "687299447843272",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isBoolean",
                "init" : {
                  "value" : "isAlive"
                }
              }
            }
          },
          "name" : "Stephania"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "687298711651548"
      },
      "id" : "687296704916940"
    } ]
  }
}`

const TextReplace = `{
  "version" : 3.3,
  "@type" : "transform",
  "contentInputType" : "json",
  "contentOutputType" : "xml",
  "transform" : {
    "jsonIgnoreProperty" : false,
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ford",
        "statements" : [ {
          "id" : "688018774511479",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "templete",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "PEZJWE1MIHhzaTpzY2hlbWFMb2NhdGlvbj0iaHR0cDovL3d3dy5maW5hY2xlLmNvbS9maXhtbCBpbnF1aXJlQ3VzdG9tZXJMaW1pdERldGFpbHMueHNkIiB4bWxucz0iaHR0cDovL3d3dy5maW5hY2xlLmNvbS9maXhtbCIgeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSI+CiAgICA8SGVhZGVyPgogICAgICAgIDxSZXF1ZXN0SGVhZGVyPgogICAgICAgICAgICA8TWVzc2FnZUtleT4KICAgICAgICAgICAgICAgIDxSZXF1ZXN0VVVJRD4xOTExMWhoaDFqMTEzMWU5PC9SZXF1ZXN0VVVJRD4KICAgICAgICAgICAgICAgIDxTZXJ2aWNlUmVxdWVzdElkPmlucXVpcmVDdXN0b21lckxpbWl0RGV0YWlsczwvU2VydmljZVJlcXVlc3RJZD4KICAgICAgICAgICAgICAgIDxTZXJ2aWNlUmVxdWVzdFZlcnNpb24+MTAuMjwvU2VydmljZVJlcXVlc3RWZXJzaW9uPgogICAgICAgICAgICAgICAgPENoYW5uZWxJZD5DT1I8L0NoYW5uZWxJZD4KICAgICAgICAgICAgICAgIDxMYW5ndWFnZUlkPjwvTGFuZ3VhZ2VJZD4KICAgICAgICAgICAgPC9NZXNzYWdlS2V5PgogICAgICAgICAgICA8UmVxdWVzdE1lc3NhZ2VJbmZvPgogICAgICAgICAgICAgICAgPEJhbmtJZD48L0JhbmtJZD4KICAgICAgICAgICAgICAgIDxUaW1lWm9uZT48L1RpbWVab25lPgogICAgICAgICAgICAgICAgPEVudGl0eUlkPjwvRW50aXR5SWQ+CiAgICAgICAgICAgICAgICA8RW50aXR5VHlwZT48L0VudGl0eVR5cGU+CiAgICAgICAgICAgICAgICA8QXJtQ29ycmVsYXRpb25JZD48L0FybUNvcnJlbGF0aW9uSWQ+CiAgICAgICAgICAgICAgICA8TWVzc2FnZURhdGVUaW1lPjIwMjItMDItMTZUMTU6NDQ6MzQuNjUxPC9NZXNzYWdlRGF0ZVRpbWU+CiAgICAgICAgICAgIDwvUmVxdWVzdE1lc3NhZ2VJbmZvPgogICAgICAgICAgICA8U2VjdXJpdHk+CiAgICAgICAgICAgICAgICA8VG9rZW4+CiAgICAgICAgICAgICAgICAgICAgPFBhc3N3b3JkVG9rZW4+CiAgICAgICAgICAgICAgICAgICAgICAgIDxVc2VySWQ+PC9Vc2VySWQ+CiAgICAgICAgICAgICAgICAgICAgICAgIDxQYXNzd29yZD48L1Bhc3N3b3JkPgogICAgICAgICAgICAgICAgICAgIDwvUGFzc3dvcmRUb2tlbj4KICAgICAgICAgICAgICAgIDwvVG9rZW4+CiAgICAgICAgICAgICAgICA8RklDZXJ0VG9rZW4+PC9GSUNlcnRUb2tlbj4KICAgICAgICAgICAgICAgIDxSZWFsVXNlckxvZ2luU2Vzc2lvbklkPjwvUmVhbFVzZXJMb2dpblNlc3Npb25JZD4KICAgICAgICAgICAgICAgIDxSZWFsVXNlcj48L1JlYWxVc2VyPgogICAgICAgICAgICAgICAgPFJlYWxVc2VyUHdkPjwvUmVhbFVzZXJQd2Q+CiAgICAgICAgICAgICAgICA8U1NPVHJhbnNmZXJUb2tlbj48L1NTT1RyYW5zZmVyVG9rZW4+CiAgICAgICAgICAgIDwvU2VjdXJpdHk+CiAgICAgICAgPC9SZXF1ZXN0SGVhZGVyPgogICAgPC9IZWFkZXI+CiAgICA8Qm9keT4KICAgICAgICA8aW5xdWlyZUN1c3RvbWVyTGltaXREZXRhaWxzUmVxdWVzdD4KICAgICAgICAgICAgPGN1c3RvbWVyTGltaXREZXRhaWxzSW5wdXRWTz4KICAgICAgICAgICAgICAgIDxjdXN0Q2lmSWQ+JHtjdXN0Q2lmSWR9PC9jdXN0Q2lmSWQ+CiAgICAgICAgICAgIDwvY3VzdG9tZXJMaW1pdERldGFpbHNJbnB1dFZPPgogICAgICAgICAgICA8aW5xdWlyZUN1c3RvbWVyTGltaXREZXRhaWxzX0N1c3RvbURhdGEvPgogICAgICAgIDwvaW5xdWlyZUN1c3RvbWVyTGltaXREZXRhaWxzUmVxdWVzdD4KICAgIDwvQm9keT4KPC9GSVhNTD4=",
              "dataType" : "text"
            }
          },
          "name" : "Judd"
        }, {
          "id" : "688251489501611",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "templete2",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "decode",
                "init" : {
                  "value" : "templete@local",
                  "format" : "base64"
                }
              }
            }
          },
          "name" : "Pauline"
        }, {
          "id" : "688499030429924",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "abc",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "1230M",
              "dataType" : "text"
            }
          },
          "name" : "Jayden"
        }, {
          "id" : "688798578316059",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "ReplacedText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "replace",
                "init" : {
                  "value" : "templete2@local",
                  "fields" : {
                    "${custCifId}" : "cifId"
                  }
                }
              }
            }
          },
          "name" : "Orie"
        }, {
          "id" : "689015942587113",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "templete",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toXml",
                "init" : {
                  "value" : "ReplacedText@local"
                }
              }
            }
          },
          "name" : "Dominique"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "689014156891014"
      },
      "id" : "689017078381197"
    } ]
  }
}`

const TestKeyword_trim = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Terence",
                  "statements": [
                      {
                          "id": "689833843957067",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "finalText",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataValue": "text",
                                  "dataType": "text",
                                  "keywordArguments": {
                                      "format": "trim",
                                      "init": {
                                          "value": "name"
                                      }
                                  }
                              }
                          },
                          "name": "Jimmie"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "689839117068332"
              },
              "id": "689836144876107"
          }
      ]
  }
}`

const TestKeyword_toLower = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ulises",
        "statements" : [ {
          "id" : "690767036623207",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toLowerCase",
                "init" : {
                  "value" : "name"
                }
              }
            }
          },
          "name" : "Claude"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "690771265423157"
      },
      "id" : "690771241812375"
    } ]
  }
}`

const TestKeyword_toUpper = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Domenica",
        "statements" : [ {
          "id" : "691662902615603",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toUpperCase",
                "init" : {
                  "value" : "name"
                }
              }
            }
          },
          "name" : "Patrick"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "691661063425968"
      },
      "id" : "691665527576471"
    } ]
  }
}`

const SubString = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Wyatt",
        "statements" : [ {
          "id" : "692345242892936",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "Mohd Javeed Pasha",
              "dataType" : "text"
            }
          },
          "name" : "Garnet"
        }, {
          "id" : "692684047443208",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "subString",
                "init" : {
                  "value" : "name@local",
                  "startIndex" : 5,
                  "endIndex" : 11
                }
              }
            }
          },
          "name" : "Lavonne"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "692684182815498"
      },
      "id" : "692681193910553"
    } ]
  }
}`

const IndexOf = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Brenna",
        "statements" : [ {
          "id" : "693563357661903",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "Mohd Javeed Pasha",
              "dataType" : "text"
            }
          },
          "name" : "Olga"
        }, {
          "id" : "693999264665773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "indexOf",
                "init" : {
                  "value" : "name@local",
                  "subString" : "d"
                }
              }
            }
          },
          "name" : "Kaycee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "693993877376356"
      },
      "id" : "693993093750514"
    } ]
  }
}`

const TestKeyword_toNumber = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ebba",
        "statements" : [ {
          "id" : "694848342141676",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toNumber",
                "init" : {
                  "value" : "mobile"
                }
              }
            }
          },
          "name" : "Elnora"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "694849433820124"
      },
      "id" : "694843028188673"
    } ]
  }
}`

const TestKeyword_isNumberTrue = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Ernest",
        "statements" : [ {
          "id" : "695591939257364",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isNumber",
                "init" : {
                  "value" : "mobile"
                }
              }
            }
          },
          "name" : "Morris"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "695601553862272"
      },
      "id" : "695608900012874"
    } ]
  }
}`

const TestKeyword_isBooleanfalse = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Charley",
        "statements" : [ {
          "id" : "696376584913544",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "isBoolean",
                "init" : {
                  "value" : "name"
                }
              }
            }
          },
          "name" : "Bertram"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "696373357912957"
      },
      "id" : "696375477343406"
    } ]
  }
}`

const TestTextEqualIgnoreCase = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "condition": {
                  "@type": "logical",
                  "type": "and",
                  "rules": [
                      {
                          "@type": "relational",
                          "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "StateMentId"
                          },
                          "operator": {
                              "actualValue": "equalIgnoreCase"
                          },
                          "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "staTEMEntid"
                          }
                      }
                  ]
              },
              "@type": "ConditionalStatement",
              "success": {
                  "name": "transformation",
                  "statements": [
                      {
                          "id": "958777415385605",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "status",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataValue": "Success",
                                  "dataType": "text"
                              }
                          },
                          "name": "Jocelyn"
                      }
                  ],
                  "id": "958772861621868"
              },
              "failure": {
                  "name": "transformation",
                  "statements": [
                      {
                          "id": "958777415385605",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "status",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "literal",
                                  "dataValue": "Failed",
                                  "dataType": "text"
                              }
                          },
                          "name": "Jocelyn"
                      }
                  ],
                  "id": "958772861621868"
              },
              "id": "exception1"
          }
      ]
  }
}`

const LengthOfString = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Brenna",
        "statements" : [ {
          "id" : "693563357661903",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "literal",
              "dataValue" : "Mohd Javeed Pasha",
              "dataType" : "text"
            }
          },
          "name" : "Olga"
        }, {
          "id" : "693999264665773",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "length",
                "init" : {
                  "value" : "name@local"
                }
              }
            }
          },
          "name" : "Kaycee"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "693993877376356"
      },
      "id" : "693993093750514"
    } ]
  }
}`

const RegXFormat = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "@type": "SectionalStatement",
                "section": {
                    "jsonIgnoreProperty": false,
                    "name": "Brenna",
                    "statements": [
                        {
                            "id": "693999264665773",
                            "@type": "AssignmentStatement",
                            "assignment": {
                                "@type": "SimpleAssignmentStatement",
                                "lhs": {
                                    "@type": "literal",
                                    "dataValue": "isValidPan",
                                    "dataType": "text"
                                },
                                "operator": {
                                    "actualValue": "="
                                },
                                "rhs": {
                                    "@type": "keyword",
                                    "dataValue": "text",
                                    "dataType": "text",
                                    "keywordArguments": {
                                        "format": "regex",
                                        "init": {
                                            "value": "panNumber",
                                            "format": "[A-Z]{3}[ABCFGHLJPTF]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}"
                                        }
                                    }
                                }
                            },
                            "name": "Kaycee"
                        }
                    ],
                    "jsonIgnoreAliasValue": null,
                    "id": "693993877376356"
                },
                "id": "693993093750514"
            }
        ]
    }
}`

const RegXFormatInvalid = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
      "id": "transform_custodetails",
      "name": "Request payload Transformation",
      "statements": [
          {
              "@type": "SectionalStatement",
              "section": {
                  "jsonIgnoreProperty": false,
                  "name": "Brenna",
                  "statements": [
                      {
                          "id": "693999264665773",
                          "@type": "AssignmentStatement",
                          "assignment": {
                              "@type": "SimpleAssignmentStatement",
                              "lhs": {
                                  "@type": "literal",
                                  "dataValue": "isValidPan",
                                  "dataType": "text"
                              },
                              "operator": {
                                  "actualValue": "="
                              },
                              "rhs": {
                                  "@type": "keyword",
                                  "dataValue": "text",
                                  "dataType": "text",
                                  "keywordArguments": {
                                      "format": "regex",
                                      "init": {
                                          "value": "panNumberInvalid",
                                          "format": "[A-Z]{3}[ABCFGHLJPTF]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}"
                                      }
                                  }
                              }
                          },
                          "name": "Kaycee"
                      }
                  ],
                  "jsonIgnoreAliasValue": null,
                  "id": "693993877376356"
              },
              "id": "693993093750514"
          }
      ]
  }
}`

const IsEmptyForTextConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "yeah"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "text",
                      "keywordArguments": {
                        "init": {
                          "value": "flag"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "Check String is Empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": true,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`

const KeyNotPresentForIsEmptyConfig = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "yeah"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "text",
                      "keywordArguments": {
                        "init": {
                          "value": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "Check String is Empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`
const TestValueKeyNotPresentInConfigForIsEmpty = `{
  "version": 3.3,
  "@type": "transform",
  "transform": {
    "id": "transform_custodetails",
    "name": "Request payload Transformation",
    "statements": [
      {
        "id": 1741174953797060,
        "name": "BestOak",
        "@type": "SectionalStatement",
        "section": {
          "id": 819452784956344,
          "name": "SECTION Statement 947427",
          "statements": [
            {
              "id": 1741256222349595,
              "name": "SprayBay",
              "@type": "ConditionalStatement",
              "failure": {
                "id": 0,
                "name": "RanchBull"
              },
              "success": {
                "id": 156521794166778,
                "name": "WarmDepth",
                "statements": [
                  {
                    "id": 1741256286433993,
                    "name": "HornHerb",
                    "@type": "AssignmentStatement",
                    "mandatory": true,
                    "assignment": {
                      "lhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "result"
                      },
                      "rhs": {
                        "@type": "literal",
                        "dataType": "text",
                        "dataValue": "yeah"
                      },
                      "operator": {
                        "actualValue": "="
                      }
                    }
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "condition": {
                "type": "and",
                "@type": "logical",
                "rules": [
                  {
                    "lhs": {
                      "@type": "keyword",
                      "dataType": "boolean",
                      "dataValue": "text",
                      "keywordArguments": {
                        "init": {
                          "valuef": "keyNotPresent"
                        },
                        "format": "isEmpty"
                      },
                      "functionLabelName": "Check String is Empty or not"
                    },
                    "rhs": {
                      "@type": "literal",
                      "dataType": "boolean",
                      "dataValue": true
                    },
                    "@type": "relational",
                    "operator": {
                      "actualValue": "=="
                    }
                  }
                ]
              },
              "mandatory": true
            }
          ],
          "jsonIgnoreProperty": false,
          "jsonIgnoreAliasValue": ""
        },
        "mandatory": true
      }
    ]
  }
}`
