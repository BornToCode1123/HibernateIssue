package configs 

const NumberToTextStringConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Braxton",
        "statements" : [ {
          "id" : "483133788215255",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "mobile"
                }
              }
            }
          },
          "name" : "Bud"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "483143457363727"
      },
      "id" : "483144182447660"
    } ]
  }
}`

const NumberToTextConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Jermaine",
        "statements" : [ {
          "id" : "485203877275063",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "mobile1"
                }
              }
            }
          },
          "name" : "Bernadine"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "485202717578995"
      },
      "id" : "485209564760520"
    } ]
  }
}`

const NumberToTextLocalConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Tyrese",
        "statements" : [ {
          "id" : "486608967372393",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "mobile1",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "number",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toText",
                "init" : {
                  "value" : "mobile1"
                }
              }
            }
          },
          "name" : "Kira"
        }, {
          "id" : "487283140365357",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "mobile1@local",
              "dataType" : "text"
            }
          },
          "name" : "Keely"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "487288734836717"
      },
      "id" : "487287294601901"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

