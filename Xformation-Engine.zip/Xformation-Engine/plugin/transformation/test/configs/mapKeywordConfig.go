package configs 

const MapGetValuesSets = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Gloria",
        "statements" : [ {
          "id" : "122687032826354",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getValueSet",
                "init" : {
                  "value" : "MonthlyData"
                }
              }
            }
          },
          "name" : "Bertha"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "122685872935729"
      },
      "id" : "122699203898789"
    } ]
  }
}`

const MapGetKeySets = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Eulalia",
        "statements" : [ {
          "id" : "125082698297690",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "getKeySet",
                "init" : {
                  "value" : "MonthlyData"
                }
              }
            }
          },
          "name" : "Samson"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "125088462771317"
      },
      "id" : "125089271111510"
    } ]
  }
}`

const MapLengths = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Katelin",
        "statements" : [ {
          "id" : "126417958901002",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "finalText",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "map",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "length",
                "init" : {
                  "value" : "MonthlyData"
                }
              }
            }
          },
          "name" : "Cyrus"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "126417061453619"
      },
      "id" : "126413322075216"
    } ]
  }
}`

