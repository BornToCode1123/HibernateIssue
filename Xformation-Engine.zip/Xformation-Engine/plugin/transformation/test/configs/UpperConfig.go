package configs 

const UpperNumberConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Silas",
        "statements" : [ {
          "id" : "178221770310123",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toUpperCase",
                "init" : {
                  "value" : "experience"
                }
              }
            }
          },
          "name" : "Bradley"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "178232818106663"
      },
      "id" : "178235796354172"
    } ]
  }
}`

const LocalUpperConfig = `{
  "version" : "1",
  "@type" : "transform",
  "transform" : {
    "id" : "transform_config_1",
    "name" : "customerResponse",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Andreanne",
        "statements" : [ {
          "id" : "182676876702686",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "lhs" : {
              "@type" : "declare",
              "dataValue" : "gender",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toUpperCase",
                "init" : {
                  "value" : "gender"
                }
              }
            }
          },
          "name" : "Domingo"
        }, {
          "id" : "183989129787754",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "UpperLocal",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "variable",
              "dataValue" : "gender@local",
              "dataType" : "text"
            }
          },
          "name" : "Napoleon"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "183985186117751"
      },
      "id" : "183987400345089"
    } ]
  },
  "delete" : { },
  "extract" : { }
}`

const UpperConfig = `{
  "version" : 3.3,
  "@type" : "transform",
  "transform" : {
    "id" : "transform_custodetails",
    "name" : "Request payload Transformation",
    "statements" : [ {
      "@type" : "SectionalStatement",
      "section" : {
        "jsonIgnoreProperty" : false,
        "name" : "Zoie",
        "statements" : [ {
          "id" : "185805242132314",
          "@type" : "AssignmentStatement",
          "assignment" : {
            "@type" : "SimpleAssignmentStatement",
            "lhs" : {
              "@type" : "literal",
              "dataValue" : "Name",
              "dataType" : "text"
            },
            "operator" : {
              "actualValue" : "="
            },
            "rhs" : {
              "@type" : "keyword",
              "dataValue" : "text",
              "dataType" : "text",
              "keywordArguments" : {
                "format" : "toUpperCase",
                "init" : {
                  "value" : "gender"
                }
              }
            }
          },
          "name" : "Pasquale"
        } ],
        "jsonIgnoreAliasValue" : null,
        "id" : "185804696467808"
      },
      "id" : "185808908359257"
    } ]
  }
}`

