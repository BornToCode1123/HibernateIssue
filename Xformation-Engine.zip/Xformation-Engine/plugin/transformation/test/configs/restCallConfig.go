package configs

const SchemaConfig = `{
              "id": 372432763917846,
              "name": "req",
              "@type": "transform",
              "debug": false,
              "errors": {
                "id": 372432763917846,
                "name": "ErrorStatement",
                "statements": [
                  {
                    "id": 373202132096397,
                    "name": "STATEMENT 372871499698820",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 372888561974162,
                      "name": "SECTION Statement 372888561974162",
                      "statements": [],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "headers": {},
              "version": 3,
              "transform": {
                "id": 372432763917846,
                "name": "req",
                "statements": [
                  {
                    "id": 1731049804033159,
                    "name": "PotFrame",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 408449356722679,
                      "name": "SECTION Statement 225627",
                      "statements": [
                        {
                          "id": 1731049803605729,
                          "name": "CropRoad",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "productEndpoint"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "products"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731049816851192,
                          "name": "PumpBid",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "restcallResp"
                            },
                            "rhs": {
                              "@type": "function",
                              "dataType": "map",
                              "functionName": "apiRestCall",
                              "functionArguments": {
                                "host": "https://dummyjson.com/",
                                "headers": "headers@local",
                                "methodType": "GET",
                                "urlPattern": "productEndpoint@local",
                                "readTimeout": 60,
                                "customHeaders": {},
                                "contentInputType": "json",
                                "connectionTimeout": 60,
                                "contentOutputType": "json",
                                "allowInsecureConnection": true,
                                "jsonSchema": {
                                  "type": "object",
                                  "properties": {
                                    "products": {
                                      "type": "array",
                                      "items": {
                                        "type": "object",
                                        "properties": {
                                          "id": {
                                            "type": "float"
                                          },
                                          "title": {
                                            "type": "string"
                                          },
                                          "description": {
                                            "type": "string"
                                          },
                                          "category": {
                                            "type": "string"
                                          },
                                          "price": {
                                            "type": "number"
                                          },
                                          "discountPercentage": {
                                            "type": "number"
                                          },
                                          "rating": {
                                            "type": "number"
                                          },
                                          "stock": {
                                            "type": "integer"
                                          },
                                          "brand": {
                                            "type": "string"
                                          },
                                          "sku": {
                                            "type": "string"
                                          },
                                          "weight": {
                                            "type": "integer"
                                          },
                                          "warrantyInformation": {
                                            "type": "string"
                                          },
                                          "shippingInformation": {
                                            "type": "string"
                                          },
                                          "availabilityStatus": {
                                            "type": "string"
                                          },
                                          "returnPolicy": {
                                            "type": "string"
                                          },
                                          "minimumOrderQuantity": {
                                            "type": "integer"
                                          },
                                          "thumbnail": {
                                            "type": "string",
                                            "format": "uri"
                                          }
                                        },
                                        "required": [
                                          "id"
                                        ]
                                      }
                                    },
                                    "total": {
                                      "type": "integer"
                                    },
                                    "skip": {
                                      "type": "integer"
                                    },
                                    "limit": {
                                      "type": "integer"
                                    }
                                  },
                                  "required": [
                                    "total",
                                    "skip",
                                    "limit"
                                  ]
                                }
                              }
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        }
                      ],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "contentInputType": "json",
              "ignoreNullFields": false,
              "contentOutputType": "json"
            }`

const SchemaConfig2 = `{
              "id": 372432763917846,
              "name": "req",
              "@type": "transform",
              "debug": false,
              "errors": {
                "id": 372432763917846,
                "name": "ErrorStatement",
                "statements": [
                  {
                    "id": 373202132096397,
                    "name": "STATEMENT 372871499698820",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 372888561974162,
                      "name": "SECTION Statement 372888561974162",
                      "statements": [],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "headers": {},
              "version": 3,
              "transform": {
                "id": 372432763917846,
                "name": "req",
                "statements": [
                  {
                    "id": 1731049804033159,
                    "name": "PotFrame",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 408449356722679,
                      "name": "SECTION Statement 225627",
                      "statements": [
                        {
                          "id": 1731049803605729,
                          "name": "CropRoad",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "productEndpoint"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "products"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731049816851192,
                          "name": "PumpBid",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "restcallResp"
                            },
                            "rhs": {
                              "@type": "function",
                              "dataType": "map",
                              "functionName": "apiRestCall",
                              "functionArguments": {
                                "host": "https://dummyjson.com/",
                                "headers": "headers@local",
                                "methodType": "GET",
                                "urlPattern": "productEndpoint@local",
                                "readTimeout": 60,
                                "customHeaders": {},
                                "contentInputType": "json",
                                "connectionTimeout": 60,
                                "contentOutputType": "json",
                                "allowInsecureConnection": true,
                                "jsonSchema": {
                                  "type": "object",
                                  "properties": {
                                    "products": {
                                      "type": "array",
                                      "items": {
                                        "type": "object",
                                        "properties": {
                                          "id": {
                                            "type": "integer"
                                          },
                                          "title": {
                                            "type": "string"
                                          },
                                          "description": {
                                            "type": "string"
                                          },
                                          "category": {
                                            "type": "string"
                                          },
                                          "price": {
                                            "type": "number"
                                          },
                                          "discountPercentage": {
                                            "type": "number"
                                          },
                                          "rating": {
                                            "type": "number"
                                          },
                                          "stock": {
                                            "type": "integer"
                                          },
                                          "brand": {
                                            "type": "string"
                                          },
                                          "sku": {
                                            "type": "string"
                                          },
                                          "weight": {
                                            "type": "integer"
                                          },
                                          "warrantyInformation": {
                                            "type": "string"
                                          },
                                          "shippingInformation": {
                                            "type": "string"
                                          },
                                          "availabilityStatus": {
                                            "type": "string"
                                          },
                                          "returnPolicy": {
                                            "type": "string"
                                          },
                                          "minimumOrderQuantity": {
                                            "type": "integer"
                                          },
                                          "thumbnail": {
                                            "type": "string",
                                            "format": "uri"
                                          }
                                        },
                                        "required": [
                                          "id"
                                        ]
                                      }
                                    },
                                    "total": {
                                      "type": "integer"
                                    },
                                    "skip": {
                                      "type": "integer"
                                    },
                                    "limit": {
                                      "type": "integer"
                                    }
                                  },
                                  "required": [
                                    "total",
                                    "skip",
                                    "limit"
                                  ]
                                }
                              }
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731073676044736,
                          "name": "RichOak",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "id"
                            },
                            "rhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "restcallResp.body.products.[0].id"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731072814535229,
                          "name": "CleanState",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "total"
                            },
                            "rhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "restcallResp.body.total"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731072863315971,
                          "name": "OldHint",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "skip"
                            },
                            "rhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "restcallResp.body.skip"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731072952772354,
                          "name": "BrightJar",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "limit"
                            },
                            "rhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "restcallResp.body.limit"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        }
                      ],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "contentInputType": "json",
              "ignoreNullFields": false,
              "contentOutputType": "json"
            }`

const SchemaConfig3 = `{
              "id": 372432763917846,
              "name": "req",
              "@type": "transform",
              "debug": false,
              "errors": {
                "id": 372432763917846,
                "name": "ErrorStatement",
                "statements": [
                  {
                    "id": 373202132096397,
                    "name": "STATEMENT 372871499698820",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 372888561974162,
                      "name": "SECTION Statement 372888561974162",
                      "statements": [],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "headers": {},
              "version": 3,
              "transform": {
                "id": 372432763917846,
                "name": "req",
                "statements": [
                  {
                    "id": 1731049804033159,
                    "name": "PotFrame",
                    "@type": "SectionalStatement",
                    "section": {
                      "id": 408449356722679,
                      "name": "SECTION Statement 225627",
                      "statements": [
                        {
                          "id": 1731049803605729,
                          "name": "CropRoad",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "productEndpoint"
                            },
                            "rhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "products"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731049816851192,
                          "name": "PumpBid",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "declare",
                              "dataType": "text",
                              "dataValue": "restcallResp"
                            },
                            "rhs": {
                              "@type": "function",
                              "dataType": "map",
                              "functionName": "apiRestCall",
                              "functionArguments": {
                                "host": "https://dummyjson.com/",
                                "headers": "headers@local",
                                "methodType": "GET",
                                "urlPattern": "productEndpoint@local",
                                "readTimeout": 60,
                                "customHeaders": {},
                                "contentInputType": "json",
                                "connectionTimeout": 60,
                                "contentOutputType": "json",
                                "allowInsecureConnection": true
                              }
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731073676044736,
                          "name": "RichOak",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "id"
                            },
                            "rhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "restcallResp.body.products.[0].id"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731072814535229,
                          "name": "CleanState",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "total"
                            },
                            "rhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "restcallResp.body.total"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731072863315971,
                          "name": "OldHint",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "skip"
                            },
                            "rhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "restcallResp.body.skip"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        },
                        {
                          "id": 1731072952772354,
                          "name": "BrightJar",
                          "@type": "AssignmentStatement",
                          "mandatory": true,
                          "assignment": {
                            "lhs": {
                              "@type": "literal",
                              "dataType": "text",
                              "dataValue": "limit"
                            },
                            "rhs": {
                              "@type": "local",
                              "dataType": "text",
                              "dataValue": "restcallResp.body.limit"
                            },
                            "operator": {
                              "actualValue": "="
                            }
                          }
                        }
                      ],
                      "jsonIgnoreProperty": false
                    },
                    "mandatory": true
                  }
                ],
                "jsonIgnoreProperty": false
              },
              "contentInputType": "json",
              "ignoreNullFields": false,
              "contentOutputType": "json"
            }`
