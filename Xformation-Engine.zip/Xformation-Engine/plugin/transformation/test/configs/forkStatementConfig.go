package configs

const ForkStatementConfig = `{
    "id": 183029378596678,
    "name": "req",
    "@type": "transform",
    "debug": false,
    "headers": {},
    "version": 3,
    "transform": {
      "id": 183029378596678,
      "name": "req",
      "statements": [
        {
          "id": 1728294244320450,
          "name": "MainSection",
          "@type": "SectionalStatement",
          "section": {
            "id": 280691774841578,
            "name": "MainSection",
            "statements": [
              {
                "id": 1727331876204202,
                "name": "ForkStatement",
                "@type": "ForkStatement",
                "fork": {
                  "id": 280691774841570,
                  "name": "ForkStatement",
                  "@type": "SectionalStatement",
                  "statements": [
                    {
                      "id": 1728742149011305,
                      "name": "firstSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 146047136581860,
                        "name": "firstSection",
                        "statements": [
                          {
                            "id": 1728742166277381,
                            "name": "BeamPlate",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "F_Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Pratima"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    },
                    {
                      "id": 1728742130757594,
                      "name": "secondSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 262439789847357,
                        "name": "secondSection",
                        "statements": [
                          {
                            "id": 1728742180346577,
                            "name": "CreamChance",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "L-Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Javed"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    },
                    {
                      "id": 1728742172105469,
                      "name": "thirdSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 695247064687125,
                        "name": "thirdSection",
                        "statements": [
                          {
                            "id": 1728742188015284,
                            "name": "RankStay",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "M_Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "akash"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    },
                    {
                      "id": 1728742149011305,
                      "name": "firstSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 146047136581860,
                        "name": "firstSection",
                        "statements": [
                          {
                            "id": 1728742166277381,
                            "name": "BeamPlate",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "A_Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Pratima"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    },
                    {
                      "id": 1728742130757594,
                      "name": "secondSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 262439789847357,
                        "name": "secondSection",
                        "statements": [
                          {
                            "id": 1728742180346577,
                            "name": "CreamChance",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "B-Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Javed"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    },
                    {
                      "id": 1728742172105469,
                      "name": "thirdSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 695247064687125,
                        "name": "thirdSection",
                        "statements": [
                          {
                            "id": 1728742188015284,
                            "name": "RankStay",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "C_Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "akash"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    },
                    {
                      "id": 1728742149011305,
                      "name": "firstSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 146047136581860,
                        "name": "firstSection",
                        "statements": [
                          {
                            "id": 1728742166277381,
                            "name": "BeamPlate",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "D_Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Pratima"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    },
                    {
                      "id": 1728742130757594,
                      "name": "secondSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 262439789847357,
                        "name": "secondSection",
                        "statements": [
                          {
                            "id": 1728742180346577,
                            "name": "CreamChance",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "E-Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "Javed"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    },
                    {
                      "id": 1728742172105469,
                      "name": "thirdSection",
                      "@type": "SectionalStatement",
                      "section": {
                        "id": 695247064687125,
                        "name": "thirdSection",
                        "statements": [
                          {
                            "id": 1728742188015284,
                            "name": "RankStay",
                            "@type": "AssignmentStatement",
                            "mandatory": true,
                            "assignment": {
                              "lhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "G_Name"
                              },
                              "rhs": {
                                "@type": "literal",
                                "dataType": "text",
                                "dataValue": "akash"
                              },
                              "operator": {
                                "actualValue": "="
                              }
                            }
                          }
                        ]
                      }
                    }
                  ]
                }
              }
            ]
          }
        }
      ]
    }
  }`
