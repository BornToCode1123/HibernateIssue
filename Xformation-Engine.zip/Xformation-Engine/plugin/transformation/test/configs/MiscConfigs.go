package configs

const InbuiltStatements = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_related_parties",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Winston",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "literal",
				  "dataValue" : "No",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "No",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Eldon",
				  "statements" : [ {
					"@type" : "SectionalStatement",
					"section" : {
					  "name" : "Statement 1697108026382390",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Kaleb",
						  "statements" : [ {
							"id" : "346087226682179",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "declare",
								"dataType" : "text",
								"dataValue" : "name"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "javeed"
							  }
							},
							"name" : "Sylvia"
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "name@local",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "javeed",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Haylee",
								  "statements" : [ {
									"@type" : "SectionalStatement",
									"section" : {
									  "name" : "Statement 1697108026382390",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Rupert",
										  "statements" : [ {
											"id" : "348488769805737",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "declare",
												"dataType" : "text",
												"dataValue" : "name"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "Mohammad"
											  }
											},
											"name" : "Ella"
										  }, {
											"id" : "349564424549642",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "name"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataType" : "text",
												"dataValue" : "name"
											  }
											},
											"name" : "Hans"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "349562733842819"
										},
										"id" : "349568712195266"
									  } ],
									  "id" : "349562018395557"
									},
									"id" : 1697107976635457
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "349568480198177"
								},
								"id" : "349565035707265"
							  } ],
							  "id" : "349568894294146"
							},
							"failure" : null,
							"id" : "2-2"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "349561944013901"
						},
						"id" : "349569692583234"
					  } ],
					  "id" : "349564897076454"
					},
					"id" : 1697107976635457
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "349568630683597"
				},
				"id" : "349567008212234"
			  } ],
			  "id" : "349564123364686"
			},
			"failure" : null,
			"id" : "1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "349568951997263"
		},
		"id" : "349569185060308"
	  } ]
	}
  }`

const SimpleExpression = `{
	"version" : 1,
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "transform cibilresponse for Grid",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Marquise",
		  "statements" : [ {
			"id" : "350352152678684",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "city",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "address.[0].city",
				"dataType" : "number"
			  }
			},
			"name" : "Marvin"
		  }, {
			"id" : "351231091208002",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "x.y.z",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 10.000001,
				"dataType" : "number"
			  }
			},
			"name" : "Santiago"
		  }, {
			"id" : "351468906105763",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "b",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 10,
				"dataType" : "number"
			  }
			},
			"name" : "Jude"
		  }, {
			"id" : "351768638873496",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "c",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "+",
				  "variables" : [ {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 100
				  }, {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "x.y.z"
				  }, {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "b"
				  } ]
				},
				"dataType" : "number"
			  }
			},
			"name" : "Janae"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "351762536327251"
		},
		"id" : "351761714887525"
	  } ]
	}
  }`

const NewApplications = `{
	"transform" : {
	  "id" : "transform_config_2",
	  "name" : "transform Consumer Communication Address Details",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Barney",
		  "statements" : [ {
			"id" : "352253591845685",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "totalArrearsAmount",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"filter" : {
				  "id" : "352259972131565",
				  "name" : "filteraccountsbytype",
				  "condition" : {
					"@type" : "logical",
					"type" : "and",
					"rules" : [ {
					  "@type" : "relational",
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "number",
						"dataValue" : "dateClosed"
					  },
					  "operator" : {
						"actualValue" : "=="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : null,
						"dataType" : "number"
					  }
					} ]
				  }
				},
				"@type" : "keyword",
				"dataType" : "number",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"value" : "response.accountSegmentTL",
					"aggregate" : "amountOverdue"
				  },
				  "format" : "sum"
				}
			  }
			},
			"name" : "Walton"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "352258615776495"
		},
		"id" : "352253406175059"
	  } ]
	}
  }`

const DateDiffBetweenCurrent = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Edythe",
		  "statements" : [ {
			"id" : "352757865209071",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "date_Difference",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "dateDiff",
				  "init" : {
					"value" : "endDate",
					"format" : "dd-MM-yyyy"
				  }
				}
			  }
			},
			"name" : "Monroe"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "352751642700104"
		},
		"id" : "352756955111862"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const SplitConfValues = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Rodrick",
		  "statements" : [ {
			"id" : "353239362408866",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "primaryGSTIN",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "primaryGSTIN",
					"splitby" : ","
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Adonis"
		  }, {
			"id" : "353408596111180",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "primaryGSTINNI",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "primaryGSTINNI",
					"splitby" : ","
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Turner"
		  }, {
			"id" : "353593394736860",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "A",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "declare",
				"dataValue" : 1,
				"dataType" : "number"
			  }
			},
			"name" : "Otis"
		  }, {
			"id" : "353753518466798",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "B",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "declare",
				"dataValue" : 1,
				"dataType" : "number"
			  }
			},
			"name" : "Misael"
		  }, {
			"id" : "354979885003634",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "consumerDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Aisha",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Aurelie",
								  "statements" : [ {
									"id" : "354354029869832",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "primaryGSTIN_id",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Anais"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "354357074283722"
								},
								"id" : "354355821430289"
							  } ],
							  "id" : "354352680274088"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 2,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Cathy",
								  "statements" : [ {
									"id" : "354807840179803",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "primaryGSTIN_Value",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Jonas"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "354802418150528"
								},
								"id" : "354803112144982"
							  } ],
							  "id" : "354801759138178"
							},
							"failure" : null,
							"id" : 6
						  }, {
							"id" : "354971457898115",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "A",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "A"
								  }, {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 1
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Ken"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "354971588911646"
						},
						"id" : "354973983895043"
					  } ]
					},
					"value" : "primaryGSTIN@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Hubert"
		  }, {
			"id" : "356116234582371",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "consumerDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Aiden",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "B",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Joshuah",
								  "statements" : [ {
									"id" : "355571773822583",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "primaryGSTINNI-id",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Beryl"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "355576778780649"
								},
								"id" : "355579908116236"
							  } ],
							  "id" : "355577214192289"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "B",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 2,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Arjun",
								  "statements" : [ {
									"id" : "355954066100411",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "primaryGSTINNI_Value",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Zaria"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "355965065835907"
								},
								"id" : "355963683595490"
							  } ],
							  "id" : "355968452996719"
							},
							"failure" : null,
							"id" : 6
						  }, {
							"id" : "356114157704098",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "B",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "B"
								  }, {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 1
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Carson"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "356116385801547"
						},
						"id" : "356114525583810"
					  } ]
					},
					"value" : "primaryGSTINNI@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Missouri"
		  }, {
			"id" : "356277868678052",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "primaryGSTINDetails",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "consumerDetails",
				"dataType" : "text"
			  }
			},
			"name" : "Julien"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "356278555321114"
		},
		"id" : "356276884578430"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const IterateFilterFieldsLocal = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Kaci",
		  "statements" : [ {
			"id" : "356855691567952",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "response",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "response",
				"dataType" : "list"
			  }
			},
			"name" : "Lesley"
		  }, {
			"id" : "357128959784079",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "FilteredData",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"filter" : {
				  "id" : "357121715709534",
				  "name" : "filteraccountsbytype",
				  "condition" : {
					"@type" : "logical",
					"type" : "and",
					"rules" : [ {
					  "@type" : "relational",
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "dateClosed"
					  },
					  "operator" : {
						"actualValue" : "=="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "yes",
						"dataType" : "text"
					  }
					} ]
				  }
				},
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"fields" : {
					  "dateClosed" : "dateClosed"
					},
					"value" : "response@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Elian"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "357123675847592"
		},
		"id" : "357128314922424"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : { }
  }`

const TypesOfStatements = `{
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Alessia",
		  "statements" : [ {
			"id" : "357606910814852",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataType" : "text",
				"dataValue" : "normalStatement"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataType" : "text",
				"dataValue" : "normalStatement"
			  }
			},
			"name" : "Ida"
		  }, {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : " ",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Leonora",
				  "statements" : [ {
					"id" : "357944628650194",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "Section.InsideSection"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "InsideSection"
					  }
					},
					"name" : "Madeline"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "357944708085478"
				},
				"id" : "357949996367163"
			  } ],
			  "id" : "357948609406496"
			},
			"id" : "transform_custodetails"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "literal",
				  "dataValue" : "individualFlag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "individualFlag",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Thaddeus",
				  "statements" : [ {
					"id" : "358329577263066",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "Condition.condition.statement"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "conditionalStatement"
					  }
					},
					"name" : "Cletus"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "358327626669456"
				},
				"id" : "358329663747774"
			  } ],
			  "id" : "358323423397595"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Greg",
				  "statements" : [ {
					"id" : "358629058229409",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "Condition.condition.ElseStatement"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "Else_conditionalStatement"
					  }
					},
					"name" : "Clement"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "358622717443508"
				},
				"id" : "358624843511807"
			  } ],
			  "id" : "358628798280256"
			},
			"id" : 11211
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "358623817164072"
		},
		"id" : "358621603800665"
	  } ]
	}
  }`

const ArrayOfLOcalData = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Thelma",
		  "statements" : [ {
			"id" : "359123952976443",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "primaryGSTIN",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "primaryGSTIN",
					"splitby" : ","
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Jessyca"
		  }, {
			"id" : "359288601315655",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "primaryGSTINNI",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "primaryGSTINNI",
					"splitby" : ","
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "D'angelo"
		  }, {
			"id" : "359453700333891",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "A",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "declare",
				"dataValue" : 1,
				"dataType" : "number"
			  }
			},
			"name" : "Shany"
		  }, {
			"id" : "360681783617096",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "consumerDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Erika",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Jeramy",
								  "statements" : [ {
									"id" : "360191164296270",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "cpIdentityId",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Gerald"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "360191636373076"
								},
								"id" : "360194826010558"
							  } ],
							  "id" : "360195165745299"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 2,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Jordyn",
								  "statements" : [ {
									"id" : "360521218357670",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "cpIdentityData",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Mortimer"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "360522529928810"
								},
								"id" : "360529324789758"
							  } ],
							  "id" : "360525250063657"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"id" : "360689085675601",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "A",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "A"
								  }, {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 1
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Jany"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "360689012361684"
						},
						"id" : "360684255306581"
					  } ]
					},
					"value" : "primaryGSTIN@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Merl"
		  }, {
			"id" : "360869623886576",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "primaryGSTINDetails",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "cpIdentityData",
				"dataType" : "text"
			  }
			},
			"name" : "Ophelia"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "360865537779345"
		},
		"id" : "360861782811364"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const LopalArrayMultipleConditions = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_2",
	  "name" : "transform Consumer Communication Address Details",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Parker",
		  "statements" : [ {
			"id" : "361259292089165",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "totalLiveSanctionedAmount",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Margarete"
		  }, {
			"id" : "361412688697029",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "totalLiveSanctionedAmount",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Danyka"
		  }, {
			"id" : "361576246874638",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "key",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "Corporate credit card/Unsecured business loan/Derivatives/Unsecured Loan (refer Annex. B for validations)",
				"dataType" : "text"
			  }
			},
			"name" : "Eleanore"
		  }, {
			"id" : "361769957170199",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "UnSecured",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "key@local",
					"splitby" : "/"
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Kelli"
		  }, {
			"id" : "361896357590367",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "dummySplittedArray",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "UnSecured",
				"dataType" : "text"
			  }
			},
			"name" : "Earlene"
		  }, {
			"id" : "362074317263254",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "todayDate",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "unixTime"
				}
			  }
			},
			"name" : "Kevon"
		  }, {
			"id" : "362734057595477",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "dummyArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Francis",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "creditLender",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "Not Disclosed",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "UnSecured",
								  "dataType" : "list"
								},
								"operator" : {
								  "actualValue" : "contains"
								},
								"rhs" : {
								  "@type" : "variable",
								  "dataValue" : "enquiryPurpose",
								  "dataType" : "list"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataValue" : "date",
								  "dataType" : "number",
								  "keywordArguments" : {
									"format" : "unixTime",
									"init" : {
									  "value" : "enquiryDt",
									  "format" : "dd-MMM-yyyy"
									}
								  }
								},
								"operator" : {
								  "actualValue" : ">="
								},
								"rhs" : {
								  "@type" : "local",
								  "dataValue" : "todayDate",
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Geoffrey",
								  "statements" : [ {
									"id" : "362737058806407",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "totalLiveSanctionedAmount",
										"dataType" : "number"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "expression",
										"structure" : {
										  "@type" : "arithmetic",
										  "dataType" : "+",
										  "variables" : [ {
											"@type" : "local",
											"dataType" : "number",
											"dataValue" : "totalLiveSanctionedAmount"
										  }, {
											"@type" : "variable",
											"dataType" : "number",
											"dataValue" : "highCreditSanctionedAmount"
										  } ]
										},
										"dataType" : "number"
									  }
									},
									"name" : "Esperanza"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "362736573714855"
								},
								"id" : "362738359960857"
							  } ],
							  "id" : "362734490780684"
							},
							"failure" : null,
							"id" : 1
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "362736149426732"
						},
						"id" : "362738216492804"
					  } ]
					},
					"value" : "enquiryDetailsInLast24Month"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Oren"
		  }, {
			"id" : "362902556523952",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "totalLiveSanctionedAmount",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "totalLiveSanctionedAmount",
				"dataType" : "number"
			  }
			},
			"name" : "Muriel"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "362909748578697"
		},
		"id" : "362906247117616"
	  } ]
	}
  }`

const TestLoanDetailsHugeJson = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "flatJson",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Burdette",
		  "statements" : [ {
			"id" : "363294516223276",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "keyword",
				"dataValue" : "none",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "map"
			  }
			},
			"name" : "Meta"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "363291681491177"
		},
		"id" : "363298355808395"
	  } ]
	}
  }`

const MultipleCalls = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_related_parties",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Yasmeen",
		  "statements" : [ {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : "Statement 1697108026382390",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Jodie",
				  "statements" : [ {
					"id" : "363929484319592",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "declare",
						"dataType" : "text",
						"dataValue" : "name"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "javeed"
					  }
					},
					"name" : "Akeem"
				  }, {
					"id" : "364053563205910",
					"@type" : "AssignmentStatement",
					"mandatory" : false,
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "name"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "local",
						"dataType" : "text",
						"dataValue" : "name"
					  }
					},
					"name" : "Dameon"
				  }, {
					"id" : "364243213903657",
					"@type" : "AssignmentStatement",
					"mandatory" : false,
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "fName"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "local",
						"dataType" : "text",
						"dataValue" : "name"
					  }
					},
					"name" : "Olen"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "364241777605119"
				},
				"id" : "364241041093658"
			  } ],
			  "id" : "364241913824713"
			},
			"id" : 1697107976635457
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "364249975066639"
		},
		"id" : "364242618404424"
	  } ]
	}
  }`

const NilComparison = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Kade",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "typeOfBorrower",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "text",
				  "keywordArguments" : {
					"format" : "getNullValue"
				  }
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Howard",
				  "statements" : [ {
					"id" : "364804732031073",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "condition",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "true",
						"dataType" : "text"
					  }
					},
					"name" : "Dejuan"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "364806272421372"
				},
				"id" : "364809183478282"
			  } ],
			  "id" : "364801292415499"
			},
			"failure" : null,
			"id" : 1
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "364809893353197"
		},
		"id" : "364805846990377"
	  } ]
	}
  }`

const ExceptionHandling1 = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Jeramie",
		  "statements" : [ {
			"id" : "365222725552472",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Customer.Details",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "details",
				"dataType" : "text"
			  }
			},
			"name" : "Erin"
		  }, {
			"id" : "365387778636997",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Customer.mob",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "mobile",
				"dataType" : "text"
			  }
			},
			"name" : "Winona"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "365389187448320"
		},
		"id" : "365383337711069"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : {
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Edwina",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "statementId"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataType" : "text",
				  "dataValue" : "365222725552472"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Eloy",
				  "statements" : [ {
					"id" : "365852268422133",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "Customer.Details",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "detailes are not available from the payload",
						"dataType" : "text"
					  }
					},
					"name" : "Norval"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "365854961977057"
				},
				"id" : "365858716225526"
			  } ],
			  "id" : "365854297139058"
			},
			"failure" : null,
			"id" : "exception1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "365855932360181"
		},
		"id" : "365859437379502"
	  } ]
	}
  }`

const JsonUnFlatResponseArray = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "flatJson",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Elda",
		  "statements" : [ {
			"id" : "366375131103719",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "estampDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "array",
				"dataType" : "list"
			  }
			},
			"name" : "Werner"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "366377186430477"
		},
		"id" : "366375635887823"
	  } ]
	}
  }`

const SelectedKeys = ` {
	"version": "1",
	"@type": "transform",
	"transform": {
		"id": "transform_config_1",
		"name": "Filter the Date Repsonse",
		"statements": [
			{
				"@type": "SectionalStatement",
				"section": {
					"jsonIgnoreProperty": false,
					"name": "KVyhs",
					"statements": [
						{
							"@type": "SectionalStatement",
							"name": "qHy9X",
							"section": {
								"name": null,
								"statements": [
									{
										"@type": "SectionalStatement",
										"section": {
											"jsonIgnoreProperty": false,
											"name": "kBcQb",
											"statements": [
												{
													"id": "555236015402678",
													"@type": "AssignmentStatement",
													"assignment": {
														"lhs": {
															"@type": "literal",
															"dataValue": "requiredArray",
															"dataType": "list"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "keyword",
															"dataType": "list",
															"dataValue": "list",
															"keywordArguments": {
																"init": {
																	"transform": {
																		"id": "transform_config_1",
																		"name": "collect",
																		"statements": [
																			{
																				"@type": "SectionalStatement",
																				"section": {
																					"jsonIgnoreProperty": false,
																					"name": "yRxwf",
																					"statements": [
																						{
																							"@type": "SectionalStatement",
																							"name": "6RyTW",
																							"section": {
																								"name": null,
																								"statements": [
																									{
																										"@type": "SectionalStatement",
																										"section": {
																											"jsonIgnoreProperty": false,
																											"name": "kMsio",
																											"statements": [
																												{
																													"id": "555204983630623",
																													"@type": "AssignmentStatement",
																													"assignment": {
																														"lhs": {
																															"@type": "declare",
																															"dataType": "text",
																															"dataValue": "relatedPartiesObject"
																														},
																														"operator": {
																															"actualValue": "="
																														},
																														"rhs": {
																															"@type": "keyword",
																															"dataType": "text",
																															"dataValue": "value"
																														}
																													},
																													"name": "rxFgE"
																												},
																												{
																													"id": "555235432835110",
																													"@type": "AssignmentStatement",
																													"assignment": {
																														"lhs": {
																															"@type": "declare",
																															"dataType": "text",
																															"dataValue": "relatedPartiesObjectKeySet"
																														},
																														"operator": {
																															"actualValue": "="
																														},
																														"rhs": {
																															"@type": "keyword",
																															"dataType": "text",
																															"dataValue": "map",
																															"keywordArguments": {
																																"format": "getKeySet",
																																"init": {
																																	"value": "relatedPartiesObject@local"
																																}
																															}
																														}
																													},
																													"name": "AVJKv"
																												},
																												{
																													"id": "555239890339375",
																													"name": "Statement 1697201799113696",
																													"@type": "AssignmentStatement",
																													"mandatory": true,
																													"assignment": {
																														"lhs": {
																															"@type": "declare",
																															"dataType": "list",
																															"dataValue": "relatedPartieslist"
																														},
																														"rhs": {
																															"@type": "keyword",
																															"dataType": "list",
																															"dataValue": "list",
																															"keywordArguments": {
																																"init": {
																																	"transform": {
																																		"id": "6744641075848",
																																		"name": "Iterate 724645",
																																		"statements": [
																																			{
																																				"@type": "SectionalStatement",
																																				"section": {
																																					"jsonIgnoreProperty": false,
																																					"name": "QlgJZ",
																																					"statements": [
																																						{
																																							"id": "555239115326697",
																																							"@type": "AssignmentStatement",
																																							"assignment": {
																																								"lhs": {
																																									"@type": "declare",
																																									"dataType": "text",
																																									"dataValue": "relatedPartiesKey"
																																								},
																																								"operator": {
																																									"actualValue": "="
																																								},
																																								"rhs": {
																																									"@type": "keyword",
																																									"dataType": "text",
																																									"dataValue": "value"
																																								}
																																							},
																																							"name": "wUvXN"
																																						},
																																						{
																																							"condition": {
																																								"@type": "logical",
																																								"type": "and",
																																								"rules": [
																																									{
																																										"@type": "relational",
																																										"lhs": {
																																											"@type": "literal",
																																											"dataValue": true,
																																											"dataType": "text"
																																										},
																																										"operator": {
																																											"actualValue": "=="
																																										},
																																										"rhs": {
																																											"@type": "keyword",
																																											"dataValue": "map",
																																											"dataType": "text",
																																											"keywordArguments": {
																																												"format": "getValueByKey",
																																												"init": {
																																													"key": "relatedPartiesKey@local",
																																													"value": "relatedPartiesObject@local"
																																												}
																																											}
																																										}
																																									},
																																									{
																																										"@type": "logical",
																																										"type": "or",
																																										"rules": [
																																											{
																																												"@type": "relational",
																																												"lhs": {
																																													"@type": "variable",
																																													"dataType": "text",
																																													"dataValue": "relatedPartiesKey@local"
																																												},
																																												"operator": {
																																													"actualValue": "=="
																																												},
																																												"rhs": {
																																													"@type": "literal",
																																													"dataValue": "director",
																																													"dataType": "text"
																																												}
																																											},
																																											{
																																												"@type": "relational",
																																												"lhs": {
																																													"@type": "variable",
																																													"dataType": "text",
																																													"dataValue": "relatedPartiesKey@local"
																																												},
																																												"operator": {
																																													"actualValue": "=="
																																												},
																																												"rhs": {
																																													"@type": "literal",
																																													"dataValue": "partner",
																																													"dataType": "text"
																																												}
																																											},
																																											{
																																												"@type": "relational",
																																												"lhs": {
																																													"@type": "variable",
																																													"dataType": "text",
																																													"dataValue": "relatedPartiesKey@local"
																																												},
																																												"operator": {
																																													"actualValue": "=="
																																												},
																																												"rhs": {
																																													"@type": "literal",
																																													"dataValue": "Proprietor",
																																													"dataType": "text"
																																												}
																																											},
																																											{
																																												"@type": "relational",
																																												"lhs": {
																																													"@type": "variable",
																																													"dataType": "text",
																																													"dataValue": "relatedPartiesKey@local"
																																												},
																																												"operator": {
																																													"actualValue": "=="
																																												},
																																												"rhs": {
																																													"@type": "literal",
																																													"dataValue": "karta",
																																													"dataType": "text"
																																												}
																																											},
																																											{
																																												"@type": "relational",
																																												"lhs": {
																																													"@type": "variable",
																																													"dataType": "text",
																																													"dataValue": "relatedPartiesKey@local"
																																												},
																																												"operator": {
																																													"actualValue": "=="
																																												},
																																												"rhs": {
																																													"@type": "literal",
																																													"dataValue": "pOAHolder",
																																													"dataType": "text"
																																												}
																																											},
																																											{
																																												"@type": "relational",
																																												"lhs": {
																																													"@type": "variable",
																																													"dataType": "text",
																																													"dataValue": "relatedPartiesKey@local"
																																												},
																																												"operator": {
																																													"actualValue": "=="
																																												},
																																												"rhs": {
																																													"@type": "literal",
																																													"dataValue": "coParcener",
																																													"dataType": "text"
																																												}
																																											},
																																											{
																																												"@type": "relational",
																																												"lhs": {
																																													"@type": "variable",
																																													"dataType": "text",
																																													"dataValue": "relatedPartiesKey@local"
																																												},
																																												"operator": {
																																													"actualValue": "=="
																																												},
																																												"rhs": {
																																													"@type": "literal",
																																													"dataValue": "shareHolder",
																																													"dataType": "text"
																																												}
																																											},
																																											{
																																												"@type": "relational",
																																												"lhs": {
																																													"@type": "variable",
																																													"dataType": "text",
																																													"dataValue": "relatedPartiesKey@local"
																																												},
																																												"operator": {
																																													"actualValue": "=="
																																												},
																																												"rhs": {
																																													"@type": "literal",
																																													"dataValue": "authorisedSignatory",
																																													"dataType": "text"
																																												}
																																											}
																																										]
																																									}
																																								]
																																							},
																																							"@type": "ConditionalStatement",
																																							"success": {
																																								"name": "transformation",
																																								"statements": [
																																									{
																																										"@type": "SectionalStatement",
																																										"section": {
																																											"jsonIgnoreProperty": false,
																																											"name": "omIbh",
																																											"statements": [
																																												{
																																													"@type": "SectionalStatement",
																																													"name": "NnM0I",
																																													"section": {
																																														"name": null,
																																														"statements": [
																																															{
																																																"@type": "SectionalStatement",
																																																"section": {
																																																	"jsonIgnoreProperty": false,
																																																	"name": "YNpSj",
																																																	"statements": [
																																																		{
																																																			"id": "555232661365311",
																																																			"name": "Statement 1697536215578009",
																																																			"@type": "AssignmentStatement",
																																																			"mandatory": true,
																																																			"assignment": {
																																																				"lhs": {
																																																					"@type": "declare",
																																																					"dataType": "list",
																																																					"dataValue": "requiredArrayInside"
																																																				},
																																																				"rhs": {
																																																					"@type": "keyword",
																																																					"dataType": "list",
																																																					"dataValue": "list",
																																																					"keywordArguments": {
																																																						"init": {
																																																							"values": [
																																																								"relatedPartiesKey@local"
																																																							]
																																																						},
																																																						"format": "push"
																																																					}
																																																				},
																																																				"operator": {
																																																					"actualValue": "="
																																																				}
																																																			}
																																																		}
																																																	],
																																																	"jsonIgnoreAliasValue": null,
																																																	"id": "555239625363896"
																																																},
																																																"id": "555236163313500"
																																															}
																																														],
																																														"id": "555236966448263"
																																													},
																																													"id": "555234491870102"
																																												}
																																											],
																																											"jsonIgnoreAliasValue": null,
																																											"id": "555231982607805"
																																										},
																																										"id": "555238630372349"
																																									}
																																								],
																																								"id": "555232838657546"
																																							},
																																							"failure": {},
																																							"id": "555236174749167"
																																						}
																																					],
																																					"jsonIgnoreAliasValue": null,
																																					"id": "555238258442370"
																																				},
																																				"id": "555236811749765"
																																			}
																																		]
																																	},
																																	"value": "relatedPartiesObjectKeySet@local"
																																},
																																"format": "iterate"
																															}
																														},
																														"operator": {
																															"actualValue": "="
																														}
																													}
																												},
																												{
																													"id": "555238355521189",
																													"@type": "AssignmentStatement",
																													"assignment": {
																														"lhs": {
																															"@type": "literal",
																															"dataType": "text",
																															"dataValue": "requiredArrayInside"
																														},
																														"operator": {
																															"actualValue": "="
																														},
																														"rhs": {
																															"@type": "variable",
																															"dataType": "text",
																															"dataValue": "requiredArrayInside@local"
																														}
																													},
																													"name": "GPOui"
																												}
																											],
																											"jsonIgnoreAliasValue": null,
																											"id": "555233292992248"
																										},
																										"id": "555233173205286"
																									}
																								],
																								"id": "555233398606747"
																							},
																							"id": "555173340267002"
																						}
																					],
																					"jsonIgnoreAliasValue": null,
																					"id": "555231476320406"
																				},
																				"id": "555233273027320"
																			}
																		]
																	},
																	"value": "relatedParties"
																},
																"format": "iterate"
															}
														}
													},
													"name": "Cassandra"
												}
											],
											"jsonIgnoreAliasValue": null,
											"id": "555234677136910"
										},
										"id": "555234752679688"
									}
								],
								"id": "555238077550030"
							},
							"id": "555163721957422"
						}
					],
					"jsonIgnoreAliasValue": null,
					"id": "555235927211379"
				},
				"id": "555231463867455"
			}
		]
	},
	"delete": {},
	"extract": {},
	"id": "555232308320677"
  }`

const MultiExpressions = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Mckenna",
		  "statements" : [ {
			"id" : "367766191015988",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Addition",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "+",
				  "variables" : [ {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 100
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 200
				  }, {
					"@type" : "expression",
					"structure" : {
					  "@type" : "arithmetic",
					  "dataType" : "*",
					  "variables" : [ {
						"@type" : "literal",
						"dataType" : "number",
						"dataValue" : 25
					  }, {
						"@type" : "literal",
						"dataType" : "number",
						"dataValue" : 4
					  } ]
					},
					"dataType" : "number"
				  }, {
					"@type" : "expression",
					"structure" : {
					  "@type" : "arithmetic",
					  "dataType" : "-",
					  "variables" : [ {
						"@type" : "literal",
						"dataType" : "number",
						"dataValue" : 1000
					  }, {
						"@type" : "expression",
						"structure" : {
						  "@type" : "arithmetic",
						  "dataType" : "/",
						  "variables" : [ {
							"@type" : "literal",
							"dataType" : "number",
							"dataValue" : 1000
						  }, {
							"@type" : "expression",
							"structure" : {
							  "@type" : "arithmetic",
							  "dataType" : "%",
							  "variables" : [ {
								"@type" : "literal",
								"dataType" : "number",
								"dataValue" : 9
							  }, {
								"@type" : "literal",
								"dataType" : "number",
								"dataValue" : 5
							  } ]
							},
							"dataType" : "number"
						  } ]
						},
						"dataType" : "number"
					  } ]
					},
					"dataType" : "number"
				  } ]
				},
				"dataType" : "number"
			  }
			},
			"name" : "Don"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "367765660952769"
		},
		"id" : "367768004968272"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const HeadersConfig = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customerResponse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Hugh",
		  "statements" : [ {
			"id" : "368167640472515",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "UserId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "UserId@local",
				"dataType" : "text"
			  }
			},
			"name" : "Leann"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "368166671165841"
		},
		"id" : "368161746125322"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const KeywordDateInDaysInLOcal = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customerResponse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Matilde",
		  "statements" : [ {
			"id" : "369117984915406",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "professionalExperience",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "text",
				"dataType" : "text",
				"keywordArguments" : {
				  "format" : "toNumber",
				  "init" : {
					"value" : "professionalExperienceinYears"
				  }
				}
			  }
			},
			"name" : "Dahlia"
		  }, {
			"id" : "369268353059919",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "blDetails.jblCp.professionalExperience",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "number",
				"keywordArguments" : {
				  "format" : "inMonths",
				  "init" : {
					"value" : "professionalExperience@local",
					"format" : "inYears"
				  }
				}
			  }
			},
			"name" : "Lorna"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "369268516344757"
		},
		"id" : "369261700833859"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const NewVersion = `{
	"id": "180685942153368",
	"name": "testingConfiguration",
	"@type": "transform",
	"debug": false,
	"version": 2,
	"transform": {
		"id": 2542379457800,
		"name": "testingConfiguration",
		"statements": [
			{
				"@type": "SectionalStatement",
				"section": {
					"jsonIgnoreProperty": false,
					"name": "cefZD",
					"statements": [
						{
							"id": "180617949097587",
							"@type": "AssignmentStatement",
							"assignment": {
								"@type": "SimpleAssignmentStatement",
								"lhs": {
									"@type": "keyword",
									"dataValue": "none",
									"dataType": "map"
								},
								"operator": {
									"actualValue": "="
								},
								"rhs": {
									"@type": "keyword",
									"dataValue": "value",
									"dataType": "map"
								}
							},
							"name": "PuPDm"
						},
						{
							"id": "180678597074268",
							"@type": "AssignmentStatement",
							"assignment": {
								"lhs": {
									"@type": "declare",
									"dataValue": "abc",
									"dataType": "list"
								},
								"operator": {
									"actualValue": "="
								},
								"rhs": {
									"@type": "keyword",
									"dataType": "list",
									"dataValue": "list",
									"keywordArguments": {
										"init": {
											"transform": {
												"id": "transform_config_2",
												"name": "transform Consumer Communication Address Details",
												"statements": [
													{
														"@type": "SectionalStatement",
														"section": {
															"jsonIgnoreProperty": false,
															"name": "EecZQ",
															"statements": [
																{
																	"id": "180671959601255",
																	"@type": "AssignmentStatement",
																	"assignment": {
																		"@type": "SimpleAssignmentStatement",
																		"lhs": {
																			"@type": "declare",
																			"dataValue": "localObj",
																			"dataType": "map"
																		},
																		"operator": {
																			"actualValue": "="
																		},
																		"rhs": {
																			"@type": "keyword",
																			"dataValue": "value",
																			"dataType": "map"
																		}
																	},
																	"name": "yfjJm"
																}
															],
															"jsonIgnoreAliasValue": null,
															"id": "180677774876474"
														},
														"id": "180676917006423"
													}
												]
											},
											"value": "businessOwnerInformation"
										},
										"format": "iterate"
									}
								}
							},
							"name": "utzmD"
						},
						{
							"id": "180674843279186",
							"@type": "AssignmentStatement",
							"assignment": {
								"@type": "SimpleAssignmentStatement",
								"lhs": {
									"@type": "literal",
									"dataValue": "businessOwnerInformation",
									"dataType": "text"
								},
								"operator": {
									"actualValue": "="
								},
								"rhs": {
									"@type": "keyword",
									"dataType": "text",
									"dataValue": "text",
									"keywordArguments": {
										"format": "getNullValue"
									}
								}
							},
							"name": "eAaJj"
						},
						{
							"id": "180681415773098",
							"@type": "AssignmentStatement",
							"assignment": {
								"lhs": {
									"@type": "literal",
									"dataValue": "businessOwnerInformation",
									"dataType": "list"
								},
								"operator": {
									"actualValue": "="
								},
								"rhs": {
									"@type": "keyword",
									"dataType": "list",
									"dataValue": "list",
									"keywordArguments": {
										"init": {
											"transform": {
												"id": "transform_config_2",
												"name": "transform Consumer Communication Address Details",
												"statements": [
													{
														"@type": "SectionalStatement",
														"section": {
															"jsonIgnoreProperty": false,
															"name": "abFyM",
															"statements": [
																{
																	"id": "180676149011315",
																	"@type": "AssignmentStatement",
																	"assignment": {
																		"@type": "SimpleAssignmentStatement",
																		"lhs": {
																			"@type": "declare",
																			"dataValue": "localObj",
																			"dataType": "map"
																		},
																		"operator": {
																			"actualValue": "="
																		},
																		"rhs": {
																			"@type": "keyword",
																			"dataValue": "value",
																			"dataType": "map"
																		}
																	},
																	"name": "tqMAP"
																}
															],
															"jsonIgnoreAliasValue": null,
															"id": "180682063550270"
														},
														"id": "180683606687323"
													}
												]
											},
											"value": "businessOwnerInformation"
										},
										"format": "iterate"
									}
								}
							},
							"name": "fOZqn"
						}
					],
					"jsonIgnoreAliasValue": "",
					"id": "180685830945940"
				},
				"id": "180683921219681"
			}
		],
		"jsonIgnoreProperty": false,
		"jsonIgnoreAliasValue": ""
	},
	"contentInputType": "json",
	"ignoreNullFields": false,
	"contentOutputType": "json"
  }`

const ArrayContans = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Daphney",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "StringArray",
				  "dataType" : "list"
				},
				"operator" : {
				  "actualValue" : "contains"
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "abcd",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Barton",
				  "statements" : [ {
					"id" : "370031522225314",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "StringContains",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : true,
						"dataType" : "text"
					  }
					},
					"name" : "Raul"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "370038699737615"
				},
				"id" : "370037968307544"
			  } ],
			  "id" : "370032695643438"
			},
			"failure" : null,
			"id" : 1
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "StringArray",
				  "dataType" : "list"
				},
				"operator" : {
				  "actualValue" : "nContains"
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "abcde",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Myra",
				  "statements" : [ {
					"id" : "370376381114803",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "Strin_Not_Contains",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : true,
						"dataType" : "text"
					  }
					},
					"name" : "Matilde"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "370379675305034"
				},
				"id" : "370378309230219"
			  } ],
			  "id" : "370371540445195"
			},
			"failure" : null,
			"id" : 2
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "IntegerArray",
				  "dataType" : "list"
				},
				"operator" : {
				  "actualValue" : "contains"
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : 1,
				  "dataType" : "number"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Maiya",
				  "statements" : [ {
					"id" : "370727230115655",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "NumberContains",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : true,
						"dataType" : "text"
					  }
					},
					"name" : "Laney"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "370728363193662"
				},
				"id" : "370725302917770"
			  } ],
			  "id" : "370727724606534"
			},
			"failure" : null,
			"id" : 3
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "IntegerArray",
				  "dataType" : "list"
				},
				"operator" : {
				  "actualValue" : "nContains"
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : 10,
				  "dataType" : "number"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Nathen",
				  "statements" : [ {
					"id" : "371033081980485",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "Number_Not_Contains",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : true,
						"dataType" : "text"
					  }
					},
					"name" : "Cloyd"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "371044900962706"
				},
				"id" : "371045769272833"
			  } ],
			  "id" : "371043990382878"
			},
			"failure" : null,
			"id" : 4
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "371044579342990"
		},
		"id" : "371046705171783"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const TestFlatJson = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":1697108034962777,"name":"Statement 1697107973271908","@type":"AssignmentStatement","mandatory":true,"assignment":{"lhs":{"@type":"keyword","dataType":"map","dataValue":"none"},"rhs":{"@type":"keyword","dataType":"map","dataValue":"value"},"operator":{"actualValue":"="}}}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":""},"contentInputType":"flatJson","ignoreNullFields":false,"contentOutputType":"json"}`

const JsonFlatten = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "flatJson",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Kallie",
		  "statements" : [ {
			"id" : "371444728590961",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "keyword",
				"dataValue" : "none",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "map"
			  }
			},
			"name" : "Lukas"
		  }, {
			"id" : "371731687128669",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "section0.signatories[1]",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "primitive",
				"dataType" : "text"
			  }
			},
			"name" : "Grady"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "371733305004814"
		},
		"id" : "371736426045068"
	  } ]
	}
  }`

const OverrideMap = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":1697107976635457,"name":"Statement 1697108026382390","@type":"SectionalStatement","section":{"id":38462209397286,"name":"SECTION Statement 755783","statements":[{"id":1697108034962777,"name":"Statement 1697107973271908","@type":"AssignmentStatement","mandatory":true,"assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"employe.name"},"rhs":{"@type":"literal","dataType":"text","dataValue":"javeed"},"operator":{"actualValue":"="}}},{"id":1697108034962777,"name":"Statement 1697107973271908","@type":"AssignmentStatement","mandatory":true,"assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"employe"},"rhs":{"@type":"literal","dataType":"text","dataValue":null},"operator":{"actualValue":"="}}}]},"mandatory":true}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":""},"contentInputType":"json","ignoreNullFields":false,"contentOutputType":"json"}`

const ValidateKeys = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Regan",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "outsideInstitution.workingCapital.NONSTDVec.greaterthan180DPD.value",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "text",
				  "keywordArguments" : {
					"format" : "getNullValue"
				  }
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Finn",
				  "statements" : [ {
					"id" : "372592077365147",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "assetClassification"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "greaterthan180DPD"
					  }
					},
					"name" : "Keven"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "372593486549912"
				},
				"id" : "372592742223290"
			  } ],
			  "id" : "372591420810001"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Tiana",
				  "statements" : [ {
					"condition" : {
					  "@type" : "logical",
					  "type" : "and",
					  "rules" : [ {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataValue" : "outsideInstitution.workingCapital.NONSTDVec.DPD91to180.value",
						  "dataType" : "text"
						},
						"operator" : {
						  "actualValue" : "!="
						},
						"rhs" : {
						  "@type" : "keyword",
						  "dataType" : "text",
						  "dataValue" : "text",
						  "keywordArguments" : {
							"format" : "getNullValue"
						  }
						}
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Mervin",
						  "statements" : [ {
							"id" : "373269029796208",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "assetClassification"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "DPD91to180"
							  }
							},
							"name" : "Francesca"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "373269240816441"
						},
						"id" : "373269450388129"
					  } ],
					  "id" : "373266776691719"
					},
					"failure" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Obie",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "outsideInstitution.workingCapital.STDVec.DPD61to90.value",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Jeremy",
								  "statements" : [ {
									"id" : "373789752348441",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataType" : "text",
										"dataValue" : "assetClassification"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataType" : "text",
										"dataValue" : "DPD61to90"
									  }
									},
									"name" : "Clinton"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "373787786957495"
								},
								"id" : "373786531278233"
							  } ],
							  "id" : "373785824676995"
							},
							"failure" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Aniyah",
								  "statements" : [ {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "outsideInstitution.workingCapital.STDVec.DPD31to60.value",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Alvena",
										  "statements" : [ {
											"id" : "374335699622154",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "assetClassification"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "DPD31to60"
											  }
											},
											"name" : "Kaylah"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "374332163400343"
										},
										"id" : "374338474568605"
									  } ],
									  "id" : "374332569624713"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Charlene",
										  "statements" : [ {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "outsideInstitution.workingCapital.STDVec.DPD1to30.value",
												  "dataType" : "text"
												},
												"operator" : {
												  "actualValue" : "!="
												},
												"rhs" : {
												  "@type" : "keyword",
												  "dataType" : "text",
												  "dataValue" : "text",
												  "keywordArguments" : {
													"format" : "getNullValue"
												  }
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Maddison",
												  "statements" : [ {
													"id" : "374843572376219",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "assetClassification"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "DPD1to30"
													  }
													},
													"name" : "Donny"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "374848181305061"
												},
												"id" : "374843198312435"
											  } ],
											  "id" : "374841455543706"
											},
											"failure" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Leon",
												  "statements" : [ {
													"condition" : {
													  "@type" : "logical",
													  "type" : "and",
													  "rules" : [ {
														"@type" : "relational",
														"lhs" : {
														  "@type" : "variable",
														  "dataValue" : "outsideInstitution.workingCapital.STDVec.DPD0.value",
														  "dataType" : "text"
														},
														"operator" : {
														  "actualValue" : "!="
														},
														"rhs" : {
														  "@type" : "keyword",
														  "dataType" : "text",
														  "dataValue" : "text",
														  "keywordArguments" : {
															"format" : "getNullValue"
														  }
														}
													  } ]
													},
													"@type" : "ConditionalStatement",
													"success" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Delilah",
														  "statements" : [ {
															"id" : "375301703564747",
															"@type" : "AssignmentStatement",
															"assignment" : {
															  "lhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "assetClassification"
															  },
															  "operator" : {
																"actualValue" : "="
															  },
															  "rhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "DPD0"
															  }
															},
															"name" : "Lilly"
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "375307832877547"
														},
														"id" : "375302911566945"
													  } ],
													  "id" : "375308204329162"
													},
													"failure" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Tina",
														  "statements" : [ {
															"id" : "375956007509084",
															"@type" : "AssignmentStatement",
															"assignment" : {
															  "lhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "assetClassification"
															  },
															  "operator" : {
																"actualValue" : "="
															  },
															  "rhs" : {
																"@type" : "keyword",
																"dataType" : "text",
																"dataValue" : "text",
																"keywordArguments" : {
																  "format" : "getNullValue"
																}
															  }
															},
															"name" : "Kathryne"
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "375957267418842"
														},
														"id" : "375958271902032"
													  } ],
													  "id" : "375951689842547"
													},
													"id" : 1
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "375953133301998"
												},
												"id" : "375958971981542"
											  } ],
											  "id" : "375957787080283"
											},
											"id" : 1
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "375956153930646"
										},
										"id" : "375954979458969"
									  } ],
									  "id" : "375959274109005"
									},
									"id" : 1
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "375957878870822"
								},
								"id" : "375959182198289"
							  } ],
							  "id" : "375954396282219"
							},
							"id" : 1
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "375955168743584"
						},
						"id" : "375955237312616"
					  } ],
					  "id" : "375955204817055"
					},
					"id" : 1
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "375958790583224"
				},
				"id" : "375954171294593"
			  } ],
			  "id" : "375951160524228"
			},
			"id" : 1
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "375957756885950"
		},
		"id" : "375956697792311"
	  } ]
	}
  }`

const IterateFilterFields = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Addie",
		  "statements" : [ {
			"id" : "377007000743053",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "FilteredData",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"filter" : {
				  "id" : "377004176085283",
				  "name" : "filteraccountsbytype",
				  "condition" : {
					"@type" : "logical",
					"type" : "and",
					"rules" : [ {
					  "@type" : "relational",
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "dateClosed"
					  },
					  "operator" : {
						"actualValue" : "=="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "yes",
						"dataType" : "text"
					  }
					} ]
				  }
				},
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"fields" : {
					  "dateClosed" : "dateClosed"
					},
					"value" : "response"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Wiley"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "377005770173586"
		},
		"id" : "377007417142041"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : { }
  }`

const DateKeywordDefaultValue = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customerResponse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Marisol",
		  "statements" : [ {
			"id" : "377744213459103",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "todayDate",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date"
			  }
			},
			"name" : "Jaeden"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "377744276503033"
		},
		"id" : "377743610972388"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const TestLoanDetailsHugeJsonUNFlattening = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "flatJson",
	"contentOutputType" : "json",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Ursula",
		  "statements" : [ {
			"id" : "378218566546027",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "keyword",
				"dataValue" : "none",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "map"
			  }
			},
			"name" : "Elmo"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "378213429678719"
		},
		"id" : "378211111784405"
	  } ]
	}
  }`

const CIBILCommSectionalStatement = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config",
	  "name" : "CIBIL Commercial",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Felicita",
		  "statements" : [ {
			"id" : "378824923532936",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "bureauType",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "TransUnion",
				"dataType" : "text"
			  }
			},
			"name" : "Fredy"
		  }, {
			"id" : "379023693397976",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "bureauRankOrScore",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "base.responseReport.productSec.rankSec.rankVec.[0].rankValue",
				"dataType" : "text"
			  }
			},
			"name" : "Owen"
		  }, {
			"id" : "379168244014744",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "dateofReport",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "yyyy-MM-dd",
				  "init" : {
					"value" : "base.responseReport.reportHeaderRec.reportOrderDate",
					"format" : "dd-MMM-yyyy"
				  }
				}
			  }
			},
			"name" : "Nella"
		  }, {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : "Statement 1697108026382390",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Karina",
				  "statements" : [ {
					"id" : "381846595116048",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "fundBasedLimitborrower",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Lorna",
								  "statements" : [ {
									"id" : "379746414164028",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[0].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.cfType",
										"dataType" : "text"
									  }
									},
									"name" : "Flossie"
								  }, {
									"id" : "379892404650373",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[0].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.sanctionedDt",
										"dataType" : "text"
									  }
									},
									"name" : "Letitia"
								  }, {
									"id" : "380052530693200",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionAmountInRs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[0].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.sanctionedAmt",
										"dataType" : "text"
									  }
									},
									"name" : "Alexis"
								  }, {
									"id" : "380239977442298",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "outstandingAmountinrs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[0].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.outstandingBalance",
										"dataType" : "text"
									  }
									},
									"name" : "Jackie"
								  }, {
									"id" : "380386686781884",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "loanExpiryOrMaturityDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[0].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.loanExpiryDt",
										"dataType" : "text"
									  }
									},
									"name" : "Kennedy"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "loanExpiryOrMaturityDate@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Vladimir",
										  "statements" : [ {
											"id" : "380662962389968",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "loanExpiryOrMaturityDate"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Bernadine"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "380664188785022"
										},
										"id" : "380664278634876"
									  } ],
									  "id" : "380661652220324"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Berniece",
										  "statements" : [ {
											"id" : "380991082010878",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  }
											},
											"name" : "Furman"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "380999300671804"
										},
										"id" : "380998556961672"
									  } ],
									  "id" : "380995884706540"
									},
									"id" : "5.1"
								  }, {
									"id" : "381147264524852",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "overdueAmount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[0].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.overdue",
										"dataType" : "text"
									  }
									},
									"name" : "Juston"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "overdueAmount@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Garret",
										  "statements" : [ {
											"id" : "381423436634255",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "overdueAmount"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Weston"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "381428703356326"
										},
										"id" : "381426573856739"
									  } ],
									  "id" : "381424598188347"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Jacky",
										  "statements" : [ {
											"id" : "381697749827470",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  }
											},
											"name" : "Alejandra"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "381691970199269"
										},
										"id" : "381692513026563"
									  } ],
									  "id" : "381704368406933"
									},
									"id" : "6.1"
								  }, {
									"id" : "381845645447052",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  }
									},
									"name" : "Emilie"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "381846053311388"
								},
								"id" : "381849465175161"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Clementina"
				  }, {
					"id" : "385457985731014",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "fundBasedLimitborrower",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Zoila",
								  "statements" : [ {
									"id" : "382282860051248",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[1].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.cfType",
										"dataType" : "text"
									  }
									},
									"name" : "Judge"
								  }, {
									"id" : "382421215770103",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[1].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.sanctionedDt",
										"dataType" : "text"
									  }
									},
									"name" : "Daron"
								  }, {
									"id" : "382558310003555",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionAmountInRs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[1].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.sanctionedAmt",
										"dataType" : "text"
									  }
									},
									"name" : "Curtis"
								  }, {
									"id" : "382709848968422",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "outstandingAmountinrs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[1].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.outstandingBalance",
										"dataType" : "text"
									  }
									},
									"name" : "Gerard"
								  }, {
									"id" : "382848331137844",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "loanExpiryOrMaturityDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[1].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.loanExpiryDt",
										"dataType" : "text"
									  }
									},
									"name" : "Eleonore"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "loanExpiryOrMaturityDate@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Kayla",
										  "statements" : [ {
											"id" : "383428584747219",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "loanExpiryOrMaturityDate"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Sibyl"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "383427680621872"
										},
										"id" : "383425335191274"
									  } ],
									  "id" : "383425888917616"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Rebecca",
										  "statements" : [ {
											"id" : "383958541084378",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  }
											},
											"name" : "Crawford"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "383955571252441"
										},
										"id" : "383958253179069"
									  } ],
									  "id" : "383956796716224"
									},
									"id" : "5.1"
								  }, {
									"id" : "384409091167315",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "overdueAmount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[1].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.overdue",
										"dataType" : "text"
									  }
									},
									"name" : "Humberto"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "overdueAmount@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Gordon",
										  "statements" : [ {
											"id" : "384839896551369",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "overdueAmount"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Terry"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "384835427692148"
										},
										"id" : "384834256360421"
									  } ],
									  "id" : "384833838693439"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Fredrick",
										  "statements" : [ {
											"id" : "385272386864638",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  }
											},
											"name" : "Rudolph"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "385277450459841"
										},
										"id" : "385275000933314"
									  } ],
									  "id" : "385277182707479"
									},
									"id" : "6.1"
								  }, {
									"id" : "385458545188486",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  }
									},
									"name" : "Loren"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "385458295279154"
								},
								"id" : "385454431436933"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Fritz"
				  }, {
					"id" : "388662890422275",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "fundBasedLimitborrower",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Alycia",
								  "statements" : [ {
									"id" : "385918426969411",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[2].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.cfType",
										"dataType" : "text"
									  }
									},
									"name" : "Ernesto"
								  }, {
									"id" : "386114832142817",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[2].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.sanctionedDt",
										"dataType" : "text"
									  }
									},
									"name" : "Peggie"
								  }, {
									"id" : "386233902169204",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionAmountInRs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[2].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.sanctionedAmt",
										"dataType" : "text"
									  }
									},
									"name" : "Jairo"
								  }, {
									"id" : "386443911762076",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "outstandingAmountinrs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[2].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.outstandingBalance",
										"dataType" : "text"
									  }
									},
									"name" : "Barry"
								  }, {
									"id" : "386607269125051",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "loanExpiryOrMaturityDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[2].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.loanExpiryDt",
										"dataType" : "text"
									  }
									},
									"name" : "Allison"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "loanExpiryOrMaturityDate@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Graciela",
										  "statements" : [ {
											"id" : "386972080312437",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "loanExpiryOrMaturityDate"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Guido"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "386978448692874"
										},
										"id" : "386975433211467"
									  } ],
									  "id" : "386975173721803"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Thomas",
										  "statements" : [ {
											"id" : "387398561314753",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  }
											},
											"name" : "Rhiannon"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "387394142103824"
										},
										"id" : "387394502284075"
									  } ],
									  "id" : "387391007917418"
									},
									"id" : "5.1"
								  }, {
									"id" : "387607499204814",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "overdueAmount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[2].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.overdue",
										"dataType" : "text"
									  }
									},
									"name" : "Brendon"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "overdueAmount@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Declan",
										  "statements" : [ {
											"id" : "387983685152730",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "overdueAmount"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Candace"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "387984402864461"
										},
										"id" : "387981397545067"
									  } ],
									  "id" : "387989705204418"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Maida",
										  "statements" : [ {
											"id" : "388404142608810",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  }
											},
											"name" : "Laurence"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "388404607969729"
										},
										"id" : "388403767808177"
									  } ],
									  "id" : "388407117413521"
									},
									"id" : "6.1"
								  }, {
									"id" : "388665840245813",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  }
									},
									"name" : "Lenna"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "388667961671153"
								},
								"id" : "388664375414902"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Aimee"
				  }, {
					"id" : "391949172166403",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "fundBasedLimitborrower",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Jerry",
								  "statements" : [ {
									"id" : "389552757038154",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[3].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.cfType",
										"dataType" : "text"
									  }
									},
									"name" : "Ruby"
								  }, {
									"id" : "389725928953871",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[3].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.sanctionedDt",
										"dataType" : "text"
									  }
									},
									"name" : "Issac"
								  }, {
									"id" : "389892879711477",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionAmountInRs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[3].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.sanctionedAmt",
										"dataType" : "text"
									  }
									},
									"name" : "Alice"
								  }, {
									"id" : "389912090261842",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "outstandingAmountinrs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[3].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.outstandingBalance",
										"dataType" : "text"
									  }
									},
									"name" : "Dejah"
								  }, {
									"id" : "390075058472866",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "loanExpiryOrMaturityDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[3].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.loanExpiryDt",
										"dataType" : "text"
									  }
									},
									"name" : "Samanta"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "loanExpiryOrMaturityDate@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Jayme",
										  "statements" : [ {
											"id" : "390489436651554",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "loanExpiryOrMaturityDate"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Sadye"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "390487259217139"
										},
										"id" : "390483781868940"
									  } ],
									  "id" : "390483018421534"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Josefina",
										  "statements" : [ {
											"id" : "390738304606615",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  }
											},
											"name" : "Vito"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "390739598414868"
										},
										"id" : "390737689148798"
									  } ],
									  "id" : "390732354689455"
									},
									"id" : "5.1"
								  }, {
									"id" : "390903124563689",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "overdueAmount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[3].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.overdue",
										"dataType" : "text"
									  }
									},
									"name" : "Cortez"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "overdueAmount@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Kurtis",
										  "statements" : [ {
											"id" : "391285250438033",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "overdueAmount"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Macey"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "391288779356660"
										},
										"id" : "391287114162437"
									  } ],
									  "id" : "391287816876373"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Omer",
										  "statements" : [ {
											"id" : "391772824213391",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  }
											},
											"name" : "Orpha"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "391771690254050"
										},
										"id" : "391777376182287"
									  } ],
									  "id" : "391774858808091"
									},
									"id" : "6.1"
								  }, {
									"id" : "391945780328568",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  }
									},
									"name" : "Michel"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "391948991703282"
								},
								"id" : "391941747751055"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Ardella"
				  }, {
					"id" : "395539320479706",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "fundBasedLimitborrower",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Frances",
								  "statements" : [ {
									"id" : "392967915032281",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[4].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.cfType",
										"dataType" : "text"
									  }
									},
									"name" : "Chyna"
								  }, {
									"id" : "393195808031369",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[4].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.sanctionedDt",
										"dataType" : "text"
									  }
									},
									"name" : "Alfonso"
								  }, {
									"id" : "393425751559039",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "sanctionAmountInRs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[4].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.sanctionedAmt",
										"dataType" : "text"
									  }
									},
									"name" : "Abby"
								  }, {
									"id" : "393639087208410",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "outstandingAmountinrs",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[4].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.outstandingBalance",
										"dataType" : "text"
									  }
									},
									"name" : "Camille"
								  }, {
									"id" : "393831094773048",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "loanExpiryOrMaturityDate",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[4].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.dates.loanExpiryDt",
										"dataType" : "text"
									  }
									},
									"name" : "Harmon"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "loanExpiryOrMaturityDate@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Emmalee",
										  "statements" : [ {
											"id" : "394158337525193",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "loanExpiryOrMaturityDate"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Kyra"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "394151627255723"
										},
										"id" : "394151291897557"
									  } ],
									  "id" : "394153878662966"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Trystan",
										  "statements" : [ {
											"id" : "394463691320783",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "loanExpiryOrMaturityDate",
												"dataType" : "text"
											  }
											},
											"name" : "Precious"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "394461974604227"
										},
										"id" : "394467656591092"
									  } ],
									  "id" : "394461012898834"
									},
									"id" : "5.1"
								  }, {
									"id" : "394647582412812",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "overdueAmount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.creditFacilityDetailsasBorrowerSecVec.creditFacilityDetailsasBorrowerSec.[4].creditFacilityCurrentDetailsVec.creditFacilityCurrentDetails.amount.overdue",
										"dataType" : "text"
									  }
									},
									"name" : "Lonnie"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "overdueAmount@local",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Golden",
										  "statements" : [ {
											"id" : "394969582900654",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "overdueAmount"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "NIL"
											  }
											},
											"name" : "Lauriane"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "394965185307221"
										},
										"id" : "394964634481557"
									  } ],
									  "id" : "394965595815044"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Reva",
										  "statements" : [ {
											"id" : "395328594154240",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "local",
												"dataValue" : "overdueAmount",
												"dataType" : "text"
											  }
											},
											"name" : "Lacy"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "395327690311782"
										},
										"id" : "395328730431760"
									  } ],
									  "id" : "395328394310200"
									},
									"id" : "6.1"
								  }, {
									"id" : "395536669797321",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "derogatoryDetails",
										"dataType" : "text"
									  }
									},
									"name" : "Adella"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "395531097240697"
								},
								"id" : "395532157144685"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Kody"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "395539559993524"
				},
				"id" : "395534087981775"
			  } ],
			  "id" : "395533482961524"
			},
			"id" : 1697107976635457
		  }, {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : "Statement 1697108026382390",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Serena",
				  "statements" : [ {
					"id" : "397932117158138",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "overallDerogatoryInformationSummary",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Jabari",
								  "statements" : [ {
									"id" : "396295584291075",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "InvocationOrDevolvedNo",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationBorrower.total.invoked.numberOfSuitFiled",
											"values" : [ "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationBorrower.total.invoked.amt" ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Sonia"
								  }, {
									"id" : "396516596737313",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "overdueNoandamount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationBorrower.total.overdueCF.numberOfSuitFiled",
											"values" : [ "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationBorrower.total.overdueCF.amt" ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Gregg"
								  }, {
									"id" : "396796307030997",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "writtenoffnoandamount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationBorrower.total.writtenOff.numberOfSuitFiled",
											"values" : [ "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationBorrower.total.writtenOff.amt" ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Joannie"
								  }, {
									"id" : "397158154839708",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "suitFiledNoandamount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.suitFilled.amt",
											"values" : [ "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.suitFilled.numberOfSuitFiled" ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Letitia"
								  }, {
									"id" : "397414691742923",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "wilfuldefaultNoandamount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationBorrower.total.wilfulDefault",
											"values" : [ ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Jena"
								  }, {
									"id" : "397939341166817",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "type",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "borrower",
										"dataType" : "text"
									  }
									},
									"name" : "Cassie"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "397934848846790"
								},
								"id" : "397936852813059"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Patricia"
				  }, {
					"id" : "399731381940693",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "overallDerogatoryInformationSummary",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Elvis",
								  "statements" : [ {
									"id" : "398867177456098",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "InvocationOrDevolvedNo&amt",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.invoked.amt",
											"values" : [ "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.invoked.numberOfSuitFiled" ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Kathryne"
								  }, {
									"id" : "399092041812574",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "overdueNoandamount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.overdueCF.amt",
											"values" : [ "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.overdueCF.numberOfSuitFiled" ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Demarcus"
								  }, {
									"id" : "399319569072736",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "writtenoffnoandamount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.writtenOff.amt",
											"values" : [ "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.writtenOff.numberOfSuitFiled" ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Rosina"
								  }, {
									"id" : "399453065367577",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "suitFiledNoandamount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.suitFilled.amt",
											"values" : [ "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.suitFilled.numberOfSuitFiled" ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Tevin"
								  }, {
									"id" : "399631219858228",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "wilfuldefaultNoandamount",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "text",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"concatWith" : "/",
											"value" : "base.responseReport.productSec.derogatoryInformationSec.derogatoryInformationOnRelatedPartiesOrGuarantorsOfBorrowerSec.total.wilfulDefault",
											"values" : [ ]
										  },
										  "format" : "concat"
										}
									  }
									},
									"name" : "Haskell"
								  }, {
									"id" : "399738106902673",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "type",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "guarantor",
										"dataType" : "text"
									  }
									},
									"name" : "Abigale"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "399736081489630"
								},
								"id" : "399732472373566"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Raphael"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "399731889370036"
				},
				"id" : "399735994315247"
			  } ],
			  "id" : "399737793356224"
			},
			"id" : 1697107976635457
		  }, {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : "Statement 1697108026382390",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Nathen",
				  "statements" : [ {
					"id" : "403529434630291",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "facilityWiseExposureSummary",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Pearlie",
								  "statements" : [ {
									"id" : "400255487192038",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityHead",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "Non Funded",
										"dataType" : "text"
									  }
									},
									"name" : "Mariana"
								  }, {
									"id" : "400465803078473",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "totalOutstanding",
										"dataType" : "number"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "number",
										"dataType" : "text",
										"keywordArguments" : {
										  "format" : "toText",
										  "init" : {
											"value" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.nonFunded.total.value"
										  }
										}
									  }
									},
									"name" : "Luigi"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.nonFunded.NONSTDVec.greaterthan180DPD.value",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Irving",
										  "statements" : [ {
											"id" : "400753674685866",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "assetClassification"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "greaterthan180DPD"
											  }
											},
											"name" : "Chester"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "400751596236118"
										},
										"id" : "400751469481365"
									  } ],
									  "id" : "400759656533725"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Kevin",
										  "statements" : [ {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.nonFunded.NONSTDVec.DPD91to180.value",
												  "dataType" : "text"
												},
												"operator" : {
												  "actualValue" : "!="
												},
												"rhs" : {
												  "@type" : "keyword",
												  "dataType" : "text",
												  "dataValue" : "text",
												  "keywordArguments" : {
													"format" : "getNullValue"
												  }
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Reagan",
												  "statements" : [ {
													"id" : "401166887987390",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "assetClassification"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "DPD91to180"
													  }
													},
													"name" : "Elian"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "401162042889418"
												},
												"id" : "401164308433909"
											  } ],
											  "id" : "401164075366484"
											},
											"failure" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Fern",
												  "statements" : [ {
													"condition" : {
													  "@type" : "logical",
													  "type" : "and",
													  "rules" : [ {
														"@type" : "relational",
														"lhs" : {
														  "@type" : "variable",
														  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.nonFunded.STDVec.DPD61to90.value",
														  "dataType" : "text"
														},
														"operator" : {
														  "actualValue" : "!="
														},
														"rhs" : {
														  "@type" : "keyword",
														  "dataType" : "text",
														  "dataValue" : "text",
														  "keywordArguments" : {
															"format" : "getNullValue"
														  }
														}
													  } ]
													},
													"@type" : "ConditionalStatement",
													"success" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Winona",
														  "statements" : [ {
															"id" : "401675498485361",
															"@type" : "AssignmentStatement",
															"assignment" : {
															  "lhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "assetClassification"
															  },
															  "operator" : {
																"actualValue" : "="
															  },
															  "rhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "DPD61to90"
															  }
															},
															"name" : "Cierra"
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "401678084275819"
														},
														"id" : "401674168430130"
													  } ],
													  "id" : "401674335955407"
													},
													"failure" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Bruce",
														  "statements" : [ {
															"condition" : {
															  "@type" : "logical",
															  "type" : "and",
															  "rules" : [ {
																"@type" : "relational",
																"lhs" : {
																  "@type" : "variable",
																  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.nonFunded.STDVec.DPD31to60.value",
																  "dataType" : "text"
																},
																"operator" : {
																  "actualValue" : "!="
																},
																"rhs" : {
																  "@type" : "keyword",
																  "dataType" : "text",
																  "dataValue" : "text",
																  "keywordArguments" : {
																	"format" : "getNullValue"
																  }
																}
															  } ]
															},
															"@type" : "ConditionalStatement",
															"success" : {
															  "name" : "transformation",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Viola",
																  "statements" : [ {
																	"id" : "402199197161007",
																	"@type" : "AssignmentStatement",
																	"assignment" : {
																	  "lhs" : {
																		"@type" : "literal",
																		"dataType" : "text",
																		"dataValue" : "assetClassification"
																	  },
																	  "operator" : {
																		"actualValue" : "="
																	  },
																	  "rhs" : {
																		"@type" : "literal",
																		"dataType" : "text",
																		"dataValue" : "DPD31to60"
																	  }
																	},
																	"name" : "Thora"
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "402199862459162"
																},
																"id" : "402199120659165"
															  } ],
															  "id" : "402194830073181"
															},
															"failure" : {
															  "name" : "transformation",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Furman",
																  "statements" : [ {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.nonFunded.STDVec.DPD1to30.value",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "keyword",
																		  "dataType" : "text",
																		  "dataValue" : "text",
																		  "keywordArguments" : {
																			"format" : "getNullValue"
																		  }
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Kaya",
																		  "statements" : [ {
																			"id" : "402619231355619",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataType" : "text",
																				"dataValue" : "assetClassification"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataType" : "text",
																				"dataValue" : "DPD1to30"
																			  }
																			},
																			"name" : "Lia"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "402619963922527"
																		},
																		"id" : "402618012930527"
																	  } ],
																	  "id" : "402613279606735"
																	},
																	"failure" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Lenore",
																		  "statements" : [ {
																			"condition" : {
																			  "@type" : "logical",
																			  "type" : "and",
																			  "rules" : [ {
																				"@type" : "relational",
																				"lhs" : {
																				  "@type" : "variable",
																				  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.nonFunded.STDVec.DPD0.value",
																				  "dataType" : "text"
																				},
																				"operator" : {
																				  "actualValue" : "!="
																				},
																				"rhs" : {
																				  "@type" : "keyword",
																				  "dataType" : "text",
																				  "dataValue" : "text",
																				  "keywordArguments" : {
																					"format" : "getNullValue"
																				  }
																				}
																			  } ]
																			},
																			"@type" : "ConditionalStatement",
																			"success" : {
																			  "name" : "transformation",
																			  "statements" : [ {
																				"@type" : "SectionalStatement",
																				"section" : {
																				  "jsonIgnoreProperty" : false,
																				  "name" : "Dorothy",
																				  "statements" : [ {
																					"id" : "403077455804663",
																					"@type" : "AssignmentStatement",
																					"assignment" : {
																					  "lhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "assetClassification"
																					  },
																					  "operator" : {
																						"actualValue" : "="
																					  },
																					  "rhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "DPD0"
																					  }
																					},
																					"name" : "Vallie"
																				  } ],
																				  "jsonIgnoreAliasValue" : null,
																				  "id" : "403078989549106"
																				},
																				"id" : "403071305275765"
																			  } ],
																			  "id" : "403078602680458"
																			},
																			"failure" : {
																			  "name" : "transformation",
																			  "statements" : [ {
																				"@type" : "SectionalStatement",
																				"section" : {
																				  "jsonIgnoreProperty" : false,
																				  "name" : "Katherine",
																				  "statements" : [ {
																					"id" : "403389429974622",
																					"@type" : "AssignmentStatement",
																					"assignment" : {
																					  "lhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "assetClassification"
																					  },
																					  "operator" : {
																						"actualValue" : "="
																					  },
																					  "rhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "NIL"
																					  }
																					},
																					"name" : "Jeanie"
																				  } ],
																				  "jsonIgnoreAliasValue" : null,
																				  "id" : "403383332025645"
																				},
																				"id" : "403389637556506"
																			  } ],
																			  "id" : "403389100604063"
																			},
																			"id" : 1
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "403382509820385"
																		},
																		"id" : "403382122867105"
																	  } ],
																	  "id" : "403385387667156"
																	},
																	"id" : 1
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "403384576350942"
																},
																"id" : "403383672925872"
															  } ],
															  "id" : "403383529085942"
															},
															"id" : 1
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "403387127102257"
														},
														"id" : "403386773031024"
													  } ],
													  "id" : "403384543976286"
													},
													"id" : 1
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "403384919078671"
												},
												"id" : "403383676942443"
											  } ],
											  "id" : "403384730173437"
											},
											"id" : 1
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "403383262428072"
										},
										"id" : "403387268149480"
									  } ],
									  "id" : "403385207783020"
									},
									"id" : 3
								  }, {
									"id" : "403523775240445",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "count",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.nonFunded.total.count",
										"dataType" : "number"
									  }
									},
									"name" : "Adolphus"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "403522961781515"
								},
								"id" : "403524124172568"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Ciara"
				  }, {
					"id" : "407385904222612",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "facilityWiseExposureSummary",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Alysa",
								  "statements" : [ {
									"id" : "403892995709184",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityHead",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "Forex",
										"dataType" : "text"
									  }
									},
									"name" : "Violet"
								  }, {
									"id" : "404119174464102",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "totalOutstanding",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "number",
										"dataType" : "text",
										"keywordArguments" : {
										  "format" : "toText",
										  "init" : {
											"value" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.forex.total.value"
										  }
										}
									  }
									},
									"name" : "Lelah"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.forex.NONSTDVec.greaterthan180DPD.value",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Keara",
										  "statements" : [ {
											"id" : "404417921129401",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "assetClassification"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "greaterthan180DPD"
											  }
											},
											"name" : "Barney"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "404417105634956"
										},
										"id" : "404413539460201"
									  } ],
									  "id" : "404414030259648"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Jacky",
										  "statements" : [ {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.forex.NONSTDVec.DPD91to180.value",
												  "dataType" : "text"
												},
												"operator" : {
												  "actualValue" : "!="
												},
												"rhs" : {
												  "@type" : "keyword",
												  "dataType" : "text",
												  "dataValue" : "text",
												  "keywordArguments" : {
													"format" : "getNullValue"
												  }
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Destinee",
												  "statements" : [ {
													"id" : "404838280663661",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "assetClassification"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "DPD91to180"
													  }
													},
													"name" : "Kali"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "404836048130567"
												},
												"id" : "404835165520347"
											  } ],
											  "id" : "404838063489355"
											},
											"failure" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Ethel",
												  "statements" : [ {
													"condition" : {
													  "@type" : "logical",
													  "type" : "and",
													  "rules" : [ {
														"@type" : "relational",
														"lhs" : {
														  "@type" : "variable",
														  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.forex.STDVec.DPD61to90.value",
														  "dataType" : "text"
														},
														"operator" : {
														  "actualValue" : "!="
														},
														"rhs" : {
														  "@type" : "keyword",
														  "dataType" : "text",
														  "dataValue" : "text",
														  "keywordArguments" : {
															"format" : "getNullValue"
														  }
														}
													  } ]
													},
													"@type" : "ConditionalStatement",
													"success" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Estel",
														  "statements" : [ {
															"id" : "405285083457842",
															"@type" : "AssignmentStatement",
															"assignment" : {
															  "lhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "assetClassification"
															  },
															  "operator" : {
																"actualValue" : "="
															  },
															  "rhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "DPD61to90"
															  }
															},
															"name" : "Franz"
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "405282770994312"
														},
														"id" : "405285488540779"
													  } ],
													  "id" : "405288965431636"
													},
													"failure" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Krystal",
														  "statements" : [ {
															"condition" : {
															  "@type" : "logical",
															  "type" : "and",
															  "rules" : [ {
																"@type" : "relational",
																"lhs" : {
																  "@type" : "variable",
																  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.forex.STDVec.DPD31to60.value",
																  "dataType" : "text"
																},
																"operator" : {
																  "actualValue" : "!="
																},
																"rhs" : {
																  "@type" : "keyword",
																  "dataType" : "text",
																  "dataValue" : "text",
																  "keywordArguments" : {
																	"format" : "getNullValue"
																  }
																}
															  } ]
															},
															"@type" : "ConditionalStatement",
															"success" : {
															  "name" : "transformation",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Guiseppe",
																  "statements" : [ {
																	"id" : "405666269660466",
																	"@type" : "AssignmentStatement",
																	"assignment" : {
																	  "lhs" : {
																		"@type" : "literal",
																		"dataType" : "text",
																		"dataValue" : "assetClassification"
																	  },
																	  "operator" : {
																		"actualValue" : "="
																	  },
																	  "rhs" : {
																		"@type" : "literal",
																		"dataType" : "text",
																		"dataValue" : "DPD31to60"
																	  }
																	},
																	"name" : "Eliseo"
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "405665992898860"
																},
																"id" : "405669771715971"
															  } ],
															  "id" : "405662330843421"
															},
															"failure" : {
															  "name" : "transformation",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Ryder",
																  "statements" : [ {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.forex.STDVec.DPD1to30.value",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "keyword",
																		  "dataType" : "text",
																		  "dataValue" : "text",
																		  "keywordArguments" : {
																			"format" : "getNullValue"
																		  }
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Jovan",
																		  "statements" : [ {
																			"id" : "406239871571842",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataType" : "text",
																				"dataValue" : "assetClassification"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataType" : "text",
																				"dataValue" : "DPD1to30"
																			  }
																			},
																			"name" : "Willow"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "406236928631483"
																		},
																		"id" : "406236643115391"
																	  } ],
																	  "id" : "406239639945937"
																	},
																	"failure" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Barbara",
																		  "statements" : [ {
																			"condition" : {
																			  "@type" : "logical",
																			  "type" : "and",
																			  "rules" : [ {
																				"@type" : "relational",
																				"lhs" : {
																				  "@type" : "variable",
																				  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.forex.STDVec.DPD0.value",
																				  "dataType" : "text"
																				},
																				"operator" : {
																				  "actualValue" : "!="
																				},
																				"rhs" : {
																				  "@type" : "keyword",
																				  "dataType" : "text",
																				  "dataValue" : "text",
																				  "keywordArguments" : {
																					"format" : "getNullValue"
																				  }
																				}
																			  } ]
																			},
																			"@type" : "ConditionalStatement",
																			"success" : {
																			  "name" : "transformation",
																			  "statements" : [ {
																				"@type" : "SectionalStatement",
																				"section" : {
																				  "jsonIgnoreProperty" : false,
																				  "name" : "August",
																				  "statements" : [ {
																					"id" : "406637739406071",
																					"@type" : "AssignmentStatement",
																					"assignment" : {
																					  "lhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "assetClassification"
																					  },
																					  "operator" : {
																						"actualValue" : "="
																					  },
																					  "rhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "DPD0"
																					  }
																					},
																					"name" : "Hollie"
																				  } ],
																				  "jsonIgnoreAliasValue" : null,
																				  "id" : "406639452342794"
																				},
																				"id" : "406632823529275"
																			  } ],
																			  "id" : "406634587013142"
																			},
																			"failure" : {
																			  "name" : "transformation",
																			  "statements" : [ {
																				"@type" : "SectionalStatement",
																				"section" : {
																				  "jsonIgnoreProperty" : false,
																				  "name" : "Bertrand",
																				  "statements" : [ {
																					"id" : "407132324622238",
																					"@type" : "AssignmentStatement",
																					"assignment" : {
																					  "lhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "assetClassification"
																					  },
																					  "operator" : {
																						"actualValue" : "="
																					  },
																					  "rhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "NIL"
																					  }
																					},
																					"name" : "Kamron"
																				  } ],
																				  "jsonIgnoreAliasValue" : null,
																				  "id" : "407134287627287"
																				},
																				"id" : "407132463851718"
																			  } ],
																			  "id" : "407135380911879"
																			},
																			"id" : 1
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "407132998090859"
																		},
																		"id" : "407136037483737"
																	  } ],
																	  "id" : "407138075790959"
																	},
																	"id" : 1
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "407138843340049"
																},
																"id" : "407134038082342"
															  } ],
															  "id" : "407138745956819"
															},
															"id" : 1
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "407132697054935"
														},
														"id" : "407136874979329"
													  } ],
													  "id" : "407133607291083"
													},
													"id" : 1
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "407136491082288"
												},
												"id" : "407131754001101"
											  } ],
											  "id" : "407132527279834"
											},
											"id" : 1
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "407138465211302"
										},
										"id" : "407135072011589"
									  } ],
									  "id" : "407135254742114"
									},
									"id" : 3
								  }, {
									"id" : "407388848513267",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "count",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.forex.total.count",
										"dataType" : "number"
									  }
									},
									"name" : "Kobe"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "407385969732091"
								},
								"id" : "407386978464462"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Alphonso"
				  }, {
					"id" : "412035716738830",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "facilityWiseExposureSummary",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Saul",
								  "statements" : [ {
									"id" : "408112984596568",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityHead",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "Term Loan",
										"dataType" : "text"
									  }
									},
									"name" : "Branson"
								  }, {
									"id" : "408303761484317",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "totalOutstanding",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "number",
										"dataType" : "text",
										"keywordArguments" : {
										  "format" : "toText",
										  "init" : {
											"value" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.termLoan.total.value"
										  }
										}
									  }
									},
									"name" : "Gisselle"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.termLoan.NONSTDVec.greaterthan180DPD.value",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Beverly",
										  "statements" : [ {
											"id" : "408731772327325",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "assetClassification"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "greaterthan180DPD"
											  }
											},
											"name" : "Lyda"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "408733991383256"
										},
										"id" : "408738642323354"
									  } ],
									  "id" : "408737447929239"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Karolann",
										  "statements" : [ {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.termLoan.NONSTDVec.DPD91to180.value",
												  "dataType" : "text"
												},
												"operator" : {
												  "actualValue" : "!="
												},
												"rhs" : {
												  "@type" : "keyword",
												  "dataType" : "text",
												  "dataValue" : "text",
												  "keywordArguments" : {
													"format" : "getNullValue"
												  }
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Karli",
												  "statements" : [ {
													"id" : "409439556261770",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "assetClassification"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "DPD91to180"
													  }
													},
													"name" : "Berry"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "409431751334776"
												},
												"id" : "409439250487136"
											  } ],
											  "id" : "409436503384725"
											},
											"failure" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Obie",
												  "statements" : [ {
													"condition" : {
													  "@type" : "logical",
													  "type" : "and",
													  "rules" : [ {
														"@type" : "relational",
														"lhs" : {
														  "@type" : "variable",
														  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.termLoan.STDVec.DPD61to90.value",
														  "dataType" : "text"
														},
														"operator" : {
														  "actualValue" : "!="
														},
														"rhs" : {
														  "@type" : "keyword",
														  "dataType" : "text",
														  "dataValue" : "text",
														  "keywordArguments" : {
															"format" : "getNullValue"
														  }
														}
													  } ]
													},
													"@type" : "ConditionalStatement",
													"success" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Jaclyn",
														  "statements" : [ {
															"id" : "410027508856770",
															"@type" : "AssignmentStatement",
															"assignment" : {
															  "lhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "assetClassification"
															  },
															  "operator" : {
																"actualValue" : "="
															  },
															  "rhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "DPD61to90"
															  }
															},
															"name" : "Orville"
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "410024939751391"
														},
														"id" : "410029056739950"
													  } ],
													  "id" : "410029384242111"
													},
													"failure" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Enrique",
														  "statements" : [ {
															"condition" : {
															  "@type" : "logical",
															  "type" : "and",
															  "rules" : [ {
																"@type" : "relational",
																"lhs" : {
																  "@type" : "variable",
																  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.termLoan.STDVec.DPD31to60.value",
																  "dataType" : "text"
																},
																"operator" : {
																  "actualValue" : "!="
																},
																"rhs" : {
																  "@type" : "keyword",
																  "dataType" : "text",
																  "dataValue" : "text",
																  "keywordArguments" : {
																	"format" : "getNullValue"
																  }
																}
															  } ]
															},
															"@type" : "ConditionalStatement",
															"success" : {
															  "name" : "transformation",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Eladio",
																  "statements" : [ {
																	"id" : "410592568166389",
																	"@type" : "AssignmentStatement",
																	"assignment" : {
																	  "lhs" : {
																		"@type" : "literal",
																		"dataType" : "text",
																		"dataValue" : "assetClassification"
																	  },
																	  "operator" : {
																		"actualValue" : "="
																	  },
																	  "rhs" : {
																		"@type" : "literal",
																		"dataType" : "text",
																		"dataValue" : "DPD31to60"
																	  }
																	},
																	"name" : "Erick"
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "410597335641520"
																},
																"id" : "410596180000843"
															  } ],
															  "id" : "410594023552180"
															},
															"failure" : {
															  "name" : "transformation",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Jacquelyn",
																  "statements" : [ {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.termLoan.STDVec.DPD1to30.value",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "keyword",
																		  "dataType" : "text",
																		  "dataValue" : "text",
																		  "keywordArguments" : {
																			"format" : "getNullValue"
																		  }
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Dena",
																		  "statements" : [ {
																			"id" : "411154085426575",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataType" : "text",
																				"dataValue" : "assetClassification"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataType" : "text",
																				"dataValue" : "DPD1to30"
																			  }
																			},
																			"name" : "Maurice"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "411156968975018"
																		},
																		"id" : "411151559636839"
																	  } ],
																	  "id" : "411152346483002"
																	},
																	"failure" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Jordon",
																		  "statements" : [ {
																			"condition" : {
																			  "@type" : "logical",
																			  "type" : "and",
																			  "rules" : [ {
																				"@type" : "relational",
																				"lhs" : {
																				  "@type" : "variable",
																				  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.termLoan.STDVec.DPD0.value",
																				  "dataType" : "text"
																				},
																				"operator" : {
																				  "actualValue" : "!="
																				},
																				"rhs" : {
																				  "@type" : "keyword",
																				  "dataType" : "text",
																				  "dataValue" : "text",
																				  "keywordArguments" : {
																					"format" : "getNullValue"
																				  }
																				}
																			  } ]
																			},
																			"@type" : "ConditionalStatement",
																			"success" : {
																			  "name" : "transformation",
																			  "statements" : [ {
																				"@type" : "SectionalStatement",
																				"section" : {
																				  "jsonIgnoreProperty" : false,
																				  "name" : "Elisa",
																				  "statements" : [ {
																					"id" : "411615576996013",
																					"@type" : "AssignmentStatement",
																					"assignment" : {
																					  "lhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "assetClassification"
																					  },
																					  "operator" : {
																						"actualValue" : "="
																					  },
																					  "rhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "DPD0"
																					  }
																					},
																					"name" : "Georgiana"
																				  } ],
																				  "jsonIgnoreAliasValue" : null,
																				  "id" : "411618781804593"
																				},
																				"id" : "411611434412796"
																			  } ],
																			  "id" : "411611640052541"
																			},
																			"failure" : {
																			  "name" : "transformation",
																			  "statements" : [ {
																				"@type" : "SectionalStatement",
																				"section" : {
																				  "jsonIgnoreProperty" : false,
																				  "name" : "Heaven",
																				  "statements" : [ {
																					"id" : "411903504791746",
																					"@type" : "AssignmentStatement",
																					"assignment" : {
																					  "lhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "assetClassification"
																					  },
																					  "operator" : {
																						"actualValue" : "="
																					  },
																					  "rhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "NIL"
																					  }
																					},
																					"name" : "Emery"
																				  } ],
																				  "jsonIgnoreAliasValue" : null,
																				  "id" : "411903511403479"
																				},
																				"id" : "411908733284187"
																			  } ],
																			  "id" : "411905493523930"
																			},
																			"id" : 1
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "411909433805370"
																		},
																		"id" : "411903796880019"
																	  } ],
																	  "id" : "411903146438364"
																	},
																	"id" : 1
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "411902244686393"
																},
																"id" : "411903150614419"
															  } ],
															  "id" : "411903847144816"
															},
															"id" : 1
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "411906958953111"
														},
														"id" : "411908893966128"
													  } ],
													  "id" : "411901121262619"
													},
													"id" : 1
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "411901138714936"
												},
												"id" : "411906081083901"
											  } ],
											  "id" : "411901386203677"
											},
											"id" : 1
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "411902490802380"
										},
										"id" : "411907031282028"
									  } ],
									  "id" : "411906504820966"
									},
									"id" : 3
								  }, {
									"id" : "412035230020278",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "count",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.termLoan.total.count",
										"dataType" : "number"
									  }
									},
									"name" : "Deontae"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "412037015022782"
								},
								"id" : "412036081078631"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Era"
				  }, {
					"id" : "415356271137388",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "facilityWiseExposureSummary",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Brandyn",
								  "statements" : [ {
									"id" : "412472853071305",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "facilityHead",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "Working Capital",
										"dataType" : "text"
									  }
									},
									"name" : "Phoebe"
								  }, {
									"id" : "412573523539761",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "totalOutstanding",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "number",
										"dataType" : "text",
										"keywordArguments" : {
										  "format" : "toText",
										  "init" : {
											"value" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.workingCapital.total.value"
										  }
										}
									  }
									},
									"name" : "Susie"
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.workingCapital.NONSTDVec.greaterthan180DPD.value",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Mckenzie",
										  "statements" : [ {
											"id" : "412927722278353",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "assetClassification"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataType" : "text",
												"dataValue" : "greaterthan180DPD"
											  }
											},
											"name" : "Alexys"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "412922049972563"
										},
										"id" : "412928810610902"
									  } ],
									  "id" : "412925186639907"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Enid",
										  "statements" : [ {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.workingCapital.NONSTDVec.DPD91to180.value",
												  "dataType" : "text"
												},
												"operator" : {
												  "actualValue" : "!="
												},
												"rhs" : {
												  "@type" : "keyword",
												  "dataType" : "text",
												  "dataValue" : "text",
												  "keywordArguments" : {
													"format" : "getNullValue"
												  }
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Shirley",
												  "statements" : [ {
													"id" : "413348886067023",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "assetClassification"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "literal",
														"dataType" : "text",
														"dataValue" : "DPD91to180"
													  }
													},
													"name" : "Enrique"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "413343018197276"
												},
												"id" : "413341293512744"
											  } ],
											  "id" : "413346964296277"
											},
											"failure" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Sheridan",
												  "statements" : [ {
													"condition" : {
													  "@type" : "logical",
													  "type" : "and",
													  "rules" : [ {
														"@type" : "relational",
														"lhs" : {
														  "@type" : "variable",
														  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.workingCapital.STDVec.DPD61to90.value",
														  "dataType" : "text"
														},
														"operator" : {
														  "actualValue" : "!="
														},
														"rhs" : {
														  "@type" : "keyword",
														  "dataType" : "text",
														  "dataValue" : "text",
														  "keywordArguments" : {
															"format" : "getNullValue"
														  }
														}
													  } ]
													},
													"@type" : "ConditionalStatement",
													"success" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Loy",
														  "statements" : [ {
															"id" : "413717624191838",
															"@type" : "AssignmentStatement",
															"assignment" : {
															  "lhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "assetClassification"
															  },
															  "operator" : {
																"actualValue" : "="
															  },
															  "rhs" : {
																"@type" : "literal",
																"dataType" : "text",
																"dataValue" : "DPD61to90"
															  }
															},
															"name" : "Iva"
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "413712687688818"
														},
														"id" : "413716619741269"
													  } ],
													  "id" : "413713235386741"
													},
													"failure" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Kenyon",
														  "statements" : [ {
															"condition" : {
															  "@type" : "logical",
															  "type" : "and",
															  "rules" : [ {
																"@type" : "relational",
																"lhs" : {
																  "@type" : "variable",
																  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.workingCapital.STDVec.DPD31to60.value",
																  "dataType" : "text"
																},
																"operator" : {
																  "actualValue" : "!="
																},
																"rhs" : {
																  "@type" : "keyword",
																  "dataType" : "text",
																  "dataValue" : "text",
																  "keywordArguments" : {
																	"format" : "getNullValue"
																  }
																}
															  } ]
															},
															"@type" : "ConditionalStatement",
															"success" : {
															  "name" : "transformation",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Edwin",
																  "statements" : [ {
																	"id" : "414122358264998",
																	"@type" : "AssignmentStatement",
																	"assignment" : {
																	  "lhs" : {
																		"@type" : "literal",
																		"dataType" : "text",
																		"dataValue" : "assetClassification"
																	  },
																	  "operator" : {
																		"actualValue" : "="
																	  },
																	  "rhs" : {
																		"@type" : "literal",
																		"dataType" : "text",
																		"dataValue" : "DPD31to60"
																	  }
																	},
																	"name" : "Candido"
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "414129312766362"
																},
																"id" : "414125863954260"
															  } ],
															  "id" : "414122728329613"
															},
															"failure" : {
															  "name" : "transformation",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Edwina",
																  "statements" : [ {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.workingCapital.STDVec.DPD1to30.value",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "keyword",
																		  "dataType" : "text",
																		  "dataValue" : "text",
																		  "keywordArguments" : {
																			"format" : "getNullValue"
																		  }
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Taylor",
																		  "statements" : [ {
																			"id" : "414538480382245",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataType" : "text",
																				"dataValue" : "assetClassification"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataType" : "text",
																				"dataValue" : "DPD1to30"
																			  }
																			},
																			"name" : "Gretchen"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "414534908560059"
																		},
																		"id" : "414535641315914"
																	  } ],
																	  "id" : "414538994142806"
																	},
																	"failure" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Clair",
																		  "statements" : [ {
																			"condition" : {
																			  "@type" : "logical",
																			  "type" : "and",
																			  "rules" : [ {
																				"@type" : "relational",
																				"lhs" : {
																				  "@type" : "variable",
																				  "dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.workingCapital.STDVec.DPD0.value",
																				  "dataType" : "text"
																				},
																				"operator" : {
																				  "actualValue" : "!="
																				},
																				"rhs" : {
																				  "@type" : "keyword",
																				  "dataType" : "text",
																				  "dataValue" : "text",
																				  "keywordArguments" : {
																					"format" : "getNullValue"
																				  }
																				}
																			  } ]
																			},
																			"@type" : "ConditionalStatement",
																			"success" : {
																			  "name" : "transformation",
																			  "statements" : [ {
																				"@type" : "SectionalStatement",
																				"section" : {
																				  "jsonIgnoreProperty" : false,
																				  "name" : "Gianni",
																				  "statements" : [ {
																					"id" : "414935082727881",
																					"@type" : "AssignmentStatement",
																					"assignment" : {
																					  "lhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "assetClassification"
																					  },
																					  "operator" : {
																						"actualValue" : "="
																					  },
																					  "rhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "DPD0"
																					  }
																					},
																					"name" : "Melisa"
																				  } ],
																				  "jsonIgnoreAliasValue" : null,
																				  "id" : "414938436501800"
																				},
																				"id" : "414931031888036"
																			  } ],
																			  "id" : "414938007380837"
																			},
																			"failure" : {
																			  "name" : "transformation",
																			  "statements" : [ {
																				"@type" : "SectionalStatement",
																				"section" : {
																				  "jsonIgnoreProperty" : false,
																				  "name" : "Nelson",
																				  "statements" : [ {
																					"id" : "415153491298153",
																					"@type" : "AssignmentStatement",
																					"assignment" : {
																					  "lhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "assetClassification"
																					  },
																					  "operator" : {
																						"actualValue" : "="
																					  },
																					  "rhs" : {
																						"@type" : "literal",
																						"dataType" : "text",
																						"dataValue" : "NIL"
																					  }
																					},
																					"name" : "Otilia"
																				  } ],
																				  "jsonIgnoreAliasValue" : null,
																				  "id" : "415158648560043"
																				},
																				"id" : "415155036412354"
																			  } ],
																			  "id" : "415153434298490"
																			},
																			"id" : 1
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "415157504435384"
																		},
																		"id" : "415154740846941"
																	  } ],
																	  "id" : "415159202617277"
																	},
																	"id" : 1
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "415154459955946"
																},
																"id" : "415156561715983"
															  } ],
															  "id" : "415151336110805"
															},
															"id" : 1
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "415157112017939"
														},
														"id" : "415154664215093"
													  } ],
													  "id" : "415151498021765"
													},
													"id" : 1
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "415152347806117"
												},
												"id" : "415158383285388"
											  } ],
											  "id" : "415156493121098"
											},
											"id" : 1
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "415154673202806"
										},
										"id" : "415158233296014"
									  } ],
									  "id" : "415156318205162"
									},
									"id" : 3
								  }, {
									"id" : "415356941167270",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "count",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "base.responseReport.productSec.oustandingBalanceByCFAndAssetClasificationSec.outsideInstitution.workingCapital.total.count",
										"dataType" : "number"
									  }
									},
									"name" : "Leann"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "415356612598443"
								},
								"id" : "415357423174911"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Samir"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "415352650750930"
				},
				"id" : "415358298282278"
			  } ],
			  "id" : "415358574527388"
			},
			"id" : 1697107976635457
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "415357520227048"
		},
		"id" : "415357375446082"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const TestNewDateFormat = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Larue",
		  "statements" : [ {
			"id" : "415646290394585",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "dateFormatter",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "dd-MM-yyyy",
				  "init" : {
					"value" : "startDate",
					"format" : "yyyy-MM-dd HH:mm:ss"
				  }
				}
			  }
			},
			"name" : "Kole"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "415644921140228"
		},
		"id" : "415646938507983"
	  } ]
	}
  }`

const AnyDataType = `{
	"version": 3.3,
	"@type": "transform",
	"transform": {
		"id": "transform_custodetails",
		"name": "Request payload Transformation",
		"statements": [
			{
				"id": 1706087374726098,
				"name": "BreathFaith",
				"@type": "AssignmentStatement",
				"mandatory": true,
				"assignment": {
					"lhs": {
						"@type": "literal",
						"dataType": "text",
						"dataValue": "a.bc"
					},
					"rhs": {
						"@type": "variable",
						"dataType": "any",
						"dataValue": "map"
					},
					"operator": {
						"actualValue": "="
					}
				}
			},
			{
				"id": 1706087374726098,
				"name": "BreathFaith",
				"@type": "AssignmentStatement",
				"mandatory": true,
				"assignment": {
					"lhs": {
						"@type": "literal",
						"dataType": "any",
						"dataValue": "bc"
					},
					"rhs": {
						"@type": "variable",
						"dataType": "any",
						"dataValue": "list"
					},
					"operator": {
						"actualValue": "="
					}
				}
			},
			{
				"id": 1706087374726098,
				"name": "BreathFaith",
				"@type": "AssignmentStatement",
				"mandatory": true,
				"assignment": {
					"lhs": {
						"@type": "literal",
						"dataType": "text",
						"dataValue": "a.bc"
					},
					"rhs": {
						"@type": "variable",
						"dataType": "any",
						"dataValue": "text"
					},
					"operator": {
						"actualValue": "="
					}
				}
			},
			{
				"id": 1706087374726098,
				"name": "BreathFaith",
				"@type": "AssignmentStatement",
				"mandatory": true,
				"assignment": {
					"lhs": {
						"@type": "literal",
						"dataType": "any",
						"dataValue": "bc"
					},
					"rhs": {
						"@type": "variable",
						"dataType": "any",
						"dataValue": "number"
					},
					"operator": {
						"actualValue": "="
					}
				}
			}
		]
	}
  }`

const TestReferenceNUllCheck = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
	  "condition": {
		  "@type": "logical",
		  "type": "and",
		  "rules": [
			  {
				  "@type": "relational",
				  "lhs": {
					  "@type": "literal",
					  "dataValue": "javed",
					  "dataType": "text"
				  },
				  "operator": {
					  "actualValue": "==="
				  },
				  "rhs": {
					  "@type": "keyword",
					  "dataType": "text",
					  "dataValue": "text",
					  "keywordArguments": {
						  "format": "getNullValue"
					  }
				  }
			  }
		  ]
	  },
	  "@type": "ConditionalStatement",
	  "success": {
		  "name": "transformation",
		  "statements": [
			  {
				  "id": "414935082727881",
				  "@type": "AssignmentStatement",
				  "assignment": {
					  "lhs": {
						  "@type": "literal",
						  "dataType": "text",
						  "dataValue": "consition"
					  },
					  "operator": {
						  "actualValue": "="
					  },
					  "rhs": {
						  "@type": "literal",
						  "dataType": "text",
						  "dataValue": "false"
					  }
				  },
				  "name": "Melisa"
			  }
		  ],
		  "id": "414938007380837"
	  },
	  "failure": {
		  "name": "transformation",
		  "statements": [
			  {
				  "id": "414935082727881",
				  "@type": "AssignmentStatement",
				  "assignment": {
					  "lhs": {
						  "@type": "literal",
						  "dataType": "text",
						  "dataValue": "condition"
					  },
					  "operator": {
						  "actualValue": "="
					  },
					  "rhs": {
						  "@type": "literal",
						  "dataType": "text",
						  "dataValue": "false"
					  }
				  },
				  "name": "Melisa"
			  }
		  ],
		  "id": "414938007380837"
	  }
  }]
	}
  }`

const TestErrorMessageWithStatementName = `{
	"version": 3.3,
	"@type": "transform",
	"contentInputType": "json",
	"contentOutputType": "json",
	"ignoreNullFields": true,
	"transform": {
		"id": "transform_employeeDetails",
		"name": "Request payload Transformation",
		"statements": [
			{
				"id": "414935082727881",
				"@type": "AssignmentStatement",
				"assignment": {
					"lhs": {
						"@type": "literal",
						"dataType": "text",
						"dataValue": "condition"
					},
					"operator": {
						"actualValue": "="
					},
					"rhs": {
						"@type": "variable",
						"dataType": "text",
						"dataValue": "LoanFinanceDue"
					}
				},
				"name": "Melisa"
			}
		]
	}
  }`

const TestCreatingSubStringWithoutDuplicateCharacter = `{
	"version": 3.3,
	"@type": "transform",
	"transform": {
		"id": "transform_custodetails",
		"name": "Request payload Transformation",
		"statements": [
		  {
			"id": "414935082727881",
			"@type": "AssignmentStatement",
			"assignment": {
				"lhs": {
					"@type": "declare",
					"dataType": "text",
					"dataValue": "name"
				},
				"operator": {
					"actualValue": "="
				},
				"rhs": {
					"@type": "literal",
					"dataType": "text",
					"dataValue": "meemnaakshi"
				}
			},
			"name": "Melisa"
		},
		{
			"id": "985525403601979",
			"@type": "AssignmentStatement",
			"assignment": {
				"@type": "SimpleAssignmentStatement",
				"lhs": {
					"@type": "declare",
					"dataValue": "nameArray",
					"dataType": "list"
				},
				"operator": {
					"actualValue": "="
				},
				"rhs": {
					"@type": "keyword",
					"dataType": "list",
					"dataValue": "text",
					"keywordArguments": {
						"init": {
							"value": "name@local",
							"splitby": ""
						},
						"format": "split"
					}
				}
			},
			"name": "Mabel"
		},
		{
			"id": "985525403601979",
			"@type": "AssignmentStatement",
			"assignment": {
				"@type": "SimpleAssignmentStatement",
				"lhs": {
					"@type": "declare",
					"dataValue": "prefixArray",
					"dataType": "list"
				},
				"operator": {
					"actualValue": "="
				},
				"rhs": {
					"@type": "keyword",
					"dataType": "list",
					"dataValue": "list",
					"keywordArguments": {}
				}
			},
			"name": "Mabel"
		},
		{
			"id": "955811403703276",
			"@type": "AssignmentStatement",
			"assignment": {
				"lhs": {
					"@type": "declare",
					"dataValue": "grabageArray",
					"dataType": "list"
				},
				"operator": {
					"actualValue": "="
				},
				"rhs": {
					"@type": "keyword",
					"dataType": "list",
					"dataValue": "list",
					"keywordArguments": {
						"init": {
							"value": "nameArray@local",
							"transform": {
								"id": "transform_config_2",
								"name": "transform Consumer Communication Address Details",
								"statements": [
									{
										"id": "414935082727881",
										"@type": "AssignmentStatement",
										"assignment": {
											"lhs": {
												"@type": "declare",
												"dataType": "text",
												"dataValue": "char"
											},
											"operator": {
												"actualValue": "="
											},
											"rhs": {
												"@type": "keyword",
												"dataType": "text",
												"dataValue": "value"
											}
										},
										"name": "Melisa"
									},
									{
										"condition": {
											"@type": "logical",
											"type": "and",
											"rules": [
												{
													"@type": "relational",
													"lhs": {
														"@type": "variable",
														"dataValue": "prefixArray@local",
														"dataType": "list"
													},
													"operator": {
														"actualValue": "nContains"
													},
													"rhs": {
														"@type": "variable",
														"dataValue": "char@local",
														"dataType": "text"
													}
												},
												{
													"@type": "relational",
													"lhs": {
														"@type": "keyword",
														"dataValue": "list",
														"dataType": "number",
														"keywordArguments": {
															"format": "length",
															"init": {
																"value": "prefixArray@local"
															}
														}
													},
													"operator": {
														"actualValue": "<"
													},
													"rhs": {
														"@type": "literal",
														"dataValue": 3,
														"dataType": "number"
													}
												}
											]
										},
										"@type": "ConditionalStatement",
										"success": {
											"name": "transformation",
											"statements": [
												{
													"id": "786493412366609",
													"@type": "AssignmentStatement",
													"assignment": {
														"@type": "SimpleAssignmentStatement",
														"lhs": {
															"@type": "declare",
															"dataValue": "prefixArray",
															"dataType": "text"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "keyword",
															"dataValue": "list",
															"dataType": "text",
															"keywordArguments": {
																"format": "push",
																"init": {
																	"values": [
																		"char@local"
																	]
																}
															}
														}
													},
													"name": "Lysanne"
												}
											],
											"id": "414938007380837"
										}
									}
								]
							}
						},
						"format": "iterate"
					}
				}
			},
			"name": "Ismael"
		},
		{
			"id": "693999264665773",
			"@type": "AssignmentStatement",
			"assignment": {
				"@type": "SimpleAssignmentStatement",
				"lhs": {
					"@type": "literal",
					"dataValue": "finalText",
					"dataType": "list"
				},
				"operator": {
					"actualValue": "="
				},
				"rhs": {
					"@type": "keyword",
					"dataValue": "list",
					"dataType": "list",
					"keywordArguments": {
						"format": "generateCombinations",
						"init": {
							"value": "prefixArray@local"
						}
					}
				}
			},
			"name": "Kaycee"
		}
		]
	}
  }`

const TestingConditionAtFalseCase = `{
	"version": 3.3,
	"@type": "transform",
	"transform": {
		"id": "transform_custodetails",
		"name": "Request payload Transformation",
		"statements": [
			{
				"id": "414935082727881",
				"@type": "AssignmentStatement",
				"assignment": {
					"lhs": {
						"@type": "declare",
						"dataType": "boolean",
						"dataValue": "flag"
					},
					"operator": {
						"actualValue": "="
					},
					"rhs": {
						"@type": "literal",
						"dataType": "boolean",
						"dataValue": false
					}
				},
				"name": "Melisa"
			},
			{
				"condition": {
					"@type": "logical",
					"type": "and",
					"rules": [
						{
							"@type": "relational",
							"lhs": {
								"@type": "variable",
								"dataValue": "flag@local",
								"dataType": "boolean"
							},
							"operator": {
								"actualValue": "=="
							},
							"rhs": {
								"@type": "literal",
								"dataValue": false,
								"dataType": "boolean"
							}
						}
					]
				},
				"@type": "ConditionalStatement",
				"success": {
					"name": "transformation",
					"statements": [
						{
							"id": "414935082727881",
							"@type": "AssignmentStatement",
							"assignment": {
								"lhs": {
									"@type": "literal",
									"dataType": "boolean",
									"dataValue": "condition"
								},
								"operator": {
									"actualValue": "="
								},
								"rhs": {
									"@type": "literal",
									"dataType": "boolean",
									"dataValue": "success"
								}
							},
							"name": "Melisa"
						}
					],
					"id": "414938007380837"
				},
				"failure": {
					"name": "transformation",
					"statements": [
						 {
							"id": "414935082727881",
							"@type": "AssignmentStatement",
							"assignment": {
								"lhs": {
									"@type": "literal",
									"dataType": "boolean",
									"dataValue": "condition"
								},
								"operator": {
									"actualValue": "="
								},
								"rhs": {
									"@type": "literal",
									"dataType": "boolean",
									"dataValue": "failed"
								}
							},
							"name": "Melisa"
						}
					],
					"id": "414938007380837"
				}
			}
		]
	}
  }`

const TestLocalIndexValue = `{
	"id": 16970,
	"name": "applicanttransform",
	"@type": "transform",
	"debug": false,
	"version": 4,
	"transform": {
	  "id": 16970,
	  "name": "applicanttransform",
	  "statements": [
		{
		  "id": 1714395082439436,
		  "name": "NearTrash",
		  "@type": "AssignmentStatement",
		  "mandatory": true,
		  "assignment": {
			"lhs": {
			  "@type": "declare",
			  "dataType": "list",
			  "dataValue": "mobile_chunckK"
			},
			"rhs": {
			  "@type": "keyword",
			  "dataType": "list",
			  "dataValue": "text",
			  "keywordArguments": {
				"init": {
				  "value": "mobileNumber",
				  "chunkby": 3
				},
				"format": "chunk"
			  }
			},
			"operator": {
			  "actualValue": "="
			}
		  }
		},
		{
		  "id": 1714395209466758,
		  "name": "DueGun",
		  "@type": "AssignmentStatement",
		  "mandatory": true,
		  "assignment": {
			"lhs": {
			  "@type": "declare",
			  "dataType": "list",
			  "dataValue": "mobile_chunck"
			},
			"rhs": {
			  "@type": "local",
			  "dataType": "list",
			  "dataValue": "mobile_chunckK"
			},
			"operator": {
			  "actualValue": "="
			}
		  }
		},
		{
		  "id": 1714395069594431,
		  "name": "FlightLook",
		  "@type": "ConditionalStatement",
		  "failure": {
			"id": 182902076020352,
			"name": "ELSE Statement 1714395099392858",
			"statements": [
			   {
				"id": 1714395209466758,
				"name": "DueGun",
				"@type": "AssignmentStatement",
				"mandatory": true,
				"assignment": {
				  "lhs": {
					"@type": "literal",
					"dataType": "text",
					"dataValue": "status"
				  },
				  "rhs": {
					"@type": "literal",
					"dataType": "text",
					"dataValue": "failure"
				  },
				  "operator": {
					"actualValue": "="
				  }
				}
			  }
			],
			"jsonIgnoreProperty": false,
			"jsonIgnoreAliasValue": ""
		  },
		  "success": {
			"id": 740724455032900,
			"name": "THEN Statement 1714395055492486",
			"statements": [
			  {
				"id": 1714395209466758,
				"name": "DueGun",
				"@type": "AssignmentStatement",
				"mandatory": true,
				"assignment": {
				  "lhs": {
					"@type": "literal",
					"dataType": "text",
					"dataValue": "status"
				  },
				  "rhs": {
					"@type": "literal",
					"dataType": "text",
					"dataValue": "success"
				  },
				  "operator": {
					"actualValue": "="
				  }
				}
			  }
			],
			"jsonIgnoreProperty": false,
			"jsonIgnoreAliasValue": ""
		  },
		  "condition": {
			"type": "and",
			"@type": "logical",
			"rules": [
			  {
				"lhs": {
				  "@type": "local",
				  "dataType": "text",
				  "dataValue": "mobile_chunck.[0]"
				},
				"rhs": {
				  "@type": "literal",
				  "dataType": "text",
				  "dataValue": "974"
				},
				"@type": "relational",
				"operator": {
				  "actualValue": "=="
				}
			  }
			]
		  },
		  "mandatory": true
		}
	  ],
	  "jsonIgnoreProperty": false,
	  "jsonIgnoreAliasValue": ""
	},
	"contentInputType": "json",
	"ignoreNullFields": false,
	"contentOutputType": "json"
  }`

const TestingErrorMessage = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Boyd",
		  "statements" : [ {
			"id" : "955811403703276",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Errors",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Ellie",
						  "statements" : [ {
							"id" : "955814985972503",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "panNumber",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "pan",
								"dataType" : "text"
							  }
							},
							"name" : "Stephanie"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "955816556635827"
						},
						"id" : "955816910269377"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Ismael"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "955814335256251"
		},
		"id" : "955814200538388"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : {
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Lonny",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "statementId"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataType" : "text",
				  "dataValue" : "955814985972503"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Willard",
				  "statements" : [ {
					"id" : "958777415385605",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "errorMessage",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "there is no Pan number availeble in Payload",
						"dataType" : "text"
					  }
					},
					"name" : "Jocelyn"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "958776487696053"
				},
				"id" : "958773320172067"
			  } ],
			  "id" : "958772861621868"
			},
			"failure" : null,
			"id" : "exception1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "958777702796021"
		},
		"id" : "958774749532170"
	  } ]
	}
  }`

const GetValuesArray = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":"1","mandatory":false,"@type":"AssignmentStatement","assignment":{"lhs":{"@type":"declare","dataValue":"Obj","dataType":"map"},"operator":{"actualValue":"="},"rhs":{"@type":"keyword","dataValue":"map","dataType":"map"}}},{"id":2,"@type":"AssignmentStatement","assignment":{"lhs":{"@type":"declare","dataValue":"abc","dataType":"list"},"operator":{"actualValue":"="},"rhs":{"@type":"function","functionName":"iterate","functionArguments":{"arrayName":"xmlResponse.FIXML.Body.executeFinacleScriptResponse.executeFinacleScript_CustomData.CASHCREDIT","transform":{"id":"transform_config_2","name":"transform Consumer Communication Address Details","statements":[{"id":"1","mandatory":false,"@type":"AssignmentStatement","assignment":{"lhs":{"@type":"declare","dataValue":"Obj","dataType":"map"},"operator":{"actualValue":"="},"rhs":{"@type":"keyword","dataValue":"value","dataType":"map"}}},{"id":"1","@type":"AssignmentStatement","assignment":{"@type":"SimpleAssignmentStatement","lhs":{"@type":"declare","dataValue":"valueSet","dataType":"text"},"operator":{"actualValue":"="},"rhs":{"@type":"keyword","dataValue":"map","dataType":"text","keywordArguments":{"format":"getValueSet","init":{"value":"Obj@local"}}}}},{"id":"1","mandatory":false,"@type":"AssignmentStatement","assignment":{"lhs":{"@type":"declare","dataValue":"Obj","dataType":"map"},"operator":{"actualValue":"="},"rhs":{"@type":"literal","dataValue":null,"dataType":"map"}}}]}},"dataType":"list"}}},{"id":"1","mandatory":false,"@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"valueSet","dataType":"list"},"operator":{"actualValue":"="},"rhs":{"@type":"variable","dataValue":"valueSet@local","dataType":"list"}}}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":""},"contentInputType":"json","ignoreNullFields":false,"contentOutputType":"json"}`

const Iterate_AppendingArrays = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Keenan",
		  "statements" : [ {
			"id" : "960646026284392",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "a.b.c",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "list",
				"dataType" : "list",
				"keywordArguments" : {
				  "format" : "iterate",
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"id" : "1",
						"@type" : "AssignmentStatement",
						"assignment" : {
						  "@type" : "SimpleAssignmentStatement",
						  "lhs" : {
							"@type" : "literal",
							"dataValue" : "player",
							"dataType" : "text"
						  },
						  "operator" : {
							"actualValue" : "="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataValue" : "name",
							"dataType" : "text"
						  }
						}
					  }, {
						"id" : "1",
						"@type" : "AssignmentStatement",
						"assignment" : {
						  "@type" : "SimpleAssignmentStatement",
						  "lhs" : {
							"@type" : "literal",
							"dataValue" : "score",
							"dataType" : "text"
						  },
						  "operator" : {
							"actualValue" : "="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataValue" : "rank",
							"dataType" : "text"
						  }
						}
					  } ]
					}
				  }
				}
			  }
			},
			"name" : "Thalia"
		  }, {
			"id" : "961963440536610",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "a.b.c",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "list",
				"dataType" : "list",
				"keywordArguments" : {
				  "format" : "iterate",
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"id" : "1",
						"@type" : "AssignmentStatement",
						"assignment" : {
						  "@type" : "SimpleAssignmentStatement",
						  "lhs" : {
							"@type" : "literal",
							"dataValue" : "player",
							"dataType" : "text"
						  },
						  "operator" : {
							"actualValue" : "="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataValue" : "name",
							"dataType" : "text"
						  }
						}
					  }, {
						"id" : "1",
						"@type" : "AssignmentStatement",
						"assignment" : {
						  "@type" : "SimpleAssignmentStatement",
						  "lhs" : {
							"@type" : "literal",
							"dataValue" : "score",
							"dataType" : "text"
						  },
						  "operator" : {
							"actualValue" : "="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataValue" : "rank",
							"dataType" : "text"
						  }
						}
					  } ]
					}
				  }
				}
			  }
			},
			"name" : "Webster"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "961969992720980"
		},
		"id" : "961961944452201"
	  } ]
	}
  }`

const MultipleRuleswithDifferentOperators = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Lysanne",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "or",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataType" : "text",
				  "dataValue" : "name"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "Surya",
				  "dataType" : "text"
				}
			  }, {
				"@type" : "logical",
				"type" : "and",
				"rules" : [ {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataType" : "text",
					"dataValue" : "name"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataValue" : "javeed",
					"dataType" : "text"
				  }
				}, {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataType" : "number",
					"dataValue" : "age"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataValue" : 23,
					"dataType" : "number"
				  }
				} ]
			  }, {
				"@type" : "logical",
				"type" : "and",
				"rules" : [ {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataType" : "text",
					"dataValue" : "name"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataValue" : "sreekanth",
					"dataType" : "text"
				  }
				}, {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataType" : "number",
					"dataValue" : "age"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataValue" : 22,
					"dataType" : "number"
				  }
				} ]
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Diego",
				  "statements" : [ {
					"id" : "964731771590121",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "condition",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : true,
						"dataType" : "text"
					  }
					},
					"name" : "Keshaun"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "964735254479569"
				},
				"id" : "964736405139743"
			  } ],
			  "id" : "964732904994056"
			},
			"failure" : null,
			"id" : 1
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "964737850000458"
		},
		"id" : "964739223553002"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const KeywordErrorData = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Malika",
		  "statements" : [ {
			"id" : "965544288022753",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "BirthDay_Month",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "getMonth",
				  "init" : {
					"value" : "startDate",
					"format" : "dd-MM-yyyy"
				  }
				}
			  }
			},
			"name" : "Davon"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "965549286815701"
		},
		"id" : "965541127512350"
	  } ]
	},
	"errors" : {
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Haven",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "statementId"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataType" : "text",
				  "dataValue" : "965544288022753"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Robin",
				  "statements" : [ {
					"id" : "966312195700505",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "error.code",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "Davon_error.code@local",
						"dataType" : "text"
					  }
					},
					"name" : "Brent"
				  }, {
					"id" : "966695641676496",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "error.message",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "Davon_error.message@local",
						"dataType" : "text"
					  }
					},
					"name" : "Nathan"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "966691280880370"
				},
				"id" : "966697052642262"
			  } ],
			  "id" : "966698123518488"
			},
			"failure" : null,
			"id" : "exception1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "966695543248164"
		},
		"id" : "966697935954367"
	  } ]
	}
  }`

const BreakIterate = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Ara",
		  "statements" : [ {
			"id" : "967112973432817",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "sum",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Aubrey"
		  }, {
			"id" : "967986013523972",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "iteratedList",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					  "break": {
						  "@type": "logical",
						  "type": "and",
						  "rules": [
							  {
								  "@type": "relational",
								  "lhs": {
									  "@type": "local",
									  "dataValue": "sum",
									  "dataType": "text"
								  },
								  "operator": {
									  "actualValue": "=="
								  },
								  "rhs": {
									  "@type": "literal",
									  "dataValue": 5,
									  "dataType": "text"
								  }
							  }
						  ]
					  },
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Tony",
						  "statements" : [ {
							"id" : "967734094514944",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "nameOfThe",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataValue" : "value",
								"dataType" : "text"
							  }
							},
							"name" : "Alvis"
						  }, {
							"id" : "967984571634731",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "sum",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "sum"
								  }, {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 1
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Ludwig"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "967986629049157"
						},
						"id" : "967984843074111"
					  } ]
					},
					"value" : "array"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Tate"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "967982570117712"
		},
		"id" : "967989571737993"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const MandatoryStatement = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Guiseppe",
		  "statements" : [ {
			"id" : "969063814263662",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "currentDate",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "type" : "day",
				  "format" : "unixTime"
				}
			  }
			},
			"name" : "Cletus"
		  }, {
			"id" : "969549867292392",
			"mandatory" : false,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "currentDate",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date1",
				"dataType" : "date",
				"keywordArguments" : {
				  "type" : "Day",
				  "format" : "unixTime"
				}
			  }
			},
			"name" : "Stewart"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "StringArray",
				  "dataType" : "list"
				},
				"operator" : {
				  "actualValue" : "contains"
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "abcd",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Zoe",
				  "statements" : [ {
					"id" : "970164138256024",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "condition",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : true,
						"dataType" : "text"
					  }
					},
					"name" : "Eulalia"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "970161042291617"
				},
				"id" : "970161698716729"
			  } ],
			  "id" : "970163794474659"
			},
			"failure" : null,
			"id" : 3
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "970165584090990"
		},
		"id" : "970166917239865"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const ExceptionHandlingTransFormInside = `{
	"version" : 1,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "transform cibilresponse for Grid",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Raleigh",
		  "statements" : [ {
			"id" : "970377930353365",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "1st_Satatement",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "1st_Statement",
				"dataType" : "number"
			  }
			},
			"name" : "Ladarius"
		  }, {
			"id" : "970875119892599",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "dummyArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Kristofer",
						  "statements" : [ {
							"id" : "970875618737566",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "address1",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "=",
								"expressionType" : "SimpleAssignment",
								"dataType" : "text"
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "address1",
								"dataType" : "number"
							  }
							},
							"name" : "Juliet"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "970875837035964"
						},
						"id" : "970873884616494"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Anna"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "970874457528058"
		},
		"id" : "970871208750513"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : {
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Arnold",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "statementId"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataType" : "text",
				  "dataValue" : "2"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Herbert",
				  "statements" : [ {
					"id" : "971613966942583",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "insideTransForm",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "transformSatement",
						"dataType" : "text"
					  }
					},
					"name" : "Destany"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "971614232960518"
				},
				"id" : "971614931078743"
			  } ],
			  "id" : "971618851399684"
			},
			"failure" : null,
			"id" : "exception1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "971617042893005"
		},
		"id" : "971619149717087"
	  } ]
	}
  }`

const ExceptionInsideStatement = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "jsonIgnoreProperty" : true,
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : true,
		  "name" : "Otis",
		  "statements" : [ {
			"id" : "972418929644222",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Errors",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "jsonIgnoreProperty" : false,
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Pat",
						  "statements" : [ {
							"id" : "972418601943159",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "Cname",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "name",
								"dataType" : "text"
							  }
							},
							"name" : "Frank"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "972417190996748"
						},
						"id" : "972415991625429"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Lea"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "972415176479809"
		},
		"id" : "972419188681897"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : {
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : true,
		  "name" : "Matilde",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "statementId"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataType" : "text",
				  "dataValue" : "972418601943159"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : true,
				  "name" : "Tom",
				  "statements" : [ {
					"id" : "972834420102527",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "errorMessage",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "InnerStatement_Executed, Because of Errror Occured",
						"dataType" : "text"
					  }
					},
					"name" : "Arlene"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "972831237363589"
				},
				"id" : "972838620914397"
			  } ],
			  "id" : "972832997867979"
			},
			"failure" : null,
			"id" : "exception1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "972836684084105"
		},
		"id" : "972832898792252"
	  } ]
	}
  }`

const LocalArray = `{
	"transform" : {
	  "id" : "transform_config_2",
	  "name" : "transform Consumer Communication Address Details",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Genevieve",
		  "statements" : [ {
			"id" : "974248499902447",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "enquiryDetailsInLast24Month",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Jerald",
						  "statements" : [ {
							"id" : "973629319234873",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "enquiryDt",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataValue" : "date",
								"dataType" : "date",
								"keywordArguments" : {
								  "format" : "unixTime",
								  "init" : {
									"value" : "enquiryDt",
									"format" : "dd-MMM-yyyy"
								  }
								}
							  }
							},
							"name" : "Karina"
						  }, {
							"id" : "973831239472072",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "enquiryPurpose",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "enquiryPurpose",
								"dataType" : "text"
							  }
							},
							"name" : "Cordie"
						  }, {
							"id" : "974093974961612",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "enquiryAmt",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "enquiryAmt",
								"dataType" : "text"
							  }
							},
							"name" : "Arden"
						  }, {
							"id" : "974242710517784",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "creditLender",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "creditLender",
								"dataType" : "text"
							  }
							},
							"name" : "Bria"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "974249947318494"
						},
						"id" : "974243870533068"
					  } ]
					},
					"value" : "enquiryDetailsInLast24Month"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Jules"
		  }, {
			"id" : "974451625147937",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "DummyArray",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "enquiryDetailsInLast24Month",
				"dataType" : "text"
			  }
			},
			"name" : "General"
		  }, {
			"id" : "974682644274260",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "key",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "Corporate credit card/Unsecured business loan/Derivatives/Unsecured Loan (refer Annex. B for validations)",
				"dataType" : "text"
			  }
			},
			"name" : "Abbie"
		  }, {
			"id" : "975043516142955",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "UnSecured",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "key@local",
					"splitby" : "/"
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Chadd"
		  }, {
			"id" : "975493845473766",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "dummySplittedArray",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "UnSecured",
				"dataType" : "text"
			  }
			},
			"name" : "Shyann"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "975494955738113"
		},
		"id" : "975492058628971"
	  } ]
	}
  }`

const CountingArrayOfObjects = `{
	"version" : 1,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "transform Address Details",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Terrill",
		  "statements" : [ {
			"id" : "976504046351606",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "A",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Marlen"
		  }, {
			"id" : "981762050091599",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Counting_objectsintheArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Keshawn",
						  "statements" : [ {
							"id" : "979591010335776",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "A",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "A"
								  }, {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 1
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Toney"
						  }, {
							"id" : "980785151680911",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "documentID",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "local",
								"dataType" : "number",
								"dataValue" : "A"
							  }
							},
							"name" : "Dorris"
						  }, {
							"id" : "981767968067837",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "documenData",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataType" : "number",
								"dataValue" : "data"
							  }
							},
							"name" : "Joyce"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "981769520927271"
						},
						"id" : "981764717717312"
					  } ]
					},
					"value" : "address"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Rudolph"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "981763781509411"
		},
		"id" : "981762041633192"
	  } ]
	}
  }`

const BreakIterateWithPayload = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Randall",
		  "statements" : [ {
			"id" : "982809970618609",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "iteratedList",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					  "break": {
						  "@type": "logical",
						  "type": "and",
						  "rules": [
							  {
								  "@type": "relational",
								  "lhs": {
									  "@type": "keyword",
									  "dataValue": "value",
									  "dataType": "text"
								  },
								  "operator": {
									  "actualValue": "=="
								  },
								  "rhs": {
									  "@type": "literal",
									  "dataValue": "sreekanth",
									  "dataType": "text"
								  }
							  }
						  ]
					  },
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Breana",
						  "statements" : [ {
							"id" : "982802718023540",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "name",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataValue" : "value",
								"dataType" : "text"
							  }
							},
							"name" : "Palma"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "982802386875332"
						},
						"id" : "982805546572522"
					  } ]
					},
					"value" : "array"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Alessandro"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "982803559339113"
		},
		"id" : "982805203360919"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const DateDifferenceLocalYears = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "abc",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Dolly",
		  "statements" : [ {
			"id" : "983442028250744",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "startDate",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "01-01-2015",
				"dataType" : "text"
			  }
			},
			"name" : "Kristian"
		  }, {
			"id" : "983682174560692",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "endDate",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "01-01-2022",
				"dataType" : "text"
			  }
			},
			"name" : "Rossie"
		  }, {
			"id" : "983924571038893",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "difference_between_date",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "text",
				"dataValue" : "date",
				"keywordArguments" : {
				  "init" : {
					"start" : {
					  "value" : "startDate@local",
					  "format" : "dd-MM-yyyy"
					},
					"end" : {
					  "value" : "endDate@local",
					  "format" : "dd-MM-yyyy"
					}
				  },
				  "format" : "dateDiff",
				  "type" : "years"
				}
			  }
			},
			"name" : "Edwina"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "983927484350887"
		},
		"id" : "983928034143563"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const ConditionalConfig = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Valentin",
		  "statements" : [
		  {
			"id" : "987087551668971234",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "totalArrearsAmount",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Emmy"
		  },
		  {
			"id" : "985639952631343",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "dummyArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : true,
						  "name" : "Angeline",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "dateClosed",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "amountOverdue",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Roselyn",
								  "statements" : [ {
									"id" : "985373041513469",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "totalArrearsAmount",
										"dataType" : "number"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "expression",
										"structure" : {
										  "@type" : "arithmetic",
										  "dataType" : "+",
										  "variables" : [ {
											"@type" : "local",
											"dataType" : "number",
											"dataValue" : "totalArrearsAmount"
										  }, {
											"@type" : "variable",
											"dataType" : "number",
											"dataValue" : "amountOverdue"
										  } ]
										},
										"dataType" : "number"
									  }
									},
									"name" : "Cassandre"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "985375977529168"
								},
								"id" : "985375301953897"
							  } ],
							  "id" : "985371111784009"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"id" : "985639317345505",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "interanalValAfterUpdate",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "local",
								"dataValue" : "totalArrearsAmount",
								"dataType" : "text"
							  }
							},
							"name" : "Freida"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "985633325921662"
						},
						"id" : "985637813319622"
					  } ]
					},
					"value" : "response.accountSegmentTL"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Margarette"
		  }, {
			"id" : "987087551668971",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "sumOfVal",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "totalArrearsAmount",
				"dataType" : "text"
			  }
			},
			"name" : "Emmy"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "987085193976196"
		},
		"id" : "987084802425873"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const KeywordDateInDays = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Cordell",
		  "statements" : [ {
			"id" : "988325557417009",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "experienceInYears",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "number",
				"keywordArguments" : {
				  "format" : "inMonths",
				  "init" : {
					"value" : "experienceInDays",
					"format" : "inDays"
				  }
				}
			  }
			},
			"name" : "Corbin"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "988324898158567"
		},
		"id" : "988326167035778"
	  } ]
	}
  }`

const JsonFlatResponseArrayObjects = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "flatJson",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Alberta",
		  "statements" : [ {
			"id" : "989849995205095",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "estampDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "estampDetails",
				"dataType" : "list"
			  }
			},
			"name" : "Domenica"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "989846162312815"
		},
		"id" : "989849653895640"
	  } ]
	}
  }`

const DateDifferenceMonths = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "abc",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Destany",
		  "statements" : [ {
			"id" : "990767547775348",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "difference_between_date",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "text",
				"dataValue" : "date",
				"keywordArguments" : {
				  "init" : {
					"start" : {
					  "value" : "startDate",
					  "format" : "dd-MM-yyyy"
					},
					"end" : {
					  "value" : "endDate",
					  "format" : "dd-MM-yyyy"
					}
				  },
				  "format" : "dateDiff",
				  "type" : "months"
				}
			  }
			},
			"name" : "Kendall"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "990767283353699"
		},
		"id" : "990764296321041"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const TestTransFormError = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "flatJson",
	"contentOutputType" : "json",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Pattie",
		  "statements" : [ {
			"id" : "991264143781371",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "name",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "customerName",
				"dataType" : "text"
			  }
			},
			"name" : "Amy"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "991265718682645"
		},
		"id" : "991263821749824"
	  } ]
	}
  }`

const ValidationArray = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "validate" : [ {
		"condition" : {
		  "@type" : "logical",
		  "type" : "and",
		  "rules" : [ {
			"@type" : "relational",
			"lhs" : {
			  "@type" : "variable",
			  "dataType" : "text",
			  "dataValue" : "statusMessage"
			},
			"operator" : {
			  "actualValue" : "=="
			},
			"rhs" : {
			  "@type" : "literal",
			  "dataValue" : "OK",
			  "dataType" : "text"
			}
		  } ]
		},
		"error" : {
		  "subcode" : "500",
		  "message" : "Invalid status message"
		}
	  }, {
		"condition" : {
		  "@type" : "logical",
		  "type" : "and",
		  "rules" : [ {
			"@type" : "relational",
			"lhs" : {
			  "@type" : "variable",
			  "dataType" : "text",
			  "dataValue" : "status"
			},
			"operator" : {
			  "actualValue" : "=="
			},
			"rhs" : {
			  "@type" : "literal",
			  "dataValue" : "status",
			  "dataType" : "text"
			}
		  } ]
		},
		"error" : {
		  "subcode" : "500",
		  "message" : "Invalid status"
		}
	  } ],
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Hiram",
		  "statements" : [ {
			"id" : "991873849685855",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "datadata",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "validation success",
				"dataType" : "text"
			  }
			},
			"name" : "Helen"
		  }, {
			"id" : "992079061427898",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "data",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "validation success",
				"dataType" : "text"
			  }
			},
			"name" : "Darrion"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "992078035974793"
		},
		"id" : "992077797081853"
	  } ]
	}
  }`

const UplodDocument = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "flatJson",
	"contentOutputType" : "json",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Wilhelm",
		  "statements" : [ {
			"id" : "992493954947585",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "documentId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section0.documentId",
				"dataType" : "text"
			  }
			},
			"name" : "Oceane"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "992495524634013"
		},
		"id" : "992493318317609"
	  } ]
	}
  }`

const NestedConditions = `{
	"version" : "3.3",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Robyn",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "or",
			  "rules" : [ {
				"@type" : "logical",
				"type" : "and",
				"rules" : [ {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataValue" : "i",
					"dataType" : "number"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataValue" : 1,
					"dataType" : "number"
				  }
				}, {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataValue" : "j",
					"dataType" : "number"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataValue" : 2,
					"dataType" : "number"
				  }
				} ]
			  }, {
				"@type" : "logical",
				"type" : "and",
				"rules" : [ {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataValue" : "i",
					"dataType" : "number"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataValue" : 2,
					"dataType" : "number"
				  }
				}, {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataValue" : "j",
					"dataType" : "number"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataValue" : 1,
					"dataType" : "number"
				  }
				} ]
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Santiago",
				  "statements" : [ {
					"id" : "993276689935322",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "name",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "name",
						"dataType" : "text"
					  }
					},
					"name" : "Conrad"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "993274989359125"
				},
				"id" : "993272282345714"
			  } ],
			  "id" : "993276944967650"
			},
			"failure" : null,
			"id" : "1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "993277678595158"
		},
		"id" : "993287526025174"
	  } ]
	}
  }`

const SectionIsTransform = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":1697107976635457,"name":"Statement 1697108026382390","@type":"SectionalStatement","section":{"jsonIgnoreProperty":true,"jsonIgnoreAliasValue":"no name found","id":38462209397286,"name":"Section Statement 755783","statements":[{"id":1697108034962777,"name":"Statement 1697107973271908","@type":"AssignmentStatement","mandatory":true,"assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"customer.name"},"rhs":{"@type":"variable","dataType":"text","dataValue":"javeed"},"operator":{"actualValue":"="}}}]},"mandatory":true},{"id":1697107976635457,"name":"Statement 1697108026382390","@type":"SectionalStatement","section":{"jsonIgnoreProperty":true,"jsonIgnoreAliasValue":"no age found","id":38462209397286,"name":"Section Statement 755783","statements":[{"id":1697108034962777,"name":"Statement 1697107973271908","@type":"AssignmentStatement","mandatory":true,"assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"customer.age"},"rhs":{"@type":"variable","dataType":"text","dataValue":"javeed"},"operator":{"actualValue":"="}}}]},"mandatory":true}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":null},"contentInputType":"json","contentOutputType":"json"}`

const ErrorRecursive = `{
	"id" : 737001027542418,
	"name" : "/testingErrorSection",
	"@type" : "transform",
	"debug" : false,
	"errors" : {
	  "id" : 737001027542418,
	  "name" : "Error_Statements",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Elmo",
		  "statements" : [ {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : "STATEMENT 737211926838366",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Okey",
				  "statements" : [ {
					"condition" : {
					  "type" : "and",
					  "@type" : "logical",
					  "rules" : [ {
						"lhs" : {
						  "@type" : "keyword",
						  "dataType" : "list",
						  "dataValue" : "list",
						  "keywordArguments" : {
							"init" : {
							  "values" : [ "995101419618143", "994401410344523" ]
							},
							"format" : "multiSelect"
						  }
						},
						"rhs" : {
						  "@type" : "keyword",
						  "dataType" : "text",
						  "dataValue" : "text",
						  "keywordArguments" : {
							"format" : "statementId"
						  }
						},
						"@type" : "relational",
						"operator" : {
						  "actualValue" : "contains"
						}
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "id" : 699306352797201,
					  "name" : "THEN Statement 1704798993634041",
					  "statements" : [ {
						"id" : 1704799067311827,
						"name" : "MapCash",
						"@type" : "AssignmentStatement",
						"mandatory" : true,
						"assignment" : {
						  "lhs" : {
							"@type" : "literal",
							"dataType" : "text",
							"dataValue" : "error"
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataType" : "text",
							"dataValue" : "errorExecuted"
						  },
						  "operator" : {
							"actualValue" : "="
						  }
						}
					  } ]
					},
					"failure" : {
					  "id" : 0,
					  "name" : "ELSE Statement 1704798976179145"
					},
					"id" : 1704798974661373
				  } ],
				  "jsonIgnoreAliasValue" : "",
				  "id" : "996329532514693"
				},
				"id" : "996321159597911"
			  } ],
			  "id" : "996324752028974"
			},
			"id" : 737363300268300
		  } ],
		  "jsonIgnoreAliasValue" : "",
		  "id" : "996324074318086"
		},
		"id" : "996324110232474"
	  } ],
	  "jsonIgnoreProperty" : false,
	  "jsonIgnoreAliasValue" : ""
	},
	"version" : 3,
	"transform" : {
	  "id" : 737001027542418,
	  "name" : "/testingErrorSection",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Peter",
		  "statements" : [ {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : "DressHome",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Martine",
				  "statements" : [ {
					"id" : "994401410344523",
					"name" : "Lauryn",
					"@type" : "AssignmentStatement",
					"mandatory" : true,
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "name"
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "javeed"
					  },
					  "operator" : {
						"actualValue" : "="
					  }
					}
				  }, {
					"id" : "995101419618143",
					"name" : "Lupe",
					"@type" : "AssignmentStatement",
					"mandatory" : true,
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "age"
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataType" : "number",
						"dataValue" : "23"
					  },
					  "operator" : {
						"actualValue" : "="
					  }
					}
				  }, {
					"id" : "995499857950572",
					"name" : "Lila",
					"@type" : "AssignmentStatement",
					"mandatory" : true,
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "nm"
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "sathvika"
					  },
					  "operator" : {
						"actualValue" : "="
					  }
					}
				  } ],
				  "jsonIgnoreAliasValue" : "",
				  "id" : "995499594763133"
				},
				"id" : "995491236143024"
			  } ],
			  "id" : "995493222593152"
			},
			"id" : 1704799223418366
		  } ],
		  "jsonIgnoreAliasValue" : "",
		  "id" : "995491909088991"
		},
		"id" : "995496510922640"
	  } ],
	  "jsonIgnoreProperty" : false,
	  "jsonIgnoreAliasValue" : ""
	},
	"contentInputType" : "json",
	"ignoreNullFields" : false,
	"contentOutputType" : "json"
  }`

const UploadDocument2 = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "flatJson",
	"contentOutputType" : "json",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Uriel",
		  "statements" : [ {
			"id" : "997555120074222",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "data",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "map"
			  }
			},
			"name" : "Dino"
		  }, {
			"id" : "998375181636801",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericId",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.genericId@local",
				"dataType" : "number"
			  }
			},
			"name" : "Kaia"
		  }, {
			"id" : "999243232595423",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "roleId",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.roleId@local",
				"dataType" : "number"
			  }
			},
			"name" : "Hailey"
		  }, {
			"id" : "100362469894274",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "appPackageId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.appPackageId@local",
				"dataType" : "text"
			  }
			},
			"name" : "Liam"
		  }, {
			"id" : "101458184926140",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "type",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.type@local",
				"dataType" : "text"
			  }
			},
			"name" : "Abel"
		  }, {
			"id" : "102608896892667",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "documentId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section0.documentId@local",
				"dataType" : "text"
			  }
			},
			"name" : "Carey"
		  }, {
			"id" : "102899715105930",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "documentName",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section0.documentName@local",
				"dataType" : "text"
			  }
			},
			"name" : "Rosendo"
		  }, {
			"id" : "103101565587945",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "documentType",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section0.documentType@local",
				"dataType" : "text"
			  }
			},
			"name" : "Bryana"
		  }, {
			"id" : "103374156018405",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "esignOrEstampOrNone",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section0.esignorEstamp@local",
				"dataType" : "text"
			  }
			},
			"name" : "Braden"
		  }, {
			"id" : "103632140514896",
			"mandatory" : false,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "signatories",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section0.signatories@local",
				"dataType" : "text"
			  }
			},
			"name" : "Pasquale"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "103635488987800"
		},
		"id" : "103636171431833"
	  }, {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Wilburn",
		  "statements" : [ {
			"id" : "103881381603275",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "state",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section0.state@local",
				"dataType" : "text"
			  }
			},
			"name" : "Tyrique"
		  }, {
			"id" : "104068525067310",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "fileName",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section2.upload.filename@local",
				"dataType" : "text"
			  }
			},
			"name" : "Roma"
		  }, {
			"id" : "104211807141416",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "filetype",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section2.upload.filetype@local",
				"dataType" : "text"
			  }
			},
			"name" : "Roxane"
		  }, {
			"id" : "104429820852199",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "fileData",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "data.section2.upload.value@local",
				"dataType" : "text"
			  }
			},
			"name" : "Francesca"
		  }, {
			"id" : "105379562495422",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "estampDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Lilyan",
						  "statements" : [ {
							"id" : "104897582865744",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "stampDutyAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section0.stampDutyAmount@local",
								"dataType" : "text"
							  }
							},
							"name" : "Nestor"
						  }, {
							"id" : "105044114283086",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "stampDutyPaid",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section0.stampDutyPaid@local",
								"dataType" : "text"
							  }
							},
							"name" : "Edwina"
						  }, {
							"id" : "105213261589480",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "articleCode",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section0.articleCode@local",
								"dataType" : "text"
							  }
							},
							"name" : "Maybelle"
						  }, {
							"id" : "105378761746454",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "considerationPrice",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section0.considerationPrice@local",
								"dataType" : "text"
							  }
							},
							"name" : "Mortimer"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "105371586339721"
						},
						"id" : "105376131778463"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Hank"
		  }, {
			"id" : "106581465069944",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "estampDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Chase",
						  "statements" : [ {
							"id" : "106059707370058",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "stampDutyAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section1.stampDutySecond@local",
								"dataType" : "text"
							  }
							},
							"name" : "Kiara"
						  }, {
							"id" : "106228725037042",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "stampDutyPaid",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section1.stampDutyPaidSecond@local",
								"dataType" : "text"
							  }
							},
							"name" : "Kim"
						  }, {
							"id" : "106398014903623",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "articleCode",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section1.ArticleCodeSecond@local",
								"dataType" : "text"
							  }
							},
							"name" : "Noemie"
						  }, {
							"id" : "106585411705320",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "considerationPrice",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section1.CondiderationSecond@local",
								"dataType" : "text"
							  }
							},
							"name" : "Garland"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "106588054043477"
						},
						"id" : "106584738367893"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Rosemarie"
		  }, {
			"id" : "107881896688958",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "estampDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Maverick",
						  "statements" : [ {
							"id" : "107228717166198",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "stampDutyAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section2.stampDutyThrid@local",
								"dataType" : "text"
							  }
							},
							"name" : "Verla"
						  }, {
							"id" : "107405160060201",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "stampDutyPaid",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section2.stampDutyPaidThird@local",
								"dataType" : "text"
							  }
							},
							"name" : "Lelia"
						  }, {
							"id" : "107605663207700",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "articleCode",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section2.articleCodeThird@local",
								"dataType" : "text"
							  }
							},
							"name" : "Allen"
						  }, {
							"id" : "107885787007708",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "considerationPrice",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "data.section2.considerationThird@local",
								"dataType" : "text"
							  }
							},
							"name" : "Brittany"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "107881808655859"
						},
						"id" : "107884797729791"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Caleigh"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "107882940691481"
		},
		"id" : "107882451546356"
	  } ]
	}
  }`

const IntegerArray = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Ignatius",
		  "statements" : [ {
			"id" : "108267531773242",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "splittedArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"chunkby" : 3,
					"value" : "paymentHistory1"
				  },
				  "format" : "chunk"
				}
			  }
			},
			"name" : "Ashley"
		  }, {
			"id" : "109148965808178",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "IntegerArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Nash",
						  "statements" : [ {
							"id" : "108888170903507",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "localKey",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataValue" : "value",
								"dataType" : "number"
							  }
							},
							"name" : "Damien"
						  }, {
							"id" : "109133997702497",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "days",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataValue" : "text",
								"dataType" : "number",
								"keywordArguments" : {
								  "format" : "toNumber",
								  "init" : {
									"value" : "localKey@local"
								  }
								}
							  }
							},
							"name" : "Sheridan"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "109145683154185"
						},
						"id" : "109148040943671"
					  } ]
					},
					"value" : "splittedArray@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Alek"
		  }, {
			"id" : "109448812025337",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "splittedArray",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "splittedArray",
				"dataType" : "text"
			  }
			},
			"name" : "Madisen"
		  }, {
			"id" : "109658545523392",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "A",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 1,
				"dataType" : "number"
			  }
			},
			"name" : "Penelope"
		  }, {
			"id" : "110453805961340",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "dummyArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Efrain",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Angelita",
								  "statements" : [ {
									"id" : "110364940142494",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "firstElement",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Joesph"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "110362991200198"
								},
								"id" : "110368335086714"
							  } ],
							  "id" : "110369504727452"
							},
							"failure" : null,
							"id" : 2
						  }, {
							"id" : "110458891211542",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "A",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 3,
								"dataType" : "number"
							  }
							},
							"name" : "Reagan"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "110454140469025"
						},
						"id" : "110454734133639"
					  } ]
					},
					"value" : "splittedArray@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Winston"
		  }, {
			"id" : "110647873293918",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "firstElement",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "firstElement",
				"dataType" : "text"
			  }
			},
			"name" : "Brennon"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "110644403721424"
		},
		"id" : "110644662503561"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const TestLocalArrayIndexOf = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":"1","@type":"AssignmentStatement","assignment":{"@type":"SimpleAssignmentStatement","lhs":{"@type":"declare","dataValue":"a.list","dataType":"text"},"operator":{"actualValue":"="},"rhs":{"@type":"variable","dataValue":"arrResponseVO.otherScoresData","dataType":"text"}}},{"id":"1","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"scorePrimitive","dataType":"number"},"operator":{"actualValue":"="},"rhs":{"@type":"local","dataValue":"a.list.prim.[2]","dataType":"number"}}},{"id":"1","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"scoreValue","dataType":"number"},"operator":{"actualValue":"="},"rhs":{"@type":"local","dataValue":"a.list.scoresList.[2].scoreValue","dataType":"number"}}},{"id":"1","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"scoresListObject","dataType":"number"},"operator":{"actualValue":"="},"rhs":{"@type":"local","dataValue":"a.list.scoresList.[1]","dataType":"number"}}}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":null},"contentInputType":"json","contentOutputType":"json"}`

const IterateTransformLocal = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Ozella",
		  "statements" : [ {
			"id" : "110912012867831",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "response",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "response",
				"dataType" : "list"
			  }
			},
			"name" : "Joanie"
		  }, {
			"id" : "111537849763977",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "FilteredData",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"filter" : {
				  "id" : "111531543912813",
				  "name" : "filteraccountsbytype",
				  "condition" : {
					"@type" : "logical",
					"type" : "and",
					"rules" : [ {
					  "@type" : "relational",
					  "lhs" : {
						"@type" : "variable",
						"dataType" : "text",
						"dataValue" : "dateClosed"
					  },
					  "operator" : {
						"actualValue" : "=="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "yes",
						"dataType" : "text"
					  }
					} ]
				  }
				},
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Matt",
						  "statements" : [ {
							"id" : "111534804884665",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "dateClosed",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "dateClosed",
								"dataType" : "text"
							  }
							},
							"name" : "Betsy"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "111534858969148"
						},
						"id" : "111539079604713"
					  } ]
					},
					"value" : "response@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Heidi"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "111538561159936"
		},
		"id" : "111539774246930"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : { }
  }`

const IterateEmptyFields = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Eloisa",
		  "statements" : [ {
			"id" : "111859885643302",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "customer.ratings",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"fields" : { },
					"value" : "MonthlyData.data"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Orlo"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "111851282355157"
		},
		"id" : "111853151708890"
	  } ]
	}
  }`

const KeywordDateInYears = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Hortense",
		  "statements" : [ {
			"id" : "112246335568466",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "experienceInYears",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "number",
				"keywordArguments" : {
				  "format" : "inYears",
				  "init" : {
					"value" : "experienceInMonths",
					"format" : "inMonths"
				  }
				}
			  }
			},
			"name" : "Libbie"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "112243654261504"
		},
		"id" : "112243855256583"
	  } ]
	}
  }`

const ExceptionHandling = `{
	"version": "1",
	"@type": "transform",
	"transform": {
	  "id": "transform_config_1",
	  "name": "Filter the Date Repsonse",
	  "statements": [
		{
		  "@type": "SectionalStatement",
		  "section": {
			"jsonIgnoreProperty": false,
			"name": "Lawrence",
			"statements": [
			  {
				"id": "112619276746826",
				"@type": "AssignmentStatement",
				"assignment": {
				  "@type": "SimpleAssignmentStatement",
				  "lhs": {
					"@type": "literal",
					"dataValue": "Customer.Details",
					"dataType": "text"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "variable",
					"dataValue": "details",
					"dataType": "text"
				  }
				},
				"name": "Camylle"
			  }
			],
			"jsonIgnoreAliasValue": null,
			"id": "112612357813155"
		  },
		  "id": "112612990758441"
		}
	  ]
	},
	"delete": {},
	"extract": {},
	"errors": {
	  "statements": [
		{
		  "@type": "SectionalStatement",
		  "section": {
			"jsonIgnoreProperty": false,
			"name": "Ayla",
			"statements": [
			  {
				"condition": {
				  "@type": "logical",
				  "type": "and",
				  "rules": [
					{
					  "@type": "relational",
					  "lhs": {
						"@type": "keyword",
						"dataType": "text",
						"dataValue": "statementId"
					  },
					  "operator": {
						"actualValue": "=="
					  },
					  "rhs": {
						"@type": "literal",
						"dataType": "text",
						"dataValue": "112619276746826"
					  }
					}
				  ]
				},
				"@type": "ConditionalStatement",
				"success": {
				  "name": "transformation",
				  "statements": [
					{
					  "@type": "SectionalStatement",
					  "section": {
						"jsonIgnoreProperty": false,
						"name": "Allan",
						"statements": [
						  {
							"id": "113089550934724",
							"@type": "AssignmentStatement",
							"assignment": {
							  "@type": "SimpleAssignmentStatement",
							  "lhs": {
								"@type": "literal",
								"dataValue": "Customer.Details",
								"dataType": "text"
							  },
							  "operator": {
								"actualValue": "="
							  },
							  "rhs": {
								"@type": "literal",
								"dataValue": "detailes are not available from the payload",
								"dataType": "text"
							  }
							},
							"name": "Sophie"
						  }
						],
						"jsonIgnoreAliasValue": null,
						"id": "113089359856447"
					  },
					  "id": "113084358320735"
					}
				  ],
				  "id": "113089029693073"
				},
				"failure": null,
				"id": "exception1"
			  },
			  {
				"condition": {
				  "@type": "logical",
				  "type": "and",
				  "rules": [
					{
					  "@type": "relational",
					  "lhs": {
						"@type": "keyword",
						"dataType": "text",
						"dataValue": "statementId"
					  },
					  "operator": {
						"actualValue": "=="
					  },
					  "rhs": {
						"@type": "literal",
						"dataType": "text",
						"dataValue": "12"
					  }
					}
				  ]
				},
				"@type": "ConditionalStatement",
				"success": {
				  "name": "transformation",
				  "statements": [
					{
					  "@type": "SectionalStatement",
					  "section": {
						"jsonIgnoreProperty": false,
						"name": "Randall",
						"statements": [
						  {
							"id": "113378493513595",
							"@type": "AssignmentStatement",
							"assignment": {
							  "@type": "SimpleAssignmentStatement",
							  "lhs": {
								"@type": "literal",
								"dataValue": "Customer.mobleNumber",
								"dataType": "text"
							  },
							  "operator": {
								"actualValue": "="
							  },
							  "rhs": {
								"@type": "literal",
								"dataValue": "mobile not available",
								"dataType": "text"
							  }
							},
							"name": "Cordie"
						  }
						],
						"jsonIgnoreAliasValue": null,
						"id": "113374249541670"
					  },
					  "id": "113373793665668"
					}
				  ],
				  "id": "113379868436090"
				},
				"failure": null,
				"id": "exception2"
			  }
			],
			"jsonIgnoreAliasValue": null,
			"id": "113378954548378"
		  },
		  "id": "113371720390069"
		}
	  ]
	}
  }`

const IterateConfig = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Christop",
		  "statements" : [ {
			"id" : "114175488175590",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "garbageArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Anita",
						  "statements" : [ {
							"id" : "114162669496226",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "amountOverdue",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "amountOverdue",
								"dataType" : "text"
							  }
							},
							"name" : "Bertram"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "114166885112245"
						},
						"id" : "114174423467428"
					  } ]
					},
					"value" : "response"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Raymond"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "114173696036670"
		},
		"id" : "114179267843080"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : { }
  }`

const ISnullWithErrorConfig = `{
	"version": "1",
	"@type": "transform",
	"transform": {
	  "id": "transform_config_1",
	  "name": "Filter the Date Repsonse",
	  "statements": [
		{
		  "@type": "SectionalStatement",
		  "section": {
			"jsonIgnoreProperty": false,
			"name": "Orie",
			"statements": [
			  {
				"id": "114569362473274",
				"@type": "AssignmentStatement",
				"assignment": {
				  "lhs": {
					"@type": "declare",
					"dataValue": "sum",
					"dataType": "number"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "literal",
					"dataValue": 0,
					"dataType": "number"
				  }
				},
				"name": "Everett"
			  },
			  {
				"id": "115236688038246",
				"@type": "AssignmentStatement",
				"assignment": {
				  "lhs": {
					"@type": "declare",
					"dataValue": "garbageArray",
					"dataType": "list"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "keyword",
					"dataType": "list",
					"dataValue": "list",
					"keywordArguments": {
					  "init": {
						"transform": {
						  "id": "transform_config_2",
						  "name": "transform Consumer Communication Address Details",
						  "statements": [
							{
							  "@type": "SectionalStatement",
							  "section": {
								"jsonIgnoreProperty": false,
								"name": "Willis",
								"statements": [
								  {
									"condition": {
									  "@type": "logical",
									  "type": "and",
									  "rules": [
										{
										  "@type": "relational",
										  "lhs": {
											"@type": "variable",
											"dataType": "text",
											"dataValue": "isSafe"
										  },
										  "operator": {
											"actualValue": "=="
										  },
										  "rhs": {
											"@type": "keyword",
											"dataType": "text",
											"dataValue": "text",
											"keywordArguments": {
											  "format": "getNullValue"
											}
										  }
										}
									  ]
									},
									"@type": "ConditionalStatement",
									"success": {
									  "name": "transformation",
									  "statements": [
										{
										  "@type": "SectionalStatement",
										  "section": {
											"jsonIgnoreProperty": false,
											"name": "Adrien",
											"statements": [
											  {
												"id": "115238335044128",
												"@type": "AssignmentStatement",
												"assignment": {
												  "@type": "SimpleAssignmentStatement",
												  "lhs": {
													"@type": "declare",
													"dataValue": "sum",
													"dataType": "number"
												  },
												  "operator": {
													"actualValue": "="
												  },
												  "rhs": {
													"@type": "expression",
													"structure": {
													  "@type": "arithmetic",
													  "dataType": "+",
													  "variables": [
														{
														  "@type": "local",
														  "dataType": "number",
														  "dataValue": "sum"
														},
														{
														  "@type": "variable",
														  "dataType": "number",
														  "dataValue": "amountOverdue"
														}
													  ]
													},
													"dataType": "number"
												  }
												},
												"name": "Ines"
											  }
											],
											"jsonIgnoreAliasValue": null,
											"id": "115235323554381"
										  },
										  "id": "115236213163881"
										}
									  ],
									  "id": "115235311320056"
									},
									"failure": null,
									"id": "1-1"
								  }
								],
								"jsonIgnoreAliasValue": null,
								"id": "115236445107163"
							  },
							  "id": "115235374072393"
							}
						  ]
						},
						"value": "response"
					  },
					  "format": "iterate"
					}
				  }
				},
				"name": "Hulda"
			  },
			  {
				"id": "115451162307586",
				"@type": "AssignmentStatement",
				"assignment": {
				  "@type": "SimpleAssignmentStatement",
				  "lhs": {
					"@type": "literal",
					"dataValue": "sum",
					"dataType": "number"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "local",
					"dataValue": "sum",
					"dataType": "number"
				  }
				},
				"name": "Ludie"
			  }
			],
			"jsonIgnoreAliasValue": null,
			"id": "115454546442761"
		  },
		  "id": "115452673838222"
		}
	  ]
	},
	"delete": {},
	"extract": {},
	"errors": {
	  "statements": [
		{
		  "condition": {
			"@type": "logical",
			"type": "and",
			"rules": [
			  {
				"@type": "relational",
				"lhs": {
				  "@type": "keyword",
				  "dataType": "text",
				  "dataValue": "statementId"
				},
				"operator": {
				  "actualValue": "=="
				},
				"rhs": {
				  "@type": "literal",
				  "dataValue": "1-1",
				  "dataType": "text"
				}
			  }
			]
		  },
		  "@type": "ConditionalStatement",
		  "success": {
			"name": "transformation",
			"statements": [
			  {
				"id": "116186947900559",
				"@type": "AssignmentStatement",
				"assignment": {
				  "@type": "SimpleAssignmentStatement",
				  "lhs": {
					"@type": "declare",
					"dataValue": "sum",
					"dataType": "number"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "expression",
					"structure": {
					  "@type": "arithmetic",
					  "dataType": "+",
					  "variables": [
						{
						  "@type": "local",
						  "dataType": "number",
						  "dataValue": "sum"
						},
						{
						  "@type": "variable",
						  "dataType": "number",
						  "dataValue": "amountOverdue"
						}
					  ]
					},
					"dataType": "number"
				  }
				},
				"name": "Mittie"
			  }
			],
			"id": "116183575195863"
		  },
		  "failure": null,
		  "id": "1-1"
		}
	  ]
	}
  }`

const JsonFlattenArrayToUnFlattenArray = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "flatJson",
	"contentOutputType" : "json",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Dedrick",
		  "statements" : [ {
			"id" : "116631472096049",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "response",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "list"
			  }
			},
			"name" : "Mikayla"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "116638559281857"
		},
		"id" : "116634399999092"
	  } ]
	}
  }`

const ObjectIterate = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Alberta",
		  "statements" : [ {
			"id" : "117169157101119",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "dateFormatter",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "dd-MM-yyyy",
				  "init" : {
					"value" : "startDate",
					"format" : "yyyy-MM-dd HH:mm:ss"
				  }
				}
			  }
			},
			"name" : "Zella"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "117161558652235"
		},
		"id" : "117167743728234"
	  } ]
	}
  }`

const DateConfiggetYear = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Oma",
		  "statements" : [ {
			"id" : "117537824627919",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "BirthDay_year",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "getYear",
				  "init" : {
					"value" : "startDate",
					"format" : "dd-MM-yyyy"
				  }
				}
			  }
			},
			"name" : "Edwina"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "117543384552545"
		},
		"id" : "117544333612698"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const ConvertJsontoText = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":3,"@type":"AssignmentStatement","assignment":{"@type":"SimpleAssignmentStatement","lhs":{"@type":"literal","dataValue":"c","dataType":"number"},"operator":{"actualValue":"="},"rhs":{"@type":"expression","structure":{"@type":"arithmetic","dataType":"+","variables":[{"@type":"literal","dataType":"number","dataValue":"100"},{"@type":"literal","dataType":"number","dataValue":"90"}]},"dataType":"number"}}}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":null},"contentInputType":"json","contentOutputType":"json"}`

const ConditonalPrimitives = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Lela",
		  "statements" : [ {
			"id" : "118271601622761",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "CollecteD_Keys",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "Collect",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Fred",
						  "statements" : [ {
							"id" : "118271976052013",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "primitives",
								"dataType" : "list"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "function",
								"functionName" : "collect",
								"functionArguments" : {
								  "pick" : "key",
								  "condition" : {
									"@type" : "logical",
									"type" : "and",
									"rules" : [ {
									  "@type" : "relational",
									  "lhs" : {
										"@type" : "keyword",
										"dataValue" : "mapvalue",
										"dataType" : "boolean"
									  },
									  "operator" : {
										"actualValue" : "=="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : true,
										"dataType" : "boolean"
									  }
									} ]
								  }
								},
								"dataType" : "list"
							  }
							},
							"name" : "Eve"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "118278182919757"
						},
						"id" : "118278544745224"
					  } ]
					},
					"value" : "relatedParties"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Donny"
		  }, {
			"id" : "119356099390963",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "customerMappingObject",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "transform Address Information",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Violet",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "or",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "director",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "partner",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "Proprietor",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "karta",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "pOAHolder",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "coParcener",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "shareHolder",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "authorisedSignatory",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Earline",
								  "statements" : [ {
									"id" : "119352089776142",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "customerMapping",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "list",
										"dataValue" : "list",
										"keywordArguments" : {
										  "init" : {
											"transform" : {
											  "id" : "transform_config_1",
											  "name" : "customer Response",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Emmie",
												  "statements" : [ {
													"id" : "119354942597946",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataValue" : "keys",
														"dataType" : "text"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "keyword",
														"dataValue" : "value",
														"dataType" : "text"
													  }
													},
													"name" : "Fannie"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "119355971213356"
												},
												"id" : "119358972951378"
											  } ]
											}
										  },
										  "format" : "iterate"
										}
									  }
									},
									"name" : "Kendra"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "119355628639667"
								},
								"id" : "119354894844825"
							  } ],
							  "id" : "119359029729520"
							},
							"failure" : null,
							"id" : 1
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "119358167523641"
						},
						"id" : "119351928758821"
					  } ]
					},
					"value" : "primitives@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Alvena"
		  }, {
			"id" : "119576584286408",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "AllKeys",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "customerMapping",
				"dataType" : "text"
			  }
			},
			"name" : "Francis"
		  }, {
			"id" : "120198766352458",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "myValues",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "Collect",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Ana",
						  "statements" : [ {
							"id" : "120193871258049",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "expectedArray",
								"dataType" : "list"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "function",
								"functionName" : "collect",
								"functionArguments" : {
								  "pick" : "value"
								},
								"dataType" : "list"
							  }
							},
							"name" : "Owen"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "120198230482119"
						},
						"id" : "120192946672591"
					  } ]
					},
					"value" : "customerMapping@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Gaylord"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "120195416698744"
		},
		"id" : "120193732506040"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const BlConfigFileWithLocal = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Monte",
		  "statements" : [ {
			"id" : "120765254558046",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "primaryGSTIN",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "primaryGSTIN",
					"splitby" : ","
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Andreanne"
		  }, {
			"id" : "120835019939236",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "primaryGSTINNI",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "primaryGSTINNI",
					"splitby" : ","
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Gilberto"
		  }, {
			"id" : "121034310276137",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "A",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "declare",
				"dataValue" : 1,
				"dataType" : "number"
			  }
			},
			"name" : "Sigrid"
		  }, {
			"id" : "121246188537582",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "B",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "declare",
				"dataValue" : 1,
				"dataType" : "number"
			  }
			},
			"name" : "Payton"
		  }, {
			"id" : "122523689206851",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "consumerDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Lottie",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Cleveland",
								  "statements" : [ {
									"id" : "122008972237299",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "primaryGSTIN_id",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Maya"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "122004984180549"
								},
								"id" : "122003481201547"
							  } ],
							  "id" : "122007620445558"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 2,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Moises",
								  "statements" : [ {
									"id" : "122364772073030",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "primaryGSTIN_Value",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Mavis"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "122368219860881"
								},
								"id" : "122366749823760"
							  } ],
							  "id" : "122368176092074"
							},
							"failure" : null,
							"id" : 6
						  }, {
							"id" : "122529399645474",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "A",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "A"
								  }, {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 1
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Iva"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "122529225759258"
						},
						"id" : "122524403950425"
					  } ]
					},
					"value" : "primaryGSTIN@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Jabari"
		  }, {
			"id" : "123645831273287",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "consumerDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Laverna",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "B",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Willis",
								  "statements" : [ {
									"id" : "123166447161038",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "primaryGSTINNI-id",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Concepcion"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "123167373905998"
								},
								"id" : "123163293339006"
							  } ],
							  "id" : "123165614582177"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "B",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 2,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Lily",
								  "statements" : [ {
									"id" : "123438727126476",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "primaryGSTINNI_Value",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Berenice"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "123438319117517"
								},
								"id" : "123432956291096"
							  } ],
							  "id" : "123434833739523"
							},
							"failure" : null,
							"id" : 6
						  }, {
							"id" : "123647428890971",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "B",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "B"
								  }, {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 1
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Rudy"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "123646733407628"
						},
						"id" : "123647699226867"
					  } ]
					},
					"value" : "primaryGSTINNI@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Bill"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "No",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Salma",
				  "statements" : [ {
					"id" : "124068443836707",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "blDetails.jblLoanDtls",
						"dataType" : "map"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "map",
						"dataValue" : "map",
						"keywordArguments" : {
						  "init" : {
							"fields" : {
							  "existngEMIObligAmt" : "eMIBasedObligationsNI"
							}
						  },
						  "format" : "populate"
						}
					  }
					},
					"name" : "Robbie"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "124069682935361"
				},
				"id" : "124065450412668"
			  } ],
			  "id" : "124067896528551"
			},
			"failure" : null,
			"id" : 1
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "No",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Kacie",
				  "statements" : [ {
					"id" : "124389160512346",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "blDetails.jblCp",
						"dataType" : "map"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "map",
						"dataValue" : "map",
						"keywordArguments" : {
						  "init" : {
							"fields" : {
							  "isFirstLoan" : "customerCategoryNI",
							  "lastYearProfit" : "previousfinancialyearAuditedNetprofitNI",
							  "professionalId" : "professionID"
							}
						  },
						  "format" : "populate"
						}
					  }
					},
					"name" : "Tanner"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "124385778464903"
				},
				"id" : "124385431697533"
			  } ],
			  "id" : "124382227224476"
			},
			"failure" : null,
			"id" : 2
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "No",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Orie",
				  "statements" : [ {
					"id" : "124702260044787",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "genericDetails.customerPrincipal",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "map",
						"dataValue" : "map",
						"keywordArguments" : {
						  "init" : {
							"fields" : {
							  "dateOfIncorporation" : "dateofIncorporationNI",
							  "annualSalary" : "previousfinancialyearAuditedTurnoverNI",
							  "natureOfBiz" : "natureofBusinessNI",
							  "customerCategory" : "constitutionOfBusinesslookupIdNI",
							  "email" : "registeredEmailIDNI",
							  "industryGroup" : "industryTypeNI"
							}
						  },
						  "format" : "populate"
						}
					  }
					},
					"name" : "Dorothy"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "124706989019445"
				},
				"id" : "124701756282771"
			  } ],
			  "id" : "124704054451818"
			},
			"failure" : null,
			"id" : 3
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "No",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Nathanial",
				  "statements" : [ {
					"id" : "124967458604856",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "genericDetails.customerPrincipal.customer",
						"dataType" : "map"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "map",
						"dataValue" : "map",
						"keywordArguments" : {
						  "init" : {
							"fields" : {
							  "isExistingCustomer" : "customerTypeNI",
							  "branch" : "locationofApplicationOrBranch1"
							}
						  },
						  "format" : "populate"
						}
					  }
					},
					"name" : "Aglae"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "124969496579630"
				},
				"id" : "124965604666524"
			  } ],
			  "id" : "124967850879769"
			},
			"failure" : null,
			"id" : 6
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "124968696210942"
		},
		"id" : "124961509968087"
	  }, {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Brielle",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "Yes",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Karianne",
				  "statements" : [ {
					"id" : "125305759765017",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "genericDetails.customerPrincipal",
						"dataType" : "map"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "map",
						"dataValue" : "map",
						"keywordArguments" : {
						  "init" : {
							"fields" : {
							  "dateOfIncorporation" : "dateofIncorporation",
							  "annualSalary" : "previousyearAuditedTurnover",
							  "customer.branch" : "locofApplicationOrBranch",
							  "natureOfBiz" : "natureofBusiness",
							  "customerCategory" : "constitutionOfBusinesslookupId",
							  "customer.isExistingCustomer" : "customerType",
							  "email" : "registeredEmailID",
							  "industryGroup" : "industryType",
							  "occupationSubType" : "typeOfProfession"
							}
						  },
						  "format" : "populate"
						}
					  }
					},
					"name" : "Adriel"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "125306876834564"
				},
				"id" : "125308653876179"
			  } ],
			  "id" : "125308736520577"
			},
			"failure" : null,
			"id" : 7
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "Yes",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Jazlyn",
				  "statements" : [ {
					"id" : "125591117762491",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "blDetails.jblCp",
						"dataType" : "map"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "map",
						"dataValue" : "map",
						"keywordArguments" : {
						  "init" : {
							"fields" : {
							  "isFirstLoan" : "customerCategory",
							  "lastYearProfit" : "previousfinancialyearAuditedNetprofit"
							}
						  },
						  "format" : "populate"
						}
					  }
					},
					"name" : "Thad"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "125593510214738"
				},
				"id" : "125594832583647"
			  } ],
			  "id" : "125592485964383"
			},
			"failure" : null,
			"id" : 8
		  }, {
			"id" : "127421437374606",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericDetails.customerPrincipal.customerPrincipalAddressList",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "transform Address Information",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Eldora",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "individualflag",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "No",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Alverta",
								  "statements" : [ {
									"id" : "126249523798918",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "",
										"dataType" : "map"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "map",
										"dataValue" : "map",
										"keywordArguments" : {
										  "init" : {
											"fields" : {
											  "postalCode" : "pincodeNI"
											}
										  },
										  "format" : "populate"
										}
									  }
									},
									"name" : "Enos"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "126241733748592"
								},
								"id" : "126249677227947"
							  } ],
							  "id" : "126249217279662"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "individualflag",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "Yes",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Ola",
								  "statements" : [ {
									"id" : "126542610914553",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "",
										"dataType" : "map"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "map",
										"dataValue" : "map",
										"keywordArguments" : {
										  "init" : {
											"fields" : {
											  "postalCode" : "pincode"
											}
										  },
										  "format" : "populate"
										}
									  }
									},
									"name" : "Leonora"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "126549641965508"
								},
								"id" : "126544405999931"
							  } ],
							  "id" : "126541285383518"
							},
							"failure" : null,
							"id" : 2
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "individualflag",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "Yes",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Eldred",
								  "statements" : [ {
									"id" : "126866962419968",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpAddId",
										"dataType" : "number"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "cpaddid",
										"dataType" : "number"
									  }
									},
									"name" : "Oceane"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "126863611658762"
								},
								"id" : "126865722717206"
							  } ],
							  "id" : "126863105792060"
							},
							"failure" : null,
							"id" : 5
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "individualflag",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "No",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Lina",
								  "statements" : [ {
									"id" : "127236552749593",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpAddId",
										"dataType" : "number"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "cpaddidNI",
										"dataType" : "number"
									  }
									},
									"name" : "Amparo"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "127235953320797"
								},
								"id" : "127239893477281"
							  } ],
							  "id" : "127231539231170"
							},
							"failure" : null,
							"id" : 2
						  }, {
							"id" : "127422320260426",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "addressType",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "Registered Address",
								"dataType" : "number"
							  }
							},
							"name" : "Sherman"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "127427976930895"
						},
						"id" : "127427614881190"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Reese"
		  }, {
			"id" : "127606781181595",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericDetails.customerPrincipal",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "map",
				"dataValue" : "map",
				"keywordArguments" : {
				  "init" : {
					"fields" : {
					  "occupationType" : "subType",
					  "dateOfBirth" : "dateofBirth"
					}
				  },
				  "format" : "populate"
				}
			  }
			},
			"name" : "Shanny"
		  }, {
			"id" : "127797326350586",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "blDetails.jblCp",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "map",
				"dataValue" : "map",
				"keywordArguments" : {
				  "init" : {
					"fields" : {
					  "professionalId" : "membershipId",
					  "professionalExperience" : "professionalExperienceinYears"
					}
				  },
				  "format" : "populate"
				}
			  }
			},
			"name" : "Margaretta"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "Yes",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Hettie",
				  "statements" : [ {
					"id" : "128134020710136",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "blDetails.jblLoanDtls.existngEMIObligAmt",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "eMIBasedObligations",
						"dataType" : "text"
					  }
					},
					"name" : "Merritt"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "128136657026171"
				},
				"id" : "128139931019044"
			  } ],
			  "id" : "128132520270779"
			},
			"failure" : null,
			"id" : 12
		  }, {
			"id" : "128319725931348",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericDetails.application.applicationId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "appPackageId",
				"dataType" : "text"
			  }
			},
			"name" : "Bessie"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "No",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Curtis",
				  "statements" : [ {
					"id" : "129557718791248",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "genericDetails.customerPrincipal.cpIdentityList",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Jaclyn",
								  "statements" : [ {
									"id" : "128934110953928",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "nameAsInId",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "nameofBorrowerNI",
										"dataType" : "text"
									  }
									},
									"name" : "Finn"
								  }, {
									"id" : "129055704836059",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpIdentityId",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "local",
										"dataValue" : "primaryGSTINNI-id",
										"dataType" : "text"
									  }
									},
									"name" : "Emma"
								  }, {
									"id" : "129239652802639",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "idNo",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "local",
										"dataValue" : "primaryGSTIN_Value",
										"dataType" : "text"
									  }
									},
									"name" : "Cathryn"
								  }, {
									"id" : "129363573066240",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "idType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "GSTIN",
										"dataType" : "text"
									  }
									},
									"name" : "Dejuan"
								  }, {
									"id" : "129559769288093",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "isPrimary",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : 1,
										"dataType" : "text"
									  }
									},
									"name" : "Claudine"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "129559609163514"
								},
								"id" : "129556083439922"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Cathrine"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "129559997721938"
				},
				"id" : "129558574116186"
			  } ],
			  "id" : "129551921818105"
			},
			"failure" : null,
			"id" : 1
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "individualflag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "No",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Murphy",
				  "statements" : [ {
					"id" : "131296742070542",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "genericDetails.customerPrincipal.cpIdentityList",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "customer Response",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Caitlyn",
								  "statements" : [ {
									"id" : "130576201649268",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "nameAsInId",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "nameofBorrower",
										"dataType" : "text"
									  }
									},
									"name" : "Evie"
								  }, {
									"id" : "130774280904631",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpIdentityId",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "local",
										"dataValue" : "primaryGSTIN_id",
										"dataType" : "text"
									  }
									},
									"name" : "Ibrahim"
								  }, {
									"id" : "130928013154174",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "idNo",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "local",
										"dataValue" : "primaryGSTIN_Value",
										"dataType" : "text"
									  }
									},
									"name" : "Florence"
								  }, {
									"id" : "131108252942915",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "idType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "GSTIN",
										"dataType" : "text"
									  }
									},
									"name" : "Demarcus"
								  }, {
									"id" : "131295333238922",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "isPrimary",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : 1,
										"dataType" : "text"
									  }
									},
									"name" : "Narciso"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "131291150738622"
								},
								"id" : "131296125083655"
							  } ]
							}
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Treva"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "131292133645925"
				},
				"id" : "131295193264650"
			  } ],
			  "id" : "131294860097114"
			},
			"failure" : null,
			"id" : 2
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "131297832254198"
		},
		"id" : "131295034252741"
	  } ]
	}
  }`

const TestOmittNull = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Elwin",
		  "statements" : [ {
			"id" : "131746814881269",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "keyword",
				"dataValue" : "none",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "map"
			  }
			},
			"name" : "Montana"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "131743854322897"
		},
		"id" : "131748240583478"
	  } ]
	}
  }`

const ObjectNullConf = `{
	"version": "1",
	"@type": "transform",
	"transform": {
	  "id": "transform_config_1",
	  "name": "Filter the Date Repsonse",
	  "statements": [
		{
		  "@type": "SectionalStatement",
		  "section": {
			"jsonIgnoreProperty": true,
			"name": "Gerda",
			"statements": [
			  {
				"condition": {
				  "@type": "logical",
				  "type": "or",
				  "rules": [
					{
					  "@type": "relational",
					  "lhs": {
						"@type": "variable",
						"dataType": "text",
						"dataValue": "object2"
					  },
					  "operator": {
						"actualValue": "=="
					  },
					  "rhs": {
						"@type": "keyword",
						"dataType": "text",
						"dataValue": "text",
						"keywordArguments": {
						  "format": "getNullValue"
						}
					  }
					}
				  ]
				},
				"@type": "ConditionalStatement",
				"success": {
				  "name": "transformation",
				  "statements": [
					{
					  "@type": "SectionalStatement",
					  "section": {
						"jsonIgnoreProperty": false,
						"name": "Jesse",
						"statements": [
						  {
							"id": "132224714956440",
							"@type": "AssignmentStatement",
							"assignment": {
							  "lhs": {
								"@type": "literal",
								"dataValue": "condition",
								"dataType": "text"
							  },
							  "operator": {
								"actualValue": "="
							  },
							  "rhs": {
								"@type": "literal",
								"dataValue": true,
								"dataType": "text"
							  }
							},
							"name": "Antonina"
						  }
						],
						"jsonIgnoreAliasValue": null,
						"id": "132226326148349"
					  },
					  "id": "132225056207632"
					}
				  ],
				  "id": "132228536721945"
				},
				"failure": null,
				"id": 1
			  }
			],
			"jsonIgnoreAliasValue": null,
			"id": "132228068917092"
		  },
		  "id": "132223976390842"
		}
	  ]
	},
	"delete": {},
	"extract": {}
  }`

const SupportingJsonIgnorePropertyInLocal = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":1697108034962777,"name":"Statement 1697107973271908","@type":"AssignmentStatement","mandatory":true,"assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"customer.name"},"rhs":{"@type":"variable","dataType":"text","dataValue":"javeedPashaWainasdfi@local"},"operator":{"actualValue":"="}}},{"id":"1","@type":"AssignmentStatement","assignment":{"@type":"SimpleAssignmentStatement","lhs":{"@type":"keyword","dataValue":"none","dataType":"map"},"operator":{"actualValue":"="},"rhs":{"@type":"keyword","dataValue":"map","dataType":"map","keywordArguments":{"format":"populate","init":{"fields":{"employee.name":"fName@local"}}}}}}],"jsonIgnoreProperty":true,"jsonIgnoreAliasValue":null},"contentInputType":"json","contentOutputType":"json"}`

const ExceptioBySpecificStatement = `{
	"version": "1",
	"@type": "transform",
	"transform": {
	  "id": "transform_config_1",
	  "name": "Filter the Date Repsonse",
	  "statements": [
		{
		  "@type": "SectionalStatement",
		  "section": {
			"jsonIgnoreProperty": false,
			"name": "Alvena",
			"statements": [
			  {
				"id": "132655172811221",
				"@type": "AssignmentStatement",
				"assignment": {
				  "@type": "SimpleAssignmentStatement",
				  "lhs": {
					"@type": "declare",
					"dataValue": "createdValue",
					"dataType": "list"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "literal",
					"dataValue": "1,2,3,4,5",
					"dataType": "list"
				  }
				},
				"name": "Gaylord"
			  },
			  {
				"id": "132871359936487",
				"@type": "AssignmentStatement",
				"assignment": {
				  "@type": "SimpleAssignmentStatement",
				  "lhs": {
					"@type": "declare",
					"dataValue": "statementIdsArray",
					"dataType": "list"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "keyword",
					"dataType": "list",
					"dataValue": "text",
					"keywordArguments": {
					  "init": {
						"value": "createdValue@local",
						"splitby": ","
					  },
					  "format": "split"
					}
				  }
				},
				"name": "Luz"
			  },
			  {
				"id": "133046625777776",
				"@type": "AssignmentStatement",
				"assignment": {
				  "@type": "SimpleAssignmentStatement",
				  "lhs": {
					"@type": "literal",
					"dataValue": "isGraduate",
					"dataType": "text"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "variable",
					"dataValue": "graduation",
					"dataType": "text"
				  }
				},
				"name": "Marilyne"
			  }
			],
			"jsonIgnoreAliasValue": null,
			"id": "133049183976061"
		  },
		  "id": "133042882033514"
		}
	  ]
	},
	"delete": {},
	"extract": {},
	"errors": {
	  "statements": [
		{
		  "@type": "SectionalStatement",
		  "section": {
			"jsonIgnoreProperty": false,
			"name": "Isom",
			"statements": [
			  {
				"condition": {
				  "@type": "logical",
				  "type": "and",
				  "rules": [
					{
					  "@type": "relational",
					  "lhs": {
						"@type": "variable",
						"dataType": "list",
						"dataValue": "statementIdsArray@local"
					  },
					  "operator": {
						"actualValue": "contains"
					  },
					  "rhs": {
						"@type": "keyword",
						"dataType": "list",
						"dataValue": "statementId"
					  }
					}
				  ]
				},
				"@type": "ConditionalStatement",
				"success": {
				  "name": "transformation",
				  "statements": [
					{
					  "@type": "SectionalStatement",
					  "section": {
						"jsonIgnoreProperty": false,
						"name": "Kenneth",
						"statements": [
						  {
							"id": "133521642329412",
							"@type": "AssignmentStatement",
							"assignment": {
							  "@type": "SimpleAssignmentStatement",
							  "lhs": {
								"@type": "literal",
								"dataValue": "isGraduate",
								"dataType": "text"
							  },
							  "operator": {
								"actualValue": "="
							  },
							  "rhs": {
								"@type": "literal",
								"dataValue": "this is Handled in generic statement",
								"dataType": "text"
							  }
							},
							"name": "Adolf"
						  }
						],
						"jsonIgnoreAliasValue": null,
						"id": "133525770864522"
					  },
					  "id": "133522413408911"
					}
				  ],
				  "id": "133521221648067"
				},
				"failure": null,
				"id": 2
			  },
			  {
				"condition": {
				  "@type": "logical",
				  "type": "and",
				  "rules": [
					{
					  "@type": "relational",
					  "lhs": {
						"@type": "keyword",
						"dataType": "text",
						"dataValue": "statementId"
					  },
					  "operator": {
						"actualValue": "=="
					  },
					  "rhs": {
						"@type": "literal",
						"dataType": "text",
						"dataValue": "133046625777776"
					  }
					}
				  ]
				},
				"@type": "ConditionalStatement",
				"success": {
				  "name": "transformation",
				  "statements": [
					{
					  "@type": "SectionalStatement",
					  "section": {
						"jsonIgnoreProperty": false,
						"name": "Kamren",
						"statements": [
						  {
							"id": "133857627088878",
							"@type": "AssignmentStatement",
							"assignment": {
							  "@type": "SimpleAssignmentStatement",
							  "lhs": {
								"@type": "literal",
								"dataValue": "isGraduate",
								"dataType": "text"
							  },
							  "operator": {
								"actualValue": "="
							  },
							  "rhs": {
								"@type": "literal",
								"dataValue": "this is Handled in specific statement",
								"dataType": "text"
							  }
							},
							"name": "Laila"
						  }
						],
						"jsonIgnoreAliasValue": null,
						"id": "133857926348572"
					  },
					  "id": "133856285711330"
					}
				  ],
				  "id": "133858228598070"
				},
				"failure": null,
				"id": 1
			  }
			],
			"jsonIgnoreAliasValue": null,
			"id": "133858327699474"
		  },
		  "id": "133852106229971"
		}
	  ]
	}
  }`

const PLUserException = `{
	"version" : 1,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "transform Address Details",
	  "validate" : [ {
		"condition" : {
		  "@type" : "logical",
		  "type" : "and",
		  "rules" : [ {
			"@type" : "relational",
			"lhs" : {
			  "@type" : "variable",
			  "dataType" : "text",
			  "dataValue" : "appPackageId"
			},
			"operator" : {
			  "actualValue" : "!="
			},
			"rhs" : {
			  "@type" : "literal",
			  "dataValue" : "",
			  "dataType" : "text"
			}
		  } ]
		},
		"error" : {
		  "subcode" : "500",
		  "detailedMessage" : "Invalid appPackageId"
		}
	  } ],
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Dora",
		  "statements" : [ {
			"id" : "134423794381885",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "localAppId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "appPackageId",
				"dataType" : "number"
			  }
			},
			"name" : "Giovanna"
		  }, {
			"id" : "134649884305558",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericDetails.application.applicationId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "appPackageId1",
				"dataType" : "number"
			  }
			},
			"name" : "Myrl"
		  }, {
			"id" : "134819019332027",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericDetails.customerPrincipal.customer.isExistingCustomer",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "customerType",
				"dataType" : "number"
			  }
			},
			"name" : "Modesta"
		  }, {
			"id" : "134947355774367",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericDetails.customerPrincipal.customer.customerId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "customerId",
				"dataType" : "number"
			  }
			},
			"name" : "Eliezer"
		  }, {
			"id" : "135096241518358",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "plDetails.jplLoanDtls.applicationId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "appPackageId",
				"dataType" : "text"
			  }
			},
			"name" : "Federico"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "RequestedloanAmount27",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "nil",
				  "dataType" : "text"
				}
			  }, {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "RequestedloanAmount27",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Lurline",
				  "statements" : [ {
					"id" : "135409643622455",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "plDetails.jplLoanDtls.loanAmt",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "RequestedloanAmount27",
						"dataType" : "number"
					  }
					},
					"name" : "Una"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "135404661611215"
				},
				"id" : "135404691295109"
			  } ],
			  "id" : "135408668684200"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Marlee",
				  "statements" : [ {
					"condition" : {
					  "@type" : "logical",
					  "type" : "and",
					  "rules" : [ {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataValue" : "requiredloanamount",
						  "dataType" : "text"
						},
						"operator" : {
						  "actualValue" : "!="
						},
						"rhs" : {
						  "@type" : "literal",
						  "dataValue" : "nil",
						  "dataType" : "text"
						}
					  }, {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataValue" : "requiredloanamount",
						  "dataType" : "text"
						},
						"operator" : {
						  "actualValue" : "!="
						},
						"rhs" : {
						  "@type" : "literal",
						  "dataValue" : "",
						  "dataType" : "text"
						}
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Rusty",
						  "statements" : [ {
							"id" : "135968914836148",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplLoanDtls.loanAmt",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "requiredloanamount",
								"dataType" : "number"
							  }
							},
							"name" : "Giovanna"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "135967651405536"
						},
						"id" : "135968191665603"
					  } ],
					  "id" : "135962586152647"
					},
					"failure" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Marcelino",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "loanAmount12",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "nil",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "loanAmount12",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Yvonne",
								  "statements" : [ {
									"id" : "136433589142485",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "plDetails.jplLoanDtls.loanAmt",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "loanAmount12",
										"dataType" : "number"
									  }
									},
									"name" : "Salma"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "136432446496789"
								},
								"id" : "136439141355620"
							  } ],
							  "id" : "136438234977747"
							},
							"failure" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Garth",
								  "statements" : [ {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "loanAmount27",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "literal",
										  "dataValue" : "nil",
										  "dataType" : "text"
										}
									  }, {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "loanAmount27",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "literal",
										  "dataValue" : "",
										  "dataType" : "text"
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Caesar",
										  "statements" : [ {
											"id" : "136963117549476",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "plDetails.jplLoanDtls.loanAmt",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "variable",
												"dataValue" : "loanAmount27",
												"dataType" : "number"
											  }
											},
											"name" : "Hillary"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "136967629400596"
										},
										"id" : "136963891332929"
									  } ],
									  "id" : "136962460626307"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Eleanora",
										  "statements" : [ {
											"id" : "137264483182137",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "plDetails.jplLoanDtls.loanAmt",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "constant",
												"dataValue" : "nil",
												"dataType" : "text"
											  }
											},
											"name" : "Jimmy"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "137266192910287"
										},
										"id" : "137264639777700"
									  } ],
									  "id" : "137269711716229"
									},
									"id" : 406
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "137263328649919"
								},
								"id" : "137266420066714"
							  } ],
							  "id" : "137262359888587"
							},
							"id" : 404
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "137262831160363"
						},
						"id" : "137266313434563"
					  } ],
					  "id" : "137266632581794"
					},
					"id" : 402
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "137266862556367"
				},
				"id" : "137267329720451"
			  } ],
			  "id" : "137263156057946"
			},
			"id" : "4"
		  }, {
			"id" : "137479162093785",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "plDetails.jplLoanDtls.tenureInMnts",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "requestedtenor",
				"dataType" : "text"
			  }
			},
			"name" : "Foster"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "ifOthers",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "nil",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Velma",
				  "statements" : [ {
					"id" : "137765664411682",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "plDetails.jplLoanDtls.loanAdditionalInfo.loanDtlsPurposeOfLoan",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "ifOthers",
						"dataType" : "text"
					  }
					},
					"name" : "Garrett"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "137761734998206"
				},
				"id" : "137763252189039"
			  } ],
			  "id" : "137764585680292"
			},
			"failure" : null,
			"id" : "71"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "purposeofLoan01",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "nil",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Ana",
				  "statements" : [ {
					"id" : "138098779458274",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "plDetails.jplLoanDtls.purposeOfLoan",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "purposeofLoan1",
						"dataType" : "text"
					  }
					},
					"name" : "Joseph"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "138094779609018"
				},
				"id" : "138098330607922"
			  } ],
			  "id" : "138098683421911"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Abel",
				  "statements" : [ {
					"condition" : {
					  "@type" : "logical",
					  "type" : "and",
					  "rules" : [ {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataValue" : "purposeofLoan14",
						  "dataType" : "text"
						},
						"operator" : {
						  "actualValue" : "!="
						},
						"rhs" : {
						  "@type" : "literal",
						  "dataValue" : "nil",
						  "dataType" : "text"
						}
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Ulices",
						  "statements" : [ {
							"id" : "138584001424833",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplLoanDtls.purposeOfLoan",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "purposeofLoan14",
								"dataType" : "text"
							  }
							},
							"name" : "Fausto"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "138583865876359"
						},
						"id" : "138583950533305"
					  } ],
					  "id" : "138583545507625"
					},
					"failure" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Price",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "purposeofLoan27",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "nil",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Maybell",
								  "statements" : [ {
									"id" : "139029074224677",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "plDetails.jplLoanDtls.purposeOfLoan",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "purposeofLoan27",
										"dataType" : "text"
									  }
									},
									"name" : "Raina"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "139023334167769"
								},
								"id" : "139022737900792"
							  } ],
							  "id" : "139026756515311"
							},
							"failure" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Anderson",
								  "statements" : [ {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "purposeofLoan1",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "literal",
										  "dataValue" : "nil",
										  "dataType" : "text"
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Scarlett",
										  "statements" : [ {
											"id" : "139517689868999",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "plDetails.jplLoanDtls.purposeOfLoan",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "variable",
												"dataValue" : "purposeofLoan1",
												"dataType" : "text"
											  }
											},
											"name" : "Carol"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "139518628388571"
										},
										"id" : "139519219921999"
									  } ],
									  "id" : "139516974751575"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Vanessa",
										  "statements" : [ {
											"id" : "140008577644609",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "plDetails.jplLoanDtls.purposeOfLoan",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "constant",
												"dataValue" : "nil",
												"dataType" : "text"
											  }
											},
											"name" : "Angela"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "140001076397977"
										},
										"id" : "140002393414161"
									  } ],
									  "id" : "140006746179833"
									},
									"id" : "7"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "140007126497422"
								},
								"id" : "140002581885903"
							  } ],
							  "id" : "140008081207463"
							},
							"id" : "7"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "140005830977685"
						},
						"id" : "140007151168054"
					  } ],
					  "id" : "140001849209208"
					},
					"id" : "7"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "140002115325093"
				},
				"id" : "140007004519039"
			  } ],
			  "id" : "140008455563243"
			},
			"id" : "6"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "emi12",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "nil",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Harvey",
				  "statements" : [ {
					"id" : "140298746801173",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "plDetails.jplLoanDtls.emiAmt",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "emi12",
						"dataType" : "text"
					  }
					},
					"name" : "Lucienne"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "140294273242524"
				},
				"id" : "140294970740035"
			  } ],
			  "id" : "140291681142541"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Maryam",
				  "statements" : [ {
					"condition" : {
					  "@type" : "logical",
					  "type" : "and",
					  "rules" : [ {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataValue" : "Emi27",
						  "dataType" : "text"
						},
						"operator" : {
						  "actualValue" : "!="
						},
						"rhs" : {
						  "@type" : "literal",
						  "dataValue" : "nil",
						  "dataType" : "text"
						}
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Alberto",
						  "statements" : [ {
							"id" : "140809111531274",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplLoanDtls.emiAmt",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "Emi27",
								"dataType" : "text"
							  }
							},
							"name" : "Rupert"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "140807136667380"
						},
						"id" : "140808333931202"
					  } ],
					  "id" : "140807525534619"
					},
					"failure" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Gunnar",
						  "statements" : [ {
							"id" : "141145746994090",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplLoanDtls.purposeOfLoan",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "constant",
								"dataValue" : "nil",
								"dataType" : "text"
							  }
							},
							"name" : "Sabryna"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "141147000761001"
						},
						"id" : "141144190278752"
					  } ],
					  "id" : "141143455590363"
					},
					"id" : "7"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "141146363481349"
				},
				"id" : "141142792668179"
			  } ],
			  "id" : "141143157561000"
			},
			"id" : "7"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "141145754186915"
		},
		"id" : "141146935738966"
	  }, {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Chris",
		  "statements" : [ {
			"id" : "141237289367832",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "plDetails.jplLoanDtls.loanTypeId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "loanDetails",
				"dataType" : "text"
			  }
			},
			"name" : "Yesenia"
		  }, {
			"id" : "141438228573448",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "plDetails.jplPricing.priceingId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "priceingId",
				"dataType" : "number"
			  }
			},
			"name" : "Donny"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "Roi27",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "nil",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Marina",
				  "statements" : [ {
					"id" : "141754729474594",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "plDetails.jplPricing.baseRate",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "Roi27",
						"dataType" : "text"
					  }
					},
					"name" : "Courtney"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "141755117809169"
				},
				"id" : "141753971172261"
			  } ],
			  "id" : "141756799544503"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Kaci",
				  "statements" : [ {
					"condition" : {
					  "@type" : "logical",
					  "type" : "and",
					  "rules" : [ {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataValue" : "roi12",
						  "dataType" : "text"
						},
						"operator" : {
						  "actualValue" : "!="
						},
						"rhs" : {
						  "@type" : "literal",
						  "dataValue" : "nil",
						  "dataType" : "text"
						}
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Ariane",
						  "statements" : [ {
							"id" : "142276021988465",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplPricing.baseRate",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "roi12",
								"dataType" : "text"
							  }
							},
							"name" : "Terrance"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "142275255451395"
						},
						"id" : "142276163415291"
					  } ],
					  "id" : "142273964227803"
					},
					"failure" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Mertie",
						  "statements" : [ {
							"id" : "142722196041058",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplPricing.baseRate",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "constant",
								"dataValue" : "nil",
								"dataType" : "text"
							  }
							},
							"name" : "Eladio"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "142724778811634"
						},
						"id" : "142728427414506"
					  } ],
					  "id" : "142728347276352"
					},
					"id" : 10
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "142725815577728"
				},
				"id" : "142723898703332"
			  } ],
			  "id" : "142724782408663"
			},
			"id" : 10
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "Roi27",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "!="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "nil",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Jocelyn",
				  "statements" : [ {
					"id" : "143126706332750",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "plDetails.jplPricing.baseRate",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "Roi27",
						"dataType" : "text"
					  }
					},
					"name" : "Paula"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "143121170590860"
				},
				"id" : "143128581811755"
			  } ],
			  "id" : "143125675836800"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Cayla",
				  "statements" : [ {
					"condition" : {
					  "@type" : "logical",
					  "type" : "and",
					  "rules" : [ {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataValue" : "roi12",
						  "dataType" : "text"
						},
						"operator" : {
						  "actualValue" : "!="
						},
						"rhs" : {
						  "@type" : "literal",
						  "dataValue" : "nil",
						  "dataType" : "text"
						}
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Davion",
						  "statements" : [ {
							"id" : "143606555696994",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplPricing.baseRate",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "roi12",
								"dataType" : "text"
							  }
							},
							"name" : "Nash"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "143604097596776"
						},
						"id" : "143607260260710"
					  } ],
					  "id" : "143603476714268"
					},
					"failure" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Emery",
						  "statements" : [ {
							"id" : "144039920856294",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplPricing.baseRate",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "constant",
								"dataValue" : "nil",
								"dataType" : "text"
							  }
							},
							"name" : "Pamela"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "144033728565306"
						},
						"id" : "144037929166292"
					  } ],
					  "id" : "144034741314998"
					},
					"id" : "7"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "144038224904728"
				},
				"id" : "144032645593169"
			  } ],
			  "id" : "144039279458075"
			},
			"id" : 11
		  }, {
			"id" : "148357711499278",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericDetails.customerPrincipal.cpIdentityList",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "transform Address Information",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Petra",
						  "statements" : [ {
							"id" : "144568784922396",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "keyword",
								"dataValue" : "none",
								"dataType" : "map"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataType" : "map",
								"dataValue" : "map",
								"keywordArguments" : {
								  "init" : {
									"fields" : {
									  "cpIdentityKyc.kycRefNo" : "ckycNumber",
									  "cpIdentityId" : "cpIdentityId",
									  "cpIdentityKyc.cpIdentityKycId" : "cpIdentityKycId"
									}
								  },
								  "format" : "populate"
								}
							  }
							},
							"name" : "Eliseo"
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "selectkycmethod",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Paul",
								  "statements" : [ {
									"id" : "144888870965010",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpIdentityKyc.kycType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "eKYC",
										"dataType" : "text"
									  }
									},
									"name" : "Eulalia"
								  }, {
									"id" : "145061371120549",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpIdentityKyc.kycTypeLookupType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "KYCMETHOD",
										"dataType" : "text"
									  }
									},
									"name" : "Royal"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "145062396436751"
								},
								"id" : "145068291005867"
							  } ],
							  "id" : "145069974207929"
							},
							"failure" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Stevie",
								  "statements" : [ {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "selectkycmethod",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "literal",
										  "dataValue" : 2,
										  "dataType" : "text"
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Yolanda",
										  "statements" : [ {
											"id" : "145562707139880",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "cpIdentityKyc.kycType",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataValue" : "Mobile + Upload OVD's",
												"dataType" : "text"
											  }
											},
											"name" : "Cody"
										  }, {
											"id" : "145772028743082",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "cpIdentityKyc.kycTypeLookupType",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataValue" : "KYCMETHOD",
												"dataType" : "text"
											  }
											},
											"name" : "Jessie"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "145777110481323"
										},
										"id" : "145774219148540"
									  } ],
									  "id" : "145773826653420"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Autumn",
										  "statements" : [ {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "selectkycmethod",
												  "dataType" : "text"
												},
												"operator" : {
												  "actualValue" : "=="
												},
												"rhs" : {
												  "@type" : "literal",
												  "dataValue" : 3,
												  "dataType" : "text"
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Bartholome",
												  "statements" : [ {
													"id" : "146213909385579",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataValue" : "cpIdentityKyc.kycType",
														"dataType" : "text"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "literal",
														"dataValue" : "Mobile + CKYC",
														"dataType" : "text"
													  }
													},
													"name" : "Rocky"
												  }, {
													"id" : "146393297388101",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataValue" : "cpIdentityKyc.kycTypeLookupType",
														"dataType" : "text"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "literal",
														"dataValue" : "KYCMETHOD",
														"dataType" : "text"
													  }
													},
													"name" : "Forrest"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "146394346986476"
												},
												"id" : "146395694598298"
											  } ],
											  "id" : "146395046946899"
											},
											"failure" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Rhiannon",
												  "statements" : [ {
													"id" : "146738400723100",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "literal",
														"dataValue" : "cpIdentityKyc.kycType",
														"dataType" : "text"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "keyword",
														"dataType" : "text",
														"dataValue" : "text",
														"keywordArguments" : {
														  "format" : "getNullValue"
														}
													  }
													},
													"name" : "Nelda"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "146739757969624"
												},
												"id" : "146739476686913"
											  } ],
											  "id" : "146739610293722"
											},
											"id" : 404
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "146739436650863"
										},
										"id" : "146735730286871"
									  } ],
									  "id" : "146732609595198"
									},
									"id" : 402
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "146734226362979"
								},
								"id" : "146734861182281"
							  } ],
							  "id" : "146733151450340"
							},
							"id" : "2"
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "kycCompliant019",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Stacy",
								  "statements" : [ {
									"id" : "147052018078170",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpIdentityKyc.kycStatus",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "Compliant",
										"dataType" : "text"
									  }
									},
									"name" : "Paolo"
								  }, {
									"id" : "147229900656901",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpIdentityKyc.kycStatusLookupType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : "KycStatus",
										"dataType" : "text"
									  }
									},
									"name" : "Vergie"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "147228874146869"
								},
								"id" : "147228719471410"
							  } ],
							  "id" : "147227946802690"
							},
							"failure" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Bud",
								  "statements" : [ {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataValue" : "kycCompliant019",
										  "dataType" : "text"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "literal",
										  "dataValue" : 2,
										  "dataType" : "text"
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Herta",
										  "statements" : [ {
											"id" : "147733674003544",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "cpIdentityKyc.kycStatus",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataValue" : "Non-Compliant",
												"dataType" : "text"
											  }
											},
											"name" : "Randy"
										  }, {
											"id" : "147984435440026",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "cpIdentityKyc.kycStatusLookupType",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "literal",
												"dataValue" : "KycStatus",
												"dataType" : "text"
											  }
											},
											"name" : "Jarod"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "147984468275869"
										},
										"id" : "147981226943956"
									  } ],
									  "id" : "147989128463631"
									},
									"failure" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Edna",
										  "statements" : [ {
											"id" : "148351093701607",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "literal",
												"dataValue" : "cpIdentityKyc.kycStatus",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "keyword",
												"dataType" : "text",
												"dataValue" : "text",
												"keywordArguments" : {
												  "format" : "getNullValue"
												}
											  }
											},
											"name" : "Alexanne"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "148356212970208"
										},
										"id" : "148355694922054"
									  } ],
									  "id" : "148354024000891"
									},
									"id" : 404
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "148358633547834"
								},
								"id" : "148354007037029"
							  } ],
							  "id" : "148351049429869"
							},
							"id" : 403
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "148354928571061"
						},
						"id" : "148357878343122"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Dean"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "balancetransfer",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : true,
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Alfonso",
				  "statements" : [ {
					"id" : "149072510913935",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "plDetails.jplCpLoanDtlsList",
						"dataType" : "list"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "keyword",
						"dataType" : "list",
						"dataValue" : "list",
						"keywordArguments" : {
						  "init" : {
							"transform" : {
							  "id" : "transform_config_1",
							  "name" : "transform Address Information",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Logan",
								  "statements" : [ {
									"id" : "149071665302700",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "@type" : "SimpleAssignmentStatement",
									  "lhs" : {
										"@type" : "keyword",
										"dataValue" : "none",
										"dataType" : "map"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "map",
										"dataValue" : "map",
										"keywordArguments" : {
										  "init" : {
											"fields" : {
											  "tenor" : "existingtenor",
											  "cpLoanDtlsId" : "cpLoanDtlsId",
											  "sanctionedAmt" : "existinglaon",
											  "bankName" : "bankname",
											  "emiAmt" : "existingemi",
											  "roi" : "existingro"
											}
										  },
										  "format" : "populate"
										}
									  }
									},
									"name" : "Maxwell"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "149071127367112"
								},
								"id" : "149075169880483"
							  } ]
							},
							"value" : "section2"
						  },
						  "format" : "iterate"
						}
					  }
					},
					"name" : "Destini"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "149077006090173"
				},
				"id" : "149076713753728"
			  } ],
			  "id" : "149072049107182"
			},
			"failure" : null,
			"id" : 404
		  }, {
			"id" : "150064965865109",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "plDetails.jplChargesDtls",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "transform Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Lurline",
						  "statements" : [ {
							"id" : "149568224011882",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "chargeDtlsId",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "stampChargeDtlsId",
								"dataType" : "text"
							  }
							},
							"name" : "Jonas"
						  }, {
							"id" : "149785136938509",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "chargeId",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 16,
								"dataType" : "text"
							  }
							},
							"name" : "Granville"
						  }, {
							"id" : "149949748817749",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "applicationId",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "appPackageId",
								"dataType" : "text"
							  }
							},
							"name" : "Vanessa"
						  }, {
							"id" : "150062558750192",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "chargeAmt",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "stampDuty12",
								"dataType" : "text"
							  }
							},
							"name" : "Ernie"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "150066453647786"
						},
						"id" : "150062648563286"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Maggie"
		  }, {
			"id" : "151078083936045",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "plDetails.jplChargesDtls",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "transform Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Ramon",
						  "statements" : [ {
							"id" : "150544574488487",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "chargeDtlsId",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "procChargeDtlsId",
								"dataType" : "text"
							  }
							},
							"name" : "Retha"
						  }, {
							"id" : "150721118502140",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "chargeId",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 12,
								"dataType" : "text"
							  }
							},
							"name" : "Alvena"
						  }, {
							"id" : "150892102691790",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "applicationId",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "appPackageId",
								"dataType" : "text"
							  }
							},
							"name" : "Toni"
						  }, {
							"id" : "151073602643109",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "chargeAmt",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "processingFees12",
								"dataType" : "text"
							  }
							},
							"name" : "Ellsworth"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "151074626966899"
						},
						"id" : "151077684889982"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Stephon"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "151077121648586"
		},
		"id" : "151074183481536"
	  } ]
	},
	"errors" : {
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Alexander",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "statementId"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "statementId"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Katrina",
				  "statements" : [ {
					"@type" : "ErrorStatement",
					"id" : "validatePan",
					"error" : {
					  "name" : "throwingException",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Shaina",
						  "statements" : [ {
							"id" : "151826410603049",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "status"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "FAILURE"
							  }
							},
							"name" : "Amya"
						  }, {
							"id" : "152058865424317",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "statusCode"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "500"
							  }
							},
							"name" : "Jammie"
						  }, {
							"id" : "152286841366617",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "erorMessage"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "Server might be down, Please try after some time."
							  }
							},
							"name" : "Adaline"
						  }, {
							"id" : "152476434834013",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataType" : "text",
								"dataValue" : "detailedMessage"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "local",
								"dataType" : "text",
								"dataValue" : "currentError.detailedMessage"
							  }
							},
							"name" : "Evie"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "152476415955823"
						},
						"id" : "152475155302466"
					  } ],
					  "id" : "validatePan"
					}
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "152471350370537"
				},
				"id" : "152477650344140"
			  } ],
			  "id" : "152471801342587"
			},
			"failure" : null,
			"id" : "exception1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "152478282881058"
		},
		"id" : "152479795159838"
	  } ]
	}
  }`

const RangeIteration = `{
	"version": "1",
	"@type": "transform",
	"transform": {
		"id": "transform_config_1",
		"name": "customerResponse",
		"statements": [
			{
				"@type": "SectionalStatement",
				"section": {
					"jsonIgnoreProperty": false,
					"name": "NPRrk",
					"statements": [
						{
							"@type": "SectionalStatement",
							"name": "u7wEL",
							"section": {
								"name": null,
								"statements": [
									{
										"@type": "SectionalStatement",
										"section": {
											"jsonIgnoreProperty": false,
											"name": "JHgcV",
											"statements": [
												{
													"id": "583463193383137",
													"@type": "AssignmentStatement",
													"assignment": {
														"@type": "SimpleAssignmentStatement",
														"lhs": {
															"@type": "declare",
															"dataValue": "A",
															"dataType": "number"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "declare",
															"dataValue": 1,
															"dataType": "number"
														}
													},
													"name": "Justen"
												},
												{
													"id": "583484375140855",
													"@type": "AssignmentStatement",
													"assignment": {
														"@type": "SimpleAssignmentStatement",
														"lhs": {
															"@type": "literal",
															"dataValue": "Values",
															"dataType": "list"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "keyword",
															"dataType": "list",
															"dataValue": "list",
															"keywordArguments": {
																"init": {
																	"transform": {
																		"id": "transform_config_1",
																		"name": "customerResponse",
																		"statements": [
																			{
																				"@type": "SectionalStatement",
																				"section": {
																					"jsonIgnoreProperty": false,
																					"name": "RhCNq",
																					"statements": [
																						{
																							"@type": "SectionalStatement",
																							"name": "Qidac",
																							"section": {
																								"name": null,
																								"statements": [
																									{
																										"@type": "SectionalStatement",
																										"section": {
																											"jsonIgnoreProperty": false,
																											"name": "INMuh",
																											"statements": [
																												{
																													"id": "583466570922682",
																													"@type": "AssignmentStatement",
																													"assignment": {
																														"lhs": {
																															"@type": "declare",
																															"dataType": "text",
																															"dataValue": "relatedPartiesObject"
																														},
																														"operator": {
																															"actualValue": "="
																														},
																														"rhs": {
																															"@type": "keyword",
																															"dataType": "text",
																															"dataValue": "value"
																														}
																													},
																													"name": "TeyLx"
																												},
																												{
																													"id": "583485123192667",
																													"@type": "AssignmentStatement",
																													"assignment": {
																														"lhs": {
																															"@type": "declare",
																															"dataType": "text",
																															"dataValue": "relatedPartiesObjectKeySet"
																														},
																														"operator": {
																															"actualValue": "="
																														},
																														"rhs": {
																															"@type": "keyword",
																															"dataType": "text",
																															"dataValue": "map",
																															"keywordArguments": {
																																"format": "getKeySet",
																																"init": {
																																	"value": "relatedPartiesObject@local"
																																}
																															}
																														}
																													},
																													"name": "ppIWo"
																												},
																												{
																													"id": "583485608242687",
																													"name": "Statement1697201799113696",
																													"@type": "AssignmentStatement",
																													"mandatory": true,
																													"assignment": {
																														"lhs": {
																															"@type": "declare",
																															"dataType": "list",
																															"dataValue": "relatedPartieslist"
																														},
																														"rhs": {
																															"@type": "keyword",
																															"dataType": "list",
																															"dataValue": "list",
																															"keywordArguments": {
																																"init": {
																																	"transform": {
																																		"id": "6744641075848",
																																		"name": "Iterate724645",
																																		"statements": [
																																			{
																																				"@type": "SectionalStatement",
																																				"section": {
																																					"jsonIgnoreProperty": false,
																																					"name": "kJnlG",
																																					"statements": [
																																						{
																																							"id": "583489826502740",
																																							"@type": "AssignmentStatement",
																																							"assignment": {
																																								"lhs": {
																																									"@type": "declare",
																																									"dataType": "text",
																																									"dataValue": "relatedPartiesKey"
																																								},
																																								"operator": {
																																									"actualValue": "="
																																								},
																																								"rhs": {
																																									"@type": "keyword",
																																									"dataType": "text",
																																									"dataValue": "value"
																																								}
																																							},
																																							"name": "vRDRw"
																																						},
																																						{
																																							"condition": {
																																								"@type": "logical",
																																								"type": "and",
																																								"rules": [
																																									{
																																										"@type": "relational",
																																										"lhs": {
																																											"@type": "literal",
																																											"dataValue": true,
																																											"dataType": "text"
																																										},
																																										"operator": {
																																											"actualValue": "=="
																																										},
																																										"rhs": {
																																											"@type": "keyword",
																																											"dataValue": "map",
																																											"dataType": "text",
																																											"keywordArguments": {
																																												"format": "getValueByKey",
																																												"init": {
																																													"key": "relatedPartiesKey@local",
																																													"value": "relatedPartiesObject@local"
																																												}
																																											}
																																										}
																																									}
																																								]
																																							},
																																							"@type": "ConditionalStatement",
																																							"success": {
																																								"name": "transformation",
																																								"statements": [
																																									{
																																										"@type": "SectionalStatement",
																																										"section": {
																																											"jsonIgnoreProperty": false,
																																											"name": "DpWwj",
																																											"statements": [
																																												{
																																													"@type": "SectionalStatement",
																																													"name": "P3asd",
																																													"section": {
																																														"name": null,
																																														"statements": [
																																															{
																																																"@type": "SectionalStatement",
																																																"section": {
																																																	"jsonIgnoreProperty": false,
																																																	"name": "wfgiC",
																																																	"statements": [
																																																		{
																																																			"id": "583484224017449",
																																																			"name": "Statement1697536215578009",
																																																			"@type": "AssignmentStatement",
																																																			"mandatory": true,
																																																			"assignment": {
																																																				"lhs": {
																																																					"@type": "declare",
																																																					"dataType": "list",
																																																					"dataValue": "collectedValues"
																																																				},
																																																				"rhs": {
																																																					"@type": "keyword",
																																																					"dataType": "list",
																																																					"dataValue": "list",
																																																					"keywordArguments": {
																																																						"init": {
																																																							"values": [
																																																								"relatedPartiesKey@local"
																																																							]
																																																						},
																																																						"format": "push"
																																																					}
																																																				},
																																																				"operator": {
																																																					"actualValue": "="
																																																				}
																																																			}
																																																		}
																																																	],
																																																	"jsonIgnoreAliasValue": null,
																																																	"id": "583488466815623"
																																																},
																																																"id": "583488759251988"
																																															}
																																														],
																																														"id": "583481357104262"
																																													},
																																													"id": "763043244552640"
																																												}
																																											],
																																											"jsonIgnoreAliasValue": null,
																																											"id": "583484638007156"
																																										},
																																										"id": "583489283032149"
																																									}
																																								],
																																								"id": "583485256848099"
																																							},
																																							"failure": {},
																																							"id": "583486494967008"
																																						}
																																					],
																																					"jsonIgnoreAliasValue": null,
																																					"id": "583489690571860"
																																				},
																																				"id": "583485002559103"
																																			}
																																		]
																																	},
																																	"value": "relatedPartiesObjectKeySet@local"
																																},
																																"format": "iterate"
																															}
																														},
																														"operator": {
																															"actualValue": "="
																														}
																													}
																												},
																												{
																													"id": "583481542710850",
																													"@type": "AssignmentStatement",
																													"assignment": {
																														"lhs": {
																															"@type": "literal",
																															"dataType": "text",
																															"dataValue": "collectedValues"
																														},
																														"operator": {
																															"actualValue": "="
																														},
																														"rhs": {
																															"@type": "variable",
																															"dataType": "text",
																															"dataValue": "collectedValues@local"
																														}
																													},
																													"name": "XrHXT"
																												},
																												{
																													"id": "583482343404498",
																													"@type": "AssignmentStatement",
																													"assignment": {
																														"@type": "SimpleAssignmentStatement",
																														"lhs": {
																															"@type": "declare",
																															"dataValue": "A",
																															"dataType": "number"
																														},
																														"operator": {
																															"actualValue": "="
																														},
																														"rhs": {
																															"@type": "expression",
																															"structure": {
																																"@type": "arithmetic",
																																"dataType": "+",
																																"variables": [
																																	{
																																		"@type": "local",
																																		"dataType": "number",
																																		"dataValue": "A"
																																	},
																																	{
																																		"@type": "literal",
																																		"dataType": "number",
																																		"dataValue": 1
																																	}
																																]
																															},
																															"dataType": "number"
																														}
																													},
																													"name": "Cornell"
																												}
																											],
																											"jsonIgnoreAliasValue": null,
																											"id": "583489498771794"
																										},
																										"id": "583483766472163"
																									}
																								],
																								"id": "583481800877359"
																							},
																							"id": "154291775149777"
																						}
																					],
																					"jsonIgnoreAliasValue": null,
																					"id": "583485216600889"
																				},
																				"id": "583488219421542"
																			}
																		]
																	},
																	"value": "relatedParties"
																},
																"format": "iterate"
															}
														}
													},
													"name": "Demetris"
												}
											],
											"jsonIgnoreAliasValue": null,
											"id": "583481700608294"
										},
										"id": "583486913315356"
									}
								],
								"id": "583482460757215"
							},
							"id": "154293167671638"
						}
					],
					"jsonIgnoreAliasValue": null,
					"id": "583486299733529"
				},
				"id": "583483668538776"
			}
		]
	},
	"delete": {},
	"extract": {},
	"id": "583481028711183"
  }`

const NewRequirement = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Frieda",
		  "statements" : [ {
			"id" : "154774669525577",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "keyword",
				"dataValue" : "none",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "number"
			  }
			},
			"name" : "Nayeli"
		  }, {
			"id" : "155133473353579",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ ]
					},
					"value" : "data"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Delores"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "155131384688733"
		},
		"id" : "155131249410053"
	  } ]
	}
  }`

const KeywordDateInMonths = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Marlin",
		  "statements" : [ {
			"id" : "155551449840615",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "experienceInMonths",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "number",
				"keywordArguments" : {
				  "format" : "inMonths",
				  "init" : {
					"value" : "experience",
					"format" : "inYears"
				  }
				}
			  }
			},
			"name" : "Deion"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "155555786407375"
		},
		"id" : "155559593869967"
	  } ]
	}
  }`

const ReplaceNullWithChar = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "jsonIgnoreProperty" : true,
	  "jsonIgnoreAliasValue" : "/",
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : true,
		  "name" : "Leo",
		  "statements" : [ {
			"id" : "155908469485945",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Javeed salary",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "salary",
				"dataType" : "text"
			  }
			},
			"name" : "Cordia"
		  }, {
			"id" : "156397013074777",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "details",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "jsonIgnoreProperty" : true,
					  "jsonIgnoreAliasValue" : "/",
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : true,
						  "name" : "Alexandria",
						  "statements" : [ {
							"id" : "156399903028185",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "idType",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "GSTIN",
								"dataType" : "text"
							  }
							},
							"name" : "Martin"
						  } ],
						  "jsonIgnoreAliasValue" : "/",
						  "id" : "156395017194630"
						},
						"id" : "156396730933827"
					  } ]
					},
					"value" : "data"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Reed"
		  }, {
			"id" : "156951444874991",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "allDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "jsonIgnoreProperty" : true,
					  "jsonIgnoreAliasValue" : "/",
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : true,
						  "name" : "Alexandrea",
						  "statements" : [ {
							"id" : "156959618574546",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "idType",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "GSTIN",
								"dataType" : "text"
							  }
							},
							"name" : "Rosemarie"
						  } ],
						  "jsonIgnoreAliasValue" : "/",
						  "id" : "156954136212890"
						},
						"id" : "156953434302537"
					  } ]
					},
					"value" : "data@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Hailee"
		  } ],
		  "jsonIgnoreAliasValue" : "/",
		  "id" : "156951111126668"
		},
		"id" : "156952421797508"
	  } ]
	}
  }`

const EmptyStringComparison = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Winifred",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "flag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Antwon",
				  "statements" : [ {
					"id" : "157892839142357",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "condition",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "true",
						"dataType" : "text"
					  }
					},
					"name" : "Graham"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "157898287532924"
				},
				"id" : "157894134789567"
			  } ],
			  "id" : "157898158776391"
			},
			"failure" : null,
			"id" : 1
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "157897325288221"
		},
		"id" : "157897568141720"
	  } ]
	}
  }`

const RelatedParties2 = ` {
	"version": "1",
	"@type": "transform",
	"transform": {
		"id": "transform_config_2",
		"name": "transform Consumer Communication Address Details",
		"statements": [
			{
				"@type": "SectionalStatement",
				"section": {
					"jsonIgnoreProperty": false,
					"name": "JeNob",
					"statements": [
						{
							"@type": "SectionalStatement",
							"name": "xLGZZ",
							"section": {
								"name": null,
								"statements": [
									{
										"@type": "SectionalStatement",
										"section": {
											"jsonIgnoreProperty": false,
											"name": "TfFFh",
											"statements": [
												{
													"id": "571509134981636",
													"@type": "AssignmentStatement",
													"assignment": {
														"lhs": {
															"@type": "declare",
															"dataValue": "CollecteD_Keys",
															"dataType": "list"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "keyword",
															"dataType": "list",
															"dataValue": "list",
															"keywordArguments": {
																"init": {
																	"transform": {
																		"id": "transform_config_1",
																		"name": "Collect",
																		"statements": [
																			{
																				"@type": "SectionalStatement",
																				"section": {
																					"jsonIgnoreProperty": false,
																					"name": "fcQnY",
																					"statements": [
																						{
																							"id": "571468862757618",
																							"@type": "AssignmentStatement",
																							"assignment": {
																								"lhs": {
																									"@type": "declare",
																									"dataType": "text",
																									"dataValue": "relatedPartiesObject"
																								},
																								"operator": {
																									"actualValue": "="
																								},
																								"rhs": {
																									"@type": "keyword",
																									"dataType": "text",
																									"dataValue": "value"
																								}
																							},
																							"name": "dIUvB"
																						},
																						{
																							"id": "571498670706817",
																							"@type": "AssignmentStatement",
																							"assignment": {
																								"lhs": {
																									"@type": "declare",
																									"dataType": "text",
																									"dataValue": "relatedPartiesObjectKeySet"
																								},
																								"operator": {
																									"actualValue": "="
																								},
																								"rhs": {
																									"@type": "keyword",
																									"dataType": "text",
																									"dataValue": "map",
																									"keywordArguments": {
																										"format": "getKeySet",
																										"init": {
																											"value": "relatedPartiesObject@local"
																										}
																									}
																								}
																							},
																							"name": "JDkQb"
																						},
																						{
																							"id": "571505485033223",
																							"name": "Statement 1697201799113696",
																							"@type": "AssignmentStatement",
																							"mandatory": true,
																							"assignment": {
																								"lhs": {
																									"@type": "declare",
																									"dataType": "list",
																									"dataValue": "relatedPartieslist"
																								},
																								"rhs": {
																									"@type": "keyword",
																									"dataType": "list",
																									"dataValue": "list",
																									"keywordArguments": {
																										"init": {
																											"transform": {
																												"id": "6744641075848",
																												"name": "Iterate 724645",
																												"statements": [
																													{
																														"@type": "SectionalStatement",
																														"section": {
																															"jsonIgnoreProperty": false,
																															"name": "cxIGZ",
																															"statements": [
																																{
																																	"id": "571493973338739",
																																	"@type": "AssignmentStatement",
																																	"assignment": {
																																		"lhs": {
																																			"@type": "declare",
																																			"dataType": "text",
																																			"dataValue": "relatedPartiesKey"
																																		},
																																		"operator": {
																																			"actualValue": "="
																																		},
																																		"rhs": {
																																			"@type": "keyword",
																																			"dataType": "text",
																																			"dataValue": "value"
																																		}
																																	},
																																	"name": "Bijuo"
																																},
																																{
																																	"condition": {
																																		"@type": "logical",
																																		"type": "and",
																																		"rules": [
																																			{
																																				"@type": "relational",
																																				"lhs": {
																																					"@type": "literal",
																																					"dataValue": true,
																																					"dataType": "text"
																																				},
																																				"operator": {
																																					"actualValue": "=="
																																				},
																																				"rhs": {
																																					"@type": "keyword",
																																					"dataValue": "map",
																																					"dataType": "text",
																																					"keywordArguments": {
																																						"format": "getValueByKey",
																																						"init": {
																																							"key": "relatedPartiesKey@local",
																																							"value": "relatedPartiesObject@local"
																																						}
																																					}
																																				}
																																			}
																																		]
																																	},
																																	"@type": "ConditionalStatement",
																																	"success": {
																																		"name": "transformation",
																																		"statements": [
																																			{
																																				"@type": "SectionalStatement",
																																				"section": {
																																					"jsonIgnoreProperty": false,
																																					"name": "yphLx",
																																					"statements": [
																																						{
																																							"@type": "SectionalStatement",
																																							"name": "je9kK",
																																							"section": {
																																								"name": null,
																																								"statements": [
																																									{
																																										"@type": "SectionalStatement",
																																										"section": {
																																											"jsonIgnoreProperty": false,
																																											"name": "bWAnv",
																																											"statements": [
																																												{
																																													"id": "571495001714772",
																																													"name": "Statement 1697536215578009",
																																													"@type": "AssignmentStatement",
																																													"mandatory": true,
																																													"assignment": {
																																														"lhs": {
																																															"@type": "declare",
																																															"dataType": "list",
																																															"dataValue": "primitives"
																																														},
																																														"rhs": {
																																															"@type": "keyword",
																																															"dataType": "list",
																																															"dataValue": "list",
																																															"keywordArguments": {
																																																"init": {
																																																	"values": [
																																																		"relatedPartiesKey@local"
																																																	]
																																																},
																																																"format": "push"
																																															}
																																														},
																																														"operator": {
																																															"actualValue": "="
																																														}
																																													}
																																												}
																																											],
																																											"jsonIgnoreAliasValue": null,
																																											"id": "571495170032978"
																																										},
																																										"id": "571491009868636"
																																									}
																																								],
																																								"id": "571491499625334"
																																							},
																																							"id": "571498885161049"
																																						}
																																					],
																																					"jsonIgnoreAliasValue": null,
																																					"id": "571492862703929"
																																				},
																																				"id": "571498024860821"
																																			}
																																		],
																																		"id": "571501089004978"
																																	},
																																	"failure": {},
																																	"id": "571496326727170"
																																}
																															],
																															"jsonIgnoreAliasValue": null,
																															"id": "571504971601238"
																														},
																														"id": "571504841091445"
																													}
																												]
																											},
																											"value": "relatedPartiesObjectKeySet@local"
																										},
																										"format": "iterate"
																									}
																								},
																								"operator": {
																									"actualValue": "="
																								}
																							}
																						}
																					],
																					"jsonIgnoreAliasValue": null,
																					"id": "571507933664473"
																				},
																				"id": "571502615400584"
																			}
																		]
																	},
																	"value": "relatedParties"
																},
																"format": "iterate"
															}
														}
													},
													"name": "Tyler"
												},
												{
													"id": "571503316490787",
													"@type": "AssignmentStatement",
													"assignment": {
														"@type": "SimpleAssignmentStatement",
														"lhs": {
															"@type": "literal",
															"dataValue": "PrimitiveArray",
															"dataType": "text"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "local",
															"dataValue": "primitives",
															"dataType": "text"
														}
													},
													"name": "Naomie"
												},
												{
													"id": "571515208481158",
													"@type": "AssignmentStatement",
													"assignment": {
														"@type": "SimpleAssignmentStatement",
														"lhs": {
															"@type": "declare",
															"dataValue": "customerMappingObject",
															"dataType": "list"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "keyword",
															"dataType": "list",
															"dataValue": "list",
															"keywordArguments": {
																"init": {
																	"transform": {
																		"id": "transform_config_1",
																		"name": "transform Address Information",
																		"statements": [
																			{
																				"@type": "SectionalStatement",
																				"section": {
																					"jsonIgnoreProperty": false,
																					"name": "EopWF",
																					"statements": [
																						{
																							"@type": "SectionalStatement",
																							"name": "IMN1f",
																							"section": {
																								"name": null,
																								"statements": [
																									{
																										"@type": "SectionalStatement",
																										"section": {
																											"jsonIgnoreProperty": false,
																											"name": "eneKI",
																											"statements": [
																												{
																													"condition": {
																														"@type": "logical",
																														"type": "or",
																														"rules": [
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "director",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "partner",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "Proprietor",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "karta",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "pOAHolder",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "coParcener",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "shareHolder",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "authorisedSignatory",
																																	"dataType": "text"
																																}
																															}
																														]
																													},
																													"@type": "ConditionalStatement",
																													"success": {
																														"name": "transformation",
																														"statements": [
																															{
																																"@type": "SectionalStatement",
																																"section": {
																																	"jsonIgnoreProperty": false,
																																	"name": "IEwmB",
																																	"statements": [
																																		{
																																			"@type": "SectionalStatement",
																																			"name": "VJay2",
																																			"section": {
																																				"name": null,
																																				"statements": [
																																					{
																																						"@type": "SectionalStatement",
																																						"section": {
																																							"jsonIgnoreProperty": false,
																																							"name": "dFucP",
																																							"statements": [
																																								{
																																									"id": "571513157039351",
																																									"@type": "AssignmentStatement",
																																									"assignment": {
																																										"lhs": {
																																											"@type": "declare",
																																											"dataValue": "customerMapping",
																																											"dataType": "text"
																																										},
																																										"operator": {
																																											"actualValue": "="
																																										},
																																										"rhs": {
																																											"@type": "keyword",
																																											"dataType": "list",
																																											"dataValue": "list",
																																											"keywordArguments": {
																																												"init": {
																																													"transform": {
																																														"id": "transform_config_1",
																																														"name": "customer Response",
																																														"statements": [
																																															{
																																																"@type": "SectionalStatement",
																																																"section": {
																																																	"jsonIgnoreProperty": false,
																																																	"name": "dDQpo",
																																																	"statements": [
																																																		{
																																																			"@type": "SectionalStatement",
																																																			"name": "AKirZ",
																																																			"section": {
																																																				"name": null,
																																																				"statements": [
																																																					{
																																																						"@type": "SectionalStatement",
																																																						"section": {
																																																							"jsonIgnoreProperty": false,
																																																							"name": "XOWWx",
																																																							"statements": [
																																																								{
																																																									"id": "571504853025991",
																																																									"@type": "AssignmentStatement",
																																																									"assignment": {
																																																										"lhs": {
																																																											"@type": "literal",
																																																											"dataValue": "customerMapping",
																																																											"dataType": "text"
																																																										},
																																																										"operator": {
																																																											"actualValue": "="
																																																										},
																																																										"rhs": {
																																																											"@type": "keyword",
																																																											"dataValue": "value",
																																																											"dataType": "text"
																																																										}
																																																									},
																																																									"name": "Pedro"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "director",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "gFAxO",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "tbo4b",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "aBtdd",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571507663301384",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingdirectorId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Grayce"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571501975802901"
																																																																		},
																																																																		"id": "571504747386944"
																																																																	}
																																																																],
																																																																"id": "571502244575016"
																																																															},
																																																															"id": "571508246205050"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571502023910483"
																																																												},
																																																												"id": "571503282194544"
																																																											}
																																																										],
																																																										"id": "571507959627369"
																																																									},
																																																									"failure": {},
																																																									"id": "571506385969243"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "partner",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "IFJnP",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "6yHJu",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "rgJNC",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571508891455227",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingPartnerId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Maci"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571506135014666"
																																																																		},
																																																																		"id": "571501587213411"
																																																																	}
																																																																],
																																																																"id": "571503684474604"
																																																															},
																																																															"id": "571503026632872"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571509875487780"
																																																												},
																																																												"id": "571502927152508"
																																																											}
																																																										],
																																																										"id": "571502362568150"
																																																									},
																																																									"failure": {},
																																																									"id": "571509884668695"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "Proprietor",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "jXnho",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "KynAq",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "KLHHu",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571507775908076",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingProprietorId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Gerard"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571504845177006"
																																																																		},
																																																																		"id": "571507956610322"
																																																																	}
																																																																],
																																																																"id": "571503617344499"
																																																															},
																																																															"id": "571503022893268"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571506473379999"
																																																												},
																																																												"id": "571507891190234"
																																																											}
																																																										],
																																																										"id": "571501439485248"
																																																									},
																																																									"failure": {},
																																																									"id": "571501666602292"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "karta",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "WOojk",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "DDVOR",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "vGheB",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571506386680054",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingKartaId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Brandon"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571509980642037"
																																																																		},
																																																																		"id": "571508963873322"
																																																																	}
																																																																],
																																																																"id": "571504480575178"
																																																															},
																																																															"id": "571503218678303"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571504764885696"
																																																												},
																																																												"id": "571506347197277"
																																																											}
																																																										],
																																																										"id": "571502404592831"
																																																									},
																																																									"failure": {},
																																																									"id": "571504319947698"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "pOAHolder",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "ySUrV",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "hrPp8",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "oNuKP",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571502408594251",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingpOAHolderId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Iva"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571507931401562"
																																																																		},
																																																																		"id": "571504768198309"
																																																																	}
																																																																],
																																																																"id": "571506665836714"
																																																															},
																																																															"id": "571505984604669"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571507146896460"
																																																												},
																																																												"id": "571505288417830"
																																																											}
																																																										],
																																																										"id": "571506978066049"
																																																									},
																																																									"failure": {},
																																																									"id": "571508383516513"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "coParcener",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "UzTRj",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "tFGXC",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "gIcAV",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571507113878618",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingcoParcenerId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Jorge"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571504655102355"
																																																																		},
																																																																		"id": "571507864346128"
																																																																	}
																																																																],
																																																																"id": "571504842320736"
																																																															},
																																																															"id": "571504337011689"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571504803278915"
																																																												},
																																																												"id": "571506123817108"
																																																											}
																																																										],
																																																										"id": "571509049078324"
																																																									},
																																																									"failure": {},
																																																									"id": "571506904011796"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "shareHolder",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "KWVEK",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "viRL4",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "BZuNc",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571504940914758",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingshareHolderId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Andy"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571504887445573"
																																																																		},
																																																																		"id": "571502629511432"
																																																																	}
																																																																],
																																																																"id": "571505570241746"
																																																															},
																																																															"id": "571507085035493"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571504267040230"
																																																												},
																																																												"id": "571509280725747"
																																																											}
																																																										],
																																																										"id": "571503167334456"
																																																									},
																																																									"failure": {},
																																																									"id": "571507124732255"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "authorisedSignatory",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "IDWiQ",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "5o0tN",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "gOYIm",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571511673177290",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingauthorisedSignatoryId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Kian"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571518893980137"
																																																																		},
																																																																		"id": "571512070114134"
																																																																	}
																																																																],
																																																																"id": "571511950991240"
																																																															},
																																																															"id": "571518260676816"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571514150447462"
																																																												},
																																																												"id": "571513573509951"
																																																											}
																																																										],
																																																										"id": "571512282497824"
																																																									},
																																																									"failure": {},
																																																									"id": "571504582324519"
																																																								}
																																																							],
																																																							"jsonIgnoreAliasValue": null,
																																																							"id": "571517171893191"
																																																						},
																																																						"id": "571516842050352"
																																																					}
																																																				],
																																																				"id": "571518885221998"
																																																			},
																																																			"id": "571508073553367"
																																																		}
																																																	],
																																																	"jsonIgnoreAliasValue": null,
																																																	"id": "571518888306131"
																																																},
																																																"id": "571518061423396"
																																															}
																																														]
																																													}
																																												},
																																												"format": "iterate"
																																											}
																																										}
																																									},
																																									"name": "Annie"
																																								}
																																							],
																																							"jsonIgnoreAliasValue": null,
																																							"id": "571518754567277"
																																						},
																																						"id": "571516559058621"
																																					}
																																				],
																																				"id": "571514236677907"
																																			},
																																			"id": "571507454438121"
																																		}
																																	],
																																	"jsonIgnoreAliasValue": null,
																																	"id": "571513565779820"
																																},
																																"id": "571515929454675"
																															}
																														],
																														"id": "571519514299458"
																													},
																													"failure": {},
																													"id": "571505352346668"
																												}
																											],
																											"jsonIgnoreAliasValue": null,
																											"id": "571511418635560"
																										},
																										"id": "571517232670783"
																									}
																								],
																								"id": "571516236020016"
																							},
																							"id": "571508727848457"
																						}
																					],
																					"jsonIgnoreAliasValue": null,
																					"id": "571514276666619"
																				},
																				"id": "571512317278482"
																			}
																		]
																	},
																	"value": "primitives@local"
																},
																"format": "iterate"
															}
														}
													},
													"name": "Zoila"
												},
												{
													"id": "571511726406026",
													"@type": "AssignmentStatement",
													"assignment": {
														"@type": "SimpleAssignmentStatement",
														"lhs": {
															"@type": "literal",
															"dataValue": "localArray",
															"dataType": "text"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "local",
															"dataValue": "customerMapping",
															"dataType": "text"
														}
													},
													"name": "Lamont"
												},
												{
													"id": "571517952628529",
													"@type": "AssignmentStatement",
													"assignment": {
														"@type": "SimpleAssignmentStatement",
														"lhs": {
															"@type": "declare",
															"dataValue": "customerObject",
															"dataType": "list"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "keyword",
															"dataType": "list",
															"dataValue": "list",
															"keywordArguments": {
																"init": {
																	"transform": {
																		"id": "transform_config_1",
																		"name": "transform Address Information",
																		"statements": [
																			{
																				"@type": "SectionalStatement",
																				"section": {
																					"jsonIgnoreProperty": false,
																					"name": "WIqoo",
																					"statements": [
																						{
																							"@type": "SectionalStatement",
																							"name": "UXiMz",
																							"section": {
																								"name": null,
																								"statements": [
																									{
																										"@type": "SectionalStatement",
																										"section": {
																											"jsonIgnoreProperty": false,
																											"name": "Muroi",
																											"statements": [
																												{
																													"condition": {
																														"@type": "logical",
																														"type": "or",
																														"rules": [
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "guarantor",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "coBorrower",
																																	"dataType": "text"
																																}
																															},
																															{
																																"@type": "relational",
																																"lhs": {
																																	"@type": "keyword",
																																	"dataType": "text",
																																	"dataValue": "value"
																																},
																																"operator": {
																																	"actualValue": "=="
																																},
																																"rhs": {
																																	"@type": "literal",
																																	"dataValue": "applicant",
																																	"dataType": "text"
																																}
																															}
																														]
																													},
																													"@type": "ConditionalStatement",
																													"success": {
																														"name": "transformation",
																														"statements": [
																															{
																																"@type": "SectionalStatement",
																																"section": {
																																	"jsonIgnoreProperty": false,
																																	"name": "ImmcD",
																																	"statements": [
																																		{
																																			"@type": "SectionalStatement",
																																			"name": "cBdgq",
																																			"section": {
																																				"name": null,
																																				"statements": [
																																					{
																																						"@type": "SectionalStatement",
																																						"section": {
																																							"jsonIgnoreProperty": false,
																																							"name": "YQGmw",
																																							"statements": [
																																								{
																																									"id": "571516287955212",
																																									"@type": "AssignmentStatement",
																																									"assignment": {
																																										"lhs": {
																																											"@type": "declare",
																																											"dataValue": "customer",
																																											"dataType": "text"
																																										},
																																										"operator": {
																																											"actualValue": "="
																																										},
																																										"rhs": {
																																											"@type": "keyword",
																																											"dataType": "list",
																																											"dataValue": "list",
																																											"keywordArguments": {
																																												"init": {
																																													"transform": {
																																														"id": "transform_config_1",
																																														"name": "customer Response",
																																														"statements": [
																																															{
																																																"@type": "SectionalStatement",
																																																"section": {
																																																	"jsonIgnoreProperty": false,
																																																	"name": "szwvq",
																																																	"statements": [
																																																		{
																																																			"@type": "SectionalStatement",
																																																			"name": "bxYRS",
																																																			"section": {
																																																				"name": null,
																																																				"statements": [
																																																					{
																																																						"@type": "SectionalStatement",
																																																						"section": {
																																																							"jsonIgnoreProperty": false,
																																																							"name": "PCFJr",
																																																							"statements": [
																																																								{
																																																									"id": "571515424368770",
																																																									"@type": "AssignmentStatement",
																																																									"assignment": {
																																																										"lhs": {
																																																											"@type": "literal",
																																																											"dataValue": "customer",
																																																											"dataType": "text"
																																																										},
																																																										"operator": {
																																																											"actualValue": "="
																																																										},
																																																										"rhs": {
																																																											"@type": "keyword",
																																																											"dataValue": "value",
																																																											"dataType": "text"
																																																										}
																																																									},
																																																									"name": "Bell"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "guarantor",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "TgghS",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "Iy3bh",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "bywcT",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571517235018511",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingguarantorId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Jalon"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571514445456107"
																																																																		},
																																																																		"id": "571512893686333"
																																																																	}
																																																																],
																																																																"id": "571518167742334"
																																																															},
																																																															"id": "571517729830878"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571513953330024"
																																																												},
																																																												"id": "571511857029895"
																																																											}
																																																										],
																																																										"id": "571513271385733"
																																																									},
																																																									"failure": {},
																																																									"id": "571518334696255"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "coBorrower",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "Iivcv",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "8oFNo",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "oJqPx",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571516522387595",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingcoBorrowerId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Darien"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571511060599565"
																																																																		},
																																																																		"id": "571517392607438"
																																																																	}
																																																																],
																																																																"id": "571518428810502"
																																																															},
																																																															"id": "571514520502419"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571512407050872"
																																																												},
																																																												"id": "571517999601376"
																																																											}
																																																										],
																																																										"id": "571516948815660"
																																																									},
																																																									"failure": {},
																																																									"id": "571518632548806"
																																																								},
																																																								{
																																																									"condition": {
																																																										"@type": "logical",
																																																										"type": "and",
																																																										"rules": [
																																																											{
																																																												"@type": "relational",
																																																												"lhs": {
																																																													"@type": "keyword",
																																																													"dataType": "text",
																																																													"dataValue": "value"
																																																												},
																																																												"operator": {
																																																													"actualValue": "=="
																																																												},
																																																												"rhs": {
																																																													"@type": "literal",
																																																													"dataValue": "applicant",
																																																													"dataType": "text"
																																																												}
																																																											}
																																																										]
																																																									},
																																																									"@type": "ConditionalStatement",
																																																									"success": {
																																																										"name": "transformation",
																																																										"statements": [
																																																											{
																																																												"@type": "SectionalStatement",
																																																												"section": {
																																																													"jsonIgnoreProperty": false,
																																																													"name": "dYfSN",
																																																													"statements": [
																																																														{
																																																															"@type": "SectionalStatement",
																																																															"name": "Vi2XD",
																																																															"section": {
																																																																"name": null,
																																																																"statements": [
																																																																	{
																																																																		"@type": "SectionalStatement",
																																																																		"section": {
																																																																			"jsonIgnoreProperty": false,
																																																																			"name": "qBvLl",
																																																																			"statements": [
																																																																				{
																																																																					"id": "571518868683722",
																																																																					"@type": "AssignmentStatement",
																																																																					"assignment": {
																																																																						"lhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "customerMappingapplicantId",
																																																																							"dataType": "text"
																																																																						},
																																																																						"operator": {
																																																																							"actualValue": "="
																																																																						},
																																																																						"rhs": {
																																																																							"@type": "literal",
																																																																							"dataValue": "",
																																																																							"dataType": "number"
																																																																						}
																																																																					},
																																																																					"name": "Maeve"
																																																																				}
																																																																			],
																																																																			"jsonIgnoreAliasValue": null,
																																																																			"id": "571517502828841"
																																																																		},
																																																																		"id": "571514237207110"
																																																																	}
																																																																],
																																																																"id": "571512543625617"
																																																															},
																																																															"id": "571514507925258"
																																																														}
																																																													],
																																																													"jsonIgnoreAliasValue": null,
																																																													"id": "571512944509480"
																																																												},
																																																												"id": "571513347795895"
																																																											}
																																																										],
																																																										"id": "571512293362377"
																																																									},
																																																									"failure": {},
																																																									"id": "571517007770057"
																																																								}
																																																							],
																																																							"jsonIgnoreAliasValue": null,
																																																							"id": "571511128900436"
																																																						},
																																																						"id": "571515014906526"
																																																					}
																																																				],
																																																				"id": "571517978256952"
																																																			},
																																																			"id": "571513975340624"
																																																		}
																																																	],
																																																	"jsonIgnoreAliasValue": null,
																																																	"id": "571511899854482"
																																																},
																																																"id": "571515278888141"
																																															}
																																														]
																																													}
																																												},
																																												"format": "iterate"
																																											}
																																										}
																																									},
																																									"name": "Robert"
																																								}
																																							],
																																							"jsonIgnoreAliasValue": null,
																																							"id": "571518449984485"
																																						},
																																						"id": "571514189834313"
																																					}
																																				],
																																				"id": "571513812076009"
																																			},
																																			"id": "571512343257123"
																																		}
																																	],
																																	"jsonIgnoreAliasValue": null,
																																	"id": "571513792346188"
																																},
																																"id": "571515057090687"
																															}
																														],
																														"id": "571514413480536"
																													},
																													"failure": {},
																													"id": "571518499484759"
																												}
																											],
																											"jsonIgnoreAliasValue": null,
																											"id": "571516065626736"
																										},
																										"id": "571511079703733"
																									}
																								],
																								"id": "571516379423960"
																							},
																							"id": "571513711866524"
																						}
																					],
																					"jsonIgnoreAliasValue": null,
																					"id": "571514299240464"
																				},
																				"id": "571512464885139"
																			}
																		]
																	},
																	"value": "primitives@local"
																},
																"format": "iterate"
															}
														}
													},
													"name": "Norberto"
												},
												{
													"id": "571512738507405",
													"@type": "AssignmentStatement",
													"assignment": {
														"@type": "SimpleAssignmentStatement",
														"lhs": {
															"@type": "literal",
															"dataValue": "local2ndArray",
															"dataType": "text"
														},
														"operator": {
															"actualValue": "="
														},
														"rhs": {
															"@type": "local",
															"dataValue": "customer",
															"dataType": "text"
														}
													},
													"name": "Hobart"
												}
											],
											"jsonIgnoreAliasValue": null,
											"id": "571513149439470"
										},
										"id": "571516213816421"
									}
								],
								"id": "571514075665130"
							},
							"id": "571427809731718"
						}
					],
					"jsonIgnoreAliasValue": null,
					"id": "571518577998508"
				},
				"id": "571515388033031"
			}
		]
	},
	"id": "571514701630131"
  }`

const ConditionTestingTestingTextValAsNUmeric = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":1,"@type":"ConditionalStatement","condition":{"@type":"logical","type":"and","rules":[{"@type":"relational","lhs":{"@type":"literal","dataValue":3,"dataType":"number"},"operator":{"actualValue":"=="},"rhs":{"@type":"literal","dataValue":"5","dataType":"number"}},{"@type":"relational","lhs":{"@type":"literal","dataValue":true,"dataType":"boolean"},"operator":{"actualValue":"=="},"rhs":{"@type":"literal","dataValue":"false","dataType":"boolean"}}]},"statements":[{"id":"1","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"condition","dataType":"text"},"operator":{"actualValue":"="},"rhs":{"@type":"literal","dataValue":"true","dataType":"text"}}}]}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":null},"contentInputType":"json","contentOutputType":"json"}`

const Localtransform = `{
	"version": 1,
	"@type": "transform",
	"transform": {
	  "id": "transform_config_1",
	  "name": "transform cibilresponse for Grid",
	  "statements": [
		{
		  "@type": "SectionalStatement",
		  "section": {
			"jsonIgnoreProperty": false,
			"name": "Shirley",
			"statements": [
			  {
				"id": "166902314322841",
				"@type": "AssignmentStatement",
				"assignment": {
				  "lhs": {
					"@type": "literal",
					"dataValue": "ffff",
					"dataType": "number"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "variable",
					"dataValue": "address.[0].city",
					"dataType": "number"
				  }
				},
				"name": "Quinton"
			  },
			  {
				"id": "167084330901693",
				"@type": "AssignmentStatement",
				"assignment": {
				  "lhs": {
					"@type": "declare",
					"dataValue": "a",
					"dataType": "number"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "variable",
					"dataValue": "data",
					"dataType": "number"
				  }
				},
				"name": "Vivienne"
			  },
			  {
				"id": "167739073568584",
				"@type": "AssignmentStatement",
				"assignment": {
				  "lhs": {
					"@type": "declare",
					"dataValue": "dummyArray",
					"dataType": "list"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "keyword",
					"dataType": "list",
					"dataValue": "list",
					"keywordArguments": {
					  "init": {
						"transform": {
						  "id": "transform_config_2",
						  "name": "transform Consumer Communication Address Details",
						  "statements": [
							{
							  "@type": "SectionalStatement",
							  "section": {
								"jsonIgnoreProperty": false,
								"name": "Anita",
								"statements": [
								  {
									"id": "167737569306724",
									"@type": "AssignmentStatement",
									"assignment": {
									  "@type": "SimpleAssignmentStatement",
									  "lhs": {
										"@type": "literal",
										"dataValue": "address1",
										"dataType": "number"
									  },
									  "operator": {
										"actualValue": "=",
										"expressionType": "SimpleAssignment",
										"dataType": "text"
									  },
									  "rhs": {
										"@type": "keyword",
										"dataValue": "date",
										"dataType": "date",
										"keywordArguments": {
										  "format": "unixTime",
										  "init": {
											"value": "sd",
											"format": "MMM-yy"
										  }
										}
									  }
									},
									"name": "Mireille"
								  }
								],
								"jsonIgnoreAliasValue": null,
								"id": "167738012620180"
							  },
							  "id": "167739713647842"
							}
						  ]
						},
						"value": "data"
					  },
					  "format": "iterate"
					}
				  }
				},
				"name": "Loyal"
			  },
			  {
				"id": "167903441766796",
				"@type": "AssignmentStatement",
				"assignment": {
				  "@type": "SimpleAssignmentStatement",
				  "lhs": {
					"@type": "literal",
					"dataValue": "maxDate",
					"dataType": "list"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "keyword",
					"dataType": "number",
					"dataValue": "list",
					"keywordArguments": {
					  "init": {
						"value": "dummyArray@local",
						"aggregate": "address1"
					  },
					  "format": "max"
					}
				  }
				},
				"name": "Kacie"
			  },
			  {
				"id": "168089990210661",
				"@type": "AssignmentStatement",
				"assignment": {
				  "@type": "SimpleAssignmentStatement",
				  "lhs": {
					"@type": "literal",
					"dataValue": "c",
					"dataType": "list"
				  },
				  "operator": {
					"actualValue": "="
				  },
				  "rhs": {
					"@type": "local",
					"dataValue": "dummyArray",
					"dataType": "list"
				  }
				},
				"name": "Marc"
			  }
			],
			"jsonIgnoreAliasValue": null,
			"id": "168089246653249"
		  },
		  "id": "168082020131764"
		}
	  ]
	}
  }`

const PrimitiveExpression = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "abc",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Bruce",
		  "statements" : [ {
			"id" : "168542892719784",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "A",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Conor"
		  }, {
			"id" : "169369757403419",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "CollecteD_Values",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transforming_Collect_Function",
					  "name" : "Generating_Collect_Array",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Amber",
						  "statements" : [ {
							"id" : "169024220078234",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "B",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataValue" : "value",
								"dataType" : "number"
							  }
							},
							"name" : "Christiana"
						  }, {
							"id" : "169148260756953",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "A",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "B"
								  }, {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "A"
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Johnny"
						  }, {
							"id" : "169367567756018",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "Afterarthematic",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "local",
								"dataValue" : "A",
								"dataType" : "number"
							  }
							},
							"name" : "Eleazar"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "169361981952261"
						},
						"id" : "169363064564741"
					  } ]
					},
					"value" : "primitives"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Marc"
		  }, {
			"id" : "169523324419697",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "localValue",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "CollecteD_Values",
				"dataType" : "list"
			  }
			},
			"name" : "Johan"
		  }, {
			"id" : "169691052213341",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "localA",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "A@local",
				"dataType" : "number"
			  }
			},
			"name" : "Pauline"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "169698964791766"
		},
		"id" : "169696405944962"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const VersionedConfigFile = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Tommie",
		  "statements" : [ {
			"id" : "170097647508354",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataType" : "text",
				"dataValue" : "normalStatement"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataType" : "text",
				"dataValue" : "normalStatement"
			  }
			},
			"name" : "Priscilla"
		  }, {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : "Statement 1697108026382390",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Kamren",
				  "statements" : [ {
					"id" : "170589559785364",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "Section.InsideSection"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "InsideSection"
					  }
					},
					"name" : "Dillon"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "170581924497592"
				},
				"id" : "170582400676219"
			  } ],
			  "id" : "170589280431321"
			},
			"id" : 1697107976635457
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "literal",
				  "dataValue" : "individualFlag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "individualFlag2",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "statements" : [ {
				"id" : 1,
				"@type" : "AssignmentStatement",
				"assignment" : {
				  "lhs" : {
					"@type" : "literal",
					"dataType" : "text",
					"dataValue" : "Condition"
				  },
				  "operator" : {
					"actualValue" : "="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataType" : "text",
					"dataValue" : "true"
				  }
				}
			  } ]
			},
			"failure" : {
			  "statements" : [ {
				"id" : 1,
				"@type" : "AssignmentStatement",
				"assignment" : {
				  "lhs" : {
					"@type" : "literal",
					"dataType" : "text",
					"dataValue" : "Condition"
				  },
				  "operator" : {
					"actualValue" : "="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataType" : "text",
					"dataValue" : "false"
				  }
				}
			  } ]
			},
			"id" : 11211
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "170588546273536"
		},
		"id" : "170586447625684"
	  } ]
	}
  }`

const LocalArrayValues = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Shemar",
		  "statements" : [ {
			"id" : "171234174665459",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "primaryGSTIN",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "primaryGSTIN",
					"splitby" : ","
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Karolann"
		  }, {
			"id" : "171587480119907",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "primaryGSTINNI",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "text",
				"keywordArguments" : {
				  "init" : {
					"value" : "primaryGSTINNI",
					"splitby" : ","
				  },
				  "format" : "split"
				}
			  }
			},
			"name" : "Anna"
		  }, {
			"id" : "171892721705517",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "A",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "declare",
				"dataValue" : 1,
				"dataType" : "number"
			  }
			},
			"name" : "Bernardo"
		  }, {
			"id" : "173312574213524",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "consumerDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Deontae",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 1,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Patience",
								  "statements" : [ {
									"id" : "172688574972486",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "cpIdentityId",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Michael"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "172686998637934"
								},
								"id" : "172683281392330"
							  } ],
							  "id" : "172688037126357"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "local",
								  "dataValue" : "A",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : 2,
								  "dataType" : "number"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Clementine",
								  "statements" : [ {
									"id" : "173118911464128",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "cpIdentityData",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "text"
									  }
									},
									"name" : "Claude"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "173117774959854"
								},
								"id" : "173113586818327"
							  } ],
							  "id" : "173112631656657"
							},
							"failure" : null,
							"id" : 2
						  }, {
							"id" : "173315886636929",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "A",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "+",
								  "variables" : [ {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "A"
								  }, {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 1
								  } ]
								},
								"dataType" : "number"
							  }
							},
							"name" : "Garland"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "173316215301625"
						},
						"id" : "173315379895090"
					  } ]
					},
					"value" : "primaryGSTIN@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Myah"
		  }, {
			"id" : "173435765987358",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "primaryGSTINNN",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "consumerDetails",
				"dataType" : "text"
			  }
			},
			"name" : "Eriberto"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "173436566815864"
		},
		"id" : "173432634013514"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const SwaraConf = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "arr Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Khalil",
		  "statements" : [ {
			"id" : "174672299977847",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "reviewHightlightsData.heightlistsDataList",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "arr Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Vince",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "or",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "reviewResult",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "reviewResult",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "0",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Betsy",
								  "statements" : [ {
									"id" : "174334852092306",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "reviewResult",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "variable",
										"dataValue" : "reviewResult",
										"dataType" : "text"
									  }
									},
									"name" : "Elvera"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "174331426056371"
								},
								"id" : "174336208934366"
							  } ],
							  "id" : "174332545112049"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"id" : "174679553789491",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "sortOrder",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "sortOrder",
								"dataType" : "number"
							  }
							},
							"name" : "Amie"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "174679818438846"
						},
						"id" : "174673009173385"
					  } ]
					},
					"value" : "reviewHightlightsData.heightlistsDataList"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "German"
		  }, {
			"id" : "174847421037169",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "reviewHightlightsData.name",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "reviewHightlightsData.name",
				"dataType" : "text"
			  }
			},
			"name" : "Anya"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "174848842538719"
		},
		"id" : "174844271974160"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const ValidateError = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "validate" : [ {
		"condition" : {
		  "@type" : "logical",
		  "type" : "and",
		  "rules" : [ {
			"@type" : "relational",
			"lhs" : {
			  "@type" : "variable",
			  "dataType" : "text",
			  "dataValue" : "statusMessage"
			},
			"operator" : {
			  "actualValue" : "=="
			},
			"rhs" : {
			  "@type" : "literal",
			  "dataValue" : "OK",
			  "dataType" : "text"
			}
		  } ]
		},
		"error" : {
		  "subcode" : "500",
		  "message" : "Invalid Pan Number"
		}
	  } ],
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Thalia",
		  "statements" : [ {
			"id" : "175284330131067",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "datadata",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "validation success",
				"dataType" : "text"
			  }
			},
			"name" : "Ines"
		  }, {
			"id" : "175534600459442",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "data",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "validation success",
				"dataType" : "text"
			  }
			},
			"name" : "Leon"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "175532441281919"
		},
		"id" : "175535558067041"
	  } ]
	}
  }`

const UploadDocument = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"transform" : {
	  "jsonIgnoreProperty" : true,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : true,
		  "name" : "Betsy",
		  "statements" : [ {
			"id" : "176149299408334",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "keyword",
				"dataValue" : "none",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "map"
			  }
			},
			"name" : "Roosevelt"
		  }, {
			"id" : "176335431912750",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericId",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "genericId",
				"dataType" : "number"
			  }
			},
			"name" : "Jackson"
		  }, {
			"id" : "176616130145496",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "roleId",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "roleId",
				"dataType" : "number"
			  }
			},
			"name" : "Keeley"
		  }, {
			"id" : "176842275732416",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "appPackageId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "appPackageId",
				"dataType" : "text"
			  }
			},
			"name" : "Trey"
		  }, {
			"id" : "177101150010348",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "type",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "type",
				"dataType" : "text"
			  }
			},
			"name" : "Alejandra"
		  }, {
			"id" : "177292682560616",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "documentId",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section0.documentId",
				"dataType" : "text"
			  }
			},
			"name" : "Queen"
		  }, {
			"id" : "177442613716129",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "documentName",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section0.documentName",
				"dataType" : "text"
			  }
			},
			"name" : "Jena"
		  }, {
			"id" : "177538810975126",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "documentType",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section0.documentType",
				"dataType" : "text"
			  }
			},
			"name" : "Brendan"
		  }, {
			"id" : "177719744203027",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "esignOrEstampOrNone",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section0.esignOrEstampOrNone",
				"dataType" : "text"
			  }
			},
			"name" : "Howard"
		  }, {
			"id" : "177973974098195",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "signatories",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section0.signatories",
				"dataType" : "text"
			  }
			},
			"name" : "Rachel"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "177971692197171"
		},
		"id" : "177975313694285"
	  }, {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : true,
		  "name" : "Leanna",
		  "statements" : [ {
			"id" : "178047561084593",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "state",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section0.state",
				"dataType" : "text"
			  }
			},
			"name" : "Ava"
		  }, {
			"id" : "178247725462734",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "fileName",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section2.upload.filename",
				"dataType" : "text"
			  }
			},
			"name" : "Malika"
		  }, {
			"id" : "178485592253011",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "filetype",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section2.upload.filetype",
				"dataType" : "text"
			  }
			},
			"name" : "Timmy"
		  }, {
			"id" : "178646893747612",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "fileData",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section2.upload.value",
				"dataType" : "text"
			  }
			},
			"name" : "Ellen"
		  }, {
			"id" : "179664551619729",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "estampDetails",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_2",
					  "name" : "transform Consumer Communication Address Details",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Eleazar",
						  "statements" : [ {
							"id" : "179067782889257",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "stampDutyAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "section0.stampDutyAmount",
								"dataType" : "text"
							  }
							},
							"name" : "Autumn"
						  }, {
							"id" : "179333606516834",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "stampDutyPaid",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "section0.stampDutyPaid",
								"dataType" : "text"
							  }
							},
							"name" : "Rosamond"
						  }, {
							"id" : "179499708176749",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "articleCode",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "section0.articleCode",
								"dataType" : "text"
							  }
							},
							"name" : "Michel"
						  }, {
							"id" : "179669567576488",
							"mandatory" : true,
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "articleCode",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "variable",
								"dataValue" : "section0.considerationPrice",
								"dataType" : "text"
							  }
							},
							"name" : "Esperanza"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "179661967045412"
						},
						"id" : "179669097144698"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Consuelo"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "179664929420720"
		},
		"id" : "179661266619575"
	  } ]
	}
  }`

const GettingIssueWithlocal = `{"id":46121932624130,"name":"xmlTransformation","@type":"transform","debug":false,"version":4,"transform":{"id":46121932624130,"name":"xmlTransformation","statements":[{"id":"473865803862783","@type":"AssignmentStatement","assignment":{"@type":"SimpleAssignmentStatement","lhs":{"@type":"declare","dataValue":"splitArray","dataType":"list"},"operator":{"actualValue":"="},"rhs":{"@type":"keyword","dataType":"list","dataValue":"text","keywordArguments":{"init":{"value":"primaryGSTIN","splitby":","},"format":"split"}}},"name":"Claude"},{"condition":{"@type":"logical","type":"and","rules":[{"@type":"relational","lhs":{"@type":"variable","dataType":"text","dataValue":"primaryGSTIN"},"operator":{"actualValue":"=="},"rhs":{"@type":"literal","dataValue":"","dataType":"text"}}]},"@type":"ConditionalStatement","success":{"name":"transformation","statements":[{"@type":"SectionalStatement","section":{"jsonIgnoreProperty":false,"name":"Tomas","statements":[{"id":"474601709200016","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"idNo","dataType":"text"},"operator":{"actualValue":"="},"rhs":{"@type":"keyword","dataType":"text","dataValue":"text","keywordArguments":{"format":"getNullValue"}}},"name":"Tristian"},{"id":"474888918439744","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"cpIdentityId","dataType":"text"},"operator":{"actualValue":"="},"rhs":{"@type":"keyword","dataType":"text","dataValue":"text","keywordArguments":{"format":"getNullValue"}}},"name":"Austen"}],"jsonIgnoreAliasValue":null,"id":"474881800695598"},"id":"474883896039756"}],"id":"474884603239055"},"failure":{"name":"transformation","statements":[{"@type":"SectionalStatement","section":{"jsonIgnoreProperty":false,"name":"Deonte","statements":[{"id":"475571289171189","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"idNo","dataType":"text"},"operator":{"actualValue":"="},"rhs":{"@type":"variable","dataValue":"splitArray.[1]@local","dataType":"text"}},"name":"Leta"},{"id":"476304265246851","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"cpIdentityId","dataType":"text"},"operator":{"actualValue":"="},"rhs":{"@type":"variable","dataValue":"splitArray.[0]@local","dataType":"text"}},"name":"Lavon"},{"id":"476976307409302","@type":"AssignmentStatement","assignment":{"lhs":{"@type":"literal","dataValue":"idTypeLookupType","dataType":"text"},"operator":{"actualValue":"="},"rhs":{"@type":"literal","dataValue":"GOVERNMENTID","dataType":"text"}},"name":"Dagmar"}],"jsonIgnoreAliasValue":null,"id":"476971126790723"},"id":"476975497647075"}],"id":"476975324123058"},"id":1}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":""}}`

const LocalArrayTestingIndexValues = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Nasir",
		  "statements" : [ {
			"id" : "181204280669856",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "borrower.garbageArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Roslyn",
						  "statements" : [ {
							"id" : "180398405199183",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "productType",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "BrandedProduct",
								"dataType" : "text"
							  }
							},
							"name" : "Mallory"
						  }, {
							"id" : "180571385977200",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "sanctionedDate",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "01-01-2023",
								"dataType" : "text"
							  }
							},
							"name" : "Leonie"
						  }, {
							"id" : "180706164500962",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "outstandingAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Brando"
						  }, {
							"id" : "180907693712356",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "totalWritenoffAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Arielle"
						  }, {
							"id" : "180997625775781",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "settledamount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Mae"
						  }, {
							"id" : "181202136678635",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "dateofPayment",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "NIL",
								"dataType" : "text"
							  }
							},
							"name" : "Beatrice"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "181209855120178"
						},
						"id" : "181209814238966"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Virgil"
		  }, {
			"id" : "181413507203791",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Indexed_productType",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "borrower.garbageArray.[0].productType@local",
				"dataType" : "text"
			  }
			},
			"name" : "Ron"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "181414331409733"
		},
		"id" : "181419100012232"
	  } ]
	}
  }`

const LocalArrayTestingIndexValue = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Nasir",
		  "statements" : [ {
			"id" : "181204280669856",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "borrower.garbageArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Roslyn",
						  "statements" : [ {
							"id" : "180398405199183",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "productType",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "BrandedProduct",
								"dataType" : "text"
							  }
							},
							"name" : "Mallory"
						  }, {
							"id" : "180571385977200",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "sanctionedDate",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "01-01-2023",
								"dataType" : "text"
							  }
							},
							"name" : "Leonie"
						  }, {
							"id" : "180706164500962",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "outstandingAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Brando"
						  }, {
							"id" : "180907693712356",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "totalWritenoffAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Arielle"
						  }, {
							"id" : "180997625775781",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "settledamount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Mae"
						  }, {
							"id" : "181202136678635",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "dateofPayment",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "NIL",
								"dataType" : "text"
							  }
							},
							"name" : "Beatrice"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "181209855120178"
						},
						"id" : "181209814238966"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Virgil"
		  }, 
		  {
			"id" : "181413507203791",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "indexOfVal",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "borrower.garbageArray.[0]@local",
				"dataType" : "text"
			  }
			},
			"name" : "Ron"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "181414331409733"
		},
		"id" : "181419100012232"
	  } ]
	}
  }`

const AllExpressions = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Willa",
		  "statements" : [ {
			"id" : "181866133975494",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Addition",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "+",
				  "variables" : [ {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 100
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 200
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 199
				  } ]
				},
				"dataType" : "number"
			  }
			},
			"name" : "Wyatt"
		  }, {
			"id" : "182104567370562",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Substraction",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "-",
				  "variables" : [ {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 1000
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 200
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 411
				  } ]
				},
				"dataType" : "number"
			  }
			},
			"name" : "Tyrell"
		  }, {
			"id" : "182337376484371",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Multiplication",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "*",
				  "variables" : [ {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 10
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 2
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 4
				  } ]
				},
				"dataType" : "number"
			  }
			},
			"name" : "Una"
		  }, {
			"id" : "182521911428184",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Division",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "/",
				  "variables" : [ {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 100
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 4
				  } ]
				},
				"dataType" : "number"
			  }
			},
			"name" : "Alexane"
		  }, {
			"id" : "182722172635210",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "Modulas",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "=",
				"expressionType" : "SimpleAssignment",
				"dataType" : "text"
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "%",
				  "variables" : [ {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 14
				  }, {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 10
				  } ]
				},
				"dataType" : "number"
			  }
			},
			"name" : "Aracely"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "182727515603396"
		},
		"id" : "182721238195391"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const ErrorData = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Virgie",
		  "statements" : [ {
			"id" : "183116064641132",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "name",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "customerPrincipleAddress",
				"dataType" : "text"
			  }
			},
			"name" : "Kaia"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "183111027582601"
		},
		"id" : "183112097943011"
	  } ]
	},
	"errors" : {
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Petra",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "statementId"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataType" : "text",
				  "dataValue" : "183116064641132"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Michel",
				  "statements" : [ {
					"id" : "183806553635006",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "error.code",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "Kaia_error.code@local",
						"dataType" : "text"
					  }
					},
					"name" : "Liana"
				  }, {
					"id" : "184036296226243",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "error.message",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "Kaia_error.message@local",
						"dataType" : "text"
					  }
					},
					"name" : "Janis"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "184031750336334"
				},
				"id" : "184037381122180"
			  } ],
			  "id" : "184031504614172"
			},
			"failure" : null,
			"id" : "exception1"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "184039935184637"
		},
		"id" : "184036184227363"
	  } ]
	}
  }`

const UrvasiTimewastedWork = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customer Response",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Jovan",
		  "statements" : [ {
			"id" : "184442565659628",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "liveLoanAccountSummary",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "text",
				"dataValue" : "text",
				"keywordArguments" : {
				  "format" : "getNullValue"
				}
			  }
			},
			"name" : "Dagmar"
		  }, {
			"id" : "184528502938843",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "bureauName",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "TransUnion",
				"dataType" : "text"
			  }
			},
			"name" : "Marta"
		  }, {
			"id" : "184738795288894",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "bureauScoreOrRank",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "response.scoreSegmentSC.[0].score",
				"dataType" : "number"
			  }
			},
			"name" : "Alf"
		  }, {
			"id" : "184983467187625",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "dateofReport",
				"dataType" : "date"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "dd/MM/yyyy",
				  "init" : {
					"value" : "response.processedDateTime",
					"format" : "unixTime"
				  }
				}
			  }
			},
			"name" : "Elisa"
		  }, {
			"id" : "185216608910836",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "nameoftheBorrower",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "response.nameSegmentPN.[0].consumerNameField1",
				"dataType" : "text"
			  }
			},
			"name" : "Geo"
		  }, {
			"id" : "185944023746624",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "dummyArray1",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Ryley",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "dateClosed",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Erik",
								  "statements" : [ {
									"id" : "185946051017033",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "totalLiveSanctionedAmount",
										"dataType" : "number"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "expression",
										"structure" : {
										  "@type" : "arithmetic",
										  "dataType" : "+",
										  "variables" : [ {
											"@type" : "local",
											"dataType" : "number",
											"dataValue" : "totalLiveSanctionedAmount"
										  }, {
											"@type" : "variable",
											"dataType" : "number",
											"dataValue" : "highCreditSanctionedAmount"
										  } ]
										},
										"dataType" : "number"
									  }
									},
									"name" : "Marco"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "185946384699444"
								},
								"id" : "185947569560313"
							  } ],
							  "id" : "185943780173903"
							},
							"failure" : null,
							"id" : 6
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "185946963936012"
						},
						"id" : "185945497434404"
					  } ]
					},
					"value" : "response.accountSegmentTL"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Clovis"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "local",
				  "dataValue" : "totalLiveSanctionedAmount",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "text",
				  "keywordArguments" : {
					"format" : "getNullValue"
				  }
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Francisca",
				  "statements" : [ {
					"id" : "186243505338150",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "totalLiveSanctionedAmount",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "NIL",
						"dataType" : "text"
					  }
					},
					"name" : "Marcus"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "186242483927923"
				},
				"id" : "186243168102326"
			  } ],
			  "id" : "186247919776447"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Bettye",
				  "statements" : [ {
					"id" : "186582403844446",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "totalLiveSanctionedAmount",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "local",
						"dataValue" : "totalLiveSanctionedAmount",
						"dataType" : "text"
					  }
					},
					"name" : "Vicente"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "186588018311739"
				},
				"id" : "186589554611750"
			  } ],
			  "id" : "186587635067169"
			},
			"id" : 8
		  }, {
			"id" : "187383042348948",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "dummyArray2",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Florida",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "dateClosed",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Marilyne",
								  "statements" : [ {
									"id" : "187381050270007",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "totalLiveOutstandingamount",
										"dataType" : "number"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "expression",
										"structure" : {
										  "@type" : "arithmetic",
										  "dataType" : "+",
										  "variables" : [ {
											"@type" : "local",
											"dataType" : "number",
											"dataValue" : "totalLiveOutstandingamount"
										  }, {
											"@type" : "variable",
											"dataType" : "number",
											"dataValue" : "currentBalance"
										  } ]
										},
										"dataType" : "number"
									  }
									},
									"name" : "Robert"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "187389594456103"
								},
								"id" : "187385955133554"
							  } ],
							  "id" : "187384553770796"
							},
							"failure" : null,
							"id" : 13
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "187381408946203"
						},
						"id" : "187382082399346"
					  } ]
					},
					"value" : "response.accountSegmentTL"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Paolo"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "local",
				  "dataValue" : "totalLiveOutstandingamount",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "text",
				  "keywordArguments" : {
					"format" : "getNullValue"
				  }
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Drake",
				  "statements" : [ {
					"id" : "187711596372444",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "totalLiveOutstandingamount",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "NIL",
						"dataType" : "text"
					  }
					},
					"name" : "Richard"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "187719601387777"
				},
				"id" : "187712545953028"
			  } ],
			  "id" : "187718235899795"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Ewald",
				  "statements" : [ {
					"id" : "188072997123309",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "totalLiveOutstandingamount",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "local",
						"dataValue" : "totalLiveOutstandingamount",
						"dataType" : "text"
					  }
					},
					"name" : "Earnestine"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "188075157136013"
				},
				"id" : "188076803461578"
			  } ],
			  "id" : "188075304438549"
			},
			"id" : 15
		  }, {
			"id" : "188847780342909",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "dummyArray3",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Melyna",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "dateClosed",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "amountOverdue",
								  "dataType" : "number"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Van",
								  "statements" : [ {
									"id" : "188841039572615",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "totalArrearsAmount",
										"dataType" : "number"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "expression",
										"structure" : {
										  "@type" : "arithmetic",
										  "dataType" : "+",
										  "variables" : [ {
											"@type" : "local",
											"dataType" : "number",
											"dataValue" : "totalArrearsAmount"
										  }, {
											"@type" : "variable",
											"dataType" : "number",
											"dataValue" : "amountOverdue"
										  } ]
										},
										"dataType" : "number"
									  }
									},
									"name" : "Sebastian"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "188844068491808"
								},
								"id" : "188844691022075"
							  } ],
							  "id" : "188849042823290"
							},
							"failure" : null,
							"id" : 20
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "188845026557280"
						},
						"id" : "188844765890961"
					  } ]
					},
					"value" : "response.accountSegmentTL"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Wilhelm"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "188849344116967"
		},
		"id" : "188841259434839"
	  }, {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Carleton",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "local",
				  "dataValue" : "totalArrearsAmount",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "text",
				  "keywordArguments" : {
					"format" : "getNullValue"
				  }
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Clyde",
				  "statements" : [ {
					"id" : "189155184574977",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "totalArrearsAmount",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "NIL",
						"dataType" : "text"
					  }
					},
					"name" : "Esther"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "189156360627595"
				},
				"id" : "189159036687373"
			  } ],
			  "id" : "189152531676363"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Stephany",
				  "statements" : [ {
					"id" : "189469273902459",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "totalArrearsAmount",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "local",
						"dataValue" : "totalArrearsAmount",
						"dataType" : "text"
					  }
					},
					"name" : "Hobart"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "189462773975120"
				},
				"id" : "189464034112836"
			  } ],
			  "id" : "189461265659324"
			},
			"id" : 22
		  }, {
			"id" : "189632446002736",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "totalNoofUnsecuredLast6M",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "NIL",
				"dataType" : "text"
			  }
			},
			"name" : "Clara"
		  }, {
			"id" : "189789563180670",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "totalNoofsecuredLast6M",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : "NIL",
				"dataType" : "text"
			  }
			},
			"name" : "Trever"
		  }, {
			"id" : "189949205309964",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "res1",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Giovanny"
		  }, {
			"id" : "190144711039786",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "res2",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Lenna"
		  }, {
			"id" : "190364429499639",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "globalmax",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Milton"
		  }, {
			"id" : "109216216989210",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "garbageArray",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : 32,
					  "name" : "transform",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Celine",
						  "statements" : [ {
							"id" : "190908232476048",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "i",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Rickey"
						  }, {
							"id" : "191087113801276",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "j",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Noah"
						  }, {
							"id" : "191319715324510",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "dummyArray4",
								"dataType" : "list"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataType" : "list",
								"dataValue" : "text",
								"keywordArguments" : {
								  "init" : {
									"chunkby" : 3,
									"value" : "paymentHistory1"
								  },
								  "format" : "chunk"
								}
							  }
							},
							"name" : "Emmett"
						  }, {
							"id" : "193895293403831",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "garbageArray1",
								"dataType" : "list"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataType" : "list",
								"dataValue" : "list",
								"keywordArguments" : {
								  "init" : {
									"transform" : {
									  "id" : 37,
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Nella",
										  "statements" : [ {
											"id" : "191848000395647",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "declare",
												"dataType" : "number",
												"dataValue" : "j"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "expression",
												"structure" : {
												  "@type" : "arithmetic",
												  "dataType" : "+",
												  "variables" : [ {
													"@type" : "local",
													"dataType" : "number",
													"dataValue" : "j"
												  }, {
													"@type" : "literal",
													"dataType" : "number",
													"dataValue" : 1
												  } ]
												}
											  }
											},
											"name" : "Florida"
										  }, {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "j@local",
												  "dataType" : "number"
												},
												"operator" : {
												  "actualValue" : "=="
												},
												"rhs" : {
												  "@type" : "literal",
												  "dataValue" : 1,
												  "dataType" : "number"
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Kory",
												  "statements" : [ {
													"id" : "192257505905231",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "declare",
														"dataValue" : "str",
														"dataType" : "text"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "keyword",
														"dataValue" : "value",
														"dataType" : "text"
													  }
													},
													"name" : "Delfina"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "192256445930802"
												},
												"id" : "192254111647949"
											  } ],
											  "id" : "192257337892944"
											},
											"failure" : null,
											"id" : 39
										  }, {
											"id" : "192456471303160",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "declare",
												"dataValue" : "temp1",
												"dataType" : "text"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "keyword",
												"dataValue" : "value",
												"dataType" : "text"
											  }
											},
											"name" : "Chanelle"
										  }, {
											"id" : "192726546570649",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "declare",
												"dataValue" : "num1",
												"dataType" : "number"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "keyword",
												"dataValue" : "text",
												"dataType" : "text",
												"keywordArguments" : {
												  "format" : "toNumber",
												  "init" : {
													"value" : "temp1@local"
												  }
												}
											  }
											},
											"name" : "Mabel"
										  }, {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "num1@local",
												  "dataType" : "number"
												},
												"operator" : {
												  "actualValue" : ">"
												},
												"rhs" : {
												  "@type" : "literal",
												  "dataValue" : 30,
												  "dataType" : "number"
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Willard",
												  "statements" : [ {
													"id" : "193194992297154",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "declare",
														"dataValue" : "res1",
														"dataType" : "number"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "expression",
														"structure" : {
														  "@type" : "arithmetic",
														  "dataType" : "+",
														  "variables" : [ {
															"@type" : "local",
															"dataType" : "number",
															"dataValue" : "res1"
														  }, {
															"@type" : "literal",
															"dataType" : "number",
															"dataValue" : 1
														  } ]
														}
													  }
													},
													"name" : "Wiley"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "193196163887837"
												},
												"id" : "193195136052322"
											  } ],
											  "id" : "193198671553247"
											},
											"failure" : null,
											"id" : 43
										  }, {
											"id" : "193427275897121",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "declare",
												"dataType" : "number",
												"dataValue" : "i"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "expression",
												"structure" : {
												  "@type" : "arithmetic",
												  "dataType" : "+",
												  "variables" : [ {
													"@type" : "local",
													"dataType" : "number",
													"dataValue" : "i"
												  }, {
													"@type" : "literal",
													"dataType" : "number",
													"dataValue" : 1
												  } ]
												}
											  }
											},
											"name" : "Amparo"
										  }, {
											"condition" : {
											  "@type" : "logical",
											  "type" : "and",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "i@local",
												  "dataType" : "number"
												},
												"operator" : {
												  "actualValue" : "<="
												},
												"rhs" : {
												  "@type" : "literal",
												  "dataValue" : 12,
												  "dataType" : "number"
												}
											  }, {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "num1@local",
												  "dataType" : "number"
												},
												"operator" : {
												  "actualValue" : ">"
												},
												"rhs" : {
												  "@type" : "variable",
												  "dataValue" : "globalmax@local",
												  "dataType" : "number"
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Mavis",
												  "statements" : [ {
													"id" : "193894415643200",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "declare",
														"dataValue" : "globalmax",
														"dataType" : "number"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "variable",
														"dataValue" : "num1@local",
														"dataType" : "number"
													  }
													},
													"name" : "Jeanne"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "193897096394156"
												},
												"id" : "193896581150511"
											  } ],
											  "id" : "193894711141659"
											},
											"failure" : null,
											"id" : 46
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "193892488284036"
										},
										"id" : "193894765270958"
									  } ]
									},
									"value" : "dummyArray4@local"
								  },
								  "format" : "iterate"
								}
							  }
							},
							"name" : "Jessyca"
						  }, {
							"id" : "109211017598913",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "dummyArray7",
								"dataType" : "list"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataType" : "list",
								"dataValue" : "list",
								"keywordArguments" : {
								  "init" : {
									"transform" : {
									  "id" : "transform_config_1",
									  "name" : "transform Address Information",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Charlotte",
										  "statements" : [ {
											"condition" : {
											  "@type" : "logical",
											  "type" : "or",
											  "rules" : [ {
												"@type" : "relational",
												"lhs" : {
												  "@type" : "variable",
												  "dataValue" : "dateClosed",
												  "dataType" : "number"
												},
												"operator" : {
												  "actualValue" : "=="
												},
												"rhs" : {
												  "@type" : "keyword",
												  "dataType" : "text",
												  "dataValue" : "text",
												  "keywordArguments" : {
													"format" : "getNullValue"
												  }
												}
											  } ]
											},
											"@type" : "ConditionalStatement",
											"success" : {
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Corene",
												  "statements" : [ {
													"id" : "109215173064183",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "declare",
														"dataValue" : "liveLoanAccountSummary",
														"dataType" : "list"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "keyword",
														"dataType" : "list",
														"dataValue" : "list",
														"keywordArguments" : {
														  "init" : {
															"transform" : {
															  "id" : "transform_config_1",
															  "name" : "customer Response",
															  "statements" : [ {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Aric",
																  "statements" : [ {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "or",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "=="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "STD",
																		  "dataType" : "text"
																		}
																	  }, {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "=="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "000",
																		  "dataType" : "text"
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Ari",
																		  "statements" : [ {
																			"id" : "195466344078963",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "currentAssetClassification",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "Standard",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Jayde"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "195462044372314"
																		},
																		"id" : "195468649596527"
																	  } ],
																	  "id" : "195461620883355"
																	},
																	"failure" : null,
																	"id" : 50
																  }, {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "=="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "SMA",
																		  "dataType" : "text"
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Eloisa",
																		  "statements" : [ {
																			"id" : "195866763401224",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "currentAssetClassification",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "Special Mention Account",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Bernie"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "195865841079154"
																		},
																		"id" : "195861498205944"
																	  } ],
																	  "id" : "195863434902237"
																	},
																	"failure" : null,
																	"id" : 52
																  }, {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "=="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "SUB",
																		  "dataType" : "text"
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Nat",
																		  "statements" : [ {
																			"id" : "196311594303793",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "currentAssetClassification",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "Substandard",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Mose"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "196319469698547"
																		},
																		"id" : "196314268440103"
																	  } ],
																	  "id" : "196316154953236"
																	},
																	"failure" : null,
																	"id" : 54
																  }, {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "=="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "DBT",
																		  "dataType" : "text"
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Samir",
																		  "statements" : [ {
																			"id" : "196912640495598",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "currentAssetClassification",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "Doubtful",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Grover"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "196911427809726"
																		},
																		"id" : "196917684602689"
																	  } ],
																	  "id" : "196916681296244"
																	},
																	"failure" : null,
																	"id" : 56
																  }, {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "=="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "LSS",
																		  "dataType" : "text"
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Krystal",
																		  "statements" : [ {
																			"id" : "100326434029067",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "currentAssetClassification",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "Loss",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Devonte"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "100325230901884"
																		},
																		"id" : "100327765178477"
																	  } ],
																	  "id" : "100321400254517"
																	},
																	"failure" : null,
																	"id" : 57
																  }, {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "=="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "XXX",
																		  "dataType" : "text"
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Manuel",
																		  "statements" : [ {
																			"id" : "104044426522232",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "currentAssetClassification",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "Not Reported",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Abdullah"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "104046339766561"
																		},
																		"id" : "104044835019359"
																	  } ],
																	  "id" : "104045170044504"
																	},
																	"failure" : null,
																	"id" : 59
																  }, {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "000",
																		  "dataType" : "text"
																		}
																	  }, {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "XXX",
																		  "dataType" : "text"
																		}
																	  }, {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "LSS",
																		  "dataType" : "text"
																		}
																	  }, {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "DBT",
																		  "dataType" : "text"
																		}
																	  }, {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "SUB",
																		  "dataType" : "text"
																		}
																	  }, {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "SMA",
																		  "dataType" : "text"
																		}
																	  }, {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "str@local",
																		  "dataType" : "text"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "literal",
																		  "dataValue" : "STD",
																		  "dataType" : "text"
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Darian",
																		  "statements" : [ {
																			"id" : "106408903132504",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "currentAssetClassification",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "variable",
																				"dataValue" : "str@local",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Nolan"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "106404898653522"
																		},
																		"id" : "106404603962382"
																	  } ],
																	  "id" : "106403014822864"
																	},
																	"failure" : null,
																	"id" : 61
																  }, {
																	"id" : "106633121541957",
																	"@type" : "AssignmentStatement",
																	"assignment" : {
																	  "lhs" : {
																		"@type" : "literal",
																		"dataValue" : "loanType",
																		"dataType" : "text"
																	  },
																	  "operator" : {
																		"actualValue" : "="
																	  },
																	  "rhs" : {
																		"@type" : "variable",
																		"dataValue" : "accountType.accountDesc",
																		"dataType" : "text"
																	  }
																	},
																	"name" : "Lacey"
																  }, {
																	"id" : "106718739972562",
																	"@type" : "AssignmentStatement",
																	"assignment" : {
																	  "lhs" : {
																		"@type" : "literal",
																		"dataValue" : "sanctionDate",
																		"dataType" : "date"
																	  },
																	  "operator" : {
																		"actualValue" : "="
																	  },
																	  "rhs" : {
																		"@type" : "keyword",
																		"dataValue" : "date",
																		"dataType" : "date",
																		"keywordArguments" : {
																		  "format" : "dd-MM-yyyy",
																		  "init" : {
																			"value" : "dateOpenedDisbursed",
																			"format" : "unixTime"
																		  }
																		}
																	  }
																	},
																	"name" : "Zula"
																  }, {
																	"id" : "106927807125488",
																	"@type" : "AssignmentStatement",
																	"assignment" : {
																	  "lhs" : {
																		"@type" : "literal",
																		"dataValue" : "currentOutstandingOrUtilization",
																		"dataType" : "text"
																	  },
																	  "operator" : {
																		"actualValue" : "="
																	  },
																	  "rhs" : {
																		"@type" : "variable",
																		"dataValue" : "currentBalance",
																		"dataType" : "text"
																	  }
																	},
																	"name" : "Deborah"
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "106928968562193"
																},
																"id" : "106926729542920"
															  }, {
																"@type" : "SectionalStatement",
																"section" : {
																  "jsonIgnoreProperty" : false,
																  "name" : "Mertie",
																  "statements" : [ {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "emiAmount",
																		  "dataType" : "number"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "keyword",
																		  "dataType" : "text",
																		  "dataValue" : "text",
																		  "keywordArguments" : {
																			"format" : "getNullValue"
																		  }
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Herta",
																		  "statements" : [ {
																			"id" : "107251826830082",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "eMIamountIfapplicable",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "variable",
																				"dataValue" : "emiAmount",
																				"dataType" : "number"
																			  }
																			},
																			"name" : "Jerad"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "107258636128973"
																		},
																		"id" : "107254853288347"
																	  } ],
																	  "id" : "107256953219977"
																	},
																	"failure" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Walter",
																		  "statements" : [ {
																			"id" : "107751880900301",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "eMIamountIfapplicable",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "NIL",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Juana"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "107756993067091"
																		},
																		"id" : "107753290412407"
																	  } ],
																	  "id" : "107756878235167"
																	},
																	"id" : 68
																  }, {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "repaymentTenure",
																		  "dataType" : "number"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "keyword",
																		  "dataType" : "text",
																		  "dataValue" : "text",
																		  "keywordArguments" : {
																			"format" : "getNullValue"
																		  }
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Jannie",
																		  "statements" : [ {
																			"id" : "108218556939707",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "residualTenure",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "variable",
																				"dataValue" : "repaymentTenure",
																				"dataType" : "number"
																			  }
																			},
																			"name" : "Reginald"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "108211258188780"
																		},
																		"id" : "108213156661094"
																	  } ],
																	  "id" : "108219649363851"
																	},
																	"failure" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Domenica",
																		  "statements" : [ {
																			"id" : "108586169328046",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "residualTenure",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "NIL",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Devonte"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "108584594409935"
																		},
																		"id" : "108589727862683"
																	  } ],
																	  "id" : "108584314451092"
																	},
																	"id" : 72
																  }, {
																	"condition" : {
																	  "@type" : "logical",
																	  "type" : "and",
																	  "rules" : [ {
																		"@type" : "relational",
																		"lhs" : {
																		  "@type" : "variable",
																		  "dataValue" : "typeOfCollateral.colleteralTypeDesc",
																		  "dataType" : "number"
																		},
																		"operator" : {
																		  "actualValue" : "!="
																		},
																		"rhs" : {
																		  "@type" : "keyword",
																		  "dataType" : "text",
																		  "dataValue" : "text",
																		  "keywordArguments" : {
																			"format" : "getNullValue"
																		  }
																		}
																	  } ]
																	},
																	"@type" : "ConditionalStatement",
																	"success" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Gonzalo",
																		  "statements" : [ {
																			"id" : "108926281267350",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "securedbyCollateral",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "variable",
																				"dataValue" : "typeOfCollateral.colleteralTypeDesc",
																				"dataType" : "number"
																			  }
																			},
																			"name" : "Juston"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "108926132468469"
																		},
																		"id" : "108924191907180"
																	  } ],
																	  "id" : "108926973754655"
																	},
																	"failure" : {
																	  "name" : "transformation",
																	  "statements" : [ {
																		"@type" : "SectionalStatement",
																		"section" : {
																		  "jsonIgnoreProperty" : false,
																		  "name" : "Eula",
																		  "statements" : [ {
																			"id" : "109214429538068",
																			"@type" : "AssignmentStatement",
																			"assignment" : {
																			  "lhs" : {
																				"@type" : "literal",
																				"dataValue" : "securedbyCollateral",
																				"dataType" : "text"
																			  },
																			  "operator" : {
																				"actualValue" : "="
																			  },
																			  "rhs" : {
																				"@type" : "literal",
																				"dataValue" : "No Collateral",
																				"dataType" : "text"
																			  }
																			},
																			"name" : "Enoch"
																		  } ],
																		  "jsonIgnoreAliasValue" : null,
																		  "id" : "109213524070285"
																		},
																		"id" : "109215134962446"
																	  } ],
																	  "id" : "109211513975225"
																	},
																	"id" : 76
																  } ],
																  "jsonIgnoreAliasValue" : null,
																  "id" : "109212390476247"
																},
																"id" : "109213561247938"
															  } ]
															}
														  },
														  "format" : "iterate"
														}
													  }
													},
													"name" : "Maureen"
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "109217969039340"
												},
												"id" : "109218219199454"
											  } ],
											  "id" : "109211816896583"
											},
											"failure" : null,
											"id" : 49
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "109219703147780"
										},
										"id" : "109212164616676"
									  } ]
									}
								  },
								  "format" : "iterate"
								}
							  }
							},
							"name" : "Dale"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "109219483802334"
						},
						"id" : "109218091348271"
					  } ]
					},
					"value" : "response.accountSegmentTL"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Desmond"
		  }, {
			"id" : "111117455832136",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "garbageArray2",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : 81,
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Deron",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "paymentHistory2",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Layla",
								  "statements" : [ {
									"id" : "109845005616091",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "@type" : "SimpleAssignmentStatement",
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "dummyArray5",
										"dataType" : "list"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "list",
										"dataValue" : "text",
										"keywordArguments" : {
										  "init" : {
											"chunkby" : 3,
											"value" : "paymentHistory2"
										  },
										  "format" : "chunk"
										}
									  }
									},
									"name" : "Edwin"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "109846475189136"
								},
								"id" : "109844666299654"
							  } ],
							  "id" : "109843577535148"
							},
							"failure" : null,
							"id" : 82
						  }, {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataValue" : "dummyArray5@local",
								  "dataType" : "text"
								},
								"operator" : {
								  "actualValue" : "!="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Eusebio",
								  "statements" : [ {
									"id" : "111119620394887",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "declare",
										"dataValue" : "garbageArray3",
										"dataType" : "list"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataType" : "list",
										"dataValue" : "list",
										"keywordArguments" : {
										  "init" : {
											"transform" : {
											  "id" : 86,
											  "name" : "transformation",
											  "statements" : [ {
												"@type" : "SectionalStatement",
												"section" : {
												  "jsonIgnoreProperty" : false,
												  "name" : "Rosendo",
												  "statements" : [ {
													"id" : "110486705222059",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "declare",
														"dataValue" : "temp2",
														"dataType" : "text"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "keyword",
														"dataValue" : "value",
														"dataType" : "text"
													  }
													},
													"name" : "Fermin"
												  }, {
													"id" : "110713615496470",
													"@type" : "AssignmentStatement",
													"assignment" : {
													  "lhs" : {
														"@type" : "declare",
														"dataValue" : "num2",
														"dataType" : "number"
													  },
													  "operator" : {
														"actualValue" : "="
													  },
													  "rhs" : {
														"@type" : "keyword",
														"dataValue" : "text",
														"dataType" : "text",
														"keywordArguments" : {
														  "format" : "toNumber",
														  "init" : {
															"value" : "temp2@local"
														  }
														}
													  }
													},
													"name" : "Horacio"
												  }, {
													"condition" : {
													  "@type" : "logical",
													  "type" : "and",
													  "rules" : [ {
														"@type" : "relational",
														"lhs" : {
														  "@type" : "variable",
														  "dataValue" : "num2@local",
														  "dataType" : "number"
														},
														"operator" : {
														  "actualValue" : ">"
														},
														"rhs" : {
														  "@type" : "literal",
														  "dataValue" : 30,
														  "dataType" : "number"
														}
													  } ]
													},
													"@type" : "ConditionalStatement",
													"success" : {
													  "name" : "transformation",
													  "statements" : [ {
														"@type" : "SectionalStatement",
														"section" : {
														  "jsonIgnoreProperty" : false,
														  "name" : "Lora",
														  "statements" : [ {
															"id" : "111118073983133",
															"@type" : "AssignmentStatement",
															"assignment" : {
															  "lhs" : {
																"@type" : "declare",
																"dataValue" : "res2",
																"dataType" : "number"
															  },
															  "operator" : {
																"actualValue" : "="
															  },
															  "rhs" : {
																"@type" : "expression",
																"structure" : {
																  "@type" : "arithmetic",
																  "dataType" : "+",
																  "variables" : [ {
																	"@type" : "local",
																	"dataType" : "number",
																	"dataValue" : "res2"
																  }, {
																	"@type" : "literal",
																	"dataType" : "number",
																	"dataValue" : 1
																  } ]
																}
															  }
															},
															"name" : "Isaac"
														  } ],
														  "jsonIgnoreAliasValue" : null,
														  "id" : "111115862938020"
														},
														"id" : "111115196274502"
													  } ],
													  "id" : "111119878562081"
													},
													"failure" : null,
													"id" : 89
												  } ],
												  "jsonIgnoreAliasValue" : null,
												  "id" : "111116187126144"
												},
												"id" : "111116913998252"
											  } ]
											},
											"value" : "dummyArray5@local"
										  },
										  "format" : "iterate"
										}
									  }
									},
									"name" : "Madonna"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "111115877815723"
								},
								"id" : "111112227504832"
							  } ],
							  "id" : "111117535585501"
							},
							"failure" : null,
							"id" : 84
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "111118544905724"
						},
						"id" : "111111329827212"
					  } ]
					},
					"value" : "response.accountSegmentTL"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Dangelo"
		  }, {
			"id" : "111305763885338",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "noofInstance",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "+",
				  "variables" : [ {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "res2"
				  }, {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "res1"
				  } ]
				}
			  }
			},
			"name" : "Mae"
		  }, {
			"id" : "111403605656009",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "maxDPDLast12Months",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "globalmax@local",
				"dataType" : "number"
			  }
			},
			"name" : "Brett"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "111408638154266"
		},
		"id" : "111406742486213"
	  }, {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Maxie",
		  "statements" : [ {
			"id" : "111609654666488",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "sum1",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Manuela"
		  }, {
			"id" : "111811163186155",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "sum2",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Jerad"
		  }, {
			"id" : "111922026201281",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "sum3",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Simeon"
		  }, {
			"id" : "112011055103485",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "percent1",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Gino"
		  }, {
			"id" : "112227202837393",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "percent2",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 0,
				"dataType" : "number"
			  }
			},
			"name" : "Earl"
		  }, {
			"id" : "113658258416886",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataType" : "list",
				"dataValue" : "dummyArray8"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : 98,
					  "name" : "transform",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Stephen",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "and",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "variable",
								  "dataType" : "number",
								  "dataValue" : "dateClosed"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "text",
								  "keywordArguments" : {
									"format" : "getNullValue"
								  }
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Lowell",
								  "statements" : [ {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataType" : "text",
										  "dataValue" : "typeOfCollateral.colleteralTypeCode"
										},
										"operator" : {
										  "actualValue" : "=="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Keenan",
										  "statements" : [ {
											"id" : "112971811742252",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "declare",
												"dataType" : "number",
												"dataValue" : "sum1"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "expression",
												"structure" : {
												  "@type" : "arithmetic",
												  "dataType" : "+",
												  "variables" : [ {
													"@type" : "local",
													"dataType" : "number",
													"dataValue" : "sum1"
												  }, {
													"@type" : "variable",
													"dataType" : "number",
													"dataValue" : "highCreditSanctionedAmount"
												  } ]
												}
											  }
											},
											"name" : "Jed"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "112979403144321"
										},
										"id" : "112974054172417"
									  } ],
									  "id" : "112978755779604"
									},
									"failure" : null,
									"id" : 100
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataType" : "text",
										  "dataValue" : "typeOfCollateral.colleteralTypeCode"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Camren",
										  "statements" : [ {
											"id" : "113222532468969",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "declare",
												"dataType" : "number",
												"dataValue" : "sum2"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "expression",
												"structure" : {
												  "@type" : "arithmetic",
												  "dataType" : "+",
												  "variables" : [ {
													"@type" : "local",
													"dataType" : "number",
													"dataValue" : "sum2"
												  }, {
													"@type" : "variable",
													"dataType" : "number",
													"dataValue" : "highCreditSanctionedAmount"
												  } ]
												}
											  }
											},
											"name" : "Darryl"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "113223556394847"
										},
										"id" : "113224886043481"
									  } ],
									  "id" : "113224759645682"
									},
									"failure" : null,
									"id" : 102
								  }, {
									"condition" : {
									  "@type" : "logical",
									  "type" : "and",
									  "rules" : [ {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataType" : "text",
										  "dataValue" : "typeOfCollateral.colleteralTypeCode"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "keyword",
										  "dataType" : "text",
										  "dataValue" : "text",
										  "keywordArguments" : {
											"format" : "getNullValue"
										  }
										}
									  }, {
										"@type" : "relational",
										"lhs" : {
										  "@type" : "variable",
										  "dataType" : "text",
										  "dataValue" : "typeOfCollateral.colleteralTypeCode"
										},
										"operator" : {
										  "actualValue" : "!="
										},
										"rhs" : {
										  "@type" : "literal",
										  "dataType" : "text",
										  "dataValue" : "00"
										}
									  } ]
									},
									"@type" : "ConditionalStatement",
									"success" : {
									  "name" : "transformation",
									  "statements" : [ {
										"@type" : "SectionalStatement",
										"section" : {
										  "jsonIgnoreProperty" : false,
										  "name" : "Haylee",
										  "statements" : [ {
											"id" : "113658284450543",
											"@type" : "AssignmentStatement",
											"assignment" : {
											  "lhs" : {
												"@type" : "declare",
												"dataType" : "number",
												"dataValue" : "sum3"
											  },
											  "operator" : {
												"actualValue" : "="
											  },
											  "rhs" : {
												"@type" : "expression",
												"structure" : {
												  "@type" : "arithmetic",
												  "dataType" : "+",
												  "variables" : [ {
													"@type" : "local",
													"dataType" : "number",
													"dataValue" : "sum3"
												  }, {
													"@type" : "variable",
													"dataType" : "number",
													"dataValue" : "highCreditSanctionedAmount"
												  } ]
												}
											  }
											},
											"name" : "Antonio"
										  } ],
										  "jsonIgnoreAliasValue" : null,
										  "id" : "113657269528772"
										},
										"id" : "113656232396641"
									  } ],
									  "id" : "113651353795220"
									},
									"failure" : null,
									"id" : 104
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "113656214453109"
								},
								"id" : "113654161214374"
							  } ],
							  "id" : "113653617156675"
							},
							"failure" : null,
							"id" : 99
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "113656587778331"
						},
						"id" : "113654671824881"
					  } ]
					},
					"value" : "response.accountSegmentTL"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Ezra"
		  }, {
			"id" : "113819279254532",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStaement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "unsecuredsum",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "+",
				  "variables" : [ {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "sum1"
				  }, {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "sum2"
				  } ]
				}
			  }
			},
			"name" : "Bailey"
		  }, {
			"id" : "113828131388564",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStaement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "totalsum",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "expression",
				"structure" : {
				  "@type" : "arithmetic",
				  "dataType" : "+",
				  "variables" : [ {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "sum1"
				  }, {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "sum2"
				  }, {
					"@type" : "local",
					"dataType" : "number",
					"dataValue" : "sum3"
				  } ]
				}
			  }
			},
			"name" : "Jamal"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "or",
			  "rules" : [ {
				"@type" : "logical",
				"type" : "and",
				"rules" : [ {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataType" : "number",
					"dataValue" : "unsecuredsum@local"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "keyword",
					"dataType" : "text",
					"dataValue" : "text",
					"keywordArguments" : {
					  "format" : "getNullValue"
					}
				  }
				}, {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataType" : "number",
					"dataValue" : "sum3@local"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "keyword",
					"dataType" : "text",
					"dataValue" : "text",
					"keywordArguments" : {
					  "format" : "getNullValue"
					}
				  }
				} ]
			  }, {
				"@type" : "logical",
				"type" : "and",
				"rules" : [ {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataType" : "number",
					"dataValue" : "unsecuredsum@local"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 0
				  }
				}, {
				  "@type" : "relational",
				  "lhs" : {
					"@type" : "variable",
					"dataType" : "number",
					"dataValue" : "sum3@local"
				  },
				  "operator" : {
					"actualValue" : "=="
				  },
				  "rhs" : {
					"@type" : "literal",
					"dataType" : "number",
					"dataValue" : 0
				  }
				} ]
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Tiffany",
				  "statements" : [ {
					"id" : "114249931547939",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "declare",
						"dataValue" : "percent1",
						"dataType" : "number"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : 0,
						"dataType" : "number"
					  }
					},
					"name" : "Forrest"
				  }, {
					"id" : "114425364608761",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "declare",
						"dataValue" : "percent2",
						"dataType" : "number"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : 0,
						"dataType" : "number"
					  }
					},
					"name" : "Carlos"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "114429132275809"
				},
				"id" : "114428588348156"
			  } ],
			  "id" : "114422184364945"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Hilda",
				  "statements" : [ {
					"condition" : {
					  "@type" : "logical",
					  "type" : "or",
					  "rules" : [ {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataType" : "number",
						  "dataValue" : "k"
						},
						"operator" : {
						  "actualValue" : "=="
						},
						"rhs" : {
						  "@type" : "literal",
						  "dataType" : "number",
						  "dataValue" : 0
						}
					  }, {
						"@type" : "logical",
						"type" : "and",
						"rules" : [ {
						  "@type" : "relational",
						  "lhs" : {
							"@type" : "variable",
							"dataType" : "number",
							"dataValue" : "unsecuredsum@local"
						  },
						  "operator" : {
							"actualValue" : "!="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataType" : "number",
							"dataValue" : 0
						  }
						}, {
						  "@type" : "relational",
						  "lhs" : {
							"@type" : "variable",
							"dataType" : "number",
							"dataValue" : "sum3@local"
						  },
						  "operator" : {
							"actualValue" : "!="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataType" : "number",
							"dataValue" : 0
						  }
						} ]
					  }, {
						"@type" : "logical",
						"type" : "and",
						"rules" : [ {
						  "@type" : "relational",
						  "lhs" : {
							"@type" : "variable",
							"dataType" : "number",
							"dataValue" : "unsecuredsum@local"
						  },
						  "operator" : {
							"actualValue" : "!="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataType" : "number",
							"dataValue" : 0
						  }
						}, {
						  "@type" : "relational",
						  "lhs" : {
							"@type" : "variable",
							"dataType" : "number",
							"dataValue" : "sum3@local"
						  },
						  "operator" : {
							"actualValue" : "=="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataType" : "number",
							"dataValue" : 0
						  }
						} ]
					  }, {
						"@type" : "logical",
						"type" : "and",
						"rules" : [ {
						  "@type" : "relational",
						  "lhs" : {
							"@type" : "variable",
							"dataType" : "number",
							"dataValue" : "unsecuredsum@local"
						  },
						  "operator" : {
							"actualValue" : "=="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataType" : "number",
							"dataValue" : 0
						  }
						}, {
						  "@type" : "relational",
						  "lhs" : {
							"@type" : "variable",
							"dataType" : "number",
							"dataValue" : "sum3@local"
						  },
						  "operator" : {
							"actualValue" : "!="
						  },
						  "rhs" : {
							"@type" : "literal",
							"dataType" : "number",
							"dataValue" : 0
						  }
						} ]
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Jimmie",
						  "statements" : [ {
							"id" : "114832608981778",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "percent1",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "*",
								  "variables" : [ {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 100
								  }, {
									"@type" : "expression",
									"structure" : {
									  "@type" : "arithmetic",
									  "dataType" : "/",
									  "variables" : [ {
										"@type" : "local",
										"dataType" : "number",
										"dataValue" : "unsecuredsum"
									  }, {
										"@type" : "local",
										"dataType" : "number",
										"dataValue" : "totalsum"
									  } ]
									},
									"dataType" : "number"
								  } ]
								}
							  }
							},
							"name" : "Travon"
						  }, {
							"id" : "115065058899837",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "percent2",
								"dataType" : "number"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "expression",
								"structure" : {
								  "@type" : "arithmetic",
								  "dataType" : "-",
								  "variables" : [ {
									"@type" : "literal",
									"dataType" : "number",
									"dataValue" : 100
								  }, {
									"@type" : "local",
									"dataType" : "number",
									"dataValue" : "percent1"
								  } ]
								}
							  }
							},
							"name" : "Rachelle"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "115064019028814"
						},
						"id" : "115065361098691"
					  } ],
					  "id" : "115068915354858"
					},
					"failure" : null,
					"id" : 112
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "115069978303025"
				},
				"id" : "115069019171867"
			  } ],
			  "id" : "115062679926780"
			},
			"id" : 108
		  }, {
			"id" : "115248094515655",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataType" : "number",
				"dataValue" : "prcntofSecuredExposure"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "percent2@local",
				"dataType" : "number"
			  }
			},
			"name" : "Marjory"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "115245488197677"
		},
		"id" : "115243430516559"
	  }, {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Karen",
		  "statements" : [ {
			"id" : "115385986731040",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataType" : "number",
				"dataValue" : "prcntofUnsecuredExposure"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "percent1@local",
				"dataType" : "number"
			  }
			},
			"name" : "Margret"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "or",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "local",
				  "dataType" : "number",
				  "dataValue" : "totalLiveSanctionedAmount"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "keyword",
				  "dataType" : "text",
				  "dataValue" : "text",
				  "keywordArguments" : {
					"format" : "getNullValue"
				  }
				}
			  }, {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "local",
				  "dataType" : "number",
				  "dataValue" : "totalLiveSanctionedAmount"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataType" : "number",
				  "dataValue" : 0
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Jude",
				  "statements" : [ {
					"id" : "115785151552009",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "prnctofOstooverallamnt",
						"dataType" : "number"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "number",
						"dataValue" : 0
					  }
					},
					"name" : "Juliet"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "115786177572745"
				},
				"id" : "115788309923500"
			  } ],
			  "id" : "115781573419953"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Louisa",
				  "statements" : [ {
					"id" : "116086739498545",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "prnctofOstooverallamnt",
						"dataType" : "number"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "expression",
						"structure" : {
						  "@type" : "arithmetic",
						  "dataType" : "*",
						  "variables" : [ {
							"@type" : "expression",
							"structure" : {
							  "@type" : "arithmetic",
							  "dataType" : "/",
							  "variables" : [ {
								"@type" : "local",
								"dataType" : "number",
								"dataValue" : "totalLiveOutstandingamount"
							  }, {
								"@type" : "local",
								"dataType" : "number",
								"dataValue" : "totalLiveSanctionedAmount"
							  } ]
							}
						  }, {
							"@type" : "literal",
							"dataType" : "number",
							"dataValue" : 100
						  } ]
						}
					  }
					},
					"name" : "Kitty"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "116083397057744"
				},
				"id" : "116086638696216"
			  } ],
			  "id" : "116083251459535"
			},
			"id" : 129
		  }, {
			"id" : "117417182606646",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "writenoffOrSettledSummary",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "customer Response",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Jennings",
						  "statements" : [ {
							"id" : "116619590983837",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "productType",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "NIL",
								"dataType" : "text"
							  }
							},
							"name" : "Abigail"
						  }, {
							"id" : "116823807054382",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "sanctionedDate",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "NIL",
								"dataType" : "text"
							  }
							},
							"name" : "Thea"
						  }, {
							"id" : "116997926678588",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "outstandingAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Garth"
						  }, {
							"id" : "117108023902834",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "totalWritenoffAmount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Soledad"
						  }, {
							"id" : "117293529095405",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "settledamount",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : 0,
								"dataType" : "number"
							  }
							},
							"name" : "Donavon"
						  }, {
							"id" : "117411930053415",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "dateofPayment",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "NIL",
								"dataType" : "text"
							  }
							},
							"name" : "Hayden"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "117413405417729"
						},
						"id" : "117414848856360"
					  } ]
					}
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Rosemary"
		  }, {
			"id" : "117606735455139",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataType" : "list",
				"dataValue" : "liveLoanAccountSummary"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataType" : "list",
				"dataValue" : "liveLoanAccountSummary@local"
			  }
			},
			"name" : "Nicholas"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "117604823246787"
		},
		"id" : "117603143633966"
	  } ]
	}
  }`

const CountWithFilter = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Lucy",
		  "statements" : [ {
			"id" : "117921310768985",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "FilteredData",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"filter" : {
				  "id" : "117921520860110",
				  "name" : "filteraccountsbytype",
				  "condition" : {
					"@type" : "logical",
					"type" : "and",
					"rules" : [ {
					  "@type" : "relational",
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "dateClosed"
					  },
					  "operator" : {
						"actualValue" : "=="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "yes",
						"dataType" : "text"
					  }
					} ]
				  }
				},
				"@type" : "keyword",
				"dataType" : "number",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"value" : "response"
				  },
				  "format" : "count"
				}
			  }
			},
			"name" : "Brain"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "117925075473270"
		},
		"id" : "117924152249978"
	  } ]
	},
	"delete" : { },
	"extract" : { },
	"errors" : { }
  }`

const DateDifferenceBetweenHours = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "abc",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Emanuel",
		  "statements" : [ {
			"id" : "118421007586719",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "difference_between_date",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "text",
				"dataValue" : "date",
				"keywordArguments" : {
				  "init" : {
					"start" : {
					  "value" : "startDate",
					  "format" : "dd-MM-yyyy"
					},
					"end" : {
					  "value" : "endDate",
					  "format" : "dd-MM-yyyy"
					}
				  },
				  "format" : "dateDiff",
				  "type" : "hours"
				}
			  }
			},
			"name" : "Alberto"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "118421060801105"
		},
		"id" : "118426876498601"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const ReplaceNullWithCharPOpulate = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "jsonIgnoreProperty" : true,
	  "jsonIgnoreAliasValue" : "/",
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : true,
		  "name" : "Shany",
		  "statements" : [ {
			"id" : "118912230166264",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "genericDetails.customerPrincipal",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "map",
				"dataValue" : "map",
				"keywordArguments" : {
				  "init" : {
					"fields" : {
					  "occupationType" : "subType",
					  "dateOfBirth" : "dateofBirth"
					}
				  },
				  "format" : "populate"
				}
			  }
			},
			"name" : "Reba"
		  } ],
		  "jsonIgnoreAliasValue" : "/",
		  "id" : "118919418250754"
		},
		"id" : "118911011539090"
	  } ]
	}
  }`

const JsonUnFlatResponseArrayObjects = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "flatJson",
	"contentOutputType" : "json",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Christelle",
		  "statements" : [ {
			"id" : "119308991185073",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "response",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "list"
			  }
			},
			"name" : "Rowland"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "119308518233902"
		},
		"id" : "119308058494248"
	  } ]
	}
  }`

const JsonIgnorePropertyBasedOnDataTYpes = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "jsonIgnoreProperty" : true,
	  "jsonIgnoreAliasValue" : "/",
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : true,
		  "name" : "Wendy",
		  "statements" : [ {
			"id" : "119766894125466",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataType" : "list",
				"dataValue" : "detailedMessage"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataType" : "list",
				"dataValue" : "Project-K"
			  }
			},
			"name" : "Rose"
		  } ],
		  "jsonIgnoreAliasValue" : "/",
		  "id" : "119768848806149"
		},
		"id" : "119766037238414"
	  } ]
	}
  }`

const JsonIgnorePropertyPopulate = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "json",
	"contentOutputType" : "json",
	"ignoreNullFields" : true,
	"transform" : {
	  "jsonIgnoreProperty" : true,
	  "jsonIgnoreAliasValue" : "/",
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : true,
		  "name" : "Cara",
		  "statements" : [ {
			"id" : "120249165208682",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "keyword",
				"dataValue" : "none",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "map",
				"dataValue" : "map",
				"keywordArguments" : {
				  "init" : {
					"fields" : {
					  "bankName" : "bankname"
					}
				  },
				  "format" : "populate"
				}
			  }
			},
			"name" : "Monserrate"
		  } ],
		  "jsonIgnoreAliasValue" : "/",
		  "id" : "120242847319106"
		},
		"id" : "120241775226961"
	  } ]
	}
  }`

const DateConfiggetDay = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Harry",
		  "statements" : [ {
			"id" : "120692052362982",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "BirthDay_Day",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "getDay",
				  "init" : {
					"value" : "startDate",
					"format" : "dd-MM-yyyy"
				  }
				}
			  }
			},
			"name" : "Una"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "120697035030655"
		},
		"id" : "120692113742111"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const StatementIdExample = `{"id":2542379457800,"name":"testingConfiguration","@type":"transform","debug":false,"version":2,"transform":{"id":2542379457800,"name":"testingConfiguration","statements":[{"id":1697108034962777,"name":"Statement 1697107973271908","@type":"AssignmentStatement","mandatory":true,"assignment":{"lhs":{"@type":"literal","dataType":"text","dataValue":"customer.name"},"rhs":{"@type":"variable","dataType":"text","dataValue":"javeedPashaWain"},"operator":{"actualValue":"="}}}],"jsonIgnoreProperty":false,"jsonIgnoreAliasValue":null},"contentInputType":"json","contentOutputType":"json"}`

const MapLengtCondition = `{
	"version" : 3.3,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Estel",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "FIXML.Body.executeFinacleScriptResponse.executeFinacleScript_CustomData.SuccessFlag",
				  "dataType" : "text"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : "YES",
				  "dataType" : "text"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Holly",
				  "statements" : [ {
					"id" : "121236013539721",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "cifIdFlag",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : 1,
						"dataType" : "text"
					  }
					},
					"name" : "Betsy"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "121237128755252"
				},
				"id" : "121236341887934"
			  } ],
			  "id" : "121234236822171"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Andy",
				  "statements" : [ {
					"id" : "121543498301476",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "cifIdFlag",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : 0,
						"dataType" : "text"
					  }
					},
					"name" : "George"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "121542695584350"
				},
				"id" : "121548698612937"
			  } ],
			  "id" : "121548600228484"
			},
			"id" : 1
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "121546479109501"
		},
		"id" : "121541510747261"
	  } ]
	}
  }`

const DateConfiggetMonth = `{
	"version" : "1",
	"@type" : "transform",
	"contentInputType" : "json",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "Filter the Date Repsonse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Deborah",
		  "statements" : [ {
			"id" : "121915505664579",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "BirthDay_Month",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "getMonth",
				  "init" : {
					"value" : "startDate",
					"format" : "dd-MM-yyyy"
				  }
				}
			  }
			},
			"name" : "Lenny"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "121913952274053"
		},
		"id" : "121915988360434"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const TestLocalNUmericValue = `{
	"id" : 2542379457800,
	"name" : "testingConfiguration",
	"@type" : "transform",
	"debug" : false,
	"version" : 2,
	"transform" : {
	  "id" : 2542379457800,
	  "name" : "testingConfiguration",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Katrine",
		  "statements" : [ {
			"id" : "730256796848193",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "lengthOftheList",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "list",
				"dataType" : "text",
				"keywordArguments" : {
				  "format" : "length",
				  "init" : {
					"value" : "arrResponseVO.otherScoresData.scoresList"
				  }
				}
			  }
			},
			"name" : "Chadd"
		  }, {
			"id" : "730811679123709",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "localNumeric",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataValue" : 3,
				"dataType" : "number"
			  }
			},
			"name" : "Macie"
		  }, {
			"id" : "731323173287982",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "localNumeric",
				"dataType" : "number"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "localNumeric",
				"dataType" : "number"
			  }
			},
			"name" : "Stephon"
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "local",
				  "dataValue" : "localNumeric",
				  "dataType" : "number"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "local",
				  "dataValue" : "lengthOftheList",
				  "dataType" : "number"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Myrl",
				  "statements" : [ {
					"id" : "732417515116920",
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "condition",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "true",
						"dataType" : "text"
					  }
					},
					"name" : "Boyd"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "732415162276628"
				},
				"id" : "732417958938607"
			  } ],
			  "id" : "732416591137982"
			},
			"failure" : null,
			"id" : 1
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "732416952068206"
		},
		"id" : "732416712392966"
	  } ],
	  "jsonIgnoreProperty" : false,
	  "jsonIgnoreAliasValue" : null
	},
	"contentInputType" : "json",
	"contentOutputType" : "json"
  }`

const JsonUnFlatten = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "flatJson",
	"contentOutputType" : "flatJson",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Myrtis",
		  "statements" : [ {
			"id" : "122374636420426",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "keyword",
				"dataValue" : "none",
				"dataType" : "map"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "value",
				"dataType" : "map"
			  }
			},
			"name" : "Jena"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "122372537054967"
		},
		"id" : "122376836182227"
	  } ]
	}
  }`

const SectionalMandatory = `{
	"version" : "1",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "jsonIgnoreProperty" : false,
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Sophie",
		  "statements" : [ {
			"id" : "122732670163652",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataType" : "text",
				"dataValue" : "normalStatement"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "literal",
				"dataType" : "text",
				"dataValue" : "normalStatement"
			  }
			},
			"name" : "Crystel"
		  }, {
			"@type" : "SectionalStatement",
			"section" : {
			  "name" : "Statement 1697108026382390",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Kristoffer",
				  "statements" : [ {
					"id" : "123086753257228",
					"@type" : "AssignmentStatement",
					"mandatory" : true,
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "Section.InsideSection"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "InsideSection"
					  }
					},
					"name" : "Foster"
				  }, {
					"id" : "123259620166957",
					"@type" : "AssignmentStatement",
					"mandatory" : true,
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "Section.sectionalSecondStatement"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataType" : "text",
						"dataValue" : "sectionalSecondStatement"
					  }
					},
					"name" : "Norwood"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "123255002968955"
				},
				"id" : "123255747669075"
			  } ],
			  "id" : "123256376419712"
			},
			"id" : 1697107976635457
		  }, {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "literal",
				  "dataType" : "text",
				  "dataValue" : "literal"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataType" : "text",
				  "dataValue" : "literal"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Eldora",
				  "statements" : [ {
					"id" : "123565292804381",
					"mandatory" : false,
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "condition.name",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "variable",
						"dataValue" : "javeed",
						"dataType" : "text"
					  }
					},
					"name" : "Kristopher"
				  }, {
					"id" : "123708676193884",
					"mandatory" : false,
					"@type" : "AssignmentStatement",
					"assignment" : {
					  "@type" : "SimpleAssignmentStatement",
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "condition.isGraduate",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "yes",
						"dataType" : "text"
					  }
					},
					"name" : "Michele"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "123701175716861"
				},
				"id" : "123702712013952"
			  } ],
			  "id" : "123701198386941"
			},
			"failure" : null,
			"id" : "3"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "123709277267809"
		},
		"id" : "123707099059007"
	  } ]
	}
  }`

const ContentInputOutputConf = `{
	"version" : "1",
	"contentInputType" : "text",
	"contentOutputType" : "json",
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "customerResponse",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Emerson",
		  "statements" : [ {
			"id" : "124084143117808",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "appID",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "appID",
				"dataType" : "text"
			  }
			},
			"name" : "Bertram"
		  }, {
			"id" : "124248254669462",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "userID",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "userID",
				"dataType" : "text"
			  }
			},
			"name" : "Katharina"
		  }, {
			"id" : "124437460714489",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "status",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "status",
				"dataType" : "text"
			  }
			},
			"name" : "Herta"
		  }, {
			"id" : "124596596619435",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "comments",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "comments",
				"dataType" : "text"
			  }
			},
			"name" : "Minerva"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "124607472298748"
		},
		"id" : "124601002929749"
	  } ]
	},
	"delete" : { },
	"extract" : { }
  }`

const JsonUnFlatjsonContentInput = `{
	"version" : 3.3,
	"@type" : "transform",
	"contentInputType" : "flatJson",
	"contentOutputType" : "flatJson",
	"transform" : {
	  "jsonIgnoreProperty" : false,
	  "id" : "transform_employeeDetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Emmett",
		  "statements" : [ {
			"id" : "126853718829999",
			"mandatory" : true,
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "response.data.flag",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "variable",
				"dataValue" : "section0.addAdditionalStmap",
				"dataType" : "text"
			  }
			},
			"name" : "Ibrahim"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "126855446078147"
		},
		"id" : "126857017713139"
	  } ]
	}
  }`

const PlElseStatementFailing = `{
	"version" : 1,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "transform Address Details",
	  "validate" : [ {
		"condition" : {
		  "@type" : "logical",
		  "type" : "and",
		  "rules" : [ {
			"@type" : "relational",
			"lhs" : {
			  "@type" : "variable",
			  "dataType" : "text",
			  "dataValue" : "appPackageId"
			},
			"operator" : {
			  "actualValue" : "!="
			},
			"rhs" : {
			  "@type" : "literal",
			  "dataValue" : "",
			  "dataType" : "text"
			}
		  } ]
		},
		"error" : {
		  "subcode" : "500",
		  "detailedMessage" : "Invalid appPackageId"
		}
	  } ],
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Orpha",
		  "statements" : [ {
			"condition" : {
			  "@type" : "logical",
			  "type" : "and",
			  "rules" : [ {
				"@type" : "relational",
				"lhs" : {
				  "@type" : "variable",
				  "dataValue" : "selectOffer",
				  "dataType" : "boolean"
				},
				"operator" : {
				  "actualValue" : "=="
				},
				"rhs" : {
				  "@type" : "literal",
				  "dataValue" : true,
				  "dataType" : "boolean"
				}
			  } ]
			},
			"@type" : "ConditionalStatement",
			"success" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Zelda",
				  "statements" : [ {
					"id" : "127536610687073",
					"@type" : "AssignmentStatement",
					"mandatory" : true,
					"assignment" : {
					  "lhs" : {
						"@type" : "literal",
						"dataValue" : "plDetails.jplDecision.decisionValue",
						"dataType" : "text"
					  },
					  "operator" : {
						"actualValue" : "="
					  },
					  "rhs" : {
						"@type" : "literal",
						"dataValue" : "311480",
						"dataType" : "text"
					  }
					},
					"name" : "Lola"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "127533332512566"
				},
				"id" : "127532468952033"
			  } ],
			  "id" : "127531924522793"
			},
			"failure" : {
			  "name" : "transformation",
			  "statements" : [ {
				"@type" : "SectionalStatement",
				"section" : {
				  "jsonIgnoreProperty" : false,
				  "name" : "Stefan",
				  "statements" : [ {
					"condition" : {
					  "@type" : "logical",
					  "type" : "and",
					  "rules" : [ {
						"@type" : "relational",
						"lhs" : {
						  "@type" : "variable",
						  "dataValue" : "selectOffer",
						  "dataType" : "boolean"
						},
						"operator" : {
						  "actualValue" : "=="
						},
						"rhs" : {
						  "@type" : "literal",
						  "dataValue" : false,
						  "dataType" : "boolean"
						}
					  } ]
					},
					"@type" : "ConditionalStatement",
					"success" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Aryanna",
						  "statements" : [ {
							"id" : "128161044748859",
							"@type" : "AssignmentStatement",
							"mandatory" : true,
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplDecision.decisionValue",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "311481",
								"dataType" : "text"
							  }
							},
							"name" : "Antwan"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "128163171698397"
						},
						"id" : "128162359377740"
					  } ],
					  "id" : "128167163233564"
					},
					"failure" : {
					  "name" : "transformation",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Ismael",
						  "statements" : [ {
							"id" : "128604667528010",
							"@type" : "AssignmentStatement",
							"mandatory" : true,
							"assignment" : {
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "plDetails.jplDecision.decisionValue",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "keyword",
								"dataType" : "text",
								"dataValue" : "text",
								"keywordArguments" : {
								  "format" : "getNullValue"
								}
							  }
							},
							"name" : "Tracy"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "128607324559595"
						},
						"id" : "128608854270163"
					  } ],
					  "id" : "128606686732546"
					},
					"id" : "2"
				  } ],
				  "jsonIgnoreAliasValue" : null,
				  "id" : "128604310488639"
				},
				"id" : "128605201312687"
			  } ],
			  "id" : "128609830133241"
			},
			"id" : "2"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "128603683386106"
		},
		"id" : "128603869152450"
	  } ]
	}
  }`

const pageNation = `{
	"transform" : {
	  "id" : "transform_custodetails",
	  "name" : "Request payload Transformation",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Beulah",
		  "statements" : [ {
			"id" : "129025333942568",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "pageNationValue",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "function",
				"functionName" : "pageNation",
				"functionArguments" : {
				  "dataValue" : "customerDetails"
				},
				"dataType" : "list"
			  }
			},
			"name" : "Bennie"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "129029312601017"
		},
		"id" : "129024494433702"
	  } ]
	}
  }`

const DateTesting1 = `{
	"version" : 1,
	"@type" : "transform",
	"transform" : {
	  "id" : "transform_config_1",
	  "name" : "transform cibilresponse for Grid",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Armani",
		  "statements" : [ {
			"id" : "129401207502985",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "dateofReport",
				"dataType" : "date"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataValue" : "date",
				"dataType" : "date",
				"keywordArguments" : {
				  "format" : "dd-MM-yyyy",
				  "init" : {
					"value" : "response.processedDateTime",
					"format" : "unixTime"
				  }
				}
			  }
			},
			"name" : "Roxanne"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "129404676892369"
		},
		"id" : "129405980013565"
	  } ]
	}
  }`

const RelatedParties = `{
	"transform" : {
	  "id" : "transform_config_2",
	  "name" : "transform Consumer Communication Address Details",
	  "statements" : [ {
		"@type" : "SectionalStatement",
		"section" : {
		  "jsonIgnoreProperty" : false,
		  "name" : "Ottis",
		  "statements" : [ {
			"id" : "130181978706628",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "lhs" : {
				"@type" : "declare",
				"dataValue" : "CollecteD_Keys",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "Collect",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Roselyn",
						  "statements" : [ {
							"id" : "130186351509966",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "declare",
								"dataValue" : "primitives",
								"dataType" : "list"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "function",
								"functionName" : "collect",
								"functionArguments" : {
								  "pick" : "key",
								  "condition" : {
									"@type" : "logical",
									"type" : "and",
									"rules" : [ {
									  "@type" : "relational",
									  "lhs" : {
										"@type" : "keyword",
										"dataValue" : "mapvalue",
										"dataType" : "boolean"
									  },
									  "operator" : {
										"actualValue" : "=="
									  },
									  "rhs" : {
										"@type" : "literal",
										"dataValue" : true,
										"dataType" : "boolean"
									  }
									} ]
								  }
								},
								"dataType" : "list"
							  }
							},
							"name" : "Immanuel"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "130183002635538"
						},
						"id" : "130181235701189"
					  } ]
					},
					"value" : "relatedParties"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Wilma"
		  }, {
			"id" : "130377779080170",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "PrimitiveArray",
				"dataType" : "text"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "local",
				"dataValue" : "primitives",
				"dataType" : "text"
			  }
			},
			"name" : "Mike"
		  }, {
			"id" : "131294680501870",
			"@type" : "AssignmentStatement",
			"assignment" : {
			  "@type" : "SimpleAssignmentStatement",
			  "lhs" : {
				"@type" : "literal",
				"dataValue" : "customerMapping",
				"dataType" : "list"
			  },
			  "operator" : {
				"actualValue" : "="
			  },
			  "rhs" : {
				"@type" : "keyword",
				"dataType" : "list",
				"dataValue" : "list",
				"keywordArguments" : {
				  "init" : {
					"transform" : {
					  "id" : "transform_config_1",
					  "name" : "transform Address Information",
					  "statements" : [ {
						"@type" : "SectionalStatement",
						"section" : {
						  "jsonIgnoreProperty" : false,
						  "name" : "Cloyd",
						  "statements" : [ {
							"condition" : {
							  "@type" : "logical",
							  "type" : "or",
							  "rules" : [ {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "Director",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "partner",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "guarantor",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "coBorrower",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "authorisedSignatory",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "shareHolder",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "coParcener",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "pOAHolder",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "Karta",
								  "dataType" : "text"
								}
							  }, {
								"@type" : "relational",
								"lhs" : {
								  "@type" : "keyword",
								  "dataType" : "text",
								  "dataValue" : "value"
								},
								"operator" : {
								  "actualValue" : "=="
								},
								"rhs" : {
								  "@type" : "literal",
								  "dataValue" : "Proprietor",
								  "dataType" : "text"
								}
							  } ]
							},
							"@type" : "ConditionalStatement",
							"success" : {
							  "name" : "transformation",
							  "statements" : [ {
								"@type" : "SectionalStatement",
								"section" : {
								  "jsonIgnoreProperty" : false,
								  "name" : "Tate",
								  "statements" : [ {
									"id" : "131095858772139",
									"@type" : "AssignmentStatement",
									"assignment" : {
									  "lhs" : {
										"@type" : "literal",
										"dataValue" : "relationshipType",
										"dataType" : "text"
									  },
									  "operator" : {
										"actualValue" : "="
									  },
									  "rhs" : {
										"@type" : "keyword",
										"dataValue" : "value",
										"dataType" : "number"
									  }
									},
									"name" : "Alden"
								  } ],
								  "jsonIgnoreAliasValue" : null,
								  "id" : "131093888466151"
								},
								"id" : "131096525628110"
							  } ],
							  "id" : "131096281706458"
							},
							"failure" : null,
							"id" : 1
						  }, {
							"id" : "131292363563935",
							"@type" : "AssignmentStatement",
							"assignment" : {
							  "@type" : "SimpleAssignmentStatement",
							  "lhs" : {
								"@type" : "literal",
								"dataValue" : "customerMappingId",
								"dataType" : "text"
							  },
							  "operator" : {
								"actualValue" : "="
							  },
							  "rhs" : {
								"@type" : "literal",
								"dataValue" : "customerMappingId",
								"dataType" : "text"
							  }
							},
							"name" : "Wilbert"
						  } ],
						  "jsonIgnoreAliasValue" : null,
						  "id" : "131296044495575"
						},
						"id" : "131293851162140"
					  } ]
					},
					"value" : "primitives@local"
				  },
				  "format" : "iterate"
				}
			  }
			},
			"name" : "Hillary"
		  } ],
		  "jsonIgnoreAliasValue" : null,
		  "id" : "131293898607051"
		},
		"id" : "131291431167274"
	  } ]
	}
  }`

const TestingConditionJsonIgnoreProperty = `{
    "version": 3.3,
    "@type": "transform",
    "transform": {
        "id": "transform_custodetails",
        "name": "Request payload Transformation",
        "statements": [
            {
                "@type": "SectionalStatement",
                "section": {
                    "jsonIgnoreProperty": false,
                    "name": "Winston",
                    "statements": [
                        {
							"name": "Melisa",
                            "condition": {
								"name": "Melisa",
                                "@type": "logical",
                                "type": "and",
                                "rules": [
                                    {
                                        "@type": "relational",
                                        "lhs": {
                                            "@type": "literal",
                                            "dataValue": "javedssss",
                                            "dataType": "text"
                                        },
                                        "operator": {
                                            "actualValue": "=="
                                        },
                                        "rhs": {
                                            "@type": "literal",
                                            "dataValue": "javed",
                                            "dataType": "text"
                                        }
                                    },
									{
                                        "@type": "relational",
                                        "lhs": {
                                            "@type": "varriableadhffkDH",
                                            "dataValue": "name",
                                            "dataType": "text"
                                        },
                                        "operator": {
                                            "actualValue": "=="
                                        },
                                        "rhs": {
                                            "@type": "literal",
                                            "dataValue": "name",
                                            "dataType": "text"
                                        }
                                    }
                                ]
                            },
                            "@type": "ConditionalStatement",
                            "success": {
                                "name": "transformation",
								
								"jsonIgnoreProperty": false,
                                "statements": [
                                    {
                                        "id": "414935082727881",
                                        "@type": "AssignmentStatement",
                                        "assignment": {
                                            "lhs": {
                                                "@type": "literal",
                                                "dataType": "boolean",
                                                "dataValue": "condition"
                                            },
                                            "operator": {
                                                "actualValue": "="
                                            },
                                            "rhs": {
                                                "@type": "literal",
                                                "dataType": "boolean",
                                                "dataValue": "success"
                                            }
                                        },
                                        "name": "Melisa"
                                    }
                                ],
                                "id": "414938007380837"
                            },
                            "failure": {
                                "name": "transformation",
                                "statements": [
                                    {
                                        "id": "414935082727881",
                                        "@type": "AssignmentStatement",
                                        "assignment": {
                                            "lhs": {
                                                "@type": "literal",
                                                "dataType": "text",
                                                "dataValue": "condition"
                                            },
                                            "operator": {
                                                "actualValue": "="
                                            },
                                            "rhs": {
                                                "@type": "literal",
                                                "dataType": "text",
                                                "dataValue": "failed"
                                            }
                                        },
                                        "name": "Melisa"
                                    }
                                ],
                                "id": "414938007380837"
                            }
                        }
                    ]
                }
            }
        ]
    }
}`

const PanicRecvery = `{
	"version": 3.3,
	"@type": "transform",
	"transform": {
	  "id": "transform_custodetails",
	  "name": "Request payload Transformation",
	  "statements": [
		{
		  "id": "414935082727881",
		  "mandatory" : false,
		  "@type": "AssignmentStatement",
		  "assignment": {
			"lhs": {
			  "@type": "literal",
			  "dataType": "boolean",
			  "dataValue": "condition"
			},
			"operator": {
			  "actualValue": "="
			},
			"rhs": {
			  "@type": "variable",
			  "dataType": "boolean",
			  "dataValue": 1
			}
		  },
		  "name": "Melisa"
		},
		{
			"id": "414935082727881",
			"mandatory" : false,
			"@type": "AssignmentStatement",
			"assignment": {
			  "lhs": {
				"@type": "literal",
				"dataType": "boolean",
				"dataValue": "status"
			  },
			  "operator": {
				"actualValue": "="
			  },
			  "rhs": {
				"@type": "literal",
				"dataType": "boolean",
				"dataValue": "panice Recovered"
			  }
			},
			"name": "Melisa"
		  }
	  ]
	}
  }`

const TestArithmeticWithStringValueConfig = `{"version":3.3,"@type":"transform","transform":{"id":"transform_custodetails","name":"Request payload Transformation","statements":[{"@type":"SectionalStatement","section":{"jsonIgnoreProperty":false,"name":"Hester","statements":[{"id":"1741862706444926","name":"WorldBox","@type":"AssignmentStatement","mandatory":true,"toogleSwitchValue":false,"assignment":{"lhs":{"@type":"literal","dataValue":"sumValue","dataType":"any"},"operator":{"actualValue":"="},"rhs":{"structure":{"@type":"arithmetic","dataType":"+","variables":[{"@type":"literal","dataValue":"1","dataType":"text"},{"structure":{"@type":"arithmetic","dataType":"+","variables":[{"@type":"literal","dataValue":"1","dataType":"text"},{"@type":"literal","dataValue":100,"dataType":"number"}]},"dataType":"text","@type":"expression"}]},"dataType":"text","@type":"expression"}}},{"id":"1741862706444926","name":"WorldBox","@type":"AssignmentStatement","mandatory":true,"toogleSwitchValue":false,"assignment":{"lhs":{"@type":"literal","dataValue":"subtractValue","dataType":"any"},"operator":{"actualValue":"="},"rhs":{"structure":{"@type":"arithmetic","dataType":"-","variables":[{"@type":"literal","dataValue":"1","dataType":"text"},{"@type":"literal","dataValue":1,"dataType":"number"}]},"dataType":"text","@type":"expression"}}},{"id":"1741862706444926","name":"WorldBox","@type":"AssignmentStatement","mandatory":true,"toogleSwitchValue":false,"assignment":{"lhs":{"@type":"literal","dataValue":"multiplyValue","dataType":"any"},"operator":{"actualValue":"="},"rhs":{"structure":{"@type":"arithmetic","dataType":"*","variables":[{"@type":"literal","dataValue":"1","dataType":"text"},{"@type":"literal","dataValue":100,"dataType":"number"}]},"dataType":"text","@type":"expression"}}},{"id":"1741862706444926","name":"WorldBox","@type":"AssignmentStatement","mandatory":true,"toogleSwitchValue":false,"assignment":{"lhs":{"@type":"literal","dataValue":"divideValue","dataType":"any"},"operator":{"actualValue":"="},"rhs":{"structure":{"@type":"arithmetic","dataType":"/","variables":[{"@type":"literal","dataValue":"100","dataType":"text"},{"@type":"literal","dataValue":25,"dataType":"number"}]},"dataType":"text","@type":"expression"}}},{"id":"1741862706444926","name":"WorldBox","@type":"AssignmentStatement","mandatory":true,"toogleSwitchValue":false,"assignment":{"lhs":{"@type":"literal","dataValue":"modValue","dataType":"any"},"operator":{"actualValue":"="},"rhs":{"structure":{"@type":"arithmetic","dataType":"%","variables":[{"@type":"literal","dataValue":"15","dataType":"text"},{"@type":"literal","dataValue":7,"dataType":"number"}]},"dataType":"text","@type":"expression"}}},{"id":"1741862706444926","name":"WorldBox","@type":"AssignmentStatement","mandatory":true,"toogleSwitchValue":false,"assignment":{"lhs":{"@type":"literal","dataValue":"exponentialValue","dataType":"any"},"operator":{"actualValue":"="},"rhs":{"structure":{"@type":"arithmetic","dataType":"^","variables":[{"@type":"literal","dataValue":"2","dataType":"text"},{"@type":"literal","dataValue":3,"dataType":"number"}]},"dataType":"text","@type":"expression"}}}],"jsonIgnoreAliasValue":null,"id":"165364545700433"},"id":"165369122110126"}]}}`
