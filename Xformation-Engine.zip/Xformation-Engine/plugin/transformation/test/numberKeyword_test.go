package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestNumberWithCeil(t *testing.T) {
	fmt.Println("---------------enterd numberKeyword_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberCeil)
	assert.Equal(t, (results), cfg.TestNumberWithCeil)
}

func TestNumberWithFloor(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberFloor)
	assert.Equal(t, (results), cfg.TestNumberWithFloor)
}
func TestNumberWithRound(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberRound)
	assert.Equal(t, (results), cfg.TestNumberWithRound)
}

func TestNumberWithRoundwithDecimal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberRoundwithDecimal)
	assert.Equal(t, (results), cfg.TestNumberWithRoundwithDecimal)
}

func TestNumberWithGetNonDecimal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberGetNonDecimal)
	assert.Equal(t, (results), cfg.TestNumberWithGetNonDecimal)
}

func TestNumberWithGetDecimal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberGetDecimal)
	assert.Equal(t, (results), cfg.TestNumberWithGetDecimal)
}
func TestNumberWithToText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberToText)
	assert.Equal(t, (results), cfg.TestNumberWithToText)
}

func TestNumberWithToTextLongNumber(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberToTextSalary)
	assert.Equal(t, (results), cfg.TestNumberWithToTextLongNumber)
}

func TestNumberWithNullValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberWithNullValue)
	assert.Equal(t, (results), cfg.TestNumberWithNullValue)
}

func TestNumberKeywordConvertTextToText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberTextConvertToText)
	fmt.Println("res ", results)
	// assert.Equal(t, (results), cfg.TestNumberWithNullValue)
}

func TestNumberToAsciiValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.NumberToAsciiValue)
	assert.Equal(t, (results), cfg.NumberToAsciiValueO)
}

func TestNumberIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.CheckNumberIsEmptyConfig)
	assert.Equal(t, (results), cfg.CheckNumberIsEmpty)
}

func TestNumberIsEmptyForKeyNotPresent(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.CheckNumberIsEmptyConfigForKeyNotPresent)
	assert.Equal(t, (results), cfg.TestIsEmptyForKeywords)
}

func TestNumberValueKeyNotPresentInConfigForIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestNumberValueKeyNotPresentInConfigForIsEmpty)
	assert.Equal(t, (results), cfg.TestKeyNotPresentInConfigForIsEmpty)
}
