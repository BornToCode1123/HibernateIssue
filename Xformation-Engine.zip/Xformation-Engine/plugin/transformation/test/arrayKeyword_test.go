package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestListLength(t *testing.T) {
	fmt.Println("---------------enterd arrayKeyword_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListLength)
	assert.Equal(t, (results), cfg.TestListLength)

}

func TestListLengthEmptyArray(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListLengthEmptyArray)
	assert.Equal(t, (results), cfg.TestListLengthEmptyArray)

}

func TestListPush(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListPush)
	assert.Equal(t, (results), cfg.TestListPush)
}

func TestSPushObject(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListPushObject)
	assert.Equal(t, (results), cfg.TestSPushObject)
}

func TestSort(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListSorting)
	assert.Equal(t, (results), cfg.TestSort)
}

func TestSortStrings(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.SortMap)
	assert.Equal(t, (results), cfg.TestSortStrings)

}

func TestSortByProperty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.SortBy)
	assert.Equal(t, (results), cfg.TestSortByProperty)
}

func TestSortLocalString(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.SortLocalStrings)
	assert.Equal(t, (results), cfg.TestSortLocalString)

}

func TestSortLocalByProperty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.SortLocalByProperty)
	assert.Equal(t, (results), cfg.TestSortByProperty)

}

func TestIterateWithEmptyFields(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IterateEmptyFields)
	assert.Equal(t, (results), cfg.TestIterateWithEmptyFields)

}

func TestListPop(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListPop)
	assert.Equal(t, (results), cfg.TestListPop)
}

func TestListWithNullValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListWithNullValue)
	assert.Equal(t, (results), cfg.TestListWithNullValue)
}

func TestIterateWithemptyArray(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ListWithNullValue)
	assert.Equal(t, (results), cfg.TestListWithNullValue)
}

func TestCreatingEmptyList(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.CreatingEmptyList)
	assert.Equal(t, (results), cfg.TestCreatingEmptyList)
}

func TestCreatingEmptyListWithCount(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")

	results := runTestCase(fileContent, cfg.CreatingEmptyListWithCount)
	assert.Equal(t, (results), cfg.TestCreatingEmptyListWithCount)
}

func TestSplittedArrayOverriding(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")

	results := runTestCase(fileContent, cfg.SplittedArrayOverriding)
	assert.Equal(t, (results), cfg.TestSplittedArrayOverriding)
}

func TestKeywordShuffle(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.Shuffle)
	assert.Equal(t, len(results), len(cfg.TestShuffle))
}

func TestKeywordShufflingWords(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ShufflingWords)
	assert.Equal(t, len(results), len(cfg.TestKeywordShufflingWords))
}

func TestKeywordReverse(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.ReverseArray)
	assert.Equal(t, len(results), len(cfg.TestKeywordReverse))
}

func TestListJsonObjectList(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.JsonObjectList)
	assert.Equal(t, (results), (cfg.TestListJsonObjectList))
}

func Test_MakeTheListEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.MakeTheListEmpty)
	assert.Equal(t, (results), (cfg.Test_MakeTheListEmpty))
}

func Test_FindingIndexesOfEveryIteration(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.FindingIndexesOfEveryIteration)
	assert.Equal(t, (results), (cfg.Test_FindingIndexesOfEveryIteration))
}

func TestListIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.CheckListIsEmpty)
	assert.Equal(t, (results), (cfg.TestIsEmptyForKeywords))
}

func TestListIsEmptyForKeyNotPresent(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestListIsEmptyForKeyNotPresent)
	assert.Equal(t, (results), (cfg.TestIsEmptyForKeywords))
}

func TestListIsEmptyForValueKeyNotPresentInConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestListIsEmptyForValueKeyNotPresentInConfig)
	assert.Equal(t, (results), (cfg.TestKeyNotPresentInConfigForIsEmpty))
}

func Test_WhileIteratingListGetValueBehaviourIsSameAsItsResponse(t *testing.T) {

	InitLogger()

	fileContent := ("./payloads/BugFixesPayload.json")

	results := runTestCase(fileContent, cfg.IterationInsideTheBehaviourOfConfig)
	assert.Equal(t, (results), (cfg.Test_WhileIteratingListGetValueBehaviourIsSameAsItsResponse))
}

func Test_WhileIteratingWithCOnfigChangingTheExistingBehaviour(t *testing.T) {

	InitLogger()

	fileContent := ("./payloads/BugFixesPayload.json")

	results := runTestCase(fileContent, cfg.IterateWithTransformChangingTheExistingBehaviourUsingConfig)
	assert.Equal(t, (results), (cfg.Test_WhileIteratingWithCOnfigChangingTheExistingBehaviour))
}
