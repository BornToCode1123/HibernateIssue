package test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"jocata_transform_plugin/constants"
	handler "jocata_transform_plugin/handler"
	"jocata_transform_plugin/khazaam"
	logger "jocata_transform_plugin/log"
	"jocata_transform_plugin/parse"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"log"
	"net/http/httptest"
	"net/url"
	"os"
)

func InitLogger() {
	logger.Log.LoadJsonConfiguration("../configs/log/loggerConfiguration.json")
	logger.Log.Trace(nil, "Logger injection done..!")
}

func runTestCase(payloadFile string, config string) string {
	utils.PopulateErrorMap()
	fileContent, err := os.ReadFile(payloadFile)
	if err != nil {
		log.Fatal(err)
	}

	var configJson rs.Config
	err1 := json.Unmarshal([]byte(config), &configJson)
	if err1 != nil {
		log.Fatal(err.Error())
	}
	localMap := make(map[string]interface{})
	localMap[constants.TRACE_ID] = "traceId-1234"
	localMap[constants.SPAN_ID] = "spanId-456"
	localMap["headers"] = make(map[string]interface{})
	results, tErr := khazaam.ConvertConfigToKhazaamSpecification(configJson, fileContent, nil, localMap, nil)

	if tErr.Detailedmessage != nil {
		tErr.Detailedmessage = constants.SYSTEM_ADMIN_ERROR_MESSAGE
		return string(parse.ParseErrortoBytes(nil, tErr, configJson.ContentOutputType))
	}
	return results
}

func runPluginTestCase(payloadFile string, config string) string {

	utils.PopulateErrorMap()
	fileContent, err := os.ReadFile(payloadFile)
	if err != nil {
		log.Fatal(err)
	}

	rec := httptest.NewRecorder()
	transformPluginConfig, endpoint, method, err := getPluginProperties(config)
	fmt.Println("err ", err)

	initMap, updatedStatements := utils.GetObjectAndMapListHardCodedData(transformPluginConfig)
	if len(updatedStatements) != 0 {
		if transform, ok := transformPluginConfig.Init.HolderConfig.(rs.Transform); ok {
			transform.Statements = updatedStatements
			transformPluginConfig.Init.HolderConfig = transform
		}
	}

	reqBody := bytes.NewBufferString(string(fileContent))
	req := httptest.NewRequest(method, endpoint, reqBody)
	req.Header.Set("Authorization", "Bearer mocktoken")
	req.Header.Set("Content-Type", "application/json")
	localMap := make(map[string]interface{})
	localMap[constants.TRACE_ID] = "traceId-1234"
	localMap[constants.SPAN_ID] = "spanId-456"
	handler.PluginHandler(rec, req, transformPluginConfig, localMap, &initMap)

	res := rec.Result()
	defer res.Body.Close()

	result, _ := io.ReadAll(res.Body)

	return string(result)
}

func getPluginProperties(payloadData string) (rs.Plugin, string, string, error) {

	var endpoint, method string
	var endpointConfig rs.Endpoint
	err := json.Unmarshal([]byte(payloadData), &endpointConfig)
	if err != nil {
		fmt.Println("Error unmarshalling payload:", err)
		return rs.Plugin{}, "", "", err
	}
	var plugin rs.Plugin

	if len(endpointConfig.Backend) > 0 {
		backend := &endpointConfig.Backend[0]
		endpoint = backend.Host[0] + backend.UrlPattern
		method = backend.Method
		plugin = backend.ExtraConfig.Executor.TransFormPlugin
	}
	return plugin, endpoint, method, nil
}

func runUrlEncodePluginTestCase(payloadFile string, config string) string {

	utils.PopulateErrorMap()

	rec := httptest.NewRecorder()
	transformPluginConfig, endpoint, method, err := getPluginProperties(config)
	fmt.Println("err ", err)

	initMap, updatedStatements := utils.GetObjectAndMapListHardCodedData(transformPluginConfig)
	if len(updatedStatements) != 0 {
		if transform, ok := transformPluginConfig.Init.HolderConfig.(rs.Transform); ok {
			transform.Statements = updatedStatements
			transformPluginConfig.Init.HolderConfig = transform
		}
	}
	formData := url.Values{}
	formData.Set("name", "John Doe")
	formData.Set("email", "johndoe@example.com")
	formData.Set("sal", "30")
	formData.Set("subscribe", "true")

	// Convert the form data to a byte buffer
	reqBody := bytes.NewBufferString(formData.Encode())
	req := httptest.NewRequest(method, endpoint, reqBody)
	req.Header.Set("Authorization", "Bearer mocktoken")
	req.Header.Set("Content-Type", "application/json")
	localMap := make(map[string]interface{})
	localMap[constants.TRACE_ID] = "traceId-1234"
	localMap[constants.SPAN_ID] = "spanId-456"
	handler.PluginHandler(rec, req, transformPluginConfig, localMap, &initMap)

	res := rec.Result()
	defer res.Body.Close()

	result, _ := io.ReadAll(res.Body)

	return string(result)
}
