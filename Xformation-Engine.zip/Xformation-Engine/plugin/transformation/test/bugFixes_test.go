package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func Test_GenerateUUIDIssue(t *testing.T) {
	fmt.Println("---------------enterd bugFix_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.GenerateUUIDWithJsonIgnoreTrue)
	assert.Equal(t, len(results), len(cfg.Test_GenerateUUIDIssue))
}

func Test_SplitEmptyString(t *testing.T) {

	InitLogger()

	fileContent := ("./payloads/BugFixesPayload.json")

	results := runTestCase(fileContent, cfg.TestEmptyStringSplit)
	assert.Equal(t, (results), (cfg.Test_SplitEmptyString))
}

func Test_ArithematicInCondition(t *testing.T) {

	InitLogger()

	fileContent := ("./payloads/BugFixesPayload.json")

	results := runTestCase(fileContent, cfg.TestArithematicInCondition)
	assert.Equal(t, (results), (cfg.Test_Arithematic_Operator))
}

func Test_XMLTempleteObjectMakingList(t *testing.T) {

	InitLogger()

	fileContent := ("./payloads/BugFixesPayload.json")

	results := runTestCase(fileContent, cfg.XMLTempleteObjectMakingList)
	fmt.Println(results)
	// assert.Equal(t, len(results), len(cfg.Test_GenerateUUIDIssue))
}

func Test_TestFilterBug(t *testing.T) {

	InitLogger()

	fileContent := ("./payloads/BugFixesPayload.json")

	results := runTestCase(fileContent, cfg.TestFilterBug)
	fmt.Println(results)
	// assert.Equal(t, len(results), len(cfg.Test_GenerateUUIDIssue))
}

func Test_ConditionalBreakWhileAndOperator(t *testing.T) {

	InitLogger()

	fileContent := ("./payloads/BugFixesPayload.json")

	results := runTestCase(fileContent, cfg.TestConditionWithrules)
	fmt.Println(results)
	// assert.Equal(t, len(results), len(cfg.Test_GenerateUUIDIssue))
}

func Test_PanicErrorRecoveryExceptionHandling(t *testing.T) {

	InitLogger()

	fileContent := ("./payloads/BugFixesPayload.json")

	results := runTestCase(fileContent, cfg.PanicErrorRecovery)
	assert.Equal(t, len(results), len(cfg.Test_PanicErrorRecoveryExceptionHandling))
}
