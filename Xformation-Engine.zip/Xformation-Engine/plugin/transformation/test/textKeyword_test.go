package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestTextWithTrim(t *testing.T) {
	fmt.Println("---------------enterd textKeyword_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_trim)
	assert.Equal(t, (results), cfg.TestTextWithTrim)
}

func TestTextWithToLower(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_toLower)
	assert.Equal(t, (results), cfg.TestTextWithToLower)
}

func TestTextWithtoUpper(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_toUpper)
	assert.Equal(t, (results), cfg.TestTextWithtoUpper)
}

func TestTextWithcamel(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_camel)
	assert.Equal(t, (results), cfg.TestTextWithcamel)
}

func TestTextWithPacal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_Pascal)
	assert.Equal(t, (results), cfg.TestTextWithPascal)
}

func TestTextWithSnake(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_SnakeCase)
	assert.Equal(t, (results), cfg.TestTextWithSnake)
}

func TestTextWithKebab(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_KebabCase)
	assert.Equal(t, (results), cfg.TestTextWithKebab)
}

func TestTextWithtoNumber(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_toNumber)
	assert.Equal(t, (results), cfg.TestTextWithtoNumber)
}

func TestTextWithtoBoolean(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_toBoolean)
	assert.Equal(t, (results), cfg.TestTextWithtoBoolean)
}

func TestTextWithisNumberFalse(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_isNumberFalse)
	assert.Equal(t, (results), cfg.TestTextWithisNumberFalse)
}

func TestTextWithisNumbertrue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_isNumberTrue)
	assert.Equal(t, (results), cfg.TestTextWithisNumbertrue)
}

func TestTextWithisBooleanfalse(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_isBooleanfalse)
	assert.Equal(t, (results), cfg.TestTextWithisBooleanfalse)
}

func TestTextWithisBooleanTrue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_isBooleanTrue)
	assert.Equal(t, (results), cfg.TestTextWithisBooleanTrue)
}

func TestTextWithisBooleanTrueWithXMLInput(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.xml")

	results := runTestCase(fileContent, cfg.TestKeyword_isBooleanTrueWithXMLInput)
	assert.Equal(t, (results), cfg.TestKeywordisBooleanTrueWithXMLInput)
}

func TestTextWithDecode(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decode.json")

	results := runTestCase(fileContent, cfg.TestKeyword_decode)
	assert.Equal(t, len(results), 7420)
}

func TestTextWithNullValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TextWithNullValue)
	assert.Equal(t, (results), cfg.TestTextWithNullValue)
}

func TestFromJsonKeyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TextFromJson)
	assert.Equal(t, (results), cfg.TestFromJsonKeyword)
}

func TestFromXMLKeyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TextFromXml)
	assert.Equal(t, len(results), 109)
}

func TestKeywordTextcontains(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestKeyword_contains)
	assert.Equal(t, results, cfg.TextKeywordContains)
}

func TestKeywordSubString(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.SubString)
	assert.Equal(t, results, cfg.TestSubString)
}

func TestKeywordIndexOf(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IndexOf)
	assert.Equal(t, results, cfg.TestIndexOf)
}

func TestTextEqualIgnoreCase(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestTextEqualIgnoreCase)
	assert.Equal(t, results, cfg.TestEqualIgnoreCase)
}

func TestLengthOfString(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.LengthOfString)
	assert.Equal(t, results, cfg.TestLengthOfString)
}

func TestRegularExpression(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.RegXFormat)
	assert.Equal(t, results, cfg.TestRegularExpression)
}

func TestRegularExpressionInvalid(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.RegXFormatInvalid)
	assert.Equal(t, results, cfg.TestRegularExpressionInvalid)
}

func TestIsEmptyForText(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.IsEmptyForTextConfig)
	assert.Equal(t, (results), cfg.TestIsEmptyForText)

}

func TestKeyNotPresentForIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.KeyNotPresentForIsEmptyConfig)
	assert.Equal(t, (results), cfg.TestIsEmptyForText)

}

func TestValueKeyNotPresentInConfigForIsEmpty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/textKeywordConfig.json")

	results := runTestCase(fileContent, cfg.TestValueKeyNotPresentInConfigForIsEmpty)
	assert.Equal(t, (results), cfg.TestKeyNotPresentInConfigForIsEmpty)

}
