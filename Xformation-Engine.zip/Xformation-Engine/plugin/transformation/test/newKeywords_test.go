package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func Test_genarateUUID_Keyword(t *testing.T) {
	fmt.Println("---------------enterd newKeywords_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.GenerateUUID_Keyword)
	assert.Equal(t, len(results), 32)
}

func Test_concat_Keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Concat_Keyword)
	assert.Equal(t, (results), cfg.Test_concat_Keyword)
}

func Test_split_Keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Split_keyword)
	assert.Equal(t, (results), cfg.Test_split_Keyword)
}

func Test_chunk_Keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Chunk_keyword)
	assert.Equal(t, (results), cfg.Test_chunk_Keyword)
}

func Test_Populate_Keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Populate_Keyword)
	assert.Equal(t, (results), cfg.Test_Populate_Keyword)
}

func Test_sum_keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Sum_keyword)
	assert.Equal(t, (results), cfg.Test_sum_keyword)
}

func Test_sum_keyword_withoutAggregation(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Sum_keyword_Without_Aggregation)
	assert.Equal(t, (results), cfg.Test_Sum_keyword_Without_Aggregation)
}

func Test_count_keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Count_keyword)
	assert.Equal(t, (results), cfg.Test_count_keyword)
}

func Test_min_keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Min_Keyword)
	assert.Equal(t, (results), cfg.Test_Min_Keyword)
}

func Test_max_keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Max_keyword)
	assert.Equal(t, (results), cfg.Test_Max_Keyword)
}

func Test_avg_keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Avg_Keyword)
	assert.Equal(t, (results), cfg.Test_Avg_Keyword)
}

func Test_sum_with_filter_keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Sum_with_filter_keyword)
	assert.Equal(t, (results), cfg.Test_sum_with_filter_keyword)
}

func Test_Iterate_With_fields(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Iterate_With_Fields_Keyword)
	assert.Equal(t, (results), cfg.Test_Iterate_With_fields)
}

func Test_Iterate_With_transform(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Iterate_With_Transform_Keyword)
	assert.Equal(t, (results), cfg.Test_Iterate_With_fields)
}

func Test_Iterate_With_transform_filter(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.IterateWithTransformFilter)
	assert.Equal(t, (results), cfg.Test_Transform_Filter)
}

func Test_Iterate_With_transform_without_array(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Iterate_With_Transform_Keyword_without_arrayName)
	assert.Equal(t, (results), cfg.Test_Transform_without_array)
}

func Test_Text_StatementId(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.TextStatementID)
	assert.Equal(t, (results), cfg.TextStatementId)

}

func Test_Text_NullField(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.TextGetNullValue)
	assert.Equal(t, (results), cfg.TextGet_NullValue)

}

func Test_DateDiff_Keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.DateDiff_Keyword)
	assert.Equal(t, (results), cfg.TestDateDiff_Keyword)

}
func Test_DateDiff_InDays_Keyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.DateDiffInDays)
	assert.Equal(t, (results), cfg.Test_DateDiff_InDays_Keyword)

}

func Test_AllStatementsKeyword(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.TextAllStatementIds)
	assert.Equal(t, (results), cfg.Test_AllStatementsKeyword)
}

func Test_chunk_Keyword_By_string(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Chunk_keyword_By_String)
	assert.Equal(t, (results), cfg.Test_chunk_Keyword)
}

func Test_Exponentiation(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Exponentiation)
	assert.Equal(t, (results), cfg.Test_Exponentiation)
}

func Test_Modulas(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Modulas)
	assert.Equal(t, (results), cfg.Test_Modulas)
}

func Test_split_WithSuffix(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.Split_keyword_With_Suffix)
	assert.Equal(t, (results), cfg.Test_split_WithSuffix)
}

func Test_Environment_Expression_type(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/newKeywordsPayload.json")
	results := runTestCase(fileContent, cfg.EnvironmentVariables)
	assert.Equal(t, (results), cfg.Test_Environment_Expression_type)
}
