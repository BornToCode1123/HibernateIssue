package test

import (
	"fmt"
	par "jocata_transform_plugin/parse"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestSimpleAlgrebraicExpression(t *testing.T) {
	fmt.Println("---------------enterd expression_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/conf4.json")

	result := runTestCase(fileContent, cfg.SimpleExpression)
	assert.Equal(t, (result), cfg.TestSimpleAlgrebraicExpression)

}

func TestNilComparison(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.NilComparison)
	assert.Equal(t, (result), cfg.TestNilComparison)
}

func TestSumOfLocalData(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.PrimitiveExpression)
	assert.Equal(t, (result), cfg.TestSumOfLocalData)
}

func TestDateDiffFunctionFormatMonths(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.DateDifferenceMonths)
	assert.Equal(t, (result), cfg.TestDateDiffFunctionFormatMonths)
}

func TestDateDiffFunctionFormatYears(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.DateDifferenceLocalYears)
	assert.Equal(t, (result), cfg.TestDateDiffFunctionFormatYears)
}

func TestDateDiffFunctionFormatDays(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.DateDifferenceLocalWithDays)
	assert.Equal(t, (result), cfg.TestDateDiffFunctionFormatDays)
}

func TestDateDiffFunctionFormatHours(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.DateDifferenceBetweenHours)
	assert.Equal(t, (result), cfg.TestDateDiffFunctionFormatHours)
}

func TestDateKeywordwithFormatGetMonth(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.DateConfiggetMonth)
	assert.Equal(t, (result), cfg.TestDateKeywordwithFormatGetMonth)
}

func TestDateKeywordwithFormatGetYear(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.DateConfiggetYear)
	assert.Equal(t, (result), cfg.TestDateKeywordwithFormatGetYear)
}

func TestDateKeywordwithFormatGetDay(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")
	result := runTestCase(fileContent, cfg.DateConfiggetDay)
	assert.Equal(t, (result), cfg.TestDateKeywordwithFormatGetDay)
}

//func TestGetDiffCurrentDate(t *testing.T) {
//	InitLogger()

//fileContent := ("./payloads/defaultValues.json")

//result := runTestCase(fileContent, cfg.DateDiffBetweenCurrent)
//fmt.Println(result)
//}

func TestAllExpressions(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.AllExpressions)
	assert.Equal(t, (result), cfg.TestAllExpressions)
}

func TestMultiExpressions(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.MultiExpressions)
	assert.Equal(t, (result), cfg.TestMultiExpressions)

}

func TestCountArrayOfObjects(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.CountingArrayOfObjects)
	assert.Equal(t, (result), cfg.TestCountArrayOfObjects)
}

func TestMandatoryKey(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.MandatoryStatement)
	// assert.Equal(t, (result), cfg.TestMandatoryKey)
	fmt.Println("res :", result)
	// currentDate can't compare....
}

func TestArrayContains(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.ArrayContans)
	assert.Equal(t, (result), cfg.TestArrayContains)
}

// pass but result not fetched
func TestLocalArray(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BLPayLoad.json")

	result := runTestCase(fileContent, cfg.BlConfigFileWithLocal)
	// assert.Equal(t, (result), cfg.TestLocalArray)
	fmt.Println("res :", result)
	// need to handle error's
}

func TestRangeIteration(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RangeIteration.json")

	result := runTestCase(fileContent, cfg.RangeIteration)
	assert.Equal(t, len(result), len(cfg.TestRangeIteration))

}

func TestLocalArraywithMultipleConditions(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/NewApplication.json")

	result := runTestCase(fileContent, cfg.LopalArrayMultipleConditions)
	assert.Equal(t, (result), cfg.TestLocalArraywithMultipleConditions)
}

func TestGetFilterOperator(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/NewApplication.json")

	result := runTestCase(fileContent, cfg.ConditionalConfig)
	assert.Equal(t, (result), cfg.TestGetFilterOperator)
}

func TestLocalRelatedParties(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/NewApplication.json")

	result := runTestCase(fileContent, cfg.RelatedParties2)
	assert.Equal(t, len((result)), len(cfg.TestLocalRelatedParties))
}

func TestStringValuesToInteger(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/NewApplication.json")

	result := runTestCase(fileContent, cfg.IntegerArray)
	assert.Equal(t, (result), cfg.TestStringValuesToInteger)
}

func TestMultipleRules(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/NewApplication.json")

	result := runTestCase(fileContent, cfg.MultipleRuleswithDifferentOperators)
	assert.Equal(t, (result), cfg.TestMultipleRules)
}

func TestConditionalPrimitives(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/NewApplication.json")

	result := runTestCase(fileContent, cfg.SelectedKeys)
	assert.Equal(t, len((result)), len(cfg.TestConditionalPrimitives))
}

func TestConsumerScreen(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Consumer.json")

	result := runTestCase(fileContent, cfg.ConsumerBRE)
	assert.Equal(t, (result), cfg.TestConsumerScreen)
}

func TestSample(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Consumer.json")

	result := runTestCase(fileContent, cfg.TestingLocalConfig)
	assert.Equal(t, (result), cfg.TestSample)
}

func TestDateWithUnix(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	result := runTestCase(fileContent, cfg.DateWithUnix)
	assert.Equal(t, (result), cfg.TestDateWithUnix)
}

func TestRelatedParties(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RelatedParties.json")

	result := runTestCase(fileContent, cfg.TestRelatedParties)
	// assert.Equal(t, (result), cfg.TestRelatedParties)
	fmt.Println("res :", result)
	// need to Handle error's.........
}

func TestErrorConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RelatedParties.json")

	result := runTestCase(fileContent, cfg.ErrorConfig)
	assert.Equal(t, (result), cfg.TestErrorConfig)
}

func TestSampleConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RelatedParties.json")

	result := runTestCase(fileContent, cfg.UsrvasiSampleConfig)
	assert.Equal(t, (result), cfg.TestSampleConfig)
}

func TestDateFormat(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RelatedParties.json")

	result := runTestCase(fileContent, cfg.FormatDateAndTime)
	assert.Equal(t, (result), cfg.TestDateFormat)
}

func TestObjectNull(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RelatedParties.json")

	result := runTestCase(fileContent, cfg.ObjectNullConf)
	assert.Equal(t, (result), cfg.TestObjectNull)
	//fmt.Println("res :", result)
}

func TestToJson(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.TojsonConfig)
	assert.Equal(t, (result), cfg.TestToJson)
}

func TestToJsonGetData(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.TojsonConfigGetdata)
	assert.Equal(t, (result), cfg.TestToJsonGetData)
}

func TestErrors(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/decrypt.json")

	result := runTestCase(fileContent, cfg.ErrorConf)
	// assert.Equal(t, (result), cfg.TestErrors)
	fmt.Println("res :", result)
	//need to Handle error's........
}

func TestSwara(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Swara.json")

	result := runTestCase(fileContent, cfg.SwaraConf)
	assert.Equal(t, (result), cfg.TestSwara)
}

func TestKeywordDateWithInYearsGetInMonths(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Swara.json")

	result := runTestCase(fileContent, cfg.KeywordDateInMonths)
	assert.Equal(t, (result), cfg.TestKeywordDateWithInYearsGetInMonths)
}

func TestKeywordDateWithInMonthsGetInYears(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Swara.json")

	result := runTestCase(fileContent, cfg.KeywordDateInYears)
	assert.Equal(t, (result), cfg.TestKeywordDateWithInMonthsGetInYears)
}

func TestKeywordDateWithInDaysGetInYears(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Swara.json")

	result := runTestCase(fileContent, cfg.KeywordDateInDays)
	assert.Equal(t, (result), cfg.TestKeywordDateWithInDaysGetInYears)
}

func TestSectionalAndConditionalStatements(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Swara.json")

	result := runTestCase(fileContent, cfg.SectionalStatement)
	assert.Equal(t, (result), cfg.TestSectionalAndConditionalStatements)
}

func TestDateFormatNewFormat(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Swara.json")

	result := runTestCase(fileContent, cfg.DateFormatNew)
	assert.Equal(t, (result), cfg.TestDateFormatNewFormat)
}

func TestDateKeywordWithLocal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Swara.json")

	result := runTestCase(fileContent, cfg.KeywordDateInDaysInLOcal)
	assert.Equal(t, (result), cfg.TestDateKeywordWithLocal)
}

func TestNestedConditions(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Swara.json")

	result := runTestCase(fileContent, cfg.NestedConditions)
	assert.Equal(t, (result), cfg.TestNestedConditions)
}

func TestBreScreenConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	result := runTestCase(fileContent, cfg.BankStatementBRE)
	assert.Equal(t, (result), cfg.TestBreScreenConfig)
}

func TestDateKeyWordDefaultDate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")
	result := runTestCase(fileContent, cfg.DateKeywordDefaultValue)
	fmt.Println("res :", result)
}

func TestContentInputAndOutputConf(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/encryptedRequest.json")

	result := runTestCase(fileContent, cfg.ContentInputOutputConf)
	// assert.Equal(t, (result), cfg.TestContentInputAndOutputConf)
	fmt.Println("res :", result)
	// need to Handle error's..
}

func TestLocalArrayIndexVAlues(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerCibil.json")

	result := runTestCase(fileContent, cfg.LocalArrayTestingIndexValues)
	assert.Equal(t, (result), cfg.TestLocalArrayIndexVAlues)
}

func TestLocalArrayIndexVAlue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerCibil.json")

	result := runTestCase(fileContent, cfg.LocalArrayTestingIndexValue)
	assert.Equal(t, (result), cfg.TestLocalArrayIndexVal)
}

func TestRelplaceCharacter(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerCibil.json")

	result := runTestCase(fileContent, cfg.ReplaceAlphabet)
	assert.Equal(t, len((result)), len(cfg.TestRelplaceCharacter))
}

func TestValidateKeys(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ValidateKeys)
	assert.Equal(t, (result), cfg.TestValidateKeys)
}

func TestExceptionHandling(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ExceptionHandling1)
	assert.Equal(t, (result), cfg.TestExceptionHandling)
}

func TestPNBStringToJSon(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.PNBConfiguration)
	assert.Equal(t, (result), cfg.TestPNBStringToJSon)
}

func TestArrMultipleValuesToJson(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ArrStringValuesToJSon)
	assert.Equal(t, (result), cfg.TestArrMultipleValuesToJson)
}

func TestValidation(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ValidateError)
	assert.Equal(t, (result), cfg.TestValidation)
}

func TestValidateArray(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ValidationArray)
	assert.Equal(t, (result), cfg.TestValidateArray)

}

func TestExceptionSingstamentMultipleErrorStatements(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ExceptionHandling)
	assert.Equal(t, (result), cfg.TestExceptionSingstamentMultipleErrorStatements)
	//fmt.Println("res :", result)
}

func TestExceptionBySpecificStatement(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ExceptioBySpecificStatement)
	assert.Equal(t, (result), cfg.TestExceptionBySpecificStatement)
	//fmt.Println("res :", result)
}

func TestSectionalStatementsMandatory(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.SectionalMandatory)
	assert.Equal(t, (result), cfg.TestSectionalStatementsMandatory)
}

func TestExceptionConfigs(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ExceptionConfig)
	assert.Equal(t, (result), cfg.TestExceptionConfigs)
}

func TestExceptionONConditionalStatements(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ExceptiomHandlingCondition)
	assert.Equal(t, (result), cfg.TestExceptionONConditionalStatements)
	// need to HAndle Exceptions....
	//fmt.Println("res :", result)
}

func TestConditionalError(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	result := runTestCase(fileContent, cfg.ExceptionCondition)
	// assert.Equal(t, (result), cfg.TestConditionalError)
	// need to debug...........
	fmt.Println("res :", result)
}

func TestExceptionHanddlingInConditions(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	results := runTestCase(fileContent, cfg.ExceptionHandlingCondition)
	assert.Equal(t, (results), cfg.TestExceptionHanddlingInConditions)
	// need to debug.............
	//fmt.Println("res :", results)
}

func TestExceptionInsidetheStatement(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	results := runTestCase(fileContent, cfg.ExceptionInsideStatement)
	assert.Equal(t, (results), cfg.TestExceptionInsidetheStatement)
}

func TestFilterIterateTransForm(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	results := runTestCase(fileContent, cfg.IterateWithFilter)
	assert.Equal(t, (results), cfg.TestFilterIterateTransForm)
}

func TestFilterIterateFields(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")
	results := runTestCase(fileContent, cfg.IterateFilterFields)
	assert.Equal(t, (results), cfg.TestFilterIterateFields)
}

func TestFilterIterateFieldsLocal(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/facilityWiseExposureSummary.json")
	results := runTestCase(fileContent, cfg.IterateFilterFieldsLocal)
	assert.Equal(t, (results), cfg.TestFilterIterateFields)
}

func TestCountFilter(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/facilityWiseExposureSummary.json")
	results := runTestCase(fileContent, cfg.CountWithFilter)
	assert.Equal(t, (results), cfg.TestCountFilter)
}

func TestExceptionErrrorMessage(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	results := runTestCase(fileContent, cfg.TestingErrorMessage)
	assert.Equal(t, (results), cfg.TestExceptionErrrorMessage)
}

func TestIsNull(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	results := runTestCase(fileContent, cfg.ISnullWithErrorConfig)
	assert.Equal(t, (results), cfg.TestIsNull)
}

func TestIterate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	results := runTestCase(fileContent, cfg.IterateConfig)
	assert.Equal(t, (results), cfg.TestIterate)
}

func TestFilterIterateTransFormLOcal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/facilityWiseExposureSummary.json")

	results := runTestCase(fileContent, cfg.IterateTransformLocal)
	assert.Equal(t, (results), cfg.TestFilterIterateTransFormLOcal)

}

func TestSwaraArrWithLocal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/swaraArr.json")
	results := runTestCase(fileContent, cfg.Swara)
	assert.Equal(t, (results), cfg.TestSwaraArrWithLocal)
}

func TestBreakIterate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/swaraArr.json")
	results := runTestCase(fileContent, cfg.BreakIterate)
	assert.Equal(t, (results), cfg.TestBreakIterate)
}

func TestBreakIterateWithPAyload(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/swaraArr.json")
	results := runTestCase(fileContent, cfg.BreakIterateWithPayload)
	assert.Equal(t, (results), cfg.TestBreakIterateWithPAyload)
}

func TestToJsonError(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/swaraArr.json")
	results := runTestCase(fileContent, cfg.ToJsonError)
	assert.Equal(t, (results), cfg.TestToJsonError)
}

func TestConsumerExceptionHandling(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.ConsumerConfigException)
	assert.Equal(t, (results), cfg.TestConsumerExceptionHandling)
}

func TestElseStatements(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.Elsestatements)
	assert.Equal(t, (results), cfg.TestElseStatements)
}

func TestErrorData(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.ErrorData)
	assert.Equal(t, (results), cfg.TestErrorData)
}

func TestKeywordErrorData(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.KeywordErrorData)
	assert.Equal(t, (results), cfg.TestErrorData2)
}

func TestMultipleCalls(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/multipleCalls.json")
	results := runTestCase(fileContent, cfg.MultipleCalls)
	assert.Equal(t, (results), cfg.TestMultipleCalls)
}

func TestInbuiltStatements(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/multipleCalls.json")
	results := runTestCase(fileContent, cfg.InbuiltStatements)
	assert.Equal(t, (results), cfg.TestInbuiltStatements)
}

func TestIgnoreProperties(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/multipleCalls.json")
	results := runTestCase(fileContent, cfg.IgnoreProperties)
	assert.Equal(t, (results), cfg.TestIgnoreProperties)
}

func TestConditionalStatementJsonIgnoreProperty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/multipleCalls.json")
	results := runTestCase(fileContent, cfg.ConditionalStatementJsonIgnoreProperty)
	assert.Equal(t, (results), cfg.TestConditionalStatementJsonIgnoreProperty)
}

func TestTransFormError(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf2.json")
	results := runTestCase(fileContent, cfg.TestTransFormError)
	assert.Equal(t, (results), cfg.TransformErrors)
}

func TestSkipNullValuesfrompayload(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/omittNull.json")
	results := runTestCase(fileContent, cfg.TestOmittNull)
	assert.Equal(t, (results), cfg.TestSkipNullValuesfrompayload)
}

func TestReplaceNullWith(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/omittNull.json")
	results := runTestCase(fileContent, cfg.ReplaceNullWithChar)
	assert.Equal(t, (results), cfg.TestReplaceNullWith)
}

func TestPaayloadNullValues(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.ArrConfiguration)
	assert.Equal(t, (results), cfg.TestPaayloadNullValues)
}

func TestPLUserExpression(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/PLUserException.json")
	results := runTestCase(fileContent, cfg.PLUserException)
	modified := []byte(results)
	if par.IsthisUserException(nil, "json", modified) {
		assert.Equal(t, (results), cfg.TestPLUserExpression)
	} else {
		assert.Equal(t, (results), cfg.TestPaayloadNullValues)
	}
}

func TestJsonIgnorePropertyBasedOnDataTypes(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.JsonIgnorePropertyBasedOnDataTYpes)
	assert.Equal(t, (results), cfg.TestJsonIgnorePropertyBasedOnDataTypes)
}

func TestJsonIgnorePropertyPopulate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.JsonIgnorePropertyPopulate)
	assert.Equal(t, (results), cfg.TestJsonIgnorePropertyPopulate)
}
func TestNewDateFormatter(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/WIO.json")
	results := runTestCase(fileContent, cfg.TestNewDateFormat)
	assert.Equal(t, (results), cfg.TestNewDateFormatter)
}
func TestConfigurationStrctureChanges(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/PLElseStatement.json")
	results := runTestCase(fileContent, cfg.VersionedConfigFile)
	assert.Equal(t, (results), cfg.VersionedConfig)
}

func TestHeaderKeyValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/WIO.json")
	results := runTestCase(fileContent, cfg.HeadersForKeyValue)
	assert.Equal(t, (results), cfg.TokenHeaders)
}

func TestMapKeywordLength(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/json.json")
	results := runTestCase(fileContent, cfg.MapLengtCondition)
	assert.Equal(t, (results), cfg.MapKeywordLength)
}

// func TestNewVersion(t *testing.T) {
// 	InitLogger()

// 	fileContent := ("./payloads/json.json")
// 	results := runTestCase(fileContent, cfg.NewVersion)
// 	assert.Equal(t, (results), cfg.NeVersion)
// }

func TestOverrideTheMap(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/json.json")
	results := runTestCase(fileContent, cfg.OverrideMap)
	assert.Equal(t, (results), cfg.Override)
}

func TestNewRequrement(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Requirement.json")
	results := runTestCase(fileContent, cfg.GetValuesArray)
	fmt.Println("res", results)

}

func TestFlatJson(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/flatJsonTMB.json")
	results := runTestCase(fileContent, cfg.TestFlatJson)
	assert.Equal(t, len(results), 2989)
}

func TestSectionIsTransForm(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/flatJsonTMB.json")
	results := runTestCase(fileContent, cfg.SectionIsTransform)
	assert.Equal(t, results, cfg.SectionIsATransformStatements)
}

func TestStatementId(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/flatJsonTMB.json")
	results := runTestCase(fileContent, cfg.StatementIdExample)
	assert.Equal(t, results, cfg.StatemetId)
}

func TestArithemticExpressionWithTextelement(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ConvertingJsonToText.json")
	results := runTestCase(fileContent, cfg.ConvertJsontoText)
	assert.Equal(t, results, cfg.AithmeticFunctionWithTextField)
}

func TestJsonIgnorePropertyHandlingLocal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ConvertingJsonToText.json")
	results := runTestCase(fileContent, cfg.SupportingJsonIgnorePropertyInLocal)
	assert.Equal(t, results, cfg.TestJsonIgnorePropertyHandlingLocal)
}

func TestConditionalRuleTextValueInNumeric(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ConvertingJsonToText.json")
	results := runTestCase(fileContent, cfg.ConditionTestingTestingTextValAsNUmeric)
	assert.Equal(t, results, cfg.TestConditionalRuleTextValueInNumeric)
}

func TestLocalNumericInteger(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.TestLocalNUmericValue)
	assert.Equal(t, results, cfg.TestLOcalNumericInteger)
}

func TestLocalList(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.TestLocalArrayIndexOf)
	assert.Equal(t, results, cfg.TestLocalList)
}

func TestApendLocalArray(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/ARRPayload.json")
	results := runTestCase(fileContent, cfg.Iterate_AppendingArrays)
	assert.Equal(t, results, cfg.TestApendLocalArray)
}

func TestGettingIssueWithLocal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.GettingIssueWithlocal)
	assert.Equal(t, results, cfg.TestGettingIssueWithLocal)
}

func TestAnyDataType(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.AnyDataType)
	assert.Equal(t, results, cfg.TestAnyDataType)
}

func TestReferenceCheck(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.TestReferenceNUllCheck)
	assert.Equal(t, results, cfg.TestReferenceCheck)
}

func TestRemovingDuplicateCharacters(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.TestCreatingSubStringWithoutDuplicateCharacter)
	assert.Equal(t, results, cfg.TestRemovingDuplicateCharacters)
}

func TestTestingConditionAtFalseCase(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.TestingConditionAtFalseCase)
	assert.Equal(t, results, cfg.TestTestingConditionAtFalseCase)

}

func TestConditionJsonIgnoreProperty(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.TestingConditionJsonIgnoreProperty)
	assert.Equal(t, results, cfg.TestConditionJsonIgnoreProperty)
}

func TestLocalVariableIndexing(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.TestLocalIndexValue)
	assert.Equal(t, results, cfg.TestLocalVariableIndexing)
}

func TestArithmeticWithStringValue(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/consumerPayload.json")
	results := runTestCase(fileContent, cfg.TestArithmeticWithStringValueConfig)
	assert.Equal(t, results, cfg.TestArithmeticWithStringValueOutput)
}
