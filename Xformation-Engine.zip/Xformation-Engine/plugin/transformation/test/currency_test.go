package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestCurrencyInINR(t *testing.T) {
	fmt.Println("---------------enterd currency_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/currencyPayload.json")

	result := runTestCase(fileContent, cfg.CurrencyFormatTestingInINR)

	assert.Equal(t, (result), cfg.TestCurrencyInINR)
}

func TestCurrencyINRConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.CurrencyINRConfig)
	assert.Equal(t, (results), cfg.TestCurrencyINRConfigTesting)
}

func TestCurrencyINRTextConfigTesting(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.CurrencyINRTextConfig)
	assert.Equal(t, (results), cfg.TestCurrencyINRTextConfigTesting)
}

func TestCurrencyConfLOcalNUmberToUsd1Testing(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.CurrencyConfLOcalNUmberToUsd1)
	assert.Equal(t, (results), cfg.TestCurrencyConfLOcalNUmberToUsd1Testing)
}

func TestCurrencyConfLOcalZeroNUmberToUsd1Testing(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.CurrencyConfLOcalZeroNUmberToUsd1)
	assert.Equal(t, (results), cfg.TestCurrencyConfLOcalZeroNUmberToUsd1Testing)
}

func TestCurrencyConfLOcalWithNull1Testing(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/Functions.json")

	results := runTestCase(fileContent, cfg.CurrencyConfLOcalWithNull1)
	assert.Equal(t, (results), cfg.TestCurrencyConfLOcalWithNull1Testing)
}
