package test

import (
	"fmt"
	"testing"

	cfg "jocata_transform_plugin/test/configs"

	"github.com/magiconair/properties/assert"
)

func TestPopulateKeyValuesinTheSameObject(t *testing.T) {
	fmt.Println("---------------enterd khazaam_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/conf8.json")

	results := runTestCase(fileContent, cfg.TransConfig8)
	assert.Equal(t, (results), cfg.TestPopulateKeyValuesinTheSameObject)
}

func TestSimpleAggregations(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf1.json")

	results := runTestCase(fileContent, cfg.TransConfig1)
	assert.Equal(t, (results), cfg.TestSimpleAggregations)
}

func TestPrimitives(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/confPrimitives.json")

	results := runTestCase(fileContent, cfg.TransConfig11)
	assert.Equal(t, len(results), len(cfg.TestPrimitives))
}

func TestSplit(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/confSplit.json")

	results := runTestCase(fileContent, cfg.SplitAndUseLocal)
	assert.Equal(t, (results), cfg.TestSplit)
}

func TestDefaultValues(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	results := runTestCase(fileContent, cfg.DefaultValues)
	assert.Equal(t, (results), cfg.TestDefaultValues)
}

func TestLocalTransformation(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf9.json")

	results := runTestCase(fileContent, cfg.Localtransform)
	assert.Equal(t, (results), cfg.TestLocalTransformation)
}

func TestDateFilterWithLocal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/conf5.json")

	results := runTestCase(fileContent, cfg.DateFilter)
	assert.Equal(t, (results), cfg.TestDateFilterWithLocal)
}

func TestDateConfig(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/defaultValues.json")

	results := runTestCase(fileContent, cfg.DateConfig)
	assert.Equal(t, len((results)), len(cfg.TestDateConfig))
}

func TestRelatedPartiesScreen(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RelatedParties.json")

	results := runTestCase(fileContent, cfg.TestRelatedParties)
	assert.Equal(t, len(results), len(cfg.TestRelatedPartiesScreen))
}
