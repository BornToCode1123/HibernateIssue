package test

import (
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func Test_RestCallJsonSchemaWithInValidData2(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RestCallJsonSchemaPaylaod.json")

	results := runTestCase(fileContent, cfg.SchemaConfig)
	assert.Equal(t, (results), (cfg.Test_RestCallInvalid2))
}

func Test_RestCallJsonSchemaWithValidData2(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RestCallJsonSchemaPaylaod.json")

	results := runTestCase(fileContent, cfg.SchemaConfig2)
	assert.Equal(t, (results), (cfg.Test_RestCallValid2))
}

func Test_RestCallJsonSchemaWithNoJsonKey2(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/RestCallJsonSchemaPaylaod.json")

	results := runTestCase(fileContent, cfg.SchemaConfig3)
	assert.Equal(t, (results), (cfg.Test_RestCallNoJsonSchemaKey2))
}
