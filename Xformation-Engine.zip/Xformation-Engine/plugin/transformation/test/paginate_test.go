package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestPaginationTesting(t *testing.T) {
	fmt.Println("---------------enterd paginate_test.go--------------------")
	InitLogger()
	fileContent := ("./payloads/paginate.json")
	results := runTestCase(fileContent, cfg.PaginationConfig)
	assert.Equal(t, (results), cfg.TestPagination)
}

func TestPaginateNegativeSize(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/paginate1.json")
	results := runTestCase(fileContent, cfg.PaginationConfig)
	assert.Equal(t, (results), cfg.TestPaginateNegativeSize)
}

func TestPaginateNegativePageNo(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/paginate2.json")
	results := runTestCase(fileContent, cfg.PaginationConfig)
	assert.Equal(t, (results), cfg.TestPaginateNegativePageNo)
}

func TestPaginateIncorrectArrayName(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/paginate.json")
	results := runTestCase(fileContent, cfg.PaginateIncorrectArrayName)
	assert.Equal(t, (results), cfg.TestPaginateIncorrectArrayName)
}

func TestPaginateLastPage(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/paginate3.json")
	results := runTestCase(fileContent, cfg.PaginationConfig)
	assert.Equal(t, (results), cfg.TestPaginateLastPage)
}

func TestPaginateIncorrectPageNo(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/paginate4.json")
	results := runTestCase(fileContent, cfg.PaginationConfig)
	assert.Equal(t, (results), cfg.TestPaginateIncorrectPageNo)
}

func TestPaginateMissingPageNoAndSizeKeys(t *testing.T) {
	InitLogger()
	fileContent := ("./payloads/paginate5.json")
	results := runTestCase(fileContent, cfg.PaginationConfig)
	assert.Equal(t, (results), cfg.TestPaginateMissingPageNoAndSizeKeys)
}
