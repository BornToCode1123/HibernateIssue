package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func Test_LogStatementForInfoLevel(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/LogStatementPayload.json")

	results := runTestCase(fileContent, cfg.LogStatementInfoLevelConfig)
	fmt.Println(results)
}

func Test_LogStatementForDebugLevel(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/LogStatementPayload.json")

	results := runTestCase(fileContent, cfg.LogStatementDebugLevelConfig)
	fmt.Println(results)
}

func Test_LogStatementForTraceLevel(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/LogStatementPayload.json")

	results := runTestCase(fileContent, cfg.LogStatementTraceLevelConfig)
	fmt.Println(results)
}

func Test_LogStatementForErrorLevel(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/LogStatementPayload.json")

	results := runTestCase(fileContent, cfg.LogStatementErrorLevelConfig)
	fmt.Println(results)
}

func Test_LogStatementForOtherLevel(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/LogStatementPayload.json")

	results := runTestCase(fileContent, cfg.LogStatementForOtherLevelConfig)
	fmt.Println(results)
	assert.Equal(t, (results), (cfg.Test_LogStatementForOtherLevel))
}

func Test_LogStatementWithInvalidData(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/LogStatementPayload.json")

	results := runTestCase(fileContent, cfg.LogStatementWithInvalidDataConfig)
	fmt.Println(results)
	assert.Equal(t, (results), (cfg.Test_LogStatementForInvalidData))
}
