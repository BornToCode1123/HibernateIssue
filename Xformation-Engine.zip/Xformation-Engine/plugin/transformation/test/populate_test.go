package test

import (
	"fmt"
	cfg "jocata_transform_plugin/test/configs"
	"testing"

	"github.com/magiconair/properties/assert"
)

func TestPopulateSample(t *testing.T) {
	fmt.Println("---------------enterd populate_test.go--------------------")
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	results := runTestCase(fileContent, cfg.PopulateSample)
	assert.Equal(t, (results), cfg.TestPopulateSample)
}

func TestPopulateLocal(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	results := runTestCase(fileContent, cfg.PopulateLocal)
	assert.Equal(t, (results), cfg.TestPopulateLocal)
}

func TestPopulateLocalAndData(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	results := runTestCase(fileContent, cfg.PopulateLocalandData)
	assert.Equal(t, (results), cfg.TestPopulateLocalAndData)
}

func TestPopulatewithEmptyFields(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	results := runTestCase(fileContent, cfg.PopulateEmptyFields)
	assert.Equal(t, (results), cfg.TestPopulatewithEmptyFields)
}

func TestMultpilePopulate(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")
	results := runTestCase(fileContent, cfg.MultiplePopulate)
	assert.Equal(t, (results), cfg.TestMultpilePopulate)
}

func TestPopulateArrayandObjects(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	results := runTestCase(fileContent, cfg.ObjectMapWithArray)
	assert.Equal(t, (results), cfg.TestPopulateArrayandObjects)
}

func TestAppendObjects(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	results := runTestCase(fileContent, cfg.AppendObjects)
	assert.Equal(t, (results), cfg.TestAppendObjects)
}

func TestOverrideObjects(t *testing.T) {
	InitLogger()

	fileContent := ("./payloads/BankStatement.json")

	results := runTestCase(fileContent, cfg.AppendObjects)
	assert.Equal(t, (results), cfg.TestOverrideObjects)
}
