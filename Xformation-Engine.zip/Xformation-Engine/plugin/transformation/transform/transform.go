package transform

import (
	"encoding/json"
	"fmt"

	c "jocata_transform_plugin/constants"
	exp "jocata_transform_plugin/expression"
	fun "jocata_transform_plugin/functions"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"

	"github.com/thedevsaddam/gojsonq/v2"
)

func ProcessConfig(config rs.Config, data rs.JSONQData) rs.TransformResult {
	transformConfig := config.HolderConfig.(rs.Transform)
	var statementDetails = rs.StatementDetails{
		TransformType: c.TRANSFORM,
		ConfigType:    c.TRANSFORM,
	}

	if config.Errors.Statements != nil {
		data.ErrorConfig = config.Errors
	}
	if config.Debug {
		logger.Log.Debug(data.LocalData, "Xformation running in Debug mode")
	}

	cr := ProcessTransformConfig(transformConfig, data, statementDetails)
	if config.Debug && cr.Errors == nil {
		return rs.TransformResult{Result: cr.Results["transformed"], Errors: *data.ErrorData}
	}
	if cr.Errors != nil {
		if cr.Errors[0].Code == "1111" {
			return rs.TransformResult{Result: cr.Results["transformed"], Errors: nil}
		}
	}
	return rs.TransformResult{Result: cr.Results["transformed"], Errors: cr.Errors, Mandatory: true}
}

func ProcessTransformConfig(config rs.Transform, data rs.JSONQData, statementDetails rs.StatementDetails) rs.ConfigResult {
	var res = utils.MakeResultMap()
	configStatements := config.Statements
	cs := processTransform(configStatements, data, res, statementDetails)
	return rs.ConfigResult{Results: cs.Results, Errors: cs.Errors}
}

func processTransform(configStatements []rs.Statement, data rs.JSONQData, res map[string]map[string]interface{}, statementDetails rs.StatementDetails) rs.ConfigResult {
	transFormErrors := processStatements(configStatements, data, res, statementDetails)
	return rs.ConfigResult{Results: res, Errors: transFormErrors}
}

func processStatements(configStatements []rs.Statement, data rs.JSONQData, res map[string]map[string]interface{}, statementDetails rs.StatementDetails) []rs.TransformError {

	var transFormErrors []rs.TransformError
	for _, configStatement := range configStatements {
		sr := processStatement(configStatement, data, res, statementDetails)

		if statementDetails.TransformType == "transform" {

			if sr.TransFormError.Message != "" {
				if sr.TransFormError.Code == "1111" && len(sr.StatementResults) > 0 {
					udateMapWithExceptionResult(res, sr.StatementResults[0])
					transFormErrors = append(transFormErrors, sr.TransFormError)
					return transFormErrors
				}
				transFormErrors = append(transFormErrors, sr.TransFormError)
				break
			} else {
				makeConfigResult(sr, data, res)
			}
			if configStatement.EType == "ErrorStatement" {
				tErr := utils.PopulateTransFormError("1111", "Error Statement executed")
				transFormErrors = append(transFormErrors, tErr)
				break
			}

		} else {
			if sr.TransFormError.Detailedmessage != nil {
				if sr.TransFormError.Code == "1111" {
					makeConfigResult(sr, data, res)
					*data.IsExceptionHandled = true
					transFormErrors = append(transFormErrors, sr.TransFormError)
					if isSpecificStatement(configStatement, data) {
						break
					}
					makeConfigResult(sr, data, res)
				}
			} else if sr.StatementResults != nil {
				*data.IsExceptionHandled = true
				makeConfigResult(sr, data, res)
				if isSpecificStatement(configStatement, data) {
					break
				}
			}
		}
	}
	return transFormErrors
}

func udateMapWithExceptionResult(res map[string]map[string]interface{}, sr rs.StatementResult) {
	userException, ok := sr.Rhs.Evalue.([]interface{})
	if ok {
		res["transformed"] = userException[0].(map[string]interface{})
	} else {
		res["transformed"] = sr.Rhs.Evalue.(map[string]interface{})
	}
}

func makeConfigResult(sr rs.StatementsResult, data rs.JSONQData, res map[string]map[string]interface{}) {

	for _, sr := range sr.StatementResults {
		if (sr != rs.StatementResult{}) {
			if sr.Lhs.EType == "declare" {
				utils.PushToMap(data.LocalData, sr.Lhs.Evalue.(string), sr.Rhs.Evalue, sr.Rhs.Vtype)
			} else {
				if sr.Rhs.Vtype == "map" && sr.Rhs.Evalue != nil {
					resultmap := sr.Rhs.Evalue.(map[string]interface{})
					for k, v := range resultmap {
						if sr.Lhs.Evalue == "{}" {
							newlhs := k
							utils.PushToMap(res["transformed"], newlhs, v, sr.Rhs.Vtype)
						} else {
							newlhs := sr.Lhs.Evalue.(string) + c.OBJECT_SEPARATOR + k
							utils.PushToMap(res["transformed"], newlhs, v, sr.Rhs.Vtype)
						}
					}
					if len(resultmap) == 0 {
						utils.PushToMap(res["transformed"], sr.Lhs.Evalue.(string), sr.Rhs.Evalue, sr.Rhs.Vtype)
					}
				} else if sr.Lhs.Vtype == "list" {
					if res["transformed"][sr.Lhs.Evalue.(string)] != nil {
						destarr := sr.Rhs.Evalue.([]interface{})
						utils.PushToMap(res["transformed"], sr.Lhs.Evalue.(string), destarr, sr.Rhs.Vtype)
					} else {
						utils.PushToMap(res["transformed"], sr.Lhs.Evalue.(string), sr.Rhs.Evalue, sr.Rhs.Vtype)
					}
				} else {
					utils.PushToMap(res["transformed"], sr.Lhs.Evalue.(string), sr.Rhs.Evalue, sr.Rhs.Vtype)
				}
			}
		}
	}
}

func processStatement(s rs.Statement, data rs.JSONQData, res map[string]map[string]interface{}, statementDetails rs.StatementDetails) rs.StatementsResult {
	statementType := s.EType
	mandatory := s.Mandatory
	var mandatoryFlag = true
	var smtn []rs.StatementResult
	var sr rs.StatementResult
	var srs rs.StatementsResult
	var tErr rs.TransformError
	var r bool

	if mandatory != nil {
		mandatoryFlag = mandatory.(bool)
	}

	statementDetails.StatementPath = statementDetails.StatementPath + " -> " + s.Name
	logger.Log.Trace(data.LocalData, `Executing statement type: "%v" and it's name is : "%v"`, statementType, s.Name)

	switch statementType {
	case c.ASSIGNMENT_STATEMENT:
		assignStatemnt := s.Assignment
		sr, tErr = processAssignmentStatement(assignStatemnt, data, statementDetails.StatementPath)

	case c.CONDITIONAL_STATEMENT:
		configElseStatements := s.Failure.Statements
		conditionalStatemnt := s.Condition
		r, tErr = exp.ProcessCondition(conditionalStatemnt, data, ProcessInnerTransform, statementDetails.StatementPath)

		if r && tErr.Detailedmessage == nil {
			logger.Log.Trace(data.LocalData, "Condition is true, Executing if statements")

			successTransform := rs.Transform{Statements: s.Success.Statements, Id: s.Success.Id, JsonIgnoreProperty: s.Success.JsonIgnoreProperty, JsonIgnoreAliasValue: s.Success.JsonIgnoreAliasValue}
			statementDetails.TransformType = c.TRANSFORM
			statementDetails.StatementPath = s.Success.Name
			sRes := TransformStatements(successTransform, data, statementDetails)
			if sRes.TransFormError.Detailedmessage != nil || sRes.StatementResults != nil {
				return sRes
			}

		} else if !r && tErr.Detailedmessage == nil && configElseStatements != nil {

			logger.Log.Trace(data.LocalData, "Condition is false, Executing else statements")
			failureTransform := rs.Transform{Statements: s.Failure.Statements, Id: s.Failure.Id, JsonIgnoreProperty: s.Failure.JsonIgnoreProperty, JsonIgnoreAliasValue: s.Failure.JsonIgnoreAliasValue}
			statementDetails.TransformType = c.TRANSFORM
			statementDetails.StatementPath = s.Failure.Name
			return TransformStatements(failureTransform, data, statementDetails)

		} else if !r && tErr.Detailedmessage == nil {
			return rs.StatementsResult{}
		}

	case c.SECTIONAL_STATEMENT:
		sectionTransform := rs.Transform{Statements: s.Section.Statements, Id: s.Section.Id, JsonIgnoreProperty: s.Section.JsonIgnoreProperty, JsonIgnoreAliasValue: s.Section.JsonIgnoreAliasValue}
		return TransformStatements(sectionTransform, data, statementDetails)

	case c.EEROR_STATEMENT:
		var newMap = make(map[string]interface{})
		res["transformed"] = newMap

		ErrorStatement := rs.Transform{Statements: s.Error.Statements, Id: s.Error.Id, JsonIgnoreProperty: s.Error.JsonIgnoreProperty, JsonIgnoreAliasValue: s.Error.JsonIgnoreAliasValue}
		statementDetails.TransformType = c.TRANSFORM
		return TransformStatements(ErrorStatement, data, statementDetails)

	case c.LOG_STATEMENT:
		logStatement := s.Log
		sr, tErr = processLogStatement(logStatement, data)

	case c.FORK_STATEMENT:
		res := fun.ProcessForkStatement(s.Fork, data, statementDetails, TransformStatements)
		return res
	default:
		errMessage := fmt.Sprintf("Unknown  statement type , %v .!", statementType)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return rs.StatementsResult{TransFormError: tErr}
	}

	if tErr.Detailedmessage != nil && mandatoryFlag {
		if !isIterate(s.Assignment.Rhs) {
			logger.Log.Trace(data.LocalData, `Statement path : "%v"`, statementDetails.StatementPath)
		}

		if tErr.Code == "1111" {
			var newMap = make(map[string]interface{})
			res["transformed"] = newMap
			sr.Lhs.Evalue, sr.Rhs.Vtype, sr.Lhs.Vtype = "{}", "map", "map"
			smtn = append(smtn, sr)
			return rs.StatementsResult{
				StatementResults: smtn,
				TransFormError:   tErr,
			}
		}

		tErr.Detailedmessage = fmt.Sprintf("At statement %v %v", s.Name, tErr.Detailedmessage)
		var isExceptionHandled bool
		utils.PopulateErrorData(s.Id, s.Name, tErr, data.LocalData)

		if statementDetails.TransformType == c.ERRORS || statementDetails.ConfigType == c.ERRORS {
			smtn = append(smtn, sr)
			return rs.StatementsResult{StatementResults: smtn, TransFormError: tErr}
		}

		srs, isExceptionHandled = transformErrorStatements(data, statementDetails)

		if isExceptionHandled || srs.TransFormError.Detailedmessage != nil {
			logger.Log.Trace(data.LocalData, "Configuration exception handled")
			*data.IsExceptionHandled = false
			return rs.StatementsResult{StatementResults: srs.StatementResults, TransFormError: srs.TransFormError}
		} else {
			smtn = append(smtn, sr)
			return rs.StatementsResult{StatementResults: smtn, TransFormError: tErr}
		}
	} else if tErr.Detailedmessage != nil && !mandatoryFlag {
		tErr.Detailedmessage = fmt.Sprintf("At statement %v %v", s.Name, tErr.Detailedmessage)
		*data.ErrorData = append(*data.ErrorData, tErr)
		return rs.StatementsResult{}
	}

	smtn = append(smtn, sr)
	return rs.StatementsResult{StatementResults: smtn}
}

func isSpecificStatement(obj rs.Statement, data rs.JSONQData) bool {
	var isSpecific bool
	condition := obj.Condition
	rules := condition.Rules

	for _, rule := range rules {
		operator := rule.RuleHolder.(rs.RelationalRule).Operator
		if operator.ActualValue == "contains" {
			lhs := rule.RuleHolder.(rs.RelationalRule).Lhs
			evalLhs, _ := exp.ProcessExpression(lhs, data, ProcessInnerTransform, "")
			if multiselectArray, ok := evalLhs.Evalue.([]interface{}); ok {
				if len(multiselectArray) == 1 {
					isSpecific = true
					break
				}
			}
		}
	}
	return isSpecific
}

func processAssignmentStatement(as rs.Assignment, data rs.JSONQData, statementPath string) (rs.StatementResult, rs.TransformError) {

	evalLhs, lhserr := exp.ProcessExpression(as.Lhs, data, ProcessInnerTransform, statementPath)
	evalRhs, rhserr := exp.ProcessExpression(as.Rhs, data, ProcessInnerTransform, statementPath)

	var message string
	var tErr rs.TransformError

	if lhserr.Detailedmessage != nil {
		tErr = lhserr
		errMessage := fmt.Sprintf("On LHS , %v .!", lhserr.Detailedmessage)
		message = message + errMessage
	}

	if rhserr.Detailedmessage != nil {
		tErr = rhserr
		errMessage := fmt.Sprintf("On RHS , %v .!", rhserr.Detailedmessage)
		message = message + errMessage
	}

	if len(message) > 0 {
		logger.Log.Debug(data.LocalData, message)
		tErr.Detailedmessage = message
		return rs.StatementResult{Lhs: evalLhs, Rhs: evalRhs}, tErr
	} else {
		return rs.StatementResult{Lhs: evalLhs, Rhs: evalRhs}, rs.TransformError{}
	}
}

func processLogStatement(log rs.Log, data rs.JSONQData) (rs.StatementResult, rs.TransformError) {

	var messages = log.Messages
	var level = log.Level
	var logMessage string

	for _, message := range messages {
		logResult, tErr := exp.ProcessExpression(message, data, ProcessInnerTransform, "")
		if tErr.Detailedmessage != nil {
			return rs.StatementResult{}, tErr
		}
		if resultMap, ok := logResult.Evalue.(map[string]interface{}); ok {
			jsonString, err := json.Marshal(resultMap)
			if err != nil {
				tErr := utils.PopulateTransFormError("1003", "Failed to convert map to JSON string")
				return rs.StatementResult{}, tErr
			}
			logMessage = addToLogMessage(logMessage, string(jsonString))
		} else {
			logMessage = addToLogMessage(logMessage, fmt.Sprintf("%v", logResult.Evalue))
		}
	}
	switch level {
	case "INFO":
		logger.Log.Info(data.LocalData, logMessage)
	case "DEBUG":
		logger.Log.Debug(data.LocalData, logMessage)
	case "TRACE":
		logger.Log.Trace(data.LocalData, logMessage)
	case "ERROR":
		logger.Log.Error(data.LocalData, logMessage)
	default:
		tErr := utils.PopulateTransFormError("1002", "The log mode you are trying to use is not implemented")
		return rs.StatementResult{}, tErr
	}

	return rs.StatementResult{}, rs.TransformError{}
}

func addToLogMessage(currentMessage, newMessage string) string {
	if newMessage == "" {
		return currentMessage
	}
	if currentMessage == "" {
		return newMessage
	}
	return currentMessage + ", " + newMessage
}

func transformErrorStatements(data rs.JSONQData, statementDetails rs.StatementDetails) (rs.StatementsResult, bool) {

	var srs rs.StatementsResult
	statementDetails.ConfigType = c.ERRORS

	if data.ErrorConfig.Statements != nil {
		ErrorsStatements := rs.Transform{Statements: data.ErrorConfig.Statements, Id: data.ErrorConfig.Id, JsonIgnoreProperty: data.ErrorConfig.JsonIgnoreProperty, JsonIgnoreAliasValue: data.ErrorConfig.JsonIgnoreAliasValue}
		statementDetails.TransformType = c.ERRORS
		srs := TransformStatements(ErrorsStatements, data, statementDetails)
		if *data.IsExceptionHandled {
			return srs, true
		}
	}
	return srs, false
}

func ProcessInnerTransform(transConfig rs.Transform, data rs.JSONQData, arr *[]interface{}, statementDetails rs.StatementDetails) rs.TransformError {
	cr := ProcessTransformConfig(transConfig, data, statementDetails)
	if len(cr.Errors) > 0 {
		if cr.Errors[0].Code == "1111" {
			var array []interface{}
			*arr = array
			*arr = append(*arr, cr.Results["transformed"])
			return cr.Errors[0]
		}
		// cr.Errors[0].Detailedmessage = fmt.Sprintf("No of Errors in iterate Function are %v, they are %v", len(cr.Errors), cr.Errors[0].Detailedmessage)
		return cr.Errors[0]
	}
	if len(cr.Results["transformed"]) != 0 {
		*arr = append(*arr, cr.Results["transformed"])
	}
	return rs.TransformError{}
}

func TransformStatements(s rs.Transform, data rs.JSONQData, statementDetails rs.StatementDetails) (sr rs.StatementsResult) {
	defer func() {
		if err := recover(); err != nil {
			errMessage := fmt.Sprint("techincal error occured : ", err)
			tErr := utils.PopulateTransFormError("1001", errMessage)
			sr.TransFormError = tErr
			logger.Log.Error(data.LocalData, "panic recovered %v", errMessage)
			utils.PrintStackTrace(data.LocalData)
			logger.Log.Error(data.LocalData, "stack trace ended")
			return
		}
	}()

	var arr []interface{}
	var smtn []rs.StatementResult
	jsonProperty, jsonIgnoreAliasValue, parseErr := utils.JsonIgnorePropAssign(data.LocalData, s)
	if parseErr != nil {
		detailedmessage := "could not parse jsonIgnoreProperty value in transform"
		logger.Log.Error(data.LocalData, detailedmessage)
		tErr := utils.PopulateTransFormError("1009", detailedmessage)
		return rs.StatementsResult{TransFormError: tErr}
	}

	data = rs.JSONQData{Jqdata: data.Jqdata, ShouldReset: true, LocalData: data.LocalData, TransformedData: data.TransformedData, ErrorConfig: data.ErrorConfig, JsonIgnoreProperty: jsonProperty, ErrorData: data.ErrorData, JsonIgnoreAliasValue: jsonIgnoreAliasValue, IsExceptionHandled: data.IsExceptionHandled}

	tErrs := ProcessInnerTransform(s, data, &arr, statementDetails)
	if len(tErrs.Message) != 0 && tErrs.Code != "1111" {
		return rs.StatementsResult{
			TransFormError: tErrs,
		}
	}

	if len(arr) != 0 {
		var evalLhs, evalRhs rs.ExpressionResult
		evalLhs.Evalue = "{}"
		evalRhs.Vtype = "map"
		evalRhs.Evalue = arr[0]
		sr := rs.StatementResult{Lhs: evalLhs, Rhs: evalRhs}
		smtn = append(smtn, sr)
		return rs.StatementsResult{
			StatementResults: smtn,
			TransFormError:   tErrs,
		}
	}
	return rs.StatementsResult{}
}

func ProcessJsonSchema(payload []byte, schema, localMap map[string]interface{}, config rs.Config) (bool, rs.TransformError) {
	return utils.EvaluateJsonSchema(schema, payload, localMap)
}

func HandleException(mainTErr rs.TransformError, localMap map[string]interface{}, config rs.Config) ([]byte, bool) {
	if len(config.Errors.Statements) > 0 {
		querybuilder := gojsonq.New().FromInterface("")
		var arr []rs.TransformError
		var isExceptionHandled bool
		data := rs.JSONQData{Jqdata: querybuilder, ShouldReset: true, LocalData: localMap, JsonIgnoreProperty: false, ErrorData: &arr, JsonIgnoreAliasValue: "", IsExceptionHandled: &isExceptionHandled}

		res := utils.MakeResultMap()
		stateMentDetails := rs.StatementDetails{
			TransformType: c.TRANSFORM,
			ConfigType:    c.ERRORS,
		}

		tErr := processStatements(config.Errors.Statements, data, res, stateMentDetails)
		if len(tErr) != 0 {
			if tErr[0].Code != "1111" {
				return nil, false
			}
		}

		dataBytes, _ := json.Marshal(res["transformed"])
		if string(dataBytes) != "{}" {
			return dataBytes, true
		}
	}
	return nil, false
}

func isIterate(expr rs.Expression) bool {
	switch exp := expr.Holder.(type) {
	case rs.Keyword:
		if exp.KeywordArguments != nil {
			args := exp.KeywordArguments.(map[string]interface{})
			if args["format"] == "iterate" {
				return true
			}
		}
	}
	return false
}
