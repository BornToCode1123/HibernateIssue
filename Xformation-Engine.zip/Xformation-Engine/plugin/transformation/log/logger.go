package log

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"os"
	"strconv"

	log4go "jocata_transform_plugin/log4go"
)

var Log = log4go.Global

func WriteLoggerConfigurationFile() {

	var logMap = make(map[string]interface{})
	var pattern string
	logConfigPath := os.Getenv("LOG_CONFIG_PATH")
	fileContent, err := ioutil.ReadFile(logConfigPath)
	if err != nil {
		log.Fatal(err.Error())
	}
	err = json.Unmarshal((fileContent), &logMap)
	if err != nil {
		log.Fatal(err.Error())
	}

	if os.Getenv("LOG_FORMAT") == "json" {
		pattern = "{\"timestamp\": \"%D %T\", \"traceID\": \"%TRACE\", \"spanID\": \"%SPAN\", \"level\": \"%L\", \"message\": \"%M\"}"
	} else {
		pattern = "[%D %T] [%L] [%TRACE] [%SPAN] %M"
	}

	// if os.Getenv("LOG_FORMAT") == "json" {
	// 	pattern = "{\"timestamp\": \"%D %T\", \"level\": \"%L\", \"message\": \"%M\"}"
	// } else {
	// 	pattern = "[%D %T] [%L] %M"
	// }

	info_file_enable, _ := strconv.ParseBool(os.Getenv("INFO_FILE_ENABLE"))
	info_file_filename := os.Getenv("INFO_FILE_NAME_WITH_PATH")
	info_file_maxsize := os.Getenv("INFO_FILE_MAXSIZE")

	debug_file_enable, _ := strconv.ParseBool(os.Getenv("DEBUG_FILE_ENABLE"))
	debug_file_filename := os.Getenv("DEBUG_FILE_NAME_WITH_PATH")
	debug_file_maxsize := os.Getenv("DEBUG_FILE_MAXSIZE")

	error_file_enable, _ := strconv.ParseBool(os.Getenv("ERROR_FILE_ENABLE"))
	error_file_filename := os.Getenv("ERROR_FILE_NAME_WITH_PATH")
	error_file_maxsize := os.Getenv("ERROR_FILE_MAXSIZE")

	consoleMap := logMap["console"].(map[string]interface{})
	consoleMap["enable"], _ = strconv.ParseBool(os.Getenv("CONSOLE_ENABLE"))
	consoleMap["level"] = os.Getenv("CONSOLE_LEVEL")
	consoleMap["pattern"] = pattern

	files := logMap["files"].([]interface{})
	infoFile := files[0].(map[string]interface{})
	debugFile := files[1].(map[string]interface{})
	errFile := files[2].(map[string]interface{})

	infoFile["enable"] = info_file_enable
	infoFile["filename"] = info_file_filename
	infoFile["maxsize"] = info_file_maxsize
	infoFile["pattern"] = pattern

	debugFile["enable"] = debug_file_enable
	debugFile["filename"] = debug_file_filename
	debugFile["maxsize"] = debug_file_maxsize
	debugFile["pattern"] = pattern

	errFile["enable"] = error_file_enable
	errFile["filename"] = error_file_filename
	errFile["maxsize"] = error_file_maxsize
	errFile["pattern"] = pattern

	content, err := json.Marshal(logMap)
	if err != nil {
		log.Fatal(err)
	}
	userLogPath := os.Getenv("USER_LOG_PATH")
	err = ioutil.WriteFile(userLogPath, content, 0644)
	// Log.Debug(localMap, "creating log file")
	if err != nil {
		log.Fatal(err)
	}
}
