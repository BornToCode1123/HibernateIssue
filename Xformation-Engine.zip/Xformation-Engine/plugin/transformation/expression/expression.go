package expression

import (
	"errors"
	"fmt"
	c "jocata_transform_plugin/constants"
	fns "jocata_transform_plugin/functions"
	logger "jocata_transform_plugin/log"
	rs "jocata_transform_plugin/structs"
	"jocata_transform_plugin/utils"
	"math"
	"reflect"
	"strconv"
	"strings"
	"time"

	"github.com/thedevsaddam/gojsonq/v2"
	slices "golang.org/x/exp/slices"
)

func ProcessExpression(expr rs.Expression, data rs.JSONQData, fn rs.ProcessInnerTransform, statementPath string) (expRes rs.ExpressionResult, tErr rs.TransformError) {

	defer func() {
		if err := recover(); err != nil {
			errMessage := fmt.Sprint("techincal error occured : ", err)
			tErr = utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, "panic recovered %v", errMessage)
			utils.PrintStackTrace(data.LocalData)
			logger.Log.Error(data.LocalData, "stack trace ended")
			return
		}
	}()

	expressionType := expr.EType
	data.ResetJsonqData()
	switch expressionType {
	case c.VARIABLE:
		expRes, tErr = processVariable(expr, data)
		return
	case c.LITERAL:
		literal := expr.Holder.(rs.Literal)
		expRes, tErr = rs.ExpressionResult{Vtype: literal.DataType, Evalue: literal.DataValue}, rs.TransformError{}
		return
	case c.ENVIRONMENT:
		environment := expr.Holder.(rs.Environment)
		expRes, tErr = rs.ExpressionResult{Vtype: environment.DataType, Evalue: environment.DataValue}, rs.TransformError{}
		return
	case c.FUNCTION:
		expRes, tErr = processFunction(expr, data)
		return
	case c.EXPRESSION:
		holder := expr.Holder.(rs.ArithExpression)
		exp := holder.Structure
		expRes, tErr = processExpressionStructure(exp, data, fn, statementPath)
		expRes.Vtype = c.NUMBER
		return
	case c.KEYWORD:
		expRes, tErr = processKeyword(expr, data, fn, statementPath)
		return
	case c.DECLARE:
		declare := expr.Holder.(rs.Declare)
		expRes, tErr = rs.ExpressionResult{EType: declare.EType, Vtype: declare.DataType, Evalue: declare.DataValue}, rs.TransformError{}
		return
	case c.LOCAL:
		expRes, tErr = processLocal(expr.Holder.(rs.Local), data)
		return
	default:
		errMessage := fmt.Sprintf("Unknown  expression type , %v .!", expressionType)
		tErr = utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return
	}
}

func processExpressionStructure(exp rs.Arithematic, data rs.JSONQData, fn rs.ProcessInnerTransform, statementPath string) (rs.ExpressionResult, rs.TransformError) {
	expType := exp.EType
	switch expType {
	case "arithmetic":
		operatorType := exp.DataType
		variables := exp.Variables
		results, tErr := processArthematicExpressionVariables(variables, data, fn, statementPath)
		if tErr.Detailedmessage != nil {
			tErr.Detailedmessage = fmt.Sprintf("while processing variables for arithematic function : %v", tErr.Detailedmessage)
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return rs.ExpressionResult{}, tErr
		}
		ok, convertedResults, tErr := validateElements(results)
		if !ok {
			return rs.ExpressionResult{}, tErr
		}
		res := evaluateArthematicExpressionResult(data, operatorType, convertedResults)
		return rs.ExpressionResult{EType: exp.EType, Vtype: exp.DataType, Evalue: res}, rs.TransformError{}
	default:
		errMessage := fmt.Sprintf("Unknown  expression type , %v .!", expType)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return rs.ExpressionResult{}, tErr
	}
}

func validateElements(results []interface{}) (bool, []float64, rs.TransformError) {
	var elements []float64
	for _, element := range results {
		if element != nil {
			switch val := element.(type) {
			case float64:
				elements = append(elements, val)
			case string:
				floatValue, err := strconv.ParseFloat(val, 64)
				if err != nil {
					errMessage := fmt.Sprintf("the variable %v which is trying to use for calculate the sum, is not a number %v", val, err)
					tErr := utils.PopulateTransFormError("1001", errMessage)
					return false, elements, tErr
				}
				elements = append(elements, floatValue)
			default:
				errMessage := fmt.Sprintf("There is an element that is used in arithmetic functions, but it is not a number. %v .!", element)
				tErr := utils.PopulateTransFormError("1001", errMessage)
				return false, elements, tErr
			}
		}
	}
	return true, elements, rs.TransformError{}
}

func evaluateArthematicExpressionResult(data rs.JSONQData, operatorType string, results []float64) interface{} {
	switch operatorType {
	case "+":
		return performAddition(results)
	case "-":
		return performSubstraction(results)
	case "*":
		return performMultiplication(results)
	case "/":
		return performDivision(data, results)
	case "%":
		return performModulas(data, results)
	case "^":
		return performExponentiation(results)
	default:
		return nil
	}
}

func performExponentiation(results []float64) interface{} {
	var base float64
	for index, exponent := range results {
		if index == 0 {
			base = exponent
		} else {
			base = math.Pow(base, exponent)
		}
	}
	return base
}

func performAddition(results []float64) interface{} {
	var res float64
	for _, element := range results {
		res = res + element

	}
	return res
}

func performSubstraction(results []float64) interface{} {
	var res float64
	for i, element := range results {
		if i == 0 {
			res = element
		} else {
			res = res - element
		}

	}
	return res
}

func performMultiplication(results []float64) interface{} {
	var res float64
	res = 1
	for _, element := range results {
		res = res * element
	}

	return res
}

func performDivision(data rs.JSONQData, results []float64) interface{} {
	var res float64
	if len(results) == 2 {
		if results[1] != 0 {
			res = results[0] / results[1]
		} else {
			errMessage := fmt.Sprintf("cannot perform with %v ", results[1])
			return errors.New(errMessage)
		}

	} else {
		errMessage := fmt.Sprintf("unable to process Division, Because Too many Arguments...., %v ", results)
		logger.Log.Error(data.LocalData, errMessage)
		return errors.New(errMessage)
	}
	return res
}

func performModulas(data rs.JSONQData, results []float64) interface{} {
	var res float64
	if len(results) == 2 {
		if results[1] != 0 {
			res = math.Mod(results[0], results[1])
		} else {
			errMessage := fmt.Sprintf("cannot perform with %v ", results[1])
			logger.Log.Error(data.LocalData, errMessage)
			return errors.New(errMessage)
		}
	} else {
		errMessage := fmt.Sprintf("unable to process Modulas, Because Too many Arguments...., %v ", results)
		logger.Log.Error(data.LocalData, errMessage)
		return errors.New(errMessage)
	}
	return res
}

func processArthematicExpressionVariables(variables []rs.Expression, data rs.JSONQData, fn rs.ProcessInnerTransform, statementPath string) ([]interface{}, rs.TransformError) {
	var results []interface{}
	for _, expVarible := range variables {
		variable := expVarible

		if variable.EType == "arthematic" {
			arithVar := variable.Holder.(rs.Arithematic)
			er, tErr := processExpressionStructure(arithVar, data, fn, statementPath)
			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = fmt.Sprintf("unable to process arthematic expression variable , %v .!", arithVar.Variables) + tErr.Detailedmessage.(string)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return results, tErr
			}
			results = append(results, er.Evalue)
		} else {
			er, tErr := ProcessExpression(variable, data, fn, statementPath)
			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = (fmt.Sprintf("unable to process arthematic expression variable , %v .!", variable) + tErr.Detailedmessage.(string))
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return results, tErr
			}
			results = append(results, er.Evalue)
		}
	}
	return results, rs.TransformError{}
}

func processLocal(loc rs.Local, data rs.JSONQData) (rs.ExpressionResult, rs.TransformError) {
	variable := loc.DataValue
	if len(variable.(string)) > 0 {
		res, err := utils.GetFromMap(data.LocalData, variable.(string), data)
		if !data.JsonIgnoreProperty && err != nil {
			tErr := utils.PopulateTransFormError("1002", err.Error())
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return rs.ExpressionResult{}, tErr
		} else if data.JsonIgnoreProperty && err != nil {
			if loc.DataType == "list" {
				data.JsonIgnoreAliasValue = []interface{}{}
			}
			return rs.ExpressionResult{Vtype: loc.DataType, Evalue: data.JsonIgnoreAliasValue}, rs.TransformError{}
		}
		if err != nil {
			tErr := utils.PopulateTransFormError("1002", err.Error())
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return rs.ExpressionResult{}, tErr
		}
		return rs.ExpressionResult{Vtype: loc.DataType, Evalue: res}, rs.TransformError{}
	}
	tErr := utils.PopulateTransFormError("1002", ("the dataValue is empty... From response what value should be picked?"))
	return rs.ExpressionResult{}, tErr
}

func processVariable(expr rs.Expression, data rs.JSONQData) (rs.ExpressionResult, rs.TransformError) {

	variable := expr.Holder.(rs.Variable)
	var datVal = variable.DataValue.(string)
	var res interface{}

	if strings.Contains(variable.DataValue.(string), c.LOCAL_OBJECT_IDENTIFIER) {
		datVal = utils.ModifyName(variable.DataValue.(string))

		res, err := utils.GetFromMap(data.LocalData, datVal, data)
		if !data.JsonIgnoreProperty && err != nil {
			tErr := utils.PopulateTransFormError("1002", err.Error())
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return rs.ExpressionResult{}, tErr
		} else if data.JsonIgnoreProperty && err != nil {
			if variable.DataType == "list" {
				data.JsonIgnoreAliasValue = []interface{}{}
			}
			return rs.ExpressionResult{Vtype: variable.DataType, Evalue: data.JsonIgnoreAliasValue}, rs.TransformError{}
		}
		return rs.ExpressionResult{Vtype: variable.DataType, Evalue: res}, rs.TransformError{}
	} else {
		if len(datVal) > 0 {
			data.ResetJsonqData()
			res = data.Jqdata.Find(datVal)
			err := data.Jqdata.Error()

			if !data.JsonIgnoreProperty && err != nil {
				erMsg := err.Error()
				if len(erMsg) > 27 {
					erMsg = erMsg[27:]
				}
				detailedmessage := ("the key : " + erMsg + ", is not found in the specified payload path " + datVal)
				logger.Log.Error(data.LocalData, detailedmessage)
				tErr := utils.PopulateTransFormError("1010", detailedmessage)
				return rs.ExpressionResult{Vtype: variable.DataType, Evalue: nil}, tErr
			} else if data.JsonIgnoreProperty && err != nil {
				logger.Log.Trace(data.LocalData, "JsonIgnoreProperty Executed for %v field", datVal)
				if variable.DataType == "list" {
					slice := []interface{}{}
					return rs.ExpressionResult{Vtype: variable.DataType, Evalue: slice}, rs.TransformError{}
				}
				return rs.ExpressionResult{Vtype: variable.DataType, Evalue: data.JsonIgnoreAliasValue}, rs.TransformError{}
			}
		}
	}

	return rs.ExpressionResult{Vtype: variable.DataType, Evalue: res}, rs.TransformError{}
}

func processKeyword(expr rs.Expression, data rs.JSONQData, fn rs.ProcessInnerTransform, statementPath string) (rs.ExpressionResult, rs.TransformError) {
	expKeyword := expr.Holder.(rs.Keyword)
	dataValue := expKeyword.DataValue.(string)
	filter := expr.Holder.(rs.Keyword).Filter
	var functionArguments bool
	var args map[string]interface{}
	Arguments := expKeyword.KeywordArguments
	if Arguments != nil {
		args = Arguments.(map[string]interface{})
		if len(args) > 0 {
			functionArguments = true
		}
	}

	switch dataValue {
	case c.DATE:
		if functionArguments {
			var finalDate interface{}
			var tErr rs.TransformError

			switch args["format"] {
			case "dateDiff":
				finalDate, tErr = fns.CalculateDifferenceBetweenDates(args, data)
			case "dateDiffFromToday":
				finalDate, tErr = fns.CalculateDifferenceFromToday(args, data)
			case "createDate":
				finalDate, tErr = fns.CreateDate(args, data)
			case c.IS_EMPTY:
				finalDate, tErr = fns.IsDateEmpty(args, data)
			default:
				finalDate, tErr = fns.DataFormat(args, data)
			}

			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = fmt.Sprintf("in keyword 'date' : %v ", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return rs.ExpressionResult{}, tErr
			}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: finalDate, EType: "date"}, rs.TransformError{}
		} else {
			keywordData := make(map[string]interface{})
			finalDate, tErr := fns.DataFormat(keywordData, data)
			if tErr.Detailedmessage != nil {
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return rs.ExpressionResult{}, tErr
			}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: finalDate, EType: "date"}, rs.TransformError{}
		}
	case c.VALUE:
		logger.Log.Trace(data.LocalData, "Entered into function value")
		value := data.Jqdata.Get()
		err := data.Jqdata.Error()

		if err != nil {
			tErr := utils.PopulateTransFormError("1001", err.Error())
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return rs.ExpressionResult{}, tErr
		}
		switch res := value.(type) {
		case map[string]interface{}:
			delete(res, "localData")
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: res}, rs.TransformError{}
		}
		return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: value}, rs.TransformError{}
	case c.TEXT:
		if functionArguments {
			textFormat, tErr := fns.FormatString(args, data)
			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = fmt.Sprintf("in keyword 'text' : %v", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return rs.ExpressionResult{}, tErr
			}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: textFormat}, rs.TransformError{}
		} else {
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: ""}, rs.TransformError{}
		}
	case c.NUMBER:
		if functionArguments {
			textFormat, tErr := fns.FormatNumber(args, data)

			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = fmt.Sprintf("in keyword 'number' : %v", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return rs.ExpressionResult{}, tErr
			}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: textFormat}, rs.TransformError{}
		} else {
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: 0.0}, rs.TransformError{}
		}
	case c.LIST:
		if functionArguments {
			listFormat, tErr := fns.FormatArray(args, data, fn, ProcessCondition, filter, ProcessExpression, ProcessRules, statementPath)
			if tErr.Detailedmessage != nil {
				if tErr.Code == "1111" {
					if len(listFormat.([]interface{})) != 0 {
						return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: listFormat.([]interface{})[0]}, tErr
					}
					return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: listFormat}, tErr
				}
				tErr.Detailedmessage = fmt.Sprintf("in keyword 'list' : %v ", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: listFormat}, tErr
			}
			if listFormat == nil && args["format"] == "iterate" {
				listFormat = []interface{}{}
			}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: listFormat}, rs.TransformError{}
		} else {
			slice := []interface{}{}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: slice}, rs.TransformError{}
		}
	case c.MAP:
		if functionArguments {
			mapFormat, tErr := fns.FormatMap(args, data)
			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = fmt.Sprintf("in keyword 'map' : %v ", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return rs.ExpressionResult{}, tErr
			}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: mapFormat}, rs.TransformError{}
		} else {
			var mp = make(map[string]interface{})
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: mp}, rs.TransformError{}
		}
	case c.BOOLEAN:
		if functionArguments {
			mapFormat, tErr := fns.FormatBool(args, data)
			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = fmt.Sprintf("in keyword 'boolean' : %v ", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return rs.ExpressionResult{}, tErr
			}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: mapFormat}, rs.TransformError{}
		} else {
			var boolean bool
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: boolean}, rs.TransformError{}
		}
	case c.CURRENCY:
		keywordArgs := expKeyword.KeywordArguments
		if keywordArgs != nil {
			keywordData := keywordArgs.(map[string]interface{})
			value, tErr := fns.FormatCurrency(keywordData, data)
			if tErr.Detailedmessage != nil {
				tErr.Detailedmessage = fmt.Sprintf("in keyword 'currency' : %v", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, tErr.Detailedmessage)
				return rs.ExpressionResult{}, tErr
			}
			return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: value}, rs.TransformError{}
		}
		errMessage := fmt.Sprintf("Invalid keyWordArguments, Have %v, Want keywordArguments{} ", expr)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return rs.ExpressionResult{}, tErr
	case c.STATEMENT_ID:
		res, err := utils.GetFromMap(data.LocalData, "statementId", data)
		if err != nil {
			errMessage := fmt.Sprintf("in keyword 'statementId' : %v", err)
			tErr := utils.PopulateTransFormError("1010", errMessage)
			logger.Log.Error(data.LocalData, errMessage)
			return rs.ExpressionResult{}, tErr
		}

		return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: res}, rs.TransformError{}
	case c.NONE:
		return rs.ExpressionResult{Vtype: expKeyword.DataType, Evalue: "{}"}, rs.TransformError{}
	default:
		errMessage := fmt.Sprintf("unknown keyword %v", dataValue)
		tErr := utils.PopulateTransFormError("1010", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return rs.ExpressionResult{}, tErr
	}
}

func processFunction(expr rs.Expression, data rs.JSONQData) (rs.ExpressionResult, rs.TransformError) {

	functionResult, tErr := evaluateFunction(expr, data)
	if tErr.Detailedmessage != nil {
		return rs.ExpressionResult{Evalue: functionResult}, tErr
	}
	return rs.ExpressionResult{Vtype: expr.Holder.(rs.Function).DataType, Evalue: functionResult}, rs.TransformError{}
}

func evaluateFunction(expr rs.Expression, data rs.JSONQData) (interface{}, rs.TransformError) {

	funcName := expr.Holder.(rs.Function).FunctionName
	args := expr.Holder.(rs.Function).FunctionArguments

	switch funcName {
	case "encrypt":
		result, tErr := fns.Encrypt(args, data)
		if tErr.Detailedmessage != nil {
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return nil, tErr
		}

		return result, rs.TransformError{}
	case "decrypt":
		result, tErr := fns.Decrypt(args, data)

		if tErr.Detailedmessage != nil {
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return nil, tErr
		}
		return result, rs.TransformError{}
	case "paginate":

		result, tErr := fns.Paginate(args, data)
		if tErr.Detailedmessage != nil {
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return nil, tErr
		}
		return result, rs.TransformError{}

	case "apiRestCall":

		hcd := utils.GetConnectionDetails(args)
		result, tErr := fns.ApiRestCall(hcd, data)

		if tErr.Detailedmessage != nil {
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return nil, tErr
		}
		return result, rs.TransformError{}
	case "datasetCall":

		hcd := utils.GetConnectionDetails(args)
		result, tErr := fns.DataSetCall(hcd, data)

		if tErr.Detailedmessage != nil {
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return nil, tErr
		}
		return result, rs.TransformError{}
	case "FormTemplateCall":

		hcd := utils.GetConnectionDetails(args)
		result, tErr := fns.FormTemplateCall(hcd, data)

		if tErr.Detailedmessage != nil {
			logger.Log.Error(data.LocalData, tErr.Detailedmessage)
			return nil, tErr
		}
		return result, rs.TransformError{}

	default:
		errMessage := fmt.Sprintf("The Function %v which is being used... is not implemented", funcName)
		tErr := utils.PopulateTransFormError("1002", errMessage)
		logger.Log.Error(data.LocalData, errMessage)
		return nil, tErr
	}
}

func ProcessCondition(cs rs.Condition, data rs.JSONQData, innerTran rs.ProcessInnerTransform, statementPath string) (bool, rs.TransformError) {
	logicalType := cs.VType
	rules := cs.Rules
	return ProcessRules(logicalType, rules, data, innerTran, statementPath)
}

func ProcessRules(logicalType string, rules []rs.Rule, data rs.JSONQData, innerTran rs.ProcessInnerTransform, statementPath string) (res bool, tErr rs.TransformError) {
	defer func() {
		if err := recover(); err != nil {
			errMessage := fmt.Sprint("techincal error occured : ", err)
			tErr = utils.PopulateTransFormError("1001", errMessage)
			logger.Log.Error(data.LocalData, "panic recovered %v", errMessage)
			utils.PrintStackTrace(data.LocalData)
			logger.Log.Error(data.LocalData, "stack trace ended")
			return
		}
	}()

	var ruleOutput []bool
	var ruleErrors []string
	for index, rule := range rules {
		logger.Log.Trace(data.LocalData, "executing rule/ruleGroup no : %v", index)
		r := rule
		conditionType := r.EType
		if conditionType == "relational" {
			relational := rule.RuleHolder.(rs.RelationalRule)
			evalLhs, lhserr := ProcessExpression(relational.Lhs, data, innerTran, statementPath)
			evalRhs, rhserr := ProcessExpression(relational.Rhs, data, innerTran, statementPath)
			operator := relational.Operator
			operatorType := operator.ActualValue

			var message string

			if lhserr.Detailedmessage != nil {
				tErr = lhserr
				errMessage := fmt.Sprintf("On LHS , %v .!", lhserr.Detailedmessage)
				message = message + errMessage
				logger.Log.Error(data.LocalData, message)
			}

			if rhserr.Detailedmessage != nil {
				tErr = rhserr
				errMessage := fmt.Sprintf("On RHS , %v .!", rhserr.Detailedmessage)
				message = message + errMessage
				logger.Log.Error(data.LocalData, message)
			}

			if message != "" {
				ruleErrors = append(ruleErrors, message)
				errMsg := fmt.Sprintf("errors in condtions : %v", ruleErrors)
				tErr.Detailedmessage = errMsg
				logger.Log.Error(data.LocalData, errMsg)
				return false, tErr
			}

			res, err := evaluateRule(data, evalLhs, operatorType, evalRhs)
			logger.Log.Trace(data.LocalData, "%v no's rule result is : %v", index+1, res)
			if err == nil {

				if len(ruleOutput) == 0 {
					ruleOutput = append(ruleOutput, res)
					if logicalType == "and" && !res {
						break
					}
				} else {
					switch logicalType {
					case "and":
						ruleOutput[0] = ruleOutput[0] && res
					case "or":
						ruleOutput[0] = ruleOutput[0] || res
					default:
						ruleErrors = append(ruleErrors, "unsupported Logical type "+logicalType)
					}
				}
			} else {
				ruleErrors = append(ruleErrors, err.Error())
				res = false
				ruleOutput = append(ruleOutput, res)
				ruleOutput[0] = false
			}

		} else if conditionType == "logical" {
			logicalCondition := rule.RuleHolder.(rs.Condition)
			res, tErr := ProcessCondition(logicalCondition, data, innerTran, statementPath)

			if tErr.Detailedmessage != nil {
				errMsg := fmt.Sprintf("errors in condtions : %v", tErr.Detailedmessage)
				logger.Log.Error(data.LocalData, errMsg)
				return false, tErr
			}

			if len(ruleOutput) == 0 {
				ruleOutput = append(ruleOutput, res)
			} else {
				switch logicalType {
				case "and":
					ruleOutput[0] = ruleOutput[0] && res
				case "or":
					ruleOutput[0] = ruleOutput[0] || res
				default:
					ruleErrors = append(ruleErrors, "unsupported Logical type "+logicalType)
				}
			}
		}
		if logicalType == "and" && len(ruleOutput) != 0 {
			if !(ruleOutput[0]) {
				break
			}
		}
	}

	if len(ruleErrors) != 0 {
		logger.Log.Trace(data.LocalData, "Conditions , %v", ruleErrors)
		errMsg := fmt.Sprintf("errors in condtions : %v", ruleErrors)
		tErr := utils.PopulateTransFormError("1001", errMsg)
		logger.Log.Error(data.LocalData, errMsg)
		return false, tErr
	}
	return ruleOutput[0], rs.TransformError{}
}

func evaluateRule(data rs.JSONQData, lhs rs.ExpressionResult, operator string, rhs rs.ExpressionResult) (bool, error) {

	if compareBothDataTypes(data, lhs, rhs) {

		rhsValue := reflect.TypeOf(lhs.Evalue)
		lhsValue := reflect.TypeOf(rhs.Evalue)

		if operator == "===" {
			if lhs.Evalue != nil && rhs.Evalue != nil {
				return rhsValue.Kind() == lhsValue.Kind(), nil
			} else {
				return false, nil
			}
		}

		logger.Log.Trace(data.LocalData, "comparing '%v' '%v' '%v' ", lhs.Evalue, operator, rhs.Evalue)

		switch lhs.Vtype {
		case c.TEXT:
			switch operator {
			case c.EQUALS:
				return lhs.Evalue == rhs.Evalue, nil
			case c.NOT_EQUALS:
				return lhs.Evalue != rhs.Evalue, nil
				// contains........
			case c.EQUAL_IGNORE_CASE:
				lhsVal, lhsOk := lhs.Evalue.(string)
				RhsVal, rhsOk := rhs.Evalue.(string)
				if lhsOk && rhsOk {
					return strings.EqualFold(lhsVal, RhsVal), nil
				} else {
					errMessage := "the provided is not string. cannot compare equalIgnoreCase()"
					logger.Log.Error(data.LocalData, errMessage, lhs.Evalue, rhs.Evalue)
					return false, errors.New(errMessage)
				}
			}
		case c.BOOLEAN:

			_, lhsOk := lhs.Evalue.(bool)
			_, rhsOk := rhs.Evalue.(bool)
			if (lhsOk && rhsOk) || (operator == "===") {
				if lhs.Evalue != nil || rhs.Evalue != nil {
					switch operator {
					case c.EQUALS:
						return lhs.Evalue.(bool) == rhs.Evalue.(bool), nil
					case c.NOT_EQUALS:
						return lhs.Evalue.(bool) != rhs.Evalue.(bool), nil
					}
				} else {
					return false, nil
				}
			} else {
				errMessage := "The provided data value is not boolean, "
				logger.Log.Error(data.LocalData, errMessage)
				return false, errors.New(errMessage)
			}
		case c.NUMBER:
			var lhsOk bool
			var rhsOk bool
			if rhs.Evalue != nil {
				_, lhsOk = lhs.Evalue.(float64)
				_, rhsOk = rhs.Evalue.(float64)
			} else {
				switch operator {
				case "==":
					return lhs.Evalue == rhs.Evalue, nil
				case "!=":
					return lhs.Evalue != rhs.Evalue, nil
				default:
					return false, nil
				}
			}
			if (lhsOk && rhsOk) || (operator == "===") {
				if lhs.Evalue != nil || rhs.Evalue != nil {
					switch operator {
					case "==":
						return lhs.Evalue.(float64) == rhs.Evalue.(float64), nil
					case "!=":
						return lhs.Evalue.(float64) != rhs.Evalue.(float64), nil
					case ">":
						return lhs.Evalue.(float64) > rhs.Evalue.(float64), nil
					case "<":
						return lhs.Evalue.(float64) < rhs.Evalue.(float64), nil
					case ">=":
						return lhs.Evalue.(float64) >= rhs.Evalue.(float64), nil
					case "<=":
						return lhs.Evalue.(float64) <= rhs.Evalue.(float64), nil

					}
				} else {
					return false, nil
				}
			} else {
				var errMessage string
				if !lhsOk {
					errMessage = fmt.Sprintf("The provided data value is not numeric, %v", lhs.Evalue)
				}
				if !rhsOk {
					errMessage = fmt.Sprintf("The provided data value is not numeric, %v", rhs.Evalue)
				}

				logger.Log.Error(data.LocalData, errMessage)
				return false, errors.New(errMessage)
			}
		case c.LIST:
			if lhs.Evalue != nil || rhs.Evalue != nil {
				switch operator {
				case "==":
					return reflect.DeepEqual(lhs.Evalue, rhs.Evalue), nil
				case "!=":
					return !(reflect.DeepEqual(lhs.Evalue, rhs.Evalue)), nil

				case "contains":
					var numberArray []float64
					var textArray []string

					if lhs.Evalue == `allStatements` || rhs.Evalue == `allStatements` {
						return true, nil
					}

					switch list := lhs.Evalue.(type) {
					case []interface{}:
						if len(list) < 1 {
							return false, nil
						}
						switch list[0].(type) {
						case string:
							val := lhs.Evalue
							result, _ := gojsonq.New().FromInterface(val).GetR()
							result.As(&textArray)
							return slices.Contains(textArray, rhs.Evalue.(string)), nil
						case float64:
							val := lhs.Evalue
							result, _ := gojsonq.New().FromInterface(val).GetR()
							result.As(&numberArray)
							return Contains(numberArray, rhs.Evalue.(float64)), nil
						}
					case []string:
						return slices.Contains(list, rhs.Evalue.(string)), nil
					case []float64:
						return Contains(list, rhs.Evalue.(float64)), nil
					}

				case "nContains":
					var numberArray []float64
					var textArray []string

					switch list := lhs.Evalue.(type) {
					case []interface{}:
						if len(list) < 1 {
							return true, nil
						}
						switch list[0].(type) {
						case string:
							val := lhs.Evalue
							result, _ := gojsonq.New().FromInterface(val).GetR()
							result.As(&textArray)
							return !slices.Contains(textArray, rhs.Evalue.(string)), nil
						case float64:
							val := lhs.Evalue
							result, _ := gojsonq.New().FromInterface(val).GetR()
							result.As(&numberArray)
							return !Contains(numberArray, rhs.Evalue.(float64)), nil
						}
					case []string:
						return !slices.Contains(list, rhs.Evalue.(string)), nil
					case []float64:
						return !Contains(list, rhs.Evalue.(float64)), nil
					}
				}
			} else {
				return false, nil
			}
		case c.MAP:
			if lhs.Evalue != nil || rhs.Evalue != nil {
				switch operator {
				case c.EQUALS:
					return reflect.DeepEqual(lhs.Evalue, rhs.Evalue), nil
				case c.NOT_EQUALS:
					return !(reflect.DeepEqual(lhs.Evalue, rhs.Evalue)), nil
				case c.CONTAINS:
					switch res := lhs.Evalue.(type) {
					case map[string]interface{}:
						_, exists := res[rhs.Evalue.(string)]
						return exists, nil
					default:
						errMessage := fmt.Sprintf("the lhs data value which is used is not a map %v", res)
						logger.Log.Error(data.LocalData, errMessage)
						return false, errors.New(errMessage)
					}
				case c.NOT_CONTAINS:
					switch res := lhs.Evalue.(type) {
					case map[string]interface{}:
						_, exists := res[rhs.Evalue.(string)]
						return !exists, nil
					default:
						errMessage := fmt.Sprintf("the lhs data value which is used is not a map %v", res)
						logger.Log.Error(data.LocalData, errMessage)
						return false, errors.New(errMessage)
					}
				}
			} else {
				logger.Log.Error(data.LocalData, "Can't compare if both sides are nill")
				return false, nil
			}
		case c.DATE:
			localtime := time.Local
			actualDateFormat := fns.GetDateFormat(rhs.Evalue.(string))
			if actualDateFormat == "" {
				errMessage := fmt.Sprintf("the given date format is un supported %v", rhs.Evalue.(string))
				logger.Log.Error(data.LocalData, errMessage)
				return false, errors.New(errMessage)
			}

			if lhs.Evalue != nil || rhs.Evalue != nil {
				switch operator {
				case "checkDateFormat":
					_, err := time.ParseInLocation(actualDateFormat, lhs.Evalue.(string), localtime)
					if err != nil {
						return false, nil
					}
					return true, nil
				case "notEqualDateFormat":
					_, err := time.ParseInLocation(actualDateFormat, lhs.Evalue.(string), localtime)
					if err != nil {
						return true, nil
					}
					return false, nil

				default:
					errMessage := fmt.Sprintf("invalid operator %v", operator)
					logger.Log.Error(data.LocalData, errMessage)
					return false, errors.New(errMessage)
				}
			} else {
				logger.Log.Error(data.LocalData, "Can't compare if both sides are nill")
				return false, nil
			}
		case c.DATE_TIME:
			errMessage := "Currently we are not supporting this data type for comparison"
			logger.Log.Error(data.LocalData, errMessage)
			return false, nil
		default:
			errMessage := fmt.Sprintf("invalid dataType %v", lhs.Vtype)
			logger.Log.Error(data.LocalData, errMessage)
			return false, errors.New(errMessage)
		}
	}
	return false, errors.New("Cannot compare two differnt Types.. LHS data type " + lhs.Vtype + " and RHS data type " + rhs.Vtype)
}

func compareBothDataTypes(data rs.JSONQData, lhs rs.ExpressionResult, rhs rs.ExpressionResult) bool {
	if lhs.Vtype == rhs.Vtype {
		return true
	} else if lhs.Vtype == "list" && rhs.Vtype != "map" {
		return true
	} else if lhs.Vtype == "map" && rhs.Vtype == "text" {
		return true
	}
	logger.Log.Error(data.LocalData, "Cannot compare different data types")
	return false
}

func Contains(slice []float64, element float64) bool {
	for _, v := range slice {
		if v == element {
			return true
		}
	}
	return false
}
