





# KrakenD
KrakenD is an extensible, ultra-high performance API Gateway that helps you effortlessly adopt microservices and secure communications. KrakenD is easy to operate and run and scales out without a single point of failure.

**KrakenD Community Edition** (or *KrakenD-CE*) is the open-source distribution of [KrakenD](https://www.krakend.io).

** Golang installation is needed to run on the local machine

** U can start the service by running go run main.go -c urconfigfile.json to test integration of API Gateway, service discovery and all other components


** Does not support running on windows If u want to test Transformations. 





