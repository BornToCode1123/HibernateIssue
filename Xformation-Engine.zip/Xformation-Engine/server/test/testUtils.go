package test

import (
	logger "jocata_transform_plugin/log"
)

func InitLogger() {
	logger.Log.Trace(nil, "Logger injection done..!")
}
