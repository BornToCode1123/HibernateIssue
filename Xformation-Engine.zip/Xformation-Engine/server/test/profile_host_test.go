package test

import (
	"fmt"
	"os"
	"strings"
	"testing"

	cfg "jocata.com/gateway/krakend/test/configs"

	"github.com/magiconair/properties/assert"
	flexible "jocata.com/gateway/krakend/flexible"
)

func TestDEVProfileHost(t *testing.T) {
	InitLogger()
	os.Setenv("PROFILE", "DEV")

	filePath, _ := os.Getwd()

	hostPath := filePath + "/configs/host.json"
	os.Setenv("HOST_PROPERTIES", hostPath)

	configPath := filePath + "/endpoints/host/"

	payload, _ := flexible.GetFilesData(configPath, "")

	fmt.Println("res :", payload)
	assert.Equal(t, (payload), cfg.TestDEVProfileHost)

}
func TestQAProfileHost(t *testing.T) {
	InitLogger()
	os.Setenv("PROFILE", "QA")

	filePath, _ := os.Getwd()

	hostPath := filePath + "/configs/host.json"
	os.Setenv("HOST_PROPERTIES", hostPath)

	configPath := filePath + "/endpoints/host/"

	payload, _ := flexible.GetFilesData(configPath, "")
	fmt.Println("res :", payload)
	assert.Equal(t, (payload), cfg.TestQAProfileHost)

}
func TestUATProfileHost(t *testing.T) {
	InitLogger()
	os.Setenv("PROFILE", "UAT")

	filePath, _ := os.Getwd()
	hostPath := filePath + "/configs/host.json"
	os.Setenv("HOST_PROPERTIES", hostPath)

	configPath := filePath + "/endpoints/host/"
	payload, _ := flexible.GetFilesData(configPath, "")
	fmt.Println("res :", payload)
	assert.Equal(t, (payload), cfg.TestUATProfileHost)

}

func TestProdProfileHost(t *testing.T) {
	InitLogger()
	os.Setenv("PROFILE", "PROD")

	filePath, _ := os.Getwd()

	hostPath := filePath + "/configs/host.json"
	os.Setenv("HOST_PROPERTIES", hostPath)

	configPath := filePath + "/endpoints/host/"

	payload, _ := flexible.GetFilesData(configPath, "")

	fmt.Println("res :", payload)
	assert.Equal(t, (payload), cfg.TestPRODProfileHost)

}

func TestHostProfilePathError(t *testing.T) {
	InitLogger()
	os.Setenv("PROFILE", "DEV")

	filePath, _ := os.Getwd()

	hostPath := filePath + "/configs/host.json1"
	os.Setenv("HOST_PROPERTIES", hostPath)

	configPath := filePath + "/endpoints/host/"

	_, err := flexible.GetFilesData(configPath, "")

	fmt.Println("err.Message :-", err.Message)
	if !strings.Contains(err.Message, "Host property file not present in given path") {
		t.Fail()
	}
}

func TestHostProfileError(t *testing.T) {
	InitLogger()
	os.Setenv("PROFILE", "DEV1")

	filePath, _ := os.Getwd()

	hostPath := filePath + "/configs/host.json"
	os.Setenv("HOST_PROPERTIES", hostPath)

	configPath := filePath + "/endpoints/host/"

	_, err := flexible.GetFilesData(configPath, "")

	fmt.Println("err.Message :-", err.Message)
	if !strings.Contains(err.Message, "Given host value not present in host properties hostname") {
		t.Fail()
	}
}

func TestHostMissingError(t *testing.T) {
	InitLogger()
	os.Setenv("PROFILE", "DEV1")

	filePath, _ := os.Getwd()

	hostPath := filePath + "/configs/host.json"
	os.Setenv("HOST_PROPERTIES", hostPath)

	configPath := filePath + "/endpoints/errorhost/"

	_, err := flexible.GetFilesData(configPath, "")

	fmt.Println("err.Message :-", err.Message)

	if !strings.Contains(err.Message, "No host variables for this end point") {
		t.Fail()
	}
}

func TestConfigPathError(t *testing.T) {
	InitLogger()
	os.Setenv("PROFILE", "DEV1")

	filePath, _ := os.Getwd()

	hostPath := filePath + "/configs/host.json"
	os.Setenv("HOST_PROPERTIES", hostPath)

	configPath := filePath + "/endpoints/errorhost1/"

	_, err := flexible.GetFilesData(configPath, "")

	fmt.Println("err.Message :-", err.Message)
	assert.Equal(t, (err.Message), "open "+configPath+": The system cannot find the file specified.")

}
