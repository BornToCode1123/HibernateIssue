package encrypt

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"fmt"
)

const (
	fixedKey = "wxkbb22e5i62fl7kx7dp9fo6i0phjtxm" // 32 bytes for AES-256
	fixedIV  = "r7a6ru3hon3wsaju"                 // 16 bytes for AES block size
)

func PKCS5Padding(data []byte, blockSize int) []byte {
	padding := blockSize - len(data)%blockSize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(data, padtext...)
}

func PKCS5UnPadding(data []byte) ([]byte, error) {
	length := len(data)
	if length == 0 {
		return nil, fmt.Errorf("empty data")
	}
	padding := int(data[length-1])
	if padding > length {
		return nil, fmt.Errorf("invalid padding")
	}
	return data[:(length - padding)], nil
}

func Encrypt(plaintext string) (string, error) {
	block, err := aes.NewCipher([]byte(fixedKey))
	if err != nil {
		return "", err
	}

	padded := PKCS5Padding([]byte(plaintext), aes.BlockSize)
	iv := []byte(fixedIV)

	mode := cipher.NewCBCEncrypter(block, iv)
	ciphertext := make([]byte, len(padded))
	mode.CryptBlocks(ciphertext, padded)

	combined := append(iv, ciphertext...)
	return base64.StdEncoding.EncodeToString(combined), nil
}

func Decrypt(encryptedStr string) (string, error) {
	combined, err := base64.StdEncoding.DecodeString(encryptedStr)
	if err != nil {
		return "", err
	}

	iv := combined[:aes.BlockSize]
	ciphertext := combined[aes.BlockSize:]

	block, err := aes.NewCipher([]byte(fixedKey))
	if err != nil {
		return "", err
	}

	mode := cipher.NewCBCDecrypter(block, iv)
	mode.CryptBlocks(ciphertext, ciphertext)

	unpadded, err := PKCS5UnPadding(ciphertext)
	if err != nil {
		return "", err
	}

	return string(unpadded), nil
}
