package client

import (
	"context"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/ArthurHlt/go-eureka-client/eureka"
	"github.com/luraproject/lura/v2/logging"
)

const (
	defaultTTL = 5 * time.Second
	heartBeat  = 10 * time.Second
)

type Client interface {
	GetEntries(appId string) ([]string, error)
	Register(appId string, ip string, port int, hostName string) error
}

type client struct {
	eurekaClient *eureka.Client
	ctx          context.Context
	logger       logging.Logger
}

type ClientOptions struct {
	CertFile    string
	KeyFile     string
	CaCertFile  []string
	DialTimeout time.Duration
	Consistency string
}

func NewClient(ctx context.Context, machines []string, options ClientOptions, logger logging.Logger) (Client, error) {
	if options.DialTimeout == 0 {
		options.DialTimeout = defaultTTL
	}
	return &client{ctx: ctx, eurekaClient: eureka.NewClient(machines), logger: logger}, nil
}

func (c *client) GetEntries(appId string) ([]string, error) {
	appIdNoHttp := strings.Split(appId, ".")
	resp, err := c.eurekaClient.GetApplication(appIdNoHttp[0])
	if err != nil {
		// log.Println("Found No service for eureka " + appIdNoHttp[0])
		return nil, err
	}
	entries := make([]string, len(resp.Instances))

	for i, instance := range resp.Instances {
		if instance.Status == "UP" {
			entries[i] = instance.HomePageUrl
			log.Println("Found instance for eureka " + instance.HostName)
		}
	}

	if err != nil {
		return nil, err
	}

	return entries, nil
}

func (c *client) Register(appId string, ip string, port int, hostName string) error {

	instanceId := hostName + ":" + appId + ":" + strconv.Itoa(port)
	instance := eureka.NewInstanceInfo(instanceId, appId, ip, port, 30, false)
	instance.VipAddress = appId
	instance.HostName = hostName
	instance.InstanceID = instanceId

	if os.Getenv("escapeAuthFilter.serviceId.1") != "" && os.Getenv("escapeAuthFilter.serviceId.paths.1") != "" {
		instance.Metadata = &eureka.MetaData{
			Map: make(map[string]string),
		}
		instance.Metadata.Map["escapeAuthFilter.serviceId.1"] = os.Getenv("escapeAuthFilter.serviceId.1")
		instance.Metadata.Map["escapeAuthFilter.serviceId.paths.1"] = os.Getenv("escapeAuthFilter.serviceId.paths.1")
	}
	err := c.eurekaClient.RegisterInstance(appId, instance)

	c.logger.Info("Sending requesting to" + instanceId)
	if err != nil {
		c.logger.Error("unable to register with SD", err.Error())
	}
	go c.loop(instance)

	return nil
}

func (c *client) loop(instanceInfo *eureka.InstanceInfo) {
	t := time.NewTicker(heartBeat)
	count := 0
	if os.Getenv("ESCAPE_SD_REGISTER") == "false" {
		for {
			select {

			case <-t.C:
				err := c.eurekaClient.SendHeartbeat(instanceInfo.App, instanceInfo.InstanceID)
				if err != nil {
					count++
					c.logger.Error("unable to send the heart beat", err.Error())
				}
				if count > 5 && err != nil {
					sdError := c.eurekaClient.RegisterInstance(instanceInfo.App, instanceInfo)
					if sdError != nil {
						c.logger.Error("unable to register with SD", sdError.Error())
					} else {
						count = 0
					}
				}
			case <-c.ctx.Done():
				c.logger.Error("Killed the process, unregistering the instance", instanceInfo.InstanceID)
				err := c.eurekaClient.UnregisterInstance(instanceInfo.App, instanceInfo.InstanceID)
				if err != nil {
					c.logger.Error("Error while deregistering", err.Error())
				}
				return
			}
		}

	}
}
