package main

import (
	"context"
	"flag"
	"log"
	"net"
	"os"
	"os/signal"
	"strconv"
	"syscall"

	"go.opentelemetry.io/contrib/instrumentation/github.com/gin-gonic/gin/otelgin"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/krakendio/krakend-ce/v2"
	gologging "github.com/krakendio/krakend-gologging/v2"
	metrics "github.com/krakendio/krakend-metrics/v2/gin"
	"github.com/luraproject/lura/v2/config"
	"github.com/luraproject/lura/v2/logging"
	"github.com/luraproject/lura/v2/proxy"
	router "github.com/luraproject/lura/v2/router/gin"
	server "github.com/luraproject/lura/v2/transport/http/server"
	apm "jocata.com/gateway/krakend/signoz"

	eurekaClient "jocata.com/gateway/krakend/client"
	flexible "jocata.com/gateway/krakend/flexible"
	eurekasubscriber "jocata.com/gateway/krakend/subscriber"
)

func main() {

	envFile := os.Getenv("ENV_PATH")
	var err error
	if envFile == "" {
		err = godotenv.Load("go.env")
	} else {
		err = godotenv.Load(envFile)
	}
	if err != nil {
		log.Fatal("Error While Loading Environment file ", err.Error())
	}
	serviceConfig, configErr := flexible.LoadConfiguration()
	if configErr.Message != "" {
		log.Fatal(configErr.Message)
	}

	port, _ := strconv.Atoi(os.Getenv("PORT"))
	debug, err := strconv.ParseBool(os.Getenv("DEBUG_ENABLE"))
	hostName := os.Getenv("HOST")
	if err != nil {
		debug = false
	}

	ctx, cancel := context.WithCancel(context.Background())

	logger, err := gologging.NewLogger(serviceConfig.ExtraConfig)
	if err != nil {
		log.Fatal("Logger instance was not found in the KrakenD's Extra Config", err.Error())
	}

	serviceConfig.Debug = serviceConfig.Debug || debug

	serviceConfig.Port = port

	krakend.RegisterEncoders()

	if serviceConfig.Plugin != nil {
		logger.Debug("Loading the plugin from " + serviceConfig.Plugin.Folder)
		krakend.LoadPlugins(serviceConfig.Plugin.Folder, serviceConfig.Plugin.Pattern, logger)
	}
	cbf := CustomBackendFactory{ctx: ctx}
	cbf.met = new(krakend.MetricsAndTraces)
	metricCollector := cbf.met.Register(cbf.ctx, serviceConfig, logger)

	if os.Getenv("OTEL_EXPORTER_OTLP_ENDPOINT") != "" && os.Getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT") != "" {
		cleanup := apm.InitTracer()
		defer cleanup(context.Background())
	}

	var otel []gin.HandlerFunc

	r := otelgin.Middleware(os.Getenv("service_name"))
	otel = append(otel, r)

	routerFactory := router.NewFactory(router.Config{
		Middlewares:    otel,
		Engine:         krakend.NewEngine(serviceConfig, router.EngineOptions{Logger: logger}),
		Logger:         logger,
		HandlerFactory: krakend.NewHandlerFactory(logger, metricCollector, nil),
		ProxyFactory:   DecideToRegisterToServiceDiscovery(ctx, serviceConfig, logger, metricCollector),
		RunServer:      router.RunServerFunc(new(krakend.DefaultRunServerFactory).NewRunServer(logger, server.RunServer)),
	})

	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	defer cancel()

	go func() {
		select {
		case sig := <-sigs:
			logger.Info("Signal intercepted:", sig)
			cancel()
		case <-ctx.Done():
		}
	}()

	logger.Info("Starting the server on host", hostName+" on port ", port)

	routerFactory.NewWithContext(ctx).Run(serviceConfig)
}

func DecideToRegisterToServiceDiscovery(ctx context.Context, serviceConfig config.ServiceConfig, logger logging.Logger, metricCollector *metrics.Metrics) (f proxy.Factory) {

	if os.Getenv("ESCAPE_SD_REGISTER") == "false" {
		serviceName := os.Getenv("SERVICE_NAME")
		host, hostErr := os.Hostname()
		if hostErr != nil {
			log.Fatal("Error while getting HostName", hostErr)
		}

		hostName := os.Getenv("HOST")

		eurekaURLPort := os.Getenv("EUREKA_URL_PORT")
		if hostName == "localhost" {
			hostName = host
		}
		flag.Parse()

		machines := []string{eurekaURLPort}

		eurekaClient, err := newClient(ctx, serviceConfig.ExtraConfig, machines, logger)
		if err != nil {
			logger.Error("Error while finding the instance of the Service Discovery : ", err.Error())
		}

		err1 := eurekaClient.Register(serviceName, GetLocalIP(), serviceConfig.Port, hostName)

		if err1 != nil {
			logger.Error("Error while registering the service to the Service Discovery : ", err1.Error())
		}
		return proxy.NewDefaultFactoryWithSubscriber(krakend.NewBackendFactory(logger, metricCollector), logger, eurekasubscriber.SubscriberFactory(ctx, eurekaClient))

	} else {
		// Initialize the proxy factory without returning it
		return krakend.NewProxyFactory(logger, krakend.NewBackendFactory(logger, metricCollector), metricCollector)
	}

}

type CustomBackendFactory struct {
	ctx context.Context
	met krakend.MetricsAndTracesRegister
}

// func (cbf CustomBackendFactory) NewBackendFactory(cfg config.ServiceConfig) (proxy.BackendFactory, error) {
// 	cbf.met = new(krakend.MetricsAndTraces)
// 	metricCollector := cbf.met.Register(cbf.ctx, cfg, cbf.logger)

// 	logger, err := logging.NewLogger("DEBUG", os.Stdout, "KRAKEND")
// 	if err != nil {
// 		return nil, err
// 	}

// 	return krakend.NewBackendFactory(logger, metricCollector), nil
// }

type customProxyFactory struct {
	logger  gologging.Logger
	factory proxy.Factory
}

// New implements the Factory interface
func (cf customProxyFactory) New(cfg *config.EndpointConfig) (p proxy.Proxy, err error) {
	p, err = cf.factory.New(cfg)
	if err == nil {
		p = proxy.NewLoggingMiddleware(cf.logger, cfg.Endpoint)(p)
	}
	return
}

func GetLocalIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return ""
	}
	for _, address := range addrs {
		// check the address type and if it is not a loopback the display it
		if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String()
			}
		}
	}
	return ""
}
func newClient(ctx context.Context, e config.ExtraConfig, machines []string, logger logging.Logger) (eurekaClient.Client, error) {
	return eurekaClient.NewClient(ctx, machines, eurekaClient.ClientOptions{}, logger)
}

var aliases = map[string]string{
	"github_com/devopsfaith/krakend/transport/http/server/handler":  "plugin/http-server",
	"github.com/devopsfaith/krakend/transport/http/client/executor": "plugin/http-client",
	"github.com/devopsfaith/krakend/proxy/plugin":                   "plugin/req-resp-modifier",
	"github.com/devopsfaith/krakend/proxy":                          "proxy",
	"github_com/luraproject/lura/router/gin":                        "router",
	"github.com/devopsfaith/krakend-ratelimit/juju/router":          "qos/ratelimit/router",
	"github.com/devopsfaith/krakend-ratelimit/juju/proxy":           "qos/ratelimit/proxy",
	"github.com/devopsfaith/krakend-httpcache":                      "qos/http-cache",
	"github.com/devopsfaith/krakend-circuitbreaker/gobreaker":       "qos/circuit-breaker",
	"github.com/devopsfaith/krakend-oauth2-clientcredentials":       "auth/client-credentials",
	"github.com/devopsfaith/krakend-jose/validator":                 "auth/validator",
	"github.com/devopsfaith/krakend-jose/signer":                    "auth/signer",
	"github_com/devopsfaith/bloomfilter":                            "auth/revoker",
	"github_com/devopsfaith/krakend-botdetector":                    "security/bot-detector",
	"github_com/devopsfaith/krakend-httpsecure":                     "security/http",
	"github_com/devopsfaith/krakend-cors":                           "security/cors",
	"github.com/devopsfaith/krakend-cel":                            "validation/cel",
	"github.com/devopsfaith/krakend-jsonschema":                     "validation/json-schema",
	"github.com/devopsfaith/krakend-amqp/agent":                     "async/amqp",
	"github.com/devopsfaith/krakend-amqp/consume":                   "backend/amqp/consumer",
	"github.com/devopsfaith/krakend-amqp/produce":                   "backend/amqp/producer",
	"github.com/devopsfaith/krakend-lambda":                         "backend/lambda",
	"github.com/devopsfaith/krakend-pubsub/publisher":               "backend/pubsub/publisher",
	"github.com/devopsfaith/krakend-pubsub/subscriber":              "backend/pubsub/subscriber",
	"github.com/devopsfaith/krakend/transport/http/client/graphql":  "backend/graphql",
	"github.com/devopsfaith/krakend/http":                           "backend/http",
	"github_com/devopsfaith/krakend-gelf":                           "telemetry/gelf",
	"github_com/devopsfaith/krakend-gologging":                      "telemetry/logging",
	"github_com/devopsfaith/krakend-logstash":                       "telemetry/logstash",
	"github_com/devopsfaith/krakend-metrics":                        "telemetry/metrics",
	"github_com/letgoapp/krakend-influx":                            "telemetry/influx",
	"github_com/devopsfaith/krakend-influx":                         "telemetry/influx",
	"github_com/devopsfaith/krakend-opencensus":                     "telemetry/opencensus",
	"github.com/devopsfaith/krakend-lua/router":                     "modifier/lua-endpoint",
	"github.com/devopsfaith/krakend-lua/proxy":                      "modifier/lua-proxy",
	"github.com/devopsfaith/krakend-lua/proxy/backend":              "modifier/lua-backend",
	"github.com/devopsfaith/krakend-martian":                        "modifier/martian",
}
