package flexible

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	viper "github.com/krakendio/krakend-viper/v2"
	"github.com/luraproject/lura/v2/config"
	decrypt "jocata.com/gateway/krakend/encrypt"
)

func LoadConfiguration() (config.ServiceConfig, ConfigError) {
	client := &http.Client{}
	var token string
	var eplist []interface{}
	payLoad := ""
	var configErr ConfigError
	uiBuilderEnabled := os.Getenv("UI_BUILDER_ENABLED")
	if uiBuilderEnabled != "" && uiBuilderEnabled == "true" {

		// authentication
		authenticationURL := os.Getenv("AUTH_HOST_URL") + "/service/sysadmin-token"

		authenticationReq, err := http.NewRequest("GET", authenticationURL, nil)
		if err != nil {
			return config.ServiceConfig{}, ConfigError{Code: "10000", Message: (err.Error())}
		}

		tokenResponse, err := client.Do(authenticationReq)
		if err != nil {
			return config.ServiceConfig{}, ConfigError{Code: "10000", Message: (err.Error())}
		}
		defer tokenResponse.Body.Close()
		body, err := io.ReadAll(tokenResponse.Body)

		if err != nil {
			return config.ServiceConfig{}, ConfigError{Code: "10000", Message: (err.Error())}
		}

		tokenMap := make(map[string]interface{})
		json.Unmarshal(body, &tokenMap)
		token = tokenMap["token"].(string)

		// load endpoints from DB
		endpointsURL := os.Getenv("GENERIC_HOST_URL") + "/endpoint/getAllEndpoints?published=true"
		enpointsReq, err := http.NewRequest("GET", endpointsURL, nil)
		if err != nil {
			return config.ServiceConfig{}, ConfigError{Code: "10000", Message: (err.Error())}
		}
		enpointsReq.Header.Add("Accept", "application/json")
		enpointsReq.Header.Add("Content-Type", "application/json")
		enpointsReq.Header.Add("Authorization", "Bearer "+token)
		endpointResponse, err := client.Do(enpointsReq)
		if err != nil {
			return config.ServiceConfig{}, ConfigError{Code: "10000", Message: (err.Error())}
		}
		defer endpointResponse.Body.Close()
		body1, err := io.ReadAll(endpointResponse.Body)
		if err != nil {
			return config.ServiceConfig{}, ConfigError{Code: "10000", Message: (err.Error())}
		}
		var endpointResponseMap map[string]interface{}
		err = json.Unmarshal(body1, &endpointResponseMap)
		if err != nil {
			return config.ServiceConfig{}, ConfigError{Code: "10000", Message: (err.Error())}
		}

		if endpointResponseMap["endpoints"] != nil {
			eplist = endpointResponseMap["endpoints"].([]interface{})
		} else if endpointResponse.StatusCode != 200 {
			return config.ServiceConfig{}, ConfigError{Code: "10000", Message: string(body1)}
		}
	}

	payloadConfig := string(baseConfig)
	configFile := os.Getenv("CONFIG_FILE")
	configFilesPath := os.Getenv("CONFIG_FILES_PATH")
	pluginPath := os.Getenv("PLUGIN_PATH")

	if uiBuilderEnabled != "" && uiBuilderEnabled == "true" {
		payLoad, configErr = GetFilesDataBuilder(payLoad, token, client, eplist)
	} else {
		payLoad, configErr = GetFilesData(configFilesPath, payLoad)
	}
	if configErr.Message != "" {
		return config.ServiceConfig{}, configErr
	}

	payloadConfig = strings.ReplaceAll(payloadConfig, "$PLUGIN", pluginPath)
	payloadConfig = strings.ReplaceAll(payloadConfig, "$ENDPOINTS", payLoad)

	absPath, err := filepath.Abs(configFile)
	if err != nil {
		log.Fatalf("Error getting absolute path: %v", err)
	}

	f, err := os.Create(absPath)

	if err != nil {
		log.Fatal(err)
	}

	_, err2 := f.WriteString(payloadConfig)

	if err2 != nil {
		return config.ServiceConfig{}, ConfigError{Code: "10000", Message: err2.Error()}
	}

	f.Close()
	var parser config.Parser = viper.New()
	serviceConfig, err := parser.Parse(configFile)

	if os.Getenv("HTTPS_ENABLED") == "true" {
		serviceConfig.TLS = &config.TLS{
			PrivateKey: os.Getenv("HTTPS_PRIVATE_KEY_PATH"),
			PublicKey:  os.Getenv("HTTPS_PUBLIC_KEY_PATH"),
		}
	}

	if err != nil {
		log.Fatal("Unable to parse the Krakend Configuration file ", configFile, err.Error())
	}

	os.Remove(absPath)
	setRouterProperties(serviceConfig)
	return serviceConfig, ConfigError{}
}

func setRouterProperties(serviceConfig config.ServiceConfig) {
	router := serviceConfig.ExtraConfig["github_com/luraproject/lura/router/gin"].(map[string]interface{})
	if os.Getenv("CONSOLE_ENABLE") == "true" {
		router["disable_access_log"] = true
		serviceConfig.ExtraConfig["github_com/luraproject/lura/router/gin"] = router
	}
}

func GetFilesData(parentPath string, finalPayload string) (string, ConfigError) {
	propertiesPath := os.Getenv("HOST_PROPERTIES")
	CONFIG_ENCRYPT_ENABLED := os.Getenv("CONFIG_ENCRYPT_ENABLED")
	propertiesData, configErr := readHostConfigurationFiles(propertiesPath)
	if configErr.Message != "" {
		return "", configErr
	}

	files, err := os.ReadDir(parentPath)
	if err != nil {
		return "", ConfigError{Code: "10000", Message: (err.Error())}
	}
	path, _ := filepath.Abs(parentPath)

	for _, file := range files {
		if !file.IsDir() {
			var projectHostPropertiesData map[string]interface{}

			fileContent, err := os.ReadFile(filepath.Join(path, file.Name()))
			if err != nil {
				return "", ConfigError{Code: "1000", Message: fmt.Sprintf(err.Error(), "-- %s", filepath.Join(path, file.Name()))}
			}
			payloadData := string(fileContent)

			if CONFIG_ENCRYPT_ENABLED == "true" {
				payloadData, err = decrypt.Decrypt(payloadData)
				if err != nil {
					return "", ConfigError{Code: "1000", Message: fmt.Sprintf(err.Error(), "-- %s", filepath.Join(path, file.Name()))}
				}
			}

			isJson, projectId, err := checkIsJsonAndProject(payloadData)
			if !isJson || validateConfig(payloadData) || err != nil {
				return "", ConfigError{Code: "1000", Message: fmt.Sprintf("given endpoint is a not valid json %v; %v", filepath.Join(path, file.Name()), err)}
			}

			if propertiesData[projectId] == nil {
				return "", ConfigError{Code: "1000", Message: fmt.Sprintf("No host file is present for this endpoint %s ", filepath.Join(path, file.Name()))}
			}

			projectHostPropertiesData = propertiesData[projectId].(map[string]interface{})

			payload, configErr := replaceHost(payloadData, projectHostPropertiesData)

			if configErr.Message != "" {
				configErr.Message = `The endpoint is : '` + filepath.Join(path, file.Name()) + `' is invalid. ` + configErr.Message
				return "", configErr
			} else if payload == "" && configErr.Message == "" {
				return "", ConfigError{Code: "1000", Message: fmt.Sprintf("No host variables for this end point %s : %s", filepath.Join(path, file.Name()), "Example:Replace ${host}$  instead of host static value ")}
			}

			payload = replaceHostproperties(payload)

			if finalPayload != "" {
				finalPayload = finalPayload + ", " + payload
			} else {
				finalPayload = payload
			}

		} else {
			path = filepath.Join(path, file.Name())
			payload, configErr := GetFilesData(path, "")
			if configErr.Message != "" {
				return "", configErr
			}
			if finalPayload != "" {
				if finalPayload[len(finalPayload)-1:] == "," {
					finalPayload = finalPayload + payload
				} else {
					finalPayload = finalPayload + "," + payload
				}
			} else {
				finalPayload = payload
			}
			path = parentPath
		}
	}
	return finalPayload, ConfigError{}
}

func GetFilesDataBuilder(finalPayload string, token string, client *http.Client, epList []interface{}) (string, ConfigError) {

	propertiesPath := os.Getenv("HOST_PROPERTIES")
	propertiesData, configErr := readHostConfigurationFiles(propertiesPath)
	if configErr.Message != "" {
		return "", configErr
	}

	for _, endpoint := range epList {
		var projectHostPropertiesData map[string]interface{}
		epMap := endpoint.(map[string]interface{})
		epConfig := epMap["endpointConfig"].(map[string]interface{})
		epName := epMap["endpointName"].(string)

		jsonData, err := json.Marshal(epConfig)
		if err != nil {
			fmt.Println(err)
		}

		payloadData := string(jsonData)
		isJson, projectId, err := checkIsJsonAndProject(payloadData)
		if !isJson || validateConfig(payloadData) || err != nil {
			return "", ConfigError{Code: "1000", Message: fmt.Sprintf("given endpoint is a not valid json %v; %v", epName, err)}
		}

		if propertiesData[projectId] == nil {
			return "", ConfigError{Code: "1000", Message: fmt.Sprintf("no host file is present for this endpoint %v ", epName)}
		}

		projectHostPropertiesData = propertiesData[projectId].(map[string]interface{})

		payload, configErr := replaceHost(payloadData, projectHostPropertiesData)
		if configErr.Message != "" {
			configErr.Message = `The endpoint is : '` + epName + ` is invalid. ` + configErr.Message
			return "", configErr
		} else if payload == "" && configErr.Message == "" {
			errMessage := "No host variables for this end point : " + epName + ` Example:${host}$  need place instead of static value : 'host' `
			return "", ConfigError{Code: "1000", Message: errMessage}
		}

		payload = replaceHostproperties(payload)

		if finalPayload != "" {
			finalPayload = finalPayload + ", " + payload
		} else {
			finalPayload = payload
		}
	}
	return finalPayload, ConfigError{}
}

func replaceHostproperties(payloadData string) (finalPayload string) {
	var payload = make(map[string]interface{})
	var hostProperties = make(map[string]interface{})
	var hostConnectionDetails = make(map[string]interface{})

	json.Unmarshal([]byte(payloadData), &payload)

	endpoint := payload["endpoint"]
	timeout := payload["timeout"]
	projectId := payload["projectId"]

	backend := payload["backend"].([]interface{})
	backend_Object := backend[0].(map[string]interface{})

	host := backend_Object["host"].([]interface{})[0]
	urlPattern := backend_Object["url_pattern"]

	extra_config := backend_Object["extra_config"].(map[string]interface{})
	executor := extra_config["github.com/devopsfaith/krakend/transport/http/client/executor"].(map[string]interface{})
	plugin := executor["jocata_transform_plugin"].(map[string]interface{})

	if plugin["hostProperties"] != nil {
		hostProperties = plugin["hostProperties"].(map[string]interface{})
	}

	if hostProperties["hostConnectionDetails"] != nil {
		hostConnectionDetails = hostProperties["hostConnectionDetails"].(map[string]interface{})
	}

	hostConnectionDetails["host"] = host
	hostConnectionDetails["urlPattern"] = urlPattern

	hostProperties["endpoint"] = endpoint
	hostProperties["timeout"] = timeout
	hostProperties["projectId"] = projectId
	hostProperties["hostConnectionDetails"] = hostConnectionDetails

	plugin["hostProperties"] = hostProperties
	executor["jocata_transform_plugin"] = plugin
	extra_config["github.com/devopsfaith/krakend/transport/http/client/executor"] = executor
	backend_Object["extra_config"] = extra_config
	backend[0] = backend_Object
	payload["backend"] = backend

	bytes, _ := json.Marshal(payload)
	finalPayload = string(bytes)
	return
}

func checkIsJsonAndProject(s string) (bool, float64, error) {
	var js map[string]interface{}
	isJson := json.Unmarshal([]byte(s), &js) == nil
	if js["projectId"] != nil {
		projectId := js["projectId"].(float64)
		return isJson, projectId, nil
	} else {
		errorMessage := fmt.Sprintf("project Id is not present in the endpoint %v", js["endpointName"])
		return false, 0, errors.New(errorMessage)
	}
}

func validateConfig(endPointString string) bool {

	if strings.Contains(endPointString, `"plugin"`) || strings.Contains(endPointString, `"port"`) || strings.Contains(endPointString, `"endpoints"`) {
		return true
	} else if !strings.Contains(endPointString, `"endpoint"`) || !strings.Contains(endPointString, `"backend"`) || !strings.Contains(endPointString, `"url_pattern"`) {
		return true
	}

	return false
}

func getHostKeys(endPointString string) (string, string, ConfigError) {

	startIndex := strings.LastIndex(endPointString, "${")
	endIndex := strings.LastIndex(endPointString, "}$")

	if startIndex < 0 || endIndex < 0 {
		return "", "", ConfigError{}
	}

	if startIndex >= endIndex {
		return "", "", ConfigError{Message: `The placeholder '${' cannot be used for anything other than host and environment properties.`}
	}

	hostPlaceHolder := endPointString[startIndex : endIndex+2]
	hostValue := endPointString[startIndex+2 : endIndex]

	return hostPlaceHolder, hostValue, ConfigError{}
}

func readHostConfigurationFiles(directoryPath string) (map[float64]interface{}, ConfigError) {
	files, err := os.ReadDir(directoryPath)
	if err != nil {
		return nil, ConfigError{Code: "10001", Message: fmt.Sprintf("Unable to read directory: %s", directoryPath)}
	}

	var result []map[string]interface{}

	for _, file := range files {
		if file.IsDir() {
			continue
		}

		filePath := filepath.Join(directoryPath, file.Name())

		err := func() error {
			jsonFile, err := os.Open(filePath)
			if err != nil {
				return fmt.Errorf("unable to open file: %s", filePath)
			}
			defer jsonFile.Close()

			byteValue, err := io.ReadAll(jsonFile)
			if err != nil {
				return fmt.Errorf("error reading file: %s", filePath)
			}

			var fileData map[string]interface{}
			if err := json.Unmarshal(byteValue, &fileData); err != nil {
				return fmt.Errorf("error unmarshalling JSON from file: %s", filePath)
			}
			result = append(result, fileData)
			return nil
		}()

		if err != nil {
			return nil, ConfigError{Code: "10002", Message: err.Error()}
		}
	}

	finalResult := make(map[float64]interface{})
	for _, hostfileData := range result {
		if projectID, ok := hostfileData["projectId"].(float64); ok {
			finalResult[projectID] = hostfileData
		} else {
			return nil, ConfigError{Code: "10003", Message: "Missing projectId in one or more host files"}
		}
	}

	return finalResult, ConfigError{}
}

func getHostValue(configData map[string]interface{}, profileValue string, hostValue string) interface{} {

	hostData := configData[hostValue]
	if hostData != nil {
		hostData := hostData.(map[string]interface{})
		if profileValues := hostData[profileValue]; profileValues != nil {
			profileValues := profileValues.(map[string]interface{})
			return profileValues["value"]
		}
	}
	return nil
}

func replaceHost(payload string, propertiesData map[string]interface{}) (string, ConfigError) {

	hostPlaceHolder, hostValue, confError := getHostKeys(payload)
	if hostPlaceHolder == "" || hostValue == "" {
		return "", confError
	}

	profile := os.Getenv("PROFILE")

	hostProfileValue := getHostValue(propertiesData, profile, hostValue)

	if hostProfileValue == nil {
		res, _ := json.Marshal(propertiesData)
		return "", ConfigError{Code: "10000", Message: fmt.Sprintf("Given host value not present in host properties hostname %s  and profile %s and propertiesMap %v", hostValue, profile, string(res))}
	}
	payload = strings.ReplaceAll(payload, hostPlaceHolder, hostProfileValue.(string))
	holder := strings.Contains(payload, "${")
	if holder {
		payload, _ = replaceHost(payload, propertiesData)
	}
	return payload, ConfigError{}
}

type ConfigError struct {
	Code    string
	Message string
}

const baseConfig = `{
  "version": 3,
  "name": "Krakend-service",
  "port": 7075,
  "cache_ttl": 3600,
  "timeout": "3s",
  "plugin": {
    "pattern": ".so",
    "folder": "$PLUGIN"
  },
  "extra_config": {
    "github_com/devopsfaith/krakend-gologging": {
      "level": "DEBUG",
      "prefix": "[KRAKEND]",
      "syslog": false,
      "stdout": true
    },
    "github_com/luraproject/lura/router/gin": {
      "disable_access_log": false
    }
  },
  "endpoints": [$ENDPOINTS]
}
`
